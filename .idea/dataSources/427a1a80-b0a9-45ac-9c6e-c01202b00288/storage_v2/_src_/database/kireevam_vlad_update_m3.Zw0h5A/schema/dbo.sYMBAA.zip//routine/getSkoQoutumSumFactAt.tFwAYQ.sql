
CREATE FUNCTION dbo.getSkoQoutumSumFactAt(
 @quotumId as INT
) RETURNS FLOAT
AS
BEGIN
 -- "Фактическая стоимость после поездки, руб." в "Контракт с поставщиком ТСР"	
 DECLARE @result float
 SELECT @result = ISNULL(SUM(WM_TOURS.A_SUM_FACT),0)
 FROM WM_TOURS
 WHERE WM_TOURS.A_QUOTUM = @quotumId
 AND (WM_TOURS.A_STATUS IS NULL OR WM_TOURS.A_STATUS = (SELECT ESRN_SERV_STATUS.A_ID FROM ESRN_SERV_STATUS WHERE ESRN_SERV_STATUS.A_STATUSCODE = 'act'))
 AND WM_TOURS.A_GRANT IS NOT NULL
  
 RETURN @result
END;
go

