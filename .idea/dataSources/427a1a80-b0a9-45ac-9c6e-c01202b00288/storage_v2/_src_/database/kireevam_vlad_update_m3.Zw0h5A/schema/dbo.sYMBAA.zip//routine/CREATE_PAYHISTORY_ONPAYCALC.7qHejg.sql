CREATE PROCEDURE [dbo].[CREATE_PAYHISTORY_ONPAYCALC]
	(@file VARCHAR(255), -- Название файла, куда произошла выгрузка данных
	@curAccount INT, -- Пользователь, который запустил выгрузку
	@tableName VARCHAR(255), -- Название временной таблицы, в которой находятся идентификаторы начислений
	@attrName1 VARCHAR(255), -- Название поля временной таблицы, в которой находятся идентификаторы начислений
	@attrName2 VARCHAR(255) -- Название поля временной таблицы, в которой находятся идентификаторы выплат
	)
AS
BEGIN
	DECLARE @statusPrVpOrg INT, @status INT, @sql VARCHAR(8000)
	SET @statusPrVpOrg = (SELECT TOP 1 ssp.A_ID FROM SPR_STATUS_PAYMENT ssp WHERE ssp.A_CODE = 4)
	SET @status = (SELECT TOP 1 A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act')

	/* создаем историю выплат */
	SET @sql = 'INSERT INTO PAYHISTORY
	(
		A_NUM,
		A_DATE,
		A_STATUS_PAID,
		A_PAYMENT,
		A_PAIDAMOUNT,
		A_CROWNER,
		A_CREATEDATE,
		A_STATUS,
		GUID,
		TS,
		A_DOCMONTH,
		A_DOCYEAR
	)
	SELECT '
		+ ISNULL(char(39) + @file + char(39),'NULL') + ',
		GETDATE(),'
		+ ISNULL(cast(@statusPrVpOrg AS varchar),'NULL') + ',
		wp2.A_PAYMENT,
		wp2.OUID,'
		+ ISNULL(cast(@curAccount AS varchar),'NULL') + ',
		GETDATE(),'
		+ ISNULL(cast(@status AS varchar),'NULL') + ',
		NEWID(),
		GETDATE(),
		wpc.A_MONTH,
		wpc.A_YEAR
	FROM ' + @tableName + '
		INNER JOIN WM_PAY_CALC wpc ON ' + @tableName + '.' + @attrName1 + ' = wpc.OUID
		INNER JOIN WM_PAIDAMOUNTS wp2 ON wpc.OUID = wp2.A_PAYCALC
	WHERE ' + @tableName + '.' + @attrName2 + ' IS NULL'
	EXEC(@sql)
END
go

