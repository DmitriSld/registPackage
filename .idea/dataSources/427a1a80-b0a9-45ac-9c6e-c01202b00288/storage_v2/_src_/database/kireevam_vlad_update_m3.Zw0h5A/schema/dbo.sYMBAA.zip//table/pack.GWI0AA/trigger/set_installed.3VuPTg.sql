CREATE TRIGGER set_installed ON pack
  AFTER UPDATE
  AS
UPDATE p
  SET p.installed = ccu.userid
--SELECT p.[user],ccu.[name] 
  FROM pack p 
  JOIN INSERTED i ON p.ouid = i.ouid
  JOIN conv_corr_users ccu ON p.installed2 = ccu.[name]
  WHERE p.installed IS null
go

