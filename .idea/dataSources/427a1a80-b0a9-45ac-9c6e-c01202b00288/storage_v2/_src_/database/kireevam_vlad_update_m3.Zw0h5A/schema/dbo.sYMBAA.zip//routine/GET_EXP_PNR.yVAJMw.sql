
-- Сравнивает строки на расхождение в указанной дистанции (без учета регистра)
-- возвращет количество символов, на которые расходятся строки
CREATE FUNCTION GET_EXP_PNR
(
@ipd varchar(255)
)
RETURNS varchar(255)
AS
BEGIN
  DECLARE @codeR varchar(3)
  DECLARE @codeOSZN varchar(3)
  SELECT @codeOSZN = ESRN_OSZN_DEP.A_OSZNCODE,
  @codeR = SPR_SUBJFED.A_CODE
  FROM REGISTER_CONFIG
  LEFT JOIN ESRN_OSZN_DEP ON REGISTER_CONFIG.A_REG_ORGNAME = ESRN_OSZN_DEP.OUID
  LEFT JOIN SPR_ORG_BASE ON SPR_ORG_BASE.OUID = ESRN_OSZN_DEP.OUID
  LEFT JOIN SPR_SUBJFED ON SPR_ORG_BASE.A_SUBFED = SPR_SUBJFED.OUID
  RETURN @codeR + @codeOSZN + STUFF(@ipd, 1 , 7, '')
END



go

