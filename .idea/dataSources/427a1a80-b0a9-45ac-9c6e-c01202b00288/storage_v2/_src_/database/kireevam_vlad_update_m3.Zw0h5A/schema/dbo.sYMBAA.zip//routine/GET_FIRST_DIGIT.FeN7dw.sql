CREATE FUNCTION [dbo].[GET_FIRST_DIGIT] 
(
	@text VARCHAR(512)
)
RETURNS INT
AS
BEGIN
	-- Declare the return variable here
	DECLARE @RESULT AS INT

	-- Add the T-SQL statements to compute the return value here
	SELECT @RESULT = (CASE WHEN PATINDEX('%[^0-9]%',@text) > 0 THEN 
		CASE WHEN PATINDEX('%[0-9]%',@text) < PATINDEX('%[^0-9]%',@text) THEN
			CAST(SUBSTRING(@text,PATINDEX('%[0-9]%',@text),PATINDEX('%[^0-9]%',@text) - 1) AS INT)
		ELSE 
			CAST(SUBSTRING(@text,PATINDEX('%[0-9]%',@text),
			CASE WHEN PATINDEX('%[^0-9]%',SUBSTRING(@text,PATINDEX('%[0-9]%',@text),LEN(@text))) > 0 THEN 
				PATINDEX('%[^0-9]%',SUBSTRING(@text,PATINDEX('%[0-9]%',@text),LEN(@text))) - 1
			ELSE
				LEN(@text) END ) AS INT) END
	 ELSE CAST(@text AS INT) END) 
	-- Return the result of the function
	RETURN @RESULT
END
 
--   sx.datastore.db.SXDb.execute:410 
--   sx.common.replication.DoReplication.installPatch:2883 
--   sx.common.replication.SXPatchInstallParams.installPatch:93 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:99 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:140 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:710
go

