CREATE TRIGGER   dbo.CREATE_DOP_SPES 
   ON  dbo.DOP_SPIS_ZAJ_FIN
   AFTER  INSERT ,UPDATE
AS 
BEGIN
declare @ouid int
declare cur cursor local fast_forward
for
SELECT DISTINCT  A_OUID
  FROM inserted

open cur

FETCH NEXT FROM cur INTO @ouid
WHILE @@FETCH_STATUS=0
BEGIN
execute UPDATE_DOP_SPIS @ouid

   FETCH NEXT FROM cur INTO @ouid
END

close cur
DEALLOCATE cur
END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.common.replication.DoReplication.installPatchFileStep:3047 
--   sx.common.replication.DoReplication.installPatch:2612 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1
go

