CREATE FUNCTION dbo.DIFF_STRING
(
@string1 varchar(255),
@string2 varchar(255),
@maxdist tinyint
)
RETURNS int
AS
BEGIN
DECLARE @RESULT INT
	IF @string1 IS NULL AND @string2 IS NULL 
		SET @RESULT = 0
	ELSE
		IF @string1 = @string2 
			SET @RESULT = 0
		ELSE
			SET @RESULT = 1000
RETURN @RESULT
/*
  В данный момент функционал корректировки ошибок в строчках отключен	

  IF @string1 IS NULL OR @string2 IS NULL BEGIN
    RETURN @maxdist
  END

  DECLARE @i tinyint, @j tinyint -- индексы
  DECLARE @lenght1 tinyint, @lenght2 tinyint -- длины первой и второй строк
  DECLARE @finaldist tinyint -- на сколько символов расходятся строки

  DECLARE @d varchar(255), @ds1 varchar(255), @ds2 varchar(255)
  DECLARE @dist tinyint, @dist1 tinyint, @dist2 tinyint, @dist3 tinyint, @dist4 tinyint
  DECLARE @char2 char(1), @char2p char(1)

  SELECT @lenght1 = len(@string1) -- получаем длину первой строки
  SELECT @lenght2 = len(@string2) -- получаем длину второй строки
  SELECT @d = '' --  массив символов первой строки

  -- заполняем произвольно массив 
  SELECT @i = 1
  WHILE @i <= @lenght1
  BEGIN
    SELECT @d = @d + char(@i)
    SELECT @i = @i + 1
  END

  SELECT @char2p = '' --  j-1 -вый символ второй строки
  -- последовательно идем по символам второй строки
  SELECT @j = 1
  WHILE @j <= @lenght2 BEGIN
    SELECT @char2 = substring(@string2, @j, 1) -- j-тый символ второй строки

    SELECT @ds1 = NULL -- массив погрешностей при проходе первой строки
    
    -- последовательно идем по массиву символов первой строки
    SELECT @i = 1 
    WHILE @i <= @lenght1 BEGIN
      -- получаем погрешность, полученную сравнивая i-1-тый символ и j-1
      IF @i = 1 BEGIN
        SELECT @dist1 = @j - 1
      END ELSE BEGIN
        SELECT @dist1 = ascii(substring(@d,@i-1,1))
      END 
       
      -- если j-тый символ второй строки не совпадает с
      -- i-тым символом первой строки, то увеличиваем погрешность на 1  
      IF @char2 <> substring(@string1,@i,1) BEGIN
        SELECT @dist1 = @dist1 + 1 
      END 
      
      -- получаем погрешность, полученную сравнивая i-тый символ и j-1
      SELECT @dist2 = ascii(substring(@d,@i,1))+1   

      -- получаем погрешность, полученную для i-1 символа + 1
      IF @i = 1 BEGIN
        SELECT @dist3 = @j + 1
      END ELSE BEGIN
        SELECT @dist3 = ascii(substring(@ds1,@i-1,1)) + 1
      END
      
      -- получаем погрешность, полученную для i-2 символа + 1
      SELECT @dist4 = @dist1
      IF @j > 1 AND @i > 1 BEGIN
        IF @char2p = substring(@string1,@i,1) AND @char2 = substring(@string1,@i-1,1) BEGIN
          IF @i = 2 BEGIN
            SELECT @dist4 = @j - 2 + 1
          END ELSE BEGIN
            SELECT @dist4 = ascii(substring(@ds2,@i-2,1)) + 1
          END
        END
      END

      -- вычислеем погрешность текущего шага
      SELECT @dist = @dist1
 
      IF @dist2 < @dist BEGIN
        SELECT @dist = @dist2
      END
     
      IF @dist3 < @dist BEGIN 
        SELECT @dist = @dist3
      END

      IF @dist4 < @dist BEGIN 
        SELECT @dist = @dist4
      END

      -- добавляем в массив расхождений расхождение на текущем шаге итерации
      IF @i > 1 BEGIN
        SELECT @ds1 = @ds1 + char(@dist) 
      END ELSE BEGIN
        SELECT @ds1 = char(@dist)
      END
     
      SELECT @i = @i + 1
    END

    SELECT @char2p = @char2 -- сохраняем как предыдущий символ второй строки
    SELECT @ds2 = @d -- на дальшейшем шаге используем погрешности при проверки предпредыдущего символа
    SELECT @d = @ds1 -- на дальшейшем шаге используем погрешности при проверки предыдущего символа
    SELECT @j = @j + 1
  END

  -- вычисляем различие двух строк, как последную погрешность в массиве
  SELECT @finaldist = ascii(substring(@d,@lenght1,1))
  IF @finaldist > @maxdist + 1 BEGIN
    SELECT @finaldist = @maxdist + 1
  END
  RETURN isnull(@finaldist,@maxdist)
*/
END

go

