CREATE FUNCTION [dbo].[GET_SUMM_PAIDAMOUNTS_CHILDREN]
(
@year int,
@month int,
@finValue int,
@codeMsp1 varchar(255),
@codeMsp2 varchar(255),
@countChild int,
@codeStatusPrivilege varchar(255),
@codeStatusPrivilege2 varchar(255)
)
RETURNS float
AS
BEGIN
  DECLARE @sum2 float
SET @sum2 =0;
declare @statusCode int 
select @statusCode=a_id from ESRN_SERV_STATUS where a_statuscode='act'

SELECT @sum2=isnull(sum(isnull(AMOUNT,0)),0) FROM (
select WM_PAY_CALC.AMOUNT from WM_PAIDAMOUNTS 
inner join wm_personal_card on(wm_personal_card.ouid=WM_PAIDAMOUNTS.personouid)
inner join SPR_STATUS_PAYMENT 
on(WM_PAIDAMOUNTS.A_STATUSPRIVELEGE=SPR_STATUS_PAYMENT.A_ID and (SPR_STATUS_PAYMENT.a_code=@codeStatusPrivilege or SPR_STATUS_PAYMENT.a_code=@codeStatusPrivilege2)
/*присвоение месяца и года*/ 
)
inner join PAYHISTORY 
ON PAYHISTORY.A_PAIDAMOUNT = WM_PAIDAMOUNTS.OUID AND PAYHISTORY.A_STATUS_PAID=SPR_STATUS_PAYMENT.A_ID and (PAYHISTORY.A_DOCMONTH= @month and PAYHISTORY.A_DOCYEAR = @year)
inner join WM_PAY_CALC on(WM_PAIDAMOUNTS.A_PAYCALC=WM_PAY_CALC.ouid AND WM_PAY_CALC.A_RESIDUEPAY =0
/*равенство фин величины*/
)
inner join ESRN_SERV_SERV on(WM_PAY_CALC.a_msp=ESRN_SERV_SERV.ouid)
inner join SPR_NPD_MSP_CAT on(ESRN_SERV_SERV.a_serv=SPR_NPD_MSP_CAT.a_id and ((SPR_NPD_MSP_CAT.A_CODE=@codeMsp1 and @codeMsp1 is not null) or (SPR_NPD_MSP_CAT.A_CODE=@codeMsp2 and @codeMsp2 is not null)))
inner join tmpTableKollChildr on(tmpTableKollChildr.ouidPAIDAMOUNTS=WM_PAIDAMOUNTS.ouid and ((tmpTableKollChildr.kolChildren=2 and @countChild=2)or(tmpTableKollChildr.kolChildren=1 and @countChild=1)))
where (WM_PAIDAMOUNTS.a_status=@statusCode or WM_PAIDAMOUNTS.a_status is null)
and (ESRN_SERV_SERV.a_status=@statusCode or ESRN_SERV_SERV.a_status is null)
and (SPR_NPD_MSP_CAT.a_status=@statusCode or SPR_NPD_MSP_CAT.a_status is null)
and (WM_PAY_CALC.a_status=@statusCode or WM_PAY_CALC.a_status is null)
and (PAYHISTORY.a_status=@statusCode or PAYHISTORY.a_status is null)

and ESRN_SERV_SERV.A_CHILD in(
select 
ESRN_SERV_SERV.A_CHILD
from WM_PAIDAMOUNTS 
inner join wm_personal_card on(wm_personal_card.ouid=WM_PAIDAMOUNTS.personouid)
inner join SPR_STATUS_PAYMENT 
on(WM_PAIDAMOUNTS.A_STATUSPRIVELEGE=SPR_STATUS_PAYMENT.A_ID and  (SPR_STATUS_PAYMENT.a_code='10' or((@codeStatusPrivilege='3' or @codeStatusPrivilege2='3')and SPR_STATUS_PAYMENT.a_code='3'))
)
inner join PAYHISTORY 
ON PAYHISTORY.A_PAIDAMOUNT = WM_PAIDAMOUNTS.OUID AND PAYHISTORY.A_STATUS_PAID=SPR_STATUS_PAYMENT.A_ID and (PAYHISTORY.A_DOCMONTH= @month and PAYHISTORY.A_DOCYEAR = @year)
inner join WM_PAY_CALC on(WM_PAIDAMOUNTS.A_PAYCALC=WM_PAY_CALC.ouid 
)
inner join ESRN_SERV_SERV on(WM_PAY_CALC.a_msp=ESRN_SERV_SERV.ouid)
inner join SPR_NPD_MSP_CAT on(ESRN_SERV_SERV.a_serv=SPR_NPD_MSP_CAT.a_id and SPR_NPD_MSP_CAT.A_CODE in ('childVacation1_5noFSS','childVacation1_5Rel'))
and (SPR_NPD_MSP_CAT.a_status=@statusCode or SPR_NPD_MSP_CAT.a_status is null)
and (WM_PAY_CALC.a_status=@statusCode or WM_PAY_CALC.a_status is null)
and (wm_personal_card.a_status=@statusCode or wm_personal_card.a_status is null)
and (PAYHISTORY.a_status=@statusCode or PAYHISTORY.a_status is null)
)
GROUP BY WM_PAY_CALC.ouid,WM_PAY_CALC.AMOUNT
)tmp

select @sum2=@sum2+isnull(sum(isnull(AMOUNT,0)),0) FROM (
SELECT WM_PAIDAMOUNTS.AMOUNT
 from WM_PAIDAMOUNTS 
inner join wm_personal_card on(wm_personal_card.ouid=WM_PAIDAMOUNTS.personouid)
inner join SPR_STATUS_PAYMENT 
on(WM_PAIDAMOUNTS.A_STATUSPRIVELEGE=SPR_STATUS_PAYMENT.A_ID and (SPR_STATUS_PAYMENT.a_code=@codeStatusPrivilege or SPR_STATUS_PAYMENT.a_code=@codeStatusPrivilege2)
/*присвоение месяца и года*/ 
)
inner join PAYHISTORY 
ON PAYHISTORY.A_PAIDAMOUNT = WM_PAIDAMOUNTS.OUID AND PAYHISTORY.A_STATUS_PAID=SPR_STATUS_PAYMENT.A_ID and (PAYHISTORY.A_DOCMONTH= @month and PAYHISTORY.A_DOCYEAR = @year)
inner join WM_PAY_CALC on(WM_PAIDAMOUNTS.A_PAYCALC=WM_PAY_CALC.ouid AND WM_PAY_CALC.A_RESIDUEPAY <>0
/*равенство фин величины*/
)
inner join ESRN_SERV_SERV on(WM_PAY_CALC.a_msp=ESRN_SERV_SERV.ouid)
inner join SPR_NPD_MSP_CAT on(ESRN_SERV_SERV.a_serv=SPR_NPD_MSP_CAT.a_id and ((SPR_NPD_MSP_CAT.A_CODE=@codeMsp1 and @codeMsp1 is not null) or (SPR_NPD_MSP_CAT.A_CODE=@codeMsp2 and @codeMsp2 is not null)))
inner join tmpTableKollChildr on(tmpTableKollChildr.ouidPAIDAMOUNTS=WM_PAIDAMOUNTS.ouid and ((tmpTableKollChildr.kolChildren=2 and @countChild=2)or(tmpTableKollChildr.kolChildren=1 and @countChild=1)))
where (WM_PAIDAMOUNTS.a_status=@statusCode or WM_PAIDAMOUNTS.a_status is null)
and (ESRN_SERV_SERV.a_status=@statusCode or ESRN_SERV_SERV.a_status is null)
and (SPR_NPD_MSP_CAT.a_status=@statusCode or SPR_NPD_MSP_CAT.a_status is null)
and (WM_PAY_CALC.a_status=@statusCode or WM_PAY_CALC.a_status is null)
and (PAYHISTORY.a_status=@statusCode or PAYHISTORY.a_status is null)

and ESRN_SERV_SERV.A_CHILD in(
select 
ESRN_SERV_SERV.A_CHILD
from WM_PAIDAMOUNTS 
inner join wm_personal_card on(wm_personal_card.ouid=WM_PAIDAMOUNTS.personouid)
inner join SPR_STATUS_PAYMENT 
on(WM_PAIDAMOUNTS.A_STATUSPRIVELEGE=SPR_STATUS_PAYMENT.A_ID and  (SPR_STATUS_PAYMENT.a_code='10' or((@codeStatusPrivilege='3' or @codeStatusPrivilege2='3')and SPR_STATUS_PAYMENT.a_code='3'))
)
inner join PAYHISTORY 
ON PAYHISTORY.A_PAIDAMOUNT = WM_PAIDAMOUNTS.OUID AND PAYHISTORY.A_STATUS_PAID=SPR_STATUS_PAYMENT.A_ID and (PAYHISTORY.A_DOCMONTH= @month and PAYHISTORY.A_DOCYEAR = @year)
inner join WM_PAY_CALC on(WM_PAIDAMOUNTS.A_PAYCALC=WM_PAY_CALC.ouid 
)
inner join ESRN_SERV_SERV on(WM_PAY_CALC.a_msp=ESRN_SERV_SERV.ouid)
inner join SPR_NPD_MSP_CAT on(ESRN_SERV_SERV.a_serv=SPR_NPD_MSP_CAT.a_id and SPR_NPD_MSP_CAT.A_CODE in ('childVacation1_5noFSS','childVacation1_5Rel'))
and (SPR_NPD_MSP_CAT.a_status=@statusCode or SPR_NPD_MSP_CAT.a_status is null)
and (WM_PAY_CALC.a_status=@statusCode or WM_PAY_CALC.a_status is null)
and (wm_personal_card.a_status=@statusCode or wm_personal_card.a_status is null)
and (PAYHISTORY.a_status=@statusCode or PAYHISTORY.a_status is null)
)
GROUP BY WM_PAIDAMOUNTS.ouid,WM_PAIDAMOUNTS.AMOUNT
) tmp
if @sum2 is null
begin 
  RETURN 0
end
 RETURN @sum2
END
 
--   sx.datastore.db.SXDb.execute:410 
--   sx.common.replication.DoReplication.installPatch:3136 
--   sx.common.replication.SXPatchInstallParams.installPatch:93 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:88 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:140 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:710
 
--   sx.datastore.db.SXDb.execute:410 
--   sx.common.replication.DoReplication.installPatch:3136 
--   sx.common.replication.SXPatchInstallParams.installPatch:93 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:88 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:140 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:710
go

