CREATE FUNCTION dbo.getPCActSign(
 @pcId as INT
) RETURNS datetime
AS
BEGIN
 DECLARE @result datetime
 SELECT @result = MAX(A_DATE)
 FROM GSP_SOC_SERV
 WHERE GSP_SOC_SERV.A_PC = @pcId

 RETURN @result
END;
go

