CREATE FUNCTION [dbo].[GET_REGSTANDARTHCS] (@DATE datetime)
RETURNS TABLE
AS 
RETURN ( 
	SELECT * FROM [dbo].GET_REGSTANDARTHCS_PROC(@DATE, null)
)
 
--   sx.datastore.db.SXDb.execute:-1 
--   sx.common.replication.DoReplication.installPatch:-1 
--   sx.common.replication.SXPatchInstallParams.installPatch:-1 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:-1 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:-1 
--   sx.admin.AdmDispatchAction.execute:-1 
--   sx.admin.AdmServletUtil.processAction:-1 
--   sx.admin.AdmServlet.doGet:-1 
--   sx.admin.AdmServlet.doPost:-1 
--   javax.servlet.http.HttpServlet.service:710
go

