CREATE FUNCTION dbo.CHAES_REPOTS_TABLE_RADIACIA (@year INT, @monthBegin INT, @monthend INT, @report INT)
/*@report = 1 - Оперативная информация*/

--  DECLARE @year INT = 2017, 
--    @monthBegin INT = 8, 
--    @monthend INT = 8,
--    @report INT = 1

  --DECLARE @table TABLE (
RETURNS @table TABLE (
  id INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED
 ,[row] [bigint] NULL
 ,[A_PAIDAMOUNT] [int] NULL
 ,[AMOUNT] [float] NULL
 ,[sbor] [float] NULL
 ,[DOCMONTH] [int] NULL
 ,[DOCYEAR] [int] NULL
 ,[A_MONTH] [int] NULL
 ,[A_YEAR] [int] NULL
 ,[A_FROMID] [int] NULL
 ,[nosum] [int] NOT NULL

 ,[PERSONOUID] [int] NULL
 ,[fio] [varchar](766) NULL
 ,[bd] [varchar](10) NULL
 ,[ess] [int] NOT NULL

 ,[msplknpd] [int] NOT NULL
 ,[mspid] [int] NOT NULL
 ,[mspname] [varchar](2000) NULL
 ,[catid] [int] NULL
 ,[catname] [varchar](5000) NULL
 ,[A_DOC] [int] NULL
 ,[NPD_PARENT] [int] NULL
 ,[razdel] [varchar](50) NULL
 ,[PAY_TYPE] [varchar](255) NULL
 ,[post] [int] NOT NULL
 ,[sbor_money] FLOAT NULL
 ,[sbor_nds] FLOAT NULL
)
AS
BEGIN

  --статуcы
  DECLARE @closePayStatus INT, @status INT;
  SET @status = 10;  
  SELECT @closePayStatus = A_ID FROM SPR_STATUS_PAYMENT WHERE A_CODE = 10;

  --НДС
  DECLARE @nds FLOAT
  SELECT TOP 1 @nds = val.A_VALUE / 100
  FROM PPR_FINANCE_UNIT unit, PPR_FINANCE_VALUE val
  WHERE unit.A_ID = val.A_FINANCE_UNIT
    AND unit.A_CODE = 'addCostTax'
  ORDER BY val.A_END_DATE DESC  

  DECLARE @chaesSphere VARCHAR(255) SET @chaesSphere = 'chaes' 
  DECLARE @porSphere VARCHAR(255) SET @porSphere = 'por' 
  DECLARE @mayakSphere VARCHAR(255) SET @mayakSphere = 'mayk'
  DECLARE @semipalatinskSphere VARCHAR(255) SET @semipalatinskSphere = 'semipalatinsk'

  DECLARE @SOOT_RADIACIA TABLE (A_OUID int, A_NUM int, A_NAME VARCHAR(255), MSP_LK_NPD int)
  
  IF (@report = 1) 
    BEGIN /*Оперативная информация*/
     INSERT INTO @SOOT_RADIACIA
      SELECT SPR_SOOT_REPORT_PAY_RAD.A_OUID, A_NUM, A_NAME, A_TOID
      FROM SPR_SOOT_REPORT_PAY_RAD
       INNER JOIN LINK_REPORT_PAY_RAD ON LINK_REPORT_PAY_RAD.A_FROMID = SPR_SOOT_REPORT_PAY_RAD.A_OUID
    END 
  else
    BEGIN /*Отчет о произведенных кассовых расходах */
      INSERT INTO @SOOT_RADIACIA
      SELECT SPR_SOOT_RADIACIA_COSTS.A_OUID, A_NUM, A_NAME, A_TOID
      FROM SPR_SOOT_RADIACIA_COSTS
       INNER JOIN LINK_RADIACIA_COSTS ON LINK_RADIACIA_COSTS.A_FROMID = SPR_SOOT_RADIACIA_COSTS.A_OUID
    END     
  
 -- SELECT * FROM @SOOT_RADIACIA
  
  --выборка
  INSERT INTO @table
    SELECT
      *
     ,CAST(AMOUNT * [sbor] AS MONEY) AS [sbor_money]
     ,CAST(
        CASE
          WHEN post = 1 THEN AMOUNT * [sbor] * @nds
          ELSE 0
        END AS MONEY
      ) AS [sbor_nds]
    FROM (
      SELECT
        --Выплаты 
        ROW_NUMBER() OVER (PARTITION BY pd.A_PAIDAMOUNT ORDER BY pd.A_PAIDAMOUNT) row -- на случай если в таблице соответсвия будед два раза выбрана МСП-ЛК-НПД
       ,pd.A_PAIDAMOUNT AS A_PAIDAMOUNT
       ,CAST(_WM_PAIDAMOUNTS.AMOUNT AS MONEY) AS AMOUNT

       ,[dbo].[BANK_POST_SBOR_BAZIS] (
          SPR_PAY_TYPE.A_ID
         ,SPR_NPD_MSP_CAT.A_ID
         ,WM_PAYMENT.A_PAYMENTORG
         ,CONVERT(DATETIME, ('01.' + CONVERT(VARCHAR, @monthend) + '.' + CONVERT(VARCHAR, @year)), 104)
        )  AS sbor

       ,pd.A_DOCMONTH AS DOCMONTH
       ,pd.A_DOCYEAR AS DOCYEAR
       ,WM_PAY_CALC.A_MONTH AS A_MONTH
       ,WM_PAY_CALC.A_YEAR AS A_YEAR

        --номер строки в отчете
       , soot.A_OUID
        
       ,CASE
          WHEN soot.A_NUM in ('260', '270', '280') THEN 1
          ELSE 0
        END AS nosum

        --данные гражданина
       ,_WM_PAIDAMOUNTS.PERSONOUID
       ,f.A_NAME + ' ' + i.A_NAME + ' ' + ISNULL(o.A_NAME, '') fio
       ,CONVERT(VARCHAR(10), wpc.birthdate, 104) bd
       ,_ESRN_SERV_SERV.OUID ess

        --МСП-ЛК-НПД
       ,SPR_NPD_MSP_CAT.A_ID msplknpd
       ,PPR_SERV.A_ID mspid
       ,PPR_SERV.A_NAME mspname
       ,PPR_CAT.A_ID catid
       ,PPR_CAT.A_NAME catname
       ,SPR_NPD_MSP_CAT.A_DOC
       ,NULL AS NPD_PARENT

       ,CASE SPR_SPHERE.A_CODE
          WHEN @chaesSphere THEN 'ЧАЭС_ПОР'
          WHEN @porSphere THEN 'ЧАЭС_ПОР'
          WHEN @mayakSphere THEN 'МАЯК'
          WHEN @semipalatinskSphere THEN 'Семиполатинск'
        END razdel

        --Выплатные реквизиты
       ,SPR_PAY_TYPE.A_NAME PAY_TYPE
       ,CASE
          WHEN SPR_PAY_TYPE.A_COD = 'NR1' THEN 1
          ELSE 0
        END AS post

      --из истории выплат
      FROM (
        SELECT *
        FROM (
          SELECT
            ROW_NUMBER() OVER (PARTITION BY A_PAIDAMOUNT ORDER BY A_DOCYEAR DESC, A_DOCMONTH DESC, A_ID DESC) AS Row
           ,A_PAIDAMOUNT
           ,A_ID
           ,A_PAYMENT
           ,PAYHISTORY.A_DOCYEAR
           ,PAYHISTORY.A_DOCMONTH
          FROM PAYHISTORY
          WHERE PAYHISTORY.A_STATUS_PAID = @closePayStatus
            AND (PAYHISTORY.A_STATUS IS NULL OR PAYHISTORY.A_STATUS = @status)
            AND PAYHISTORY.A_DOCYEAR = @year
            AND PAYHISTORY.A_DOCMONTH >= @monthBegin AND PAYHISTORY.A_DOCMONTH <= @monthEnd
        ) AS ph
        WHERE ph.row = 1 
      ) AS pd

        --выплаты
        INNER JOIN (
          SELECT
            pay.OUID
           ,pay.PERSONOUID
           ,pay.AMOUNT
           ,pay.A_PAYCALC
          FROM WM_PAIDAMOUNTS AS pay
          WHERE pay.A_STATUS IS NULL OR pay.A_STATUS = @status
        ) AS _WM_PAIDAMOUNTS ON pd.A_PAIDAMOUNT = _WM_PAIDAMOUNTS.OUID

        --начисления
        INNER JOIN WM_PAY_CALC ON _WM_PAIDAMOUNTS.A_PAYCALC = WM_PAY_CALC.OUID
          AND (WM_PAY_CALC.A_STATUS IS NULL OR WM_PAY_CALC.A_STATUS = @status)

        INNER JOIN (
          SELECT
            ESRN_SERV_SERV.OUID
           ,ESRN_SERV_SERV.A_SERV
          FROM ESRN_SERV_SERV
          WHERE ESRN_SERV_SERV.A_STATUS IS NULL OR ESRN_SERV_SERV.A_STATUS = @status
        ) AS _ESRN_SERV_SERV ON WM_PAY_CALC.A_MSP = _ESRN_SERV_SERV.OUID

        INNER JOIN SPR_NPD_MSP_CAT ON SPR_NPD_MSP_CAT.A_ID = _ESRN_SERV_SERV.A_SERV
          INNER JOIN PPR_SERV ON PPR_SERV.A_ID = SPR_NPD_MSP_CAT.A_MSP
          LEFT JOIN PPR_CAT ON PPR_CAT.A_ID = SPR_NPD_MSP_CAT.A_CATEGORY
          INNER JOIN PPR_NPD_ARTICLE ON PPR_NPD_ARTICLE.A_ID = SPR_NPD_MSP_CAT.A_DOC

        INNER JOIN @SOOT_RADIACIA soot ON soot.MSP_LK_NPD = SPR_NPD_MSP_CAT.A_ID

        INNER JOIN SPR_SPHERE ON SPR_SPHERE.A_ID = SPR_NPD_MSP_CAT.A_SPH
          AND SPR_SPHERE.A_CODE IN (@chaesSphere, @porSphere, @mayakSphere, @semipalatinskSphere)

        --данные гражданина
        INNER JOIN WM_PERSONAL_CARD wpc ON _WM_PAIDAMOUNTS.PERSONOUID = wpc.ouid
        LEFT JOIN SPR_FIO_SURNAME f ON wpc.SURNAME = f.OUID
        LEFT JOIN SPR_FIO_NAME i ON wpc.A_NAME = i.OUID
        LEFT JOIN SPR_FIO_SECONDNAME o ON wpc.A_SECONDNAME = o.OUID

        -- способ доставки
        INNER JOIN WM_PAYMENT ON pd.A_PAYMENT = WM_PAYMENT.OUID
        INNER JOIN SPR_PAY_TYPE ON WM_PAYMENT.DELIVERYWAY = SPR_PAY_TYPE.A_ID
        INNER JOIN SPR_DELIVERTYPES delivery ON WM_PAYMENT.A_DELIVERY_TYPES = delivery.OUID
    ) t
    WHERE row = 1

   -- SELECT * FROM @table
  
  RETURN;
END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40
go

