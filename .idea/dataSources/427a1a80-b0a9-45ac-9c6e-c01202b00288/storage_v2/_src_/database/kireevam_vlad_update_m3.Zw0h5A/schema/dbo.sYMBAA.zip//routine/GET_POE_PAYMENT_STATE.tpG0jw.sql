
CREATE FUNCTION [dbo].[GET_POE_PAYMENT_STATE] (
	@exportId INT --Идентификатор выгрузки
)
RETURNS 
@result TABLE (
	payBookId        INT,           -- Выплатное дело
	additionalPaymentBookId INT,    --Дополнительное выплатное дело
	paymentId        INT,           -- Выплатные реквизиты текущие
	prevPaymentId    INT,           -- Выплатные реквизиты прошлые
	fioId            INT,           -- ФИО текущие
	prevFioId        INT,           -- ФИО прошлые
	addrId           INT,           -- Адресс текущие
	prevAddrId       INT,           -- Адресс прошлые
	idDocId          INT,           -- Документ текущие
	prevIdDocId      INT,           -- Документ прошлый
	payStartDate     DATETIME,      -- Дата начала действия выплаты
	payEndDate       DATETIME,      -- Дата окончания действия выплаты
	mspLkNpdId       INT,           -- МСП-ЛК-НПД текущие
	prevmspLkNpdId   INT,           -- МСП-ЛК-НПД прошлый
	curAmount        NUMERIC(18,2), -- Размер
	curAddAmount     NUMERIC(18,2), -- Доплата
	amountStart      DATETIME,      -- Дата начала действия размена
	eventTypeLast    INT,           -- Прошлое событие
	startEventType   INT,           -- Тип начала выплаты
	startEventDate   DATETIME,      -- Дата начала выплаты	
	startEventId     INT,           -- Событие начала выплаты
	startEventUnitId INT,           -- Субъект события начало выплаты
	activePay        BIT DEFAULT 0  -- Флаг активности выплатного дела
)
AS
BEGIN

	DECLARE 
	@exportRegDate DATETIME, -- дата регистрации выгрузки
	@exportDate    DATETIME, -- дата выгрузки
	@status        INT,      -- статус действует	 
	@payStartEvent INT       -- Начало выплаты	
	 
	SELECT @status        = A_ID       FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act' -- статус действует
	SELECT @payStartEvent = a_ouid     FROM  SPR_PAY_EVENT   WHERE A_CODE = '011'       -- Начало выплаты
	 
	 	 
	DECLARE @regMode INT 	
	SET @regMode = 0
	SELECT  
	@regMode = 	 payMode.A_EVENT_REG_MODE					
	FROM WM_PAY_MODE payMode
	INNER JOIN WM_PAY_EXPORT payExport ON payExport.A_PAYMODE = payMode.A_OUID
		AND (payExport.A_STATUS = @status OR payExport.A_STATUS IS NULL)
	WHERE  (payMode.A_STATUS = @status OR payMode.A_STATUS IS NULL)
		AND payExport.A_OUID = @exportId		
	 
	 
	SELECT @exportRegDate = A_REG_DATE FROM WM_PAY_EXPORT WHERE A_OUID = @exportId   -- дата регистрации выгрузки
	SELECT @exportDate = A_REG_DATE FROM WM_PAY_EXPORT    WHERE A_OUID = @exportId   -- дата выгрузки
	

	-- Раскручиваем дерево событий
	DECLARE @eventTree TABLE ( 
		ouid      INT,         -- 
		code      VARCHAR(50), -- 
		childOuid INT,         -- 
		childCode VARCHAR(50)  -- 
	);
	INSERT INTO @eventTree(ouid,code,childOuid,childCode)
	SELECT ouid,code,childOuid,childCode FROM GET_POE_EVENT_TYPE_TREE()
	ORDER BY code, lvl, childCode
	--Заполнение таблицы с обрабатываемыми выплатными делами
	DECLARE @payBook TABLE (
		payBookId INT
	);
	INSERT INTO @payBook(payBookId)
	SELECT DISTINCT linkPayBook.A_TOID
	FROM WM_PAY_EXPORT payExport 		
	INNER JOIN LINK_PAY_EXPORT_PAYBOOK linkPayBook ON linkPayBook.A_FROMID = payExport.A_OUID			 
	WHERE payExport.A_OUID = @exportId	
		AND (payExport.A_STATUS = @status OR payExport.A_STATUS IS NULL)
		

		
	--	Заполнение таблицы с закрытыми чуваками
	DECLARE @endMonth TABLE (
		payBookId INT
	);
	INSERT INTO @endMonth(payBookId)			
	SELECT payBook.payBookId
	FROM @payBook payBook
	INNER JOIN WM_PAY_EVENT_UNIT payEventUnit ON payEventUnit.A_PAYMENT_BOOK = payBook.payBookId
		AND (payEventUnit.A_STATUS = @status OR payEventUnit.A_STATUS IS NULL )
	INNER JOIN WM_PAY_EVENT payEvent ON  payEventUnit.A_EVENT = payEvent.A_OUID
       AND (payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL )
    INNER JOIN @eventTree evType ON payEvent.A_EVENT_TYPE = evType.childOuid
			AND evType.code IN ('11')
	WHERE  payEvent.A_EVENT_DATE  = @exportDate   
		 AND @regMode NOT IN (3 ,4) 
	
		
	--Таблица с соыбиями начало выплаты
	DECLARE @payStart TABLE ( 
		id            INT IDENTITY(1,1) PRIMARY KEY CLUSTERED,     
		payBookId     INT,         -- 
		additionalPaymentBookId INT,    --Дополнительное выплатное дело
		eventTypeId   INT,         -- 
		eventTypeCode VARCHAR(50), -- 
		unitId        INT,         -- 
		eventId       INT,         -- 
		eventExportId INT,         -- 
		eventRegDate  DATETIME,    -- 
		eventDate     DATETIME     -- 
	);
	INSERT INTO @payStart(payBookId,additionalPaymentBookId, eventTypeId, eventTypeCode, unitId, eventId,
				eventExportId, eventRegDate,eventDate)
	SELECT payBookId,additionalPaymentBookId, eventTypeId, eventTypeCode,
		   unitId, eventId, eventExportId, eventRegDate,eventDate
	FROM (
		SELECT evUnit.A_PAYMENT_BOOK as payBookId,evUnit.A_ADDIT_PAYMENT_BOOK as additionalPaymentBookId,ev.A_EXPORT AS eventExportId, 
			ev.A_EVENT_TYPE as eventTypeId, evType.code as eventTypeCode,
			evUnit.A_OUID as unitId, ev.A_OUID AS eventId, ev.A_EVENT_REGDATE AS eventRegDate,ev.A_EVENT_DATE eventDate ,
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK,evUnit.A_ADDIT_PAYMENT_BOOK,evType.ouid ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM WM_PAY_EVENT_UNIT evUnit 
		INNER JOIN @payBook payBook ON evUnit.A_PAYMENT_BOOK = payBook.payBookId
		INNER JOIN WM_PAY_EVENT ev ON evUnit.A_EVENT = ev.A_OUID
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
		INNER JOIN @eventTree evType ON ev.A_EVENT_TYPE = evType.childOuid
			AND evType.code IN ('01'/*,'05'*/)
			AND (ev.A_EXPORT = @exportId OR ev.A_EVENT_DATE < @exportDate OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND @regMode <> 4))
		LEFT JOIN @endMonth endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK
			AND  ev.A_EVENT_DATE = @exportDate
		WHERE endMonth.payBookId IS NULL 	
	) lastPay 
	WHERE lastPay.num = 1 AND lastPay.eventTypeCode NOT IN ('05') 	
    --Фильтрация
    DELETE FROM @payStart    
    WHERE eventTypeId<>@payStartEvent
		AND payBookId IN (SELECT payBookId FROM @payStart WHERE eventTypeId = @payStartEvent)
	DELETE FROM @payStart    
    WHERE  id NOT IN (SELECT MIN(id) id FROM @payStart GROUP BY payBookId,additionalPaymentBookId)  	
	
	--Таблица с событиями Изменение личных данных
	DECLARE @evUnitCh TABLE ( 
		payBookId     INT,      -- 
		eventExportId INT,      -- 
		eventRegDate  DATETIME, -- 
		chClass       INT,      -- 
		chOldId       INT,      -- 
		chNewId       INT       -- 
	);
	INSERT INTO @evUnitCh(payBookId, eventExportId, eventRegDate, chClass,
				chOldId, chNewId)
	SELECT payBookId, eventExportId, eventRegDate, chClass, chOldId, chNewId
	FROM (
		SELECT payStart.payBookId, ev.A_EXPORT AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			evUnitCh.A_CLASS AS chClass, evUnitCh.A_OLD_OUID AS chOldId, evUnitCh.A_NEW_OUID AS chNewId,
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK, evUnitCh.A_CLASS ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM @payStart payStart
		INNER JOIN WM_PAY_EVENT_UNIT_PERS_CHANGE evUnitCh 
			INNER JOIN WM_PAY_EVENT_UNIT evUnit ON evUnit.A_OUID = evUnitCh.A_OUID
				AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
			AND (ev.A_EXPORT = @exportId OR ev.A_EVENT_DATE < @exportDate OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND @regMode <> 4))
		LEFT JOIN @endMonth endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK
			AND  ev.A_EVENT_DATE = @exportDate
		WHERE endMonth.payBookId IS NULL 	
	) x WHERE x.num = 1
	--Таблица с событиями Изменение перода предоставления
	DECLARE @evUnitPeriod TABLE ( 
		payBookId     INT,      --
		eventExportId INT,      --
		eventRegDate  DATETIME, --
		dateStart     DATETIME, --
		dateEnd       DATETIME  --
	);
	INSERT INTO @evUnitPeriod(payBookId, eventExportId, eventRegDate, dateStart, dateEnd)
	SELECT payBookId, eventExportId, eventRegDate, dateStart, dateEnd
	FROM (
		SELECT payStart.payBookId, ev.A_EXPORT AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			ev.A_EVENT_TYPE as eventTypeId, evUnit.A_OUID AS unitId,
			evUnitPeriod.A_START_DATE AS dateStart, evUnitPeriod.A_END_DATE AS dateEnd,
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM @payStart payStart
		INNER JOIN WM_PAY_EVENT_UNIT_NEW_PERIOD evUnitPeriod 
			INNER JOIN WM_PAY_EVENT_UNIT evUnit
				INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
			ON evUnit.A_OUID = evUnitPeriod.A_OUID
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
			AND (ev.A_EXPORT = @exportId OR ev.A_EVENT_DATE < @exportDate OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND @regMode <> 4))
		LEFT JOIN @endMonth endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK
			AND  ev.A_EVENT_DATE = @exportDate
		WHERE endMonth.payBookId IS NULL 	
	) x WHERE x.num = 1
	
	--Таблица с событиями Прекращение
	DECLARE @evClose TABLE ( 
		payBookId     INT,     --
		eventExportId INT,     --
		eventRegDate  DATETIME --
	);
	INSERT INTO @evClose(payBookId, eventExportId, eventRegDate)
	SELECT payBookId, eventExportId, eventRegDate
	FROM (
		SELECT payStart.payBookId, ev.A_EXPORT AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			ev.A_EVENT_TYPE as eventTypeId, evUnit.A_OUID AS unitId,			
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM @payStart payStart
		INNER JOIN WM_PAY_EVENT_UNIT_STOP_PAY stopPay
			INNER JOIN WM_PAY_EVENT_UNIT evUnit
				INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
			ON evUnit.A_OUID = stopPay.A_OUID
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
			AND (ev.A_EXPORT = @exportId OR ev.A_EVENT_DATE < @exportDate OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND @regMode <> 4))			
			AND payStart.eventDate < ev.A_EVENT_DATE		
			AND DATEDIFF(MONTH,ev.A_EVENT_DATE,@exportDate)>0
		LEFT JOIN @endMonth endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK
			AND  ev.A_EVENT_DATE = @exportDate
		WHERE endMonth.payBookId IS NULL 

	) x WHERE x.num = 1
	--Таблица с событиями последние
	DECLARE @evLast TABLE ( 
		payBookId     INT,      --
		eventExportId INT,      --
		eventRegDate  DATETIME, -- 
		eventTypeId   INT       --
	);
	INSERT INTO @evLast(payBookId, eventExportId, eventRegDate, eventTypeId)
	SELECT payBookId, eventExportId, eventRegDate, eventTypeId
	FROM (
		SELECT payStart.payBookId, ev.A_EXPORT AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			ev.A_EVENT_TYPE as eventTypeId, evUnit.A_OUID AS unitId,			
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM @payStart payStart
			INNER JOIN WM_PAY_EVENT_UNIT evUnit
				INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
			AND (ev.A_EXPORT = @exportId OR ev.A_EVENT_DATE < @exportDate OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND @regMode <> 4))
		LEFT JOIN @endMonth endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK
			AND  ev.A_EVENT_DATE = @exportDate
		WHERE endMonth.payBookId IS NULL 
	) x WHERE x.num = 1	
	
	--Таблица с событиями изменение размера
	DECLARE @evUnitAmount TABLE ( 
		payBookId     INT,           -- 
		eventExportId INT,           -- 
		eventRegDate  DATETIME,		 -- 
		curAmount     NUMERIC(18,2), -- 
		curAddAmount  NUMERIC(18,2), -- 
		amountStart   DATETIME       -- 
	);
	INSERT INTO @evUnitAmount(payBookId, eventExportId, eventRegDate, curAmount, curAddAmount,amountStart)
	SELECT payBookId, eventExportId, eventRegDate, amount, addAmount,startAmount
	FROM (
		SELECT payStart.payBookId, ev.A_EXPORT AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			ev.A_EVENT_TYPE as eventTypeId, evUnit.A_OUID AS unitId,			
			evUnitAmount.A_NEWSIZE amount,
			CASE WHEN ev.A_EXPORT = @exportId
				then evUnitAmount.A_R1 
				ELSE 0
			END addAmount,			
			ev.A_EVENT_DATE startAmount,			
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM @payStart payStart
		INNER JOIN WM_PAY_EVENT_UNIT_NEW_SIZE evUnitAmount 
			INNER JOIN WM_PAY_EVENT_UNIT evUnit
				INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
			ON evUnit.A_OUID = evUnitAmount.A_OUID
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
			AND (ev.A_EXPORT = @exportId OR ev.A_EVENT_DATE < @exportDate OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND @regMode <> 4))
		LEFT JOIN @endMonth endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK
			AND  ev.A_EVENT_DATE = @exportDate
		WHERE endMonth.payBookId IS NULL 
	) x WHERE x.num = 1	

	--Таблица Результатом
	INSERT INTO @result(payBookId,additionalPaymentBookId, paymentId, prevPaymentId, fioId, prevFioId,
		addrId, prevAddrId, idDocId, prevIdDocId, payStartDate, payEndDate,mspLkNpdId,prevmspLkNpdId,
		curAmount, curAddAmount,amountStart,eventTypeLast,		
		startEventType,startEventDate,startEventId,startEventUnitId,activePay 	
	)
	SELECT payStart.payBookId,evUnit.A_ADDIT_PAYMENT_BOOK additionalPaymentBookId,
		evUnitPay.A_PAYMENT, CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_PAYMENT END, 
		evUnitPay.A_FIO, CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_FIO END,
		evUnitPay.A_ADDRESS, CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_ADDRESS END,
		evUnitPay.A_ID_DOC, CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_ID_DOC END,
		
		CASE WHEN evUnitPeriod.payBookId IS NOT NULL 
			THEN evUnitPeriod.dateStart
			ELSE evUnitPay.A_START_DATE
		END ,
		CASE WHEN evUnitPeriod.payBookId IS NOT NULL 
			THEN evUnitPeriod.dateEnd
			ELSE evUnitPay.A_END_DATE
		END,
		evUnitPay.A_MSP_LK_NPD, 
		CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_MSP_LK_NPD END,
		evUnitPay.A_SUM curAmount, 
		case when payStart.eventExportId = @exportId then evUnitPay.A_R1 else 0 end curAddAmount,
		evUnitPay.A_START_DATE amountStart,
		evLast.eventTypeId,
		payStart.eventTypeId startEventType,		
		payStart.eventDate startEventDate,payStart.eventId startEventId,payStart.unitId startEventUnitId,
		CASE WHEN evClose.payBookId	IS NOT NULL THEN 0 ELSE 1 END  activePay
	FROM @payStart payStart 
	INNER JOIN WM_PAY_EVENT_UNIT_NEWSERV evUnitPay ON payStart.unitId = evUnitPay.A_OUID 	
	INNER JOIN WM_PAY_EVENT_UNIT evUnit ON evUnit.A_OUID = evUnitPay.A_OUID
		AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)				
	LEFT JOIN @evUnitPeriod evUnitPeriod ON payStart.payBookId = evUnitPeriod.payBookId		
	LEFT JOIN @evLast evLast ON payStart.payBookId = evLast.payBookId		
	LEFT JOIN @evClose evClose ON payStart.payBookId = evClose.payBookId	
	--
	UPDATE @result SET curAmount = evUnitAmount.curAmount,curAddAmount = evUnitAmount.curAddAmount,amountStart = evUnitAmount.amountStart
	FROM @payStart payStart
	INNER JOIN @evUnitAmount evUnitAmount ON payStart.payBookId = evUnitAmount.payBookId
	WHERE [@result].payBookId = payStart.payBookId
	--
	UPDATE @result SET paymentId = evUnitCh.chNewId, prevPaymentId = 
		CASE WHEN evUnitCh.eventExportId = @exportId 
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM @payStart payStart
	INNER JOIN @evUnitCh evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'wmPayment'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [@result].payBookId = payStart.payBookId
	--
	UPDATE @result SET fioId = evUnitCh.chNewId, prevFioId = 
		CASE WHEN evUnitCh.eventExportId = @exportId 
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM @payStart payStart
	INNER JOIN @evUnitCh evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'pcFIOHistory'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [@result].payBookId = payStart.payBookId
	--
	UPDATE @result SET addrId = evUnitCh.chNewId, prevAddrId = 
		CASE WHEN evUnitCh.eventExportId = @exportId 
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM @payStart payStart
	INNER JOIN @evUnitCh evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'wmAddress'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [@result].payBookId = payStart.payBookId

	--
	UPDATE @result SET idDocId = evUnitCh.chNewId, prevIdDocId = 
		CASE WHEN evUnitCh.eventExportId = @exportId
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM @payStart payStart
	INNER JOIN @evUnitCh evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'wmActDocuments'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [@result].payBookId = payStart.payBookId
	--
	UPDATE @result SET mspLkNpdId = evUnitCh.chNewId, prevmspLkNpdId = 
		CASE WHEN evUnitCh.eventExportId = @exportId
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM @payStart payStart
	INNER JOIN @evUnitCh evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'sprNpdMspCat'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [@result].payBookId = payStart.payBookId
	
	RETURN
END
go

