

CREATE FUNCTION [dbo].[GET_FINANCE_VALUE]
(
@deliveryWay int,
@payType int,
@msp int,
@orgId int,
@residuePay float,
@town int,
@curdate DATETIME
)
RETURNS float
AS
BEGIN
DECLARE @code varchar(255), @organdmsp float, @organdmspisnull float,
		@orgisnullandmsp float, @result float, @isBankTransfer bit		
SELECT @isBankTransfer = A_BBANK_TRANSFER FROM PPR_SERV WHERE A_ID = @msp
IF (@isBankTransfer = 0 OR @isBankTransfer IS NULL) BEGIN 
	RETURN 0
END 
SET @code= CASE WHEN @payType = 1 THEN  'mailExp'   -- Касса орг
				WHEN @payType = 2 THEN  'mailExp'   -- Почтовые сборы
				WHEN @payType = 3 THEN  'postDuty'  -- Тариф на почтовые отправления (разовые поручения)
				WHEN @payType = 4 THEN  'postVedom' -- Тариф на почтовые отправления (по ведомости)
				WHEN @payType = 5 THEN  'bankExp'   -- Банковские сборы
				ELSE NULL
		   END
IF ((@msp IS NOT NULL OR @orgId IS NOT NULL) AND @payType IN (3,4,5)) BEGIN
  DECLARE @delWay varchar(255), @parent int, @i int
  SELECT @delWay = A_COD , @i = 0 FROM SPR_PAY_TYPE WHERE A_ID = @deliveryWay
  WHILE(1=1) BEGIN
	  IF(@delWay = 'NR1')BEGIN 
		  SELECT @parent = A_PARENT FROM SPR_MAIL_PHONE WHERE OUID = @orgId END
	  ELSE IF(@delWay = 'NR2' OR @delWay = 'NR4') BEGIN
		  SELECT @parent = A_PARENT FROM SPR_ORG_BANKS WHERE OUID = @orgId END
      ELSE BREAK
	  IF (@parent IS NOT NULL OR @i = 0) BEGIN
		SET @orgId = CASE WHEN @i = 0 THEN @orgId ELSE @parent END
		SET @i = @i + 1
	  SELECT
		  @organdmsp = CASE WHEN bankServ.A_ORGANIZATION = @orgId AND sbsl.A_TOID = @msp
				  THEN finValue.A_VALUE ELSE @organdmsp END,
		  @organdmspisnull = CASE WHEN bankServ.A_ORGANIZATION = @orgId AND sbsl.A_TOID IS NULL
				  THEN finValue.A_VALUE ELSE @organdmspisnull END,
		  @orgisnullandmsp = CASE WHEN bankServ.A_ORGANIZATION IS NULL AND sbsl.A_TOID = @msp
				  THEN finValue.A_VALUE ELSE @orgisnullandmsp END
  	
	  FROM SPR_BANK_SERV bankServ
		  LEFT JOIN PPR_FINANCE_VALUE finValue
			 ON finValue.A_FINANCE_UNIT = bankServ.A_FIN_VALUE
		  LEFT JOIN SPR_BANK_SERV_LINK sbsl
			 ON sbsl.A_FROMID = bankserv.OUID
	  WHERE 
		  (bankServ.A_ORGANIZATION = @orgId OR sbsl.A_TOID = @msp)
		  AND (finValue.A_ID IS NOT NULL AND finValue.A_BEGIN_DATE <= @curdate
			  AND (finValue.A_END_DATE IS NULL OR finValue.A_END_DATE >= @curdate))  
		
	  IF (@organdmsp IS NOT NULL)	BEGIN 			   
		  SET @result = @organdmsp BREAK END
	  ELSE IF(@organdmspisnull IS NOT NULL) BEGIN
		  SET @result = @organdmspisnull BREAK END
	  ELSE IF(@orgisnullandmsp IS NOT NULL) BEGIN
		  SET @result = @orgisnullandmsp CONTINUE END
	  ELSE
		  CONTINUE
	  END
	  ELSE BREAK
  END
SET @result = @residuePay * @result /100  
END
ELSE IF(@payType = 2) BEGIN
  SELECT 
	TOP 1 @result = 
			CASE 
				WHEN (@residuePay * postRate.A_PERSENT_SUM /100) < postRate.A_MIN_VALUE 
				THEN postRate.A_MIN_VALUE
				ELSE @residuePay * postRate.A_PERSENT_SUM /100
			END
  FROM PPR_POST_RATE postRate
		LEFT JOIN SPR_TOWN st
		ON st.OUID = @town
		LEFT JOIN SPR_FEDERATIONBOROUGHT sf
		ON st.A_BSF = sf.OUID
		LEFT JOIN SPR_SUBJFED ss
		ON sf.A_FEDSUBJID = ss.OUID
		LEFT JOIN SPR_COUNTRY sc
		ON ss.A_COUNTRY = sc.OUID
  WHERE((postRate.A_TOWN IS NULL OR postRate.A_TOWN = st.OUID) 
			AND (postRate.A_FEDBOROUGH IS NULL OR postRate.A_FEDBOROUGH = sf.OUID)
			AND (postRate.A_SUBFED IS NULL OR postRate.A_SUBFED = ss.OUID)
			AND (postRate.A_COUNTRY IS NULL OR postRate.A_COUNTRY = sc.OUID))
		AND @residuePay > postRate.A_LOWER_LIMIT
		AND (postRate.A_UP_LIMIT IS NULL OR @residuePay <= postRate.A_UP_LIMIT) 
		AND @curdate > postRate.A_BEGIN_DATE 
		AND (postRate.A_END_DATE IS NULL OR @curdate < postRate.A_END_DATE)
		AND postRate.A_PERSENT_SUM IS NOT NULL
  ORDER BY postRate.A_TOWN DESC,postRate.A_FEDBOROUGH DESC,postRate.A_SUBFED DESC,postRate.A_COUNTRY DESC
  
END   
IF(@result IS NULL)  
BEGIN
	SELECT 
		@result = ISNULL(PPR_FINANCE_VALUE.A_VALUE,@result)
	FROM PPR_FINANCE_UNIT
		LEFT JOIN PPR_FINANCE_VALUE
		ON PPR_FINANCE_VALUE.A_FINANCE_UNIT = PPR_FINANCE_UNIT.A_ID
	WHERE
		PPR_FINANCE_UNIT.A_CODE = @code
	SET @result = @residuePay * @result /100 
END 
RETURN ISNULL(@result,0)
END
go

