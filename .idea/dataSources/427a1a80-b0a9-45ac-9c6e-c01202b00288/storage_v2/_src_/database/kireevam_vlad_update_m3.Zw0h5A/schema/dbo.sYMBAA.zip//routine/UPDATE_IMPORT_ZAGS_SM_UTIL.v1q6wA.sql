CREATE PROCEDURE [dbo].[UPDATE_IMPORT_ZAGS_SM_UTIL] (@obj int,@state varchar(255),@login varchar(255))
AS
BEGIN
declare @stateHist varchar(255), @prichina varchar(255)
select @stateHist= a_State, @prichina=A_PRIVHINA
from PROTOKOL_IMPORT_ZAGS_SM where a_ouid=@obj
declare @loginId int

select @loginId=ouid from sxUser where [login]=@login


if isnull(@prichina, '')='Неоднозначная идентификация'
begin
/*Переносим ЛД*/

UPDATE TEMP_IMPORT_ZAGS_SM
set a_person=PROTOKOL_IMPORT_ZAGS_SM.A_ALL_PERSON
from  PROTOKOL_IMPORT_ZAGS_SM
inner join TEMP_IMPORT_ZAGS_SM on TEMP_IMPORT_ZAGS_SM.a_ouid=PROTOKOL_IMPORT_ZAGS_SM.A_TEMP_IMPORT_ZAGS
and PROTOKOL_IMPORT_ZAGS_SM.a_ouid=@obj
and PROTOKOL_IMPORT_ZAGS_SM.A_ALL_PERSON is not null

UPDATE PROTOKOL_IMPORT_ZAGS_SM
set a_ld=PROTOKOL_IMPORT_ZAGS_SM.A_ALL_PERSON
from  PROTOKOL_IMPORT_ZAGS_SM
where  PROTOKOL_IMPORT_ZAGS_SM.a_ouid=@obj
and PROTOKOL_IMPORT_ZAGS_SM.A_ALL_PERSON is not null



declare  @GUID1 varchar(255)
,@DATAR varchAR(255)
,@PERSON INT
,@NOMAKT varchAR(255)
,@DATREG_VAR varchAR(255)
, @GETDATE DATETIME
, @a_ouid_TEMP int

SELECT 
@a_ouid_TEMP=TEMP_IMPORT_ZAGS_SM.A_OUID
,@GUID1=TEMP_IMPORT_ZAGS_SM.GUID
,@DATAR =TEMP_IMPORT_ZAGS_SM.DATESM
,@PERSON =TEMP_IMPORT_ZAGS_SM.A_PERSON
,@NOMAKT =TEMP_IMPORT_ZAGS_SM.NUMAZSM
,@DATREG_VAR =TEMP_IMPORT_ZAGS_SM.DATEAZSM
, @GETDATE =GETDATE()
from  PROTOKOL_IMPORT_ZAGS_SM
inner join TEMP_IMPORT_ZAGS_SM on TEMP_IMPORT_ZAGS_SM.a_ouid=PROTOKOL_IMPORT_ZAGS_SM.A_TEMP_IMPORT_ZAGS
and PROTOKOL_IMPORT_ZAGS_SM.a_ouid=@obj

if (@state='otrab')
begin
IF (@PERSON IS NOT NULL)
BEGIN
execute UPDATE_LD_IMPORT_ZAGS_SM @a_ouid_TEMP 
, @GUID1 
,@DATAR 
,@PERSON 
,@NOMAKT
,@DATREG_VAR 
, @GETDATE 
if (isnull(@stateHist, '')!=isnull(@state, ''))
begin
INSERT INTO HIST_UPDATE_PROTOKOL_ZAGS_SM(GUID, A_Createdate, a_crowner, a_Status, a_prot, a_State, a_state_hist)
values (NEWID(), GETDATE(),@loginId, 10, @obj, @state, @stateHist)
update PROTOKOL_IMPORT_ZAGS_SM
set A_STATE=@state
where a_ouid=@obj
END
end
end
else if (isnull(@stateHist, '')!=isnull(@state, ''))
begin
INSERT INTO HIST_UPDATE_PROTOKOL_ZAGS_SM(GUID, A_Createdate, a_crowner, a_Status, a_prot, a_State, a_state_hist)
values (NEWID(), GETDATE(),@loginId, 10, @obj, @state, @stateHist)
update PROTOKOL_IMPORT_ZAGS_SM
set A_STATE=@state
where a_ouid=@obj
END
end
else begin
if (isnull(@stateHist, '')!=isnull(@state, ''))
begin
INSERT INTO HIST_UPDATE_PROTOKOL_ZAGS_SM(GUID, A_Createdate, a_crowner, a_Status, a_prot, a_State, a_state_hist)
values (NEWID(), GETDATE(),@loginId, 10, @obj, @state, @stateHist)

update PROTOKOL_IMPORT_ZAGS_SM
set A_STATE=@state
where a_ouid=@obj
end
end

END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40
go

