CREATE FUNCTION [dbo].[GET_POE_PAYBOOKS] (	
	@exportId INT --Идентификатор выгрузки
)
RETURNS 
@result TABLE (
	payBookId  INT,         -- Номер выплатного дела
	reciver    INT,         -- Получатель
	paymentId  INT,         -- Реквизиты
	orgId      INT,         -- Выплатная организация
	mspLkNpdId INT,         -- МСП-ЛК-НПД
	mspId      INT,         -- МСП
	lkId       INT,         -- ЛК
	osznId     INT,         -- ОСЗН
	fioId        INT,       -- ФИО
	adressId     INT,       -- АДРЕСС
	docId      INT,         -- Документ
	periodCode VARCHAR(255)--,-- Код периода выплаты мсп 
	--payStart   DATETIME,    -- Начало действия выплатного дела
	--payEnd     DATETIME     -- Окончание действия выплатного дела
)	
AS
BEGIN	
	DECLARE 
		@status          INT,     -- Статус действует
		@docStatus       INT,     -- Статус документа дейтвует
		@servSformStatus INT,     -- Статус Сформировано
		@exportDate      DATETIME -- Дата выгрузки

	SELECT @status          = A_ID          FROM ESRN_SERV_STATUS   WHERE A_STATUSCODE = 'act'      -- Статус действует
	SELECT @docStatus       = a_ouid        FROM SPR_DOC_STATUS     WHERE A_CODE       = 'active'   -- Статус документа дейтвует
	SELECT @servSformStatus = A_ID          FROM SPR_STATUS_PROCESS WHERE A_CODE       = 8          -- Статус Сформировано
	SELECT @exportDate      = A_EXPORT_DATA FROM WM_PAY_EXPORT      WHERE A_OUID       = @exportId  -- Дата выгрузки
	--Результирующая таблица
	INSERT INTO @result(payBookId,reciver,paymentId,orgId, mspLkNpdId, mspId, lkId, osznId,periodCode,
					--payStart,payEnd,
					fioId,adressId,docId)
	SELECT 
	payBookId,reciver,paymentId,orgId,mspLkNpdId,mspId,lkId,osznId,periodCode,
	--payStart,payEnd,
	fioId,adressId,docId		
	FROM (	SELECT 
			payBook.OUID                      AS payBookId, -- Номер выплатного дела
			mspLkNpd.A_ID                     AS mspLkNpdId,-- Получатель
			mspLkNpd.A_MSP                    AS mspId,     -- Реквизиты
			mspLkNpd.A_CATEGORY               AS lkId,      -- Выплатная организация
			serv.A_ORGNAME                    AS osznId,    -- ОСЗН
			reciver.OUID                      AS reciver,   -- Получатель
			payment.OUID                      AS paymentId, -- Реквизиты
			payment.A_PAYMENTORG              AS orgId,     -- Выплатная организация
			msp.A_PERIOD                      AS periodCode,-- Код периода выплаты мсп 
			fio.OUID                          AS fioId,     -- ФИО
			payment.ALTERNATIVEADDRESSDEIVERY AS adressId,  -- АДРЕСС
			doc.ouid                          AS docId,		-- Документ
			--servPeriod.payStart               AS payStart , -- Начало действия выплатного дела
			--servPeriod.payEnd                 AS payEnd,    -- Окончание действия выплатного дела			
			ROW_NUMBER() OVER(PARTITION BY payBook.OUID ORDER BY 
				CASE msp.A_PERIOD 
					WHEN 1 THEN 1 
					WHEN 4 THEN 2 
					WHEN 2 THEN 3 
					WHEN 3 THEN 4 
				END, 
				CASE WHEN per.A_ID IS NOT NULL THEN 0 ELSE 1 END, 
				CASE WHEN (YEAR(serv.A_SERVDATE) < YEAR(payExport.A_EXPORT_DATA) 
					OR (YEAR(serv.A_SERVDATE) = YEAR(payExport.A_EXPORT_DATA) AND MONTH(serv.A_SERVDATE) <= MONTH(payExport.A_EXPORT_DATA)))
					THEN 0 ELSE 1 
				END,			
				serv.A_SERVDATE DESC) AS num			
			FROM WM_PAY_EXPORT payExport 		
			INNER JOIN LINK_PAY_EXPORT_PAYBOOK linkPayBook ON linkPayBook.A_FROMID = payExport.A_OUID
				AND payExport.A_OUID = @exportId
			INNER JOIN WM_PAYMENT_BOOK payBook ON payBook.OUID = linkPayBook.A_TOID			
				AND(payBook.A_STATUS = @status OR payBook.A_STATUS IS NULL)		
			INNER JOIN WM_PAYMENT payment ON  payment.OUID = payBook.A_ACTREQUISIT
				AND (payment.A_STATUS = @status OR payment.A_STATUS IS NULL)	
			INNER JOIN WM_PERSONAL_CARD reciver ON  payment.PERSONOUID = reciver.OUID
				AND (reciver.A_STATUS = @status OR reciver.A_STATUS IS NULL)	
			INNER JOIN ESRN_SERV_SERV serv ON serv.A_PAYMENTBOOK = payBook.OUID
				AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
				AND serv.A_STATUSPRIVELEGE <> @servSformStatus			
			INNER JOIN SPR_NPD_MSP_CAT mspLkNpd ON serv.A_SERV = mspLkNpd.A_ID
			INNER JOIN PPR_SERV msp ON mspLkNpd.A_MSP = msp.A_ID
			LEFT JOIN SPR_SERV_PERIOD per ON per.A_SERV = serv.OUID
				AND DATEDIFF(DAY,per.STARTDATE,payExport.A_EXPORT_DATA) >= 0
				AND (DATEDIFF(DAY,per.A_LASTDATE,payExport.A_EXPORT_DATA) <= 0 OR per.A_LASTDATE IS NULL)
				AND (per.A_STATUS = @status OR per.A_STATUS IS NULL)			
			--Активный документа       
			LEFT JOIN (SELECT 
					  PERSONOUID pc,
					  doc.OUID,
					  ROW_NUMBER() OVER(PARTITION BY doc.PERSONOUID ORDER BY CASE  WHEN docType.A_CODE = 'rusPassport' THEN 0 ELSE 1 END, doc.ISSUEEXTENSIONSDATE,doc.OUID) num
					  FROM   WM_ACTDOCUMENTS doc
					  INNER JOIN PPR_DOC docType ON  doc.DOCUMENTSTYPE = docType.A_ID
						 AND (doc.A_STATUS = @status OR doc.A_STATUS IS  NULL)
						 AND docType.A_ISIDENTITYCARD = 1
					  WHERE doc.A_DOCSTATUS = @docStatus				   
			 )doc ON  doc.pc = reciver.OUID
				AND doc.num = 1
			--Активное ФИО                    
			LEFT JOIN (SELECT 
	 				   A_PC pc,
					   OUID,
					   ROW_NUMBER() OVER(PARTITION BY A_PC ORDER BY A_FROMDATE DESC) num
					   FROM   PC_FIO_HISTORY fioHistory				  
					   WHERE  (DATEDIFF(MONTH,A_FROMDATE,@exportDate)>=0 OR A_FROMDATE IS NULL)
							AND(fioHistory.A_STATUS = @status  OR fioHistory.A_STATUS IS NULL )
			 )fio ON fio.pc = reciver.OUID
				AND fio.num = 1		 	
	) x
	WHERE x.num = 1

	RETURN
END
go

