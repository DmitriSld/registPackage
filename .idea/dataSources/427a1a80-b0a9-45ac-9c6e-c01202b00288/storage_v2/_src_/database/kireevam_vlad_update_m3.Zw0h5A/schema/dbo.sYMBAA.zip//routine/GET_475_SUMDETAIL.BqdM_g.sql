
CREATE FUNCTION GET_475_SUMDETAIL
(
@pcId int,
@year int,
@month int,
@codeOrg varchar(10)
)
RETURNS varchar(4000)
AS
BEGIN
	DECLARE @sumDetail varchar(4000) -- детализация суммы
	DECLARE @tempSum varchar(40) -- срока с суммой для периода
	DECLARE @minPayCalcMonth int, @minPayCalcYear int, @maxPayCalcMonth int,@maxPayCalcYear int
	DECLARE @minAddPayCalcMonth int, @minAddPayCalcYear int, @maxAddPayCalcMonth int,@maxAddPayCalcYear int
	DECLARE @minDeductionMonth int, @minDeductionYear int
    DECLARE @minYear int, @maxYear int, @minMonth int,@maxMonth int
    DECLARE @minMonthName varchar(20),@maxMonthName varchar(20)
    
    DECLARE @status INT
    SET @status = (SELECT TOP 1 A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act')
    -- получем минимальные месяца/года для удержаний
	SELECT TOP 1 @minDeductionMonth = MONTH(deduc.A_OVERPAYSTART), @minDeductionYear=YEAR(deduc.A_OVERPAYSTART)      					        
	FROM WM_DEDUCTION deduc  
	INNER JOIN WM_DEDUCTION_LOG deducLog ON deducLog.A_DEDUCTION=deduc.A_ID	
	INNER JOIN WM_PAY_CALC pay ON pay.OUID=deducLog.A_PAYCALC
	INNER JOIN (SELECT wpc.OUID
            FROM WM_PAY_CALC wpc
				INNER JOIN SPR_STATUS_PROCESS ssp ON wpc.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 100
				WHERE (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month))
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			UNION ALL 
			SELECT wpc.OUID
			FROM WM_PAIDAMOUNTS wp3
				INNER JOIN SPR_STATUS_PAYMENT ssp ON wp3.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 2
				INNER JOIN WM_PAY_CALC wpc ON wp3.A_PAYCALC = wpc.OUID
                AND (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month))
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			WHERE  (wp3.A_YEAR < @year OR (wp3.A_YEAR = @year AND wp3.A_MONTH <= @month)) 
            AND (wp3.A_STATUS = @status OR wp3.A_STATUS IS NULL)
			) z ON pay.OUID = z.OUID
	INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID = pay.A_STATUS or pay.A_STATUS is null) and servstut.A_CODE = 4
	INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP = serv.OUID
	INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV = nmc.A_ID and nmc.A_CODE = 'compMilitaryFam'
	INNER JOIN WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK = book.OUID
	INNER JOIN WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
	INNER JOIN SPR_PAY_TYPE type ON payment.DELIVERYWAY = type.A_ID and type.A_COD = @codeOrg
	INNER JOIN WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId 
    ORDER BY deduc.A_OVERPAYSTART
    -- получем минимальные месяца/года для доплат
	SELECT TOP 1 @minAddPayCalcMonth = calc.A_MONTH, @minAddPayCalcYear=calc.A_YEAR      					        
	FROM WM_ADDPAY_CALC calc  
	INNER JOIN WM_PAY_CALC pay ON pay.OUID = calc.A_PAYCALC
	INNER JOIN (SELECT wpc.OUID
            FROM WM_PAY_CALC wpc
				INNER JOIN SPR_STATUS_PROCESS ssp ON wpc.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 100
				WHERE (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month)) 
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			UNION ALL 
			SELECT wpc.OUID
			FROM WM_PAIDAMOUNTS wp3
				INNER JOIN SPR_STATUS_PAYMENT ssp ON wp3.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 2
				INNER JOIN WM_PAY_CALC wpc ON wp3.A_PAYCALC = wpc.OUID
                AND (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month)) 
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			WHERE (wp3.A_YEAR < @year OR (wp3.A_YEAR = @year AND wp3.A_MONTH <= @month)) 
            AND (wp3.A_STATUS = @status OR wp3.A_STATUS IS NULL)
			) z ON pay.OUID = z.OUID
	INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID = pay.A_STATUS or pay.A_STATUS is null) and servstut.A_CODE = 4
	INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP = serv.OUID
	INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV = nmc.A_ID and nmc.A_CODE = 'compMilitaryFam'
	INNER JOIN WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK = book.OUID
	INNER JOIN WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
	INNER JOIN SPR_PAY_TYPE type ON payment.DELIVERYWAY = type.A_ID and type.A_COD = @codeOrg
	INNER JOIN WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId
    ORDER BY calc.A_YEAR, calc.A_MONTH   
    -- получем макcимальные месяца/года для доплат
	SELECT TOP 1 @maxAddPayCalcMonth=calc.A_MONTH, @maxAddPayCalcYear=calc.A_YEAR       					        
	FROM WM_ADDPAY_CALC calc  
	INNER JOIN WM_PAY_CALC pay ON pay.OUID = calc.A_PAYCALC
	INNER JOIN (SELECT wpc.OUID
            FROM WM_PAY_CALC wpc
				INNER JOIN SPR_STATUS_PROCESS ssp ON wpc.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 100
				WHERE (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month)) 
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			UNION ALL 
			SELECT wpc.OUID
			FROM WM_PAIDAMOUNTS wp3
				INNER JOIN SPR_STATUS_PAYMENT ssp ON wp3.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 2
				INNER JOIN WM_PAY_CALC wpc ON wp3.A_PAYCALC = wpc.OUID
                AND (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month)) 
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			WHERE (wp3.A_YEAR < @year OR (wp3.A_YEAR = @year AND wp3.A_MONTH <= @month)) 
            AND (wp3.A_STATUS = @status OR wp3.A_STATUS IS NULL)
			) z ON pay.OUID = z.OUID
	INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID = pay.A_STATUS or pay.A_STATUS is null) and servstut.A_CODE = 4
	INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP = serv.OUID
	INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV = nmc.A_ID and nmc.A_CODE = 'compMilitaryFam'
	INNER JOIN WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK = book.OUID
	INNER JOIN WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
	INNER JOIN SPR_PAY_TYPE type ON payment.DELIVERYWAY = type.A_ID and type.A_COD = @codeOrg
	INNER JOIN WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId
    ORDER BY calc.A_YEAR DESC, calc.A_MONTH DESC  
    -- получем минимальные месяца/года для начислений
	SELECT TOP 1 @minPayCalcMonth = pay.A_MONTH, @minPayCalcYear=pay.A_YEAR
	FROM WM_PAY_CALC pay 
	INNER JOIN (SELECT wpc.OUID
            FROM WM_PAY_CALC wpc
				INNER JOIN SPR_STATUS_PROCESS ssp ON wpc.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 100
				WHERE (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month)) 
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			UNION ALL 
			SELECT wpc.OUID
			FROM WM_PAIDAMOUNTS wp3
				INNER JOIN SPR_STATUS_PAYMENT ssp ON wp3.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 2
				INNER JOIN WM_PAY_CALC wpc ON wp3.A_PAYCALC = wpc.OUID
                AND (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month)) 
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			WHERE (wp3.A_YEAR < @year OR (wp3.A_YEAR = @year AND wp3.A_MONTH <= @month)) 
            AND (wp3.A_STATUS = @status OR wp3.A_STATUS IS NULL)
			) z ON pay.OUID = z.OUID
	INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID =  pay.A_STATUS or pay.A_STATUS is null) and  servstut.A_CODE=4
	INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP=serv.OUID
	INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV =nmc.A_ID and nmc.A_CODE='compMilitaryFam'
	INNER JOIN WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK =book.OUID
	INNER JOIN WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
	INNER JOIN SPR_PAY_TYPE type ON payment.DELIVERYWAY = type.A_ID and type.A_COD = @codeOrg
	INNER JOIN WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId
    ORDER BY pay.A_YEAR, pay.A_MONTH
    -- получем макcимальные месяца/года для начислений
	SELECT TOP 1 @maxPayCalcMonth=pay.A_MONTH, @maxPayCalcYear=pay.A_YEAR
	FROM WM_PAY_CALC pay 
	INNER JOIN (SELECT wpc.OUID
            FROM WM_PAY_CALC wpc
				INNER JOIN SPR_STATUS_PROCESS ssp ON wpc.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 100
				WHERE (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month)) 
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			UNION ALL 
			SELECT wpc.OUID
			FROM WM_PAIDAMOUNTS wp3
				INNER JOIN SPR_STATUS_PAYMENT ssp ON wp3.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 2
				INNER JOIN WM_PAY_CALC wpc ON wp3.A_PAYCALC = wpc.OUID
                AND (wpc.A_YEAR < @year OR (wpc.A_YEAR = @year AND wpc.A_MONTH <= @month)) 
                AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
			WHERE (wp3.A_YEAR < @year OR (wp3.A_YEAR = @year AND wp3.A_MONTH <= @month)) 
            AND (wp3.A_STATUS = @status OR wp3.A_STATUS IS NULL)
			) z ON pay.OUID = z.OUID
	INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID =  pay.A_STATUS or pay.A_STATUS is null) and  servstut.A_CODE=4
	INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP=serv.OUID
	INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV =nmc.A_ID and nmc.A_CODE='compMilitaryFam'
	INNER JOIN WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK =book.OUID
	INNER JOIN WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
	INNER JOIN SPR_PAY_TYPE type ON payment.DELIVERYWAY = type.A_ID and type.A_COD = @codeOrg
	INNER JOIN WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId
    ORDER BY pay.A_YEAR DESC, pay.A_MONTH DESC
    -- получаем даты ПО
	IF @maxAddPayCalcYear > @maxPayCalcYear BEGIN
		SET @maxYear = @maxAddPayCalcYear
		SET @maxMonth = @maxAddPayCalcMonth
	END ELSE IF @maxAddPayCalcYear = @maxPayCalcYear BEGIN
		SET @maxYear = @maxAddPayCalcYear 
        IF @maxAddPayCalcMonth > @maxPayCalcMonth BEGIN
			SET @maxMonth = @maxAddPayCalcMonth
        END ELSE  BEGIN
			SET @maxMonth = @maxPayCalcMonth
        END 
	END ELSE BEGIN
		SET @maxYear = @maxPayCalcYear
		SET @maxMonth = @maxPayCalcMonth
	END
	-- получаем даты С
	IF  @minPayCalcYear > @minAddPayCalcYear BEGIN
		SET @minYear = @minAddPayCalcYear
		SET @minMonth = @minAddPayCalcMonth
	END ELSE IF @minAddPayCalcYear = @minPayCalcYear BEGIN
		SET @minYear = @minAddPayCalcYear
        IF @minPayCalcMonth > @minAddPayCalcMonth BEGIN
			SET @minMonth = @minAddPayCalcMonth
        END ELSE  BEGIN
			SET @minMonth = @minPayCalcMonth
        END
	END ELSE BEGIN
		SET @minYear = @minPayCalcYear
		SET @minMonth = @minPayCalcMonth
	END
	IF  @minYear > @minDeductionYear BEGIN
		SET @minYear = @minDeductionYear
		SET @minMonth = @minDeductionMonth
	END ELSE IF @minYear = @minDeductionYear BEGIN
        IF @minMonth > @minDeductionMonth BEGIN
			SET @minMonth = @minDeductionMonth
        END 
	END 
    -- получаем названия месяцев
	SET @minMonthName = (SELECT CASE @minMonth        
							    WHEN 1 THEN 'январь' WHEN 2 THEN 'февраль'  WHEN 3 THEN 'март' WHEN 4 THEN 'апрель'									        								       							        
								WHEN 5 THEN 'май' WHEN 6 THEN 'июнь' when 7 THEN 'июль' WHEN 8 THEN 'август'									        								        							        
								WHEN 9 THEN 'сентябрь' WHEN 10 THEN 'октябрь' WHEN 11 THEN 'ноябрь' WHEN 12 THEN 'декабрь'								        								        								        
								ELSE '' END)
	SET @maxMonthName = (SELECT CASE @maxMonth        
							    WHEN 1 THEN 'январь' WHEN 2 THEN 'февраль'  WHEN 3 THEN 'март' WHEN 4 THEN 'апрель'									        								       							        
								WHEN 5 THEN 'май' WHEN 6 THEN 'июнь' when 7 THEN 'июль' WHEN 8 THEN 'август'									        								        							        
								WHEN 9 THEN 'сентябрь' WHEN 10 THEN 'октябрь' WHEN 11 THEN 'ноябрь' WHEN 12 THEN 'декабрь'								        								        								        
								ELSE '' END)
    -- детализация суммы
    IF (@minMonth = @maxMonth AND @minYear = @maxYear) BEGIN
		SET @sumDetail = ''
    END ELSE BEGIN 
		SET @sumDetail = @minMonthName + ' ' + CAST(@minYear as varchar(4)) + 'г. - ' + 
			             @maxMonthName + ' ' + CAST(@maxYear as varchar(4)) + 'г., в т.ч. ' 
    END

    -- получаем размеры по периодам
    DECLARE @iYear int, @iMonth int
    DECLARE @iMonthName varchar(20)
    DECLARE @AMOUNT DECIMAL(18,2), @DOPLAT DECIMAL(18,2), @DEDUG DECIMAL(18,2),@DOPLATDIFF DECIMAL(18,2),
            @DEDUGDIFF DECIMAL(18,2), @SUM1 DECIMAL(18,2), @SUM2 DECIMAL(18,2), @CURSUM DECIMAL(18,2), @TOTAL DECIMAL(18,2)
    DECLARE @LASTTOTAL DECIMAL(18,2), @FROMDATE1 varchar(30), @TODATE1 varchar(30),@FROMDATE2 varchar(30), @TODATE2 varchar(30)
    SET @SUM1 = 0
    SET @SUM2 = 0
    SET @CURSUM = 0
    SET @FROMDATE1 = ''
    SET @TODATE1 = ''
    SET @FROMDATE2 = ''
    SET @TODATE2 = ''

    SET @iYear = @minYear
    SET @iMonth = @minMonth
    WHILE (@iYear <= @maxYear) BEGIN
		WHILE (@iMonth <= 12) BEGIN
			-- сумма начислений на текущий месяц
            SELECT  @AMOUNT= SUM(temp.AMOUNT)  from (
			SELECT  SUM(pay.AMOUNT) as AMOUNT 
            FROM WM_PAY_CALC pay
			INNER JOIN (SELECT wpc.OUID
					FROM WM_PAY_CALC wpc
						INNER JOIN SPR_STATUS_PROCESS ssp ON wpc.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 100
						WHERE wpc.A_YEAR = @iYear AND wpc.A_MONTH = @iMonth
						AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
					UNION ALL 
					SELECT wpc.OUID
					FROM WM_PAIDAMOUNTS wp3
						INNER JOIN SPR_STATUS_PAYMENT ssp ON wp3.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 2
						INNER JOIN WM_PAY_CALC wpc ON wp3.A_PAYCALC = wpc.OUID
                        AND wpc.A_YEAR = @iYear AND wpc.A_MONTH = @iMonth
						AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
					WHERE  (wp3.A_YEAR < @iYear OR (wp3.A_YEAR = @iYear AND wp3.A_MONTH <= @iMonth))
					AND (wp3.A_STATUS = @status OR wp3.A_STATUS IS NULL)
					) z ON pay.OUID = z.OUID
			INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID =  pay.A_STATUS or pay.A_STATUS is null) and  servstut.A_CODE=4
			INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP=serv.OUID
			INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV =nmc.A_ID and nmc.A_CODE='compMilitaryFam'
			INNER JOIN WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK =book.OUID
			INNER JOIN WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
			INNER JOIN SPR_PAY_TYPE type ON payment.DELIVERYWAY =type.A_ID and type.A_COD=@codeOrg
			INNER JOIN WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId
			GROUP BY pay.OUID) as temp
			-- сумма доплат к начислениям на текущий месяц
            SELECT  @DOPLAT= SUM(temp.AMOUNT)  from (
			SELECT  SUM(calc.A_AMOUNT) as AMOUNT from WM_ADDPAY_CALC calc
			INNER JOIN WM_PAY_CALC pay ON pay.OUID=calc.A_PAYCALC
			INNER JOIN (SELECT wpc.OUID
					FROM WM_PAY_CALC wpc
						INNER JOIN SPR_STATUS_PROCESS ssp ON wpc.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 100
						WHERE wpc.A_YEAR = @iYear AND wpc.A_MONTH = @iMonth
						AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
					UNION ALL 
					SELECT wpc.OUID
					FROM WM_PAIDAMOUNTS wp3
						INNER JOIN SPR_STATUS_PAYMENT ssp ON wp3.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 2
						INNER JOIN WM_PAY_CALC wpc ON wp3.A_PAYCALC = wpc.OUID
                        AND wpc.A_YEAR = @iYear AND wpc.A_MONTH = @iMonth
						AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
					WHERE  (wp3.A_YEAR < @iYear OR (wp3.A_YEAR = @iYear AND wp3.A_MONTH <= @iMonth))
					AND (wp3.A_STATUS = @status OR wp3.A_STATUS IS NULL)
					) z ON pay.OUID = z.OUID
			INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID =  pay.A_STATUS or pay.A_STATUS is null) and  servstut.A_CODE=4
			INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP=serv.OUID
			INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV =nmc.A_ID and nmc.A_CODE='compMilitaryFam'
			INNER JOIN WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK =book.OUID
			INNER JOIN WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
			INNER JOIN SPR_PAY_TYPE type ON payment.DELIVERYWAY =type.A_ID and type.A_COD=@codeOrg
			INNER JOIN WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId
			GROUP BY calc.OUID) as temp
			-- "размер" доплаты за текущий месяц 
            SELECT @DOPLATDIFF = SUM(temp.AMOUNT) from (
			SELECT SUM(calc.A_AMOUNT) as AMOUNT from WM_ADDPAY_CALC calc
			INNER JOIN WM_PAY_CALC pay ON pay.OUID=calc.A_PAYCALC
			INNER JOIN (SELECT wpc.OUID
					FROM WM_PAY_CALC wpc
						INNER JOIN SPR_STATUS_PROCESS ssp ON wpc.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 100
						WHERE wpc.A_YEAR = @iYear AND wpc.A_MONTH = @iMonth
						AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
					UNION ALL 
					SELECT wpc.OUID
					FROM WM_PAIDAMOUNTS wp3
						INNER JOIN SPR_STATUS_PAYMENT ssp ON wp3.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 2
						INNER JOIN WM_PAY_CALC wpc ON wp3.A_PAYCALC = wpc.OUID
                        AND wpc.A_YEAR = @iYear AND wpc.A_MONTH = @iMonth
						AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
					WHERE  (wp3.A_YEAR < @iYear OR (wp3.A_YEAR = @iYear AND wp3.A_MONTH <= @iMonth))
					AND (wp3.A_STATUS = @status OR wp3.A_STATUS IS NULL)
					) z ON pay.OUID = z.OUID
			INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID =  pay.A_STATUS or pay.A_STATUS is null) and  servstut.A_CODE=4
			INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP=serv.OUID
			INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV =nmc.A_ID and nmc.A_CODE='compMilitaryFam'
			INNER JOIN  WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK =book.OUID
			INNER JOIN  WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
			INNER JOIN  SPR_PAY_TYPE type ON payment.DELIVERYWAY =type.A_ID and type.A_COD=@codeOrg
			INNER JOIN  WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId
			GROUP BY calc.OUID) as temp			
			-- сумма удержаний к начислениям на текущий месяц
            SELECT @DEDUG = SUM(temp.AMOUNT)  from (
			SELECT SUM(deduc.A_AMOUNT) as AMOUNT from WM_DEDUCTION_LOG deduc
			INNER JOIN WM_PAY_CALC pay ON pay.OUID=deduc.A_PAYCALC
			INNER JOIN (SELECT wpc.OUID
					FROM WM_PAY_CALC wpc
						INNER JOIN SPR_STATUS_PROCESS ssp ON wpc.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 100
						WHERE wpc.A_YEAR = @iYear AND wpc.A_MONTH = @iMonth
						AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
					UNION ALL 
					SELECT wpc.OUID
					FROM WM_PAIDAMOUNTS wp3
						INNER JOIN SPR_STATUS_PAYMENT ssp ON wp3.A_STATUSPRIVELEGE = ssp.A_ID AND ssp.A_CODE = 2
						INNER JOIN WM_PAY_CALC wpc ON wp3.A_PAYCALC = wpc.OUID
                        AND wpc.A_YEAR = @iYear AND wpc.A_MONTH = @iMonth
						AND (wpc.A_STATUS = @status OR wpc.A_STATUS IS NULL)
					WHERE  (wp3.A_YEAR < @iYear OR (wp3.A_YEAR = @iYear AND wp3.A_MONTH <= @iMonth))
					AND (wp3.A_STATUS = @status OR wp3.A_STATUS IS NULL)
					) z ON pay.OUID = z.OUID
			INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID =  pay.A_STATUS or pay.A_STATUS is null) and  servstut.A_CODE=4
			INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP=serv.OUID
			INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV =nmc.A_ID and nmc.A_CODE='compMilitaryFam'
			INNER JOIN WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK =book.OUID
			INNER JOIN WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
			INNER JOIN SPR_PAY_TYPE type ON payment.DELIVERYWAY =type.A_ID and type.A_COD=@codeOrg
			INNER JOIN WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId
			GROUP BY deduc.A_OUID) as temp
			-- "Размер удержания, руб." на тек.месяц      
            SELECT @DEDUGDIFF = SUM(temp.AMOUNT)  from (                                        
			SELECT SUM(deducLog.A_AMOUNT) as AMOUNT 
			FROM WM_DEDUCTION_LOG deducLog 														    
			INNER JOIN WM_DEDUCTION deduc ON deducLog.A_DEDUCTION=deduc.A_ID 
			           AND YEAR(deduc.A_OVERPAYSTART) = @iYear AND MONTH(deduc.A_OVERPAYSTART) = @iMonth	
			INNER JOIN WM_PAY_CALC pay ON pay.OUID=deducLog.A_PAYCALC
			           AND deducLog.A_YEAR = pay.A_YEAR AND deducLog.A_MONTH = pay.A_MONTH
			           AND (pay.A_YEAR < @year OR (pay.A_YEAR = @year AND pay.A_MONTH <= @month))
			INNER JOIN SPR_STATUS_PROCESS status ON pay.A_STATUSPRIVELEGE = status.A_ID and status.A_CODE=100
			INNER JOIN ESRN_SERV_STATUS servstut ON (servstut.A_ID =  pay.A_STATUS or pay.A_STATUS is null) and  servstut.A_CODE=4
			INNER JOIN ESRN_SERV_SERV serv ON pay.A_MSP=serv.OUID
			INNER JOIN SPR_NPD_MSP_CAT nmc ON  serv.A_SERV =nmc.A_ID and nmc.A_CODE='compMilitaryFam'
			INNER JOIN WM_PAYMENT_BOOK book ON serv.A_PAYMENTBOOK =book.OUID
			INNER JOIN WM_PAYMENT payment ON book.A_ACTREQUISIT = payment.OUID
			INNER JOIN SPR_PAY_TYPE type ON payment.DELIVERYWAY =type.A_ID and type.A_COD=@codeOrg
			INNER JOIN WM_PERSONAL_CARD AS PC ON PC.OUID= pay.PERSONOUID and PC.OUID=@pcId
			GROUP BY deducLog.A_OUID) as temp
       
            -- сумма на текущий месяц
			SET @TOTAL = ISNULL(@AMOUNT, 0) - ISNULL(@DOPLAT, 0) + ISNULL(@DEDUG, 0) + ISNULL(@DOPLATDIFF, 0) - ISNULL(@DEDUGDIFF, 0)
            -- название текущего месяца
			SET @iMonthName = (SELECT CASE @iMonth        
										WHEN 1 THEN 'январь' WHEN 2 THEN 'февраль'  WHEN 3 THEN 'март' WHEN 4 THEN 'апрель'									        								       							        
										WHEN 5 THEN 'май' WHEN 6 THEN 'июнь' when 7 THEN 'июль' WHEN 8 THEN 'август'									        								        							        
										WHEN 9 THEN 'сентябрь' WHEN 10 THEN 'октябрь' WHEN 11 THEN 'ноябрь' WHEN 12 THEN 'декабрь'								        								        								        
										ELSE '' END)
            
            IF (ROUND(@TOTAL, 2) < 0 OR ROUND(@TOTAL, 2) > 0) BEGIN
				IF (@iYear = @year AND @iMonth = @month) BEGIN
					-- если год-месяц совпал с годом-месяцем выгрузки
					SET @CURSUM = @TOTAL  
				END ELSE IF (@iYear < @year OR (@iYear = @year AND @iMonth < @month)) BEGIN
					-- считаем сумме ДО  года-месяца выгрузки
					SET @SUM1 = @SUM1 + @TOTAL  
					IF (@FROMDATE1 = '') BEGIN
						SET @FROMDATE1 = @iMonthName + ' ' + CAST(@iYear as varchar(4)) + 'г.' 
					END
					SET @TODATE1 = @iMonthName + ' ' + CAST(@iYear as varchar(4)) + 'г.'
				END ELSE IF (@iYear > @year OR (@iYear = @year AND @iMonth > @month)) BEGIN
					-- считаем сумме ПОСЛЕ года-месяца выгрузки
					SET @SUM2 = @SUM2 + @TOTAL  
					IF (@FROMDATE2 = '') BEGIN
						SET @FROMDATE2 = @iMonthName + ' ' + CAST(@iYear as varchar(4)) + 'г.' 
					END
					SET @TODATE2 = @iMonthName + ' ' + CAST(@iYear as varchar(4)) + 'г.'
				END 
            END

			IF (@iYear = @maxYear AND @iMonth = @maxMonth) BEGIN
			  -- если последний месяц, то выходим
			  BREAK
			END
			SET @iMonth = @iMonth + 1
		END
		SET @iMonth = 1
		SET @iYear = @iYear + 1
    END
    
    -- название месяца выгрузки
    DECLARE @monthName varchar(20)
	SET @monthName = (SELECT CASE @month        
								WHEN 1 THEN 'январь' WHEN 2 THEN 'февраль'  WHEN 3 THEN 'март' WHEN 4 THEN 'апрель'									        								       							        
								WHEN 5 THEN 'май' WHEN 6 THEN 'июнь' when 7 THEN 'июль' WHEN 8 THEN 'август'									        								        							        
								WHEN 9 THEN 'сентябрь' WHEN 10 THEN 'октябрь' WHEN 11 THEN 'ноябрь' WHEN 12 THEN 'декабрь'								        								        								        
								ELSE '' END)
					
	IF (@SUM1 < 0) BEGIN
	    SET @tempSum = '(' + CAST(@SUM1 as varchar(30)) + ')'		          	
	END	ELSE BEGIN
		SET @tempSum = CAST(@SUM1 as varchar(30))		
    END		    					
    IF (@FROMDATE1 <> '') BEGIN
		IF (@TODATE1 <> @FROMDATE1) BEGIN
			SET @sumDetail = @sumDetail + @FROMDATE1 + ' - ' + @TODATE1 + ' - ' + @tempSum + ' '
		END ELSE BEGIN
			SET @sumDetail = @sumDetail + @FROMDATE1 + ' - ' + @tempSum + ' '
        END
    END
    
	IF (@SUM2 < 0) BEGIN
	    SET @tempSum = '(' + CAST(@SUM2 as varchar(30)) + ')'		          	
	END	ELSE BEGIN
		SET @tempSum = CAST(@SUM2 as varchar(30))		
    END	    
    IF (@FROMDATE2 <> '') BEGIN
		IF (@sumDetail <> '') BEGIN
			SET @sumDetail = @sumDetail + '; '
		END 
		IF (@TODATE2 <> @FROMDATE2) BEGIN
			SET @sumDetail = @sumDetail + @FROMDATE2 + ' - ' + @TODATE2 + ' - ' + @tempSum + ';'
		END ELSE BEGIN
			SET @sumDetail = @sumDetail + @FROMDATE2 + ' - ' + @tempSum + '; ' 
        END
    END
    IF (@CURSUM > 0) BEGIN
		IF (@sumDetail <> '') BEGIN
			SET @sumDetail = @sumDetail + '; '
		END 
		SET @sumDetail = @sumDetail + @monthName + ' ' + CAST(@year as varchar(4)) + ' г.'  + ' - ' + CAST(@CURSUM as varchar(30)) + ' '
    END 
    RETURN @sumDetail
END
go

