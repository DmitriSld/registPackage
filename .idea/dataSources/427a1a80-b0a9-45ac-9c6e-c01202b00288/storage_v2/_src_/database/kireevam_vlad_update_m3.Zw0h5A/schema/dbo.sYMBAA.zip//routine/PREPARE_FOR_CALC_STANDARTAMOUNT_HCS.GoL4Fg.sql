
CREATE PROCEDURE [dbo].[PREPARE_FOR_CALC_STANDARTAMOUNT_HCS]
	@uuid varchar(100)
AS 
DECLARE @activeStatusId         INT,
        @isAutoReceipt          INT,
		@groupId                INT,
		@personId               INT,
		@npdMspCat              INT,
        @petition               INT,
		@servServ               INT,
		@beginDate              datetime,
		@endDate                datetime,
		@endGroupDate           datetime,
		@FROMDATE               datetime,
		@TODATE                 datetime,
		@tmpDATE                datetime,
		@heatingDATE            datetime,
		@date                   datetime,
		@dType                  varchar(10),
        @mspId                  INT,
		@groupCombinationCount  INT,
        @pcMspCatMpdCount       INT,
        @combination            INT,
		@iCombination           INT,
		@isTrue                 INT,
        @i                      INT,
		@j                      INT,
		@iterCount              INT,
		@pcIter                 INT,
        @mspCatMpdIter          INT,
        @num                    INT


/* статус активен */
SELECT @activeStatusId = es.A_ID
FROM   ESRN_SERV_STATUS es
WHERE  es.a_statuscode = 'act'

/*признак перерасчета по квитанциям*/
SET  @isAutoReceipt = (SELECT TOP 1 ISNULL(A_AUTO_RECEIPT, 0) 
                       FROM TMP_PC_NPDMSPCAT 
                       WHERE A_PROCESSUUID = @uuid)
SET @isAutoReceipt = 1

UPDATE TMP_PC_NPDMSPCAT 
SET A_ENDGROUPDATE = (SELECT MAX(tmp.A_ENDDATE) FROM TMP_PC_NPDMSPCAT tmp WHERE tmp.A_GROUPHCS = A_GROUPHCS)

-- таблица с данными о рассматриваемых периодах
DECLARE @timeTable TABLE(TMP_PC_NPDMSPCAT INT,
                         A_GROUPHCS INT,
						 A_PERSON INT,
						 A_PETITION INT,
						 A_SERVSERV INT,
						 A_NPDMSPCAT INT,
						 A_BEGINDATE datetime,
						 A_ENDDATE datetime)

/*получаем разбиение на периоды*/
DECLARE pcCur CURSOR  
FOR 
SELECT  tmpPc.A_ID, 
		tmpPc.A_GROUPHCS,
		tmpPc.A_PERSON,
		tmpPc.A_PETITION,
		tmpPc.A_SERVSERV,
		tmpPc.A_NPDMSPCAT,
		tmpPc.A_BEGINDATE,		
		tmpPc.A_ENDDATE,
		tmpPc.A_ENDGROUPDATE
FROM TMP_PC_NPDMSPCAT tmpPc
WHERE tmpPc.A_PROCESSUUID = @uuid

OPEN pcCur
FETCH NEXT FROM pcCur INTO @i, @groupId, @personId, @petition, @servServ, @npdMspCat, @beginDate, @endDate, @endGroupDate

WHILE @@FETCH_STATUS = 0
BEGIN
    -- текуший месяц +3
	SET @date = DATEADD(month, 3, ISNULL(@endGroupDate, GETDATE()))
    SET @FROMDATE = @beginDate 
	SET @TODATE = @endDate

	SET @isTrue = 1
    -- идем по месяцам и делим периоды по месячно (от даты перерасчета до текущий месяц + 2)
    WHILE (@isTrue = 1) BEGIN
		SET @tmpDATE = @FROMDATE
		-- первое числое следующего месяца
	    SET @tmpDATE = DATEADD(month, 1, @tmpDATE)
		SET @tmpDATE = DATEADD(day, 1 - DAY(@tmpDATE), @tmpDATE)       
		IF ((@TODATE IS NOT NULL AND
            (YEAR(@tmpDATE) < YEAR(@TODATE) OR 
            (YEAR(@tmpDATE) = YEAR(@TODATE) AND MONTH(@tmpDATE) <= MONTH(@TODATE))))
            OR 
            (@TODATE IS NULL AND
			(YEAR(@tmpDATE) < YEAR(@date) OR 
            (YEAR(@tmpDATE) = YEAR(@date) AND MONTH(@tmpDATE) <= MONTH(@date))))) BEGIN
			-- проверяем на смену отопительных периодов (летний/зимний)
			IF OBJECT_ID('SPR_HEATING_PERIOD','U') IS NOT NULL BEGIN
			   SET @heatingDATE = (SELECT A_PERIODFROM 
								  FROM SPR_HEATING_PERIOD
								  WHERE YEAR(A_PERIODFROM) = YEAR(@FROMDATE)
								  AND MONTH(A_PERIODFROM) = MONTH(@FROMDATE)
								  AND DAY(A_PERIODFROM) > 1
								  AND DAY(A_PERIODFROM) > DAY(@FROMDATE)
			                      AND (@TODATE IS NULL 
			                      OR YEAR(A_PERIODFROM) < YEAR(@TODATE)
			                      OR (YEAR(A_PERIODFROM) = YEAR(@TODATE)
								  AND MONTH(A_PERIODFROM) < MONTH(@TODATE))
			                      OR (YEAR(A_PERIODFROM) = YEAR(@TODATE)
								  AND MONTH(A_PERIODFROM) = MONTH(@TODATE)
			                      AND DAY(A_PERIODFROM) < DAY(@TODATE))) )
			   IF (@heatingDATE IS NOT NULL) BEGIN
					-- сохраняем данные о периоде до смены периола
					INSERT INTO @timeTable(TMP_PC_NPDMSPCAT, A_GROUPHCS, A_PERSON, A_PETITION, 
										   A_SERVSERV, A_NPDMSPCAT, A_BEGINDATE, A_ENDDATE)
					SELECT @i, @groupId, @personId, @petition, @servServ,
						@npdMspCat, @FROMDATE, DATEADD(day, -1, @heatingDATE)

					SET @FROMDATE = @heatingDATE                            	
			   END							                                                         	
			END             	
			-- сохраняем данные о рассматриваемом периоде
			INSERT INTO @timeTable(TMP_PC_NPDMSPCAT, A_GROUPHCS, A_PERSON, A_PETITION, 
								   A_SERVSERV, A_NPDMSPCAT, A_BEGINDATE, A_ENDDATE)
			SELECT @i, @groupId, @personId, @petition, @servServ,
				@npdMspCat, @FROMDATE, DATEADD(day, -1, @tmpDATE)

			SET @FROMDATE = @tmpDATE
		END ELSE BEGIN
			SET @isTrue = 0
        END
    END
    
	-- проверяем на смену отопительных периодов (летний/зимний)
	IF OBJECT_ID('SPR_HEATING_PERIOD','U') IS NOT NULL BEGIN
	   SET @heatingDATE = (SELECT A_PERIODFROM 
						  FROM SPR_HEATING_PERIOD
						  WHERE YEAR(A_PERIODFROM) = YEAR(@FROMDATE)
						  AND MONTH(A_PERIODFROM) = MONTH(@FROMDATE)
						  AND DAY(A_PERIODFROM) > 1
						  AND DAY(A_PERIODFROM) > DAY(@FROMDATE)
	                      AND (@TODATE IS NULL 
	                      OR YEAR(A_PERIODFROM) < YEAR(@TODATE)
	                      OR (YEAR(A_PERIODFROM) = YEAR(@TODATE)
						  AND MONTH(A_PERIODFROM) < MONTH(@TODATE))
	                      OR (YEAR(A_PERIODFROM) = YEAR(@TODATE)
						  AND MONTH(A_PERIODFROM) = MONTH(@TODATE)
	                      AND DAY(A_PERIODFROM) < DAY(@TODATE))))
	   IF (@heatingDATE IS NOT NULL) BEGIN
			-- сохраняем данные о периоде до смены периола
			INSERT INTO @timeTable(TMP_PC_NPDMSPCAT, A_GROUPHCS, A_PERSON, A_PETITION, 
								   A_SERVSERV, A_NPDMSPCAT, A_BEGINDATE, A_ENDDATE)
			SELECT @i, @groupId, @personId, @petition, @servServ,
				@npdMspCat, @FROMDATE, DATEADD(day, -1, @heatingDATE)

			SET @FROMDATE = @heatingDATE                            	
	   END							                                                         	
	END   
	-- сохраняем данные о рассматриваемом периоде
	INSERT INTO @timeTable(TMP_PC_NPDMSPCAT, A_GROUPHCS, A_PERSON, A_PETITION, 
						   A_SERVSERV, A_NPDMSPCAT, A_BEGINDATE, A_ENDDATE)
	SELECT @i, @groupId, @personId, @petition, @servServ,
		@npdMspCat, @FROMDATE, @TODATE

	FETCH NEXT FROM pcCur INTO @i, @groupId, @personId, @petition, @servServ, @npdMspCat, @beginDate, @endDate, @endGroupDate
END 
CLOSE pcCur
DEALLOCATE pcCur

DELETE FROM TMP_DEP_PC_NPDMSPCAT WHERE A_PROCESSUUID = @uuid
DELETE FROM TMP_DEP_PC_LINK WHERE A_PROCESSUUID = @uuid

/* создаем всевозможные комбинции для рассматриваемых периодов*/
DECLARE groupsCur CURSOR  
FOR 
SELECT DISTINCT A_GROUPHCS AS groupId
FROM TMP_PC_NPDMSPCAT
WHERE A_PROCESSUUID = @uuid

OPEN groupsCur
FETCH NEXT FROM groupsCur INTO @groupId

SET @combination = 0
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @num = 0
    /*общее кол-во комбинаций для этой группы*/
    SET @groupCombinationCount = ISNULL((SELECT exp(sum(log(abs(query.npdMspCat)))) FROM
                                  (SELECT COUNT(DISTINCT A_NPDMSPCAT) npdMspCat
                                   FROM TMP_PC_NPDMSPCAT
                                   INNER JOIN SPR_NPD_MSP_CAT 
                                   ON TMP_PC_NPDMSPCAT.A_NPDMSPCAT = SPR_NPD_MSP_CAT.A_ID
                                   WHERE TMP_PC_NPDMSPCAT.A_GROUPHCS = @groupId
                                   AND TMP_PC_NPDMSPCAT.A_PROCESSUUID = @uuid
                                   GROUP BY TMP_PC_NPDMSPCAT.A_PERSON, SPR_NPD_MSP_CAT.A_MSP) query),0)

	DECLARE personCur CURSOR  
    FOR 
	SELECT TMP_PC_NPDMSPCAT.A_PERSON AS personId, SPR_NPD_MSP_CAT.A_MSP AS mspId
	FROM TMP_PC_NPDMSPCAT
    INNER JOIN SPR_NPD_MSP_CAT ON TMP_PC_NPDMSPCAT.A_NPDMSPCAT = SPR_NPD_MSP_CAT.A_ID
	WHERE TMP_PC_NPDMSPCAT.A_GROUPHCS = @groupId
    AND TMP_PC_NPDMSPCAT.A_PROCESSUUID = @uuid
    GROUP BY TMP_PC_NPDMSPCAT.A_PERSON, SPR_NPD_MSP_CAT.A_MSP

    OPEN personCur
	FETCH NEXT FROM personCur INTO @personId, @mspId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @iCombination = @combination
        /*кол-во всевсозможных МСП-ЛК-НПД для этого ЛД*/
        SET @pcMspCatMpdCount = ISNULL((SELECT COUNT(DISTINCT TMP_PC_NPDMSPCAT.A_NPDMSPCAT)
                                 FROM TMP_PC_NPDMSPCAT
                                 INNER JOIN SPR_NPD_MSP_CAT 
                                 ON TMP_PC_NPDMSPCAT.A_NPDMSPCAT = SPR_NPD_MSP_CAT.A_ID
                                 WHERE TMP_PC_NPDMSPCAT.A_GROUPHCS = @groupId
                                 AND TMP_PC_NPDMSPCAT.A_PROCESSUUID = @uuid
								 AND TMP_PC_NPDMSPCAT.A_PERSON = @personId
                                 AND SPR_NPD_MSP_CAT.A_MSP = @mspId),0)
		SET @iterCount = @groupCombinationCount/@pcMspCatMpdCount
        IF (@pcMspCatMpdCount > 1) BEGIN
          SET @num = @num + 1
		  SET @pcIter = @iterCount/@num
        END ELSE BEGIN
          SET @pcIter = 1
        END
		SET @i = 0
		WHILE (@i < @pcIter) BEGIN
            SET @i = @i + 1
			DECLARE npdMspCatCur CURSOR  
			FOR 
			SELECT DISTINCT TMP_PC_NPDMSPCAT.A_NPDMSPCAT AS npdMspCatId
			FROM TMP_PC_NPDMSPCAT
            INNER JOIN SPR_NPD_MSP_CAT ON TMP_PC_NPDMSPCAT.A_NPDMSPCAT = SPR_NPD_MSP_CAT.A_ID
			WHERE TMP_PC_NPDMSPCAT.A_GROUPHCS = @groupId
            AND TMP_PC_NPDMSPCAT.A_PROCESSUUID = @uuid
			AND TMP_PC_NPDMSPCAT.A_PERSON = @personId
            AND SPR_NPD_MSP_CAT.A_MSP = @mspId

			OPEN npdMspCatCur
			FETCH NEXT FROM npdMspCatCur INTO @npdMspCat
			WHILE @@FETCH_STATUS = 0
			BEGIN		
				SET @j = 0
				IF (@pcMspCatMpdCount > 1) BEGIN
				  SET @mspCatMpdIter = @num
				END ELSE BEGIN
				  SET @mspCatMpdIter = @groupCombinationCount
				END
				WHILE (@j < @mspCatMpdIter) BEGIN						
					SET @j = @j + 1
					/* формируем комбинации данные в таблицу для дальнейших расчётов */
					INSERT INTO TMP_DEP_PC_NPDMSPCAT(A_PROCESSUUID, A_GROUPHCS, A_PERSON, A_PETITION,
						A_SERVSERV, A_NPDMSPCAT, A_BDATE, A_EDATE, A_HCS, 
                        A_COMBINATION, A_PERCENT, A_CALCTYPE, A_TSQUARE, A_HSQUARE, A_TARIF, 
                        A_NORM, A_FACTOR, A_AREA_COUNT, A_SPHERE, 
                        A_HCVRATE, 
                        A_HCVRATEFAMILY, 
                        A_SAHCS, 
                        A_HCV_RATE_RECIEPT)
					SELECT @uuid, tmp.A_GROUPHCS, tmp.A_PERSON, tmp.A_PETITION,
                        tmp.A_SERVSERV, tmp.A_NPDMSPCAT, tmp.A_BEGINDATE, tmp.A_ENDDATE, NULL,
                        @iCombination, NULL, SPR_NPD_MSP_CAT.A_CALC_ALGORITHM, NULL, NULL, NULL,  
						NULL, 0, 0,  SPR_NPD_MSP_CAT.A_SPHERE, 
                        ISNULL(TMP_SAHCS_DATA.A_HCVRATE, 0),   
					    ISNULL(TMP_SAHCS_DATA.A_HCVRATEFAMILY, 0), 
                        NULL, 
                        ISNULL(TMP_SAHCS_DATA.A_HCV_RATE_RECIEPT, 0)
					FROM @timeTable tmp
					INNER JOIN SPR_NPD_MSP_CAT 
                    ON tmp.A_NPDMSPCAT = SPR_NPD_MSP_CAT.A_ID
					INNER JOIN TMP_SAHCS_DATA 
                    ON tmp.TMP_PC_NPDMSPCAT = TMP_SAHCS_DATA.A_TMP_PC_NMC_LINK
                    AND TMP_SAHCS_DATA.A_PROCESSUUID = @uuid
					WHERE tmp.A_GROUPHCS = @groupId 
					AND tmp.A_PERSON = @personId
					AND tmp.A_NPDMSPCAT = @npdMspCat 
               				
					SET @iCombination = @iCombination + 1
				END
				FETCH NEXT FROM npdMspCatCur INTO @npdMspCat
			END            			
			CLOSE npdMspCatCur
			DEALLOCATE npdMspCatCur
		END
		FETCH NEXT FROM personCur INTO @personId, @mspId
	END
	CLOSE personCur
	DEALLOCATE personCur

    SET @combination = @combination + @groupCombinationCount
	FETCH NEXT FROM groupsCur INTO @groupId
END
CLOSE groupsCur
DEALLOCATE groupsCur

/*Используем ФВ*/
UPDATE TMP_DEP_PC_NPDMSPCAT
SET A_HCVRATE = ISNULL(Q.FV_HCVRATE, A_HCVRATE), 
A_HCVRATEFAMILY= ISNULL(Q.FV_HCVRATEFAMILY, A_HCVRATEFAMILY),   
A_HCV_RATE_RECIEPT= ISNULL(Q.FV_HCV_RATE_RECIEPT, A_HCV_RATE_RECIEPT)
FROM (
    SELECT tmp.A_ID, 
          (SELECT MAX(A_VALUE) 
        FROM PPR_FINANCE_VALUE
        WHERE (A_STATUS IS NULL OR A_STATUS = @activeStatusId)
        AND A_FINANCE_UNIT = SPR_NPD_MSP_CAT.A_FV_HCV_RATE_SS
        AND (tmp.A_EDATE IS NULL
             OR A_BEGIN_DATE IS NULL
             OR YEAR(A_BEGIN_DATE) < YEAR(tmp.A_EDATE)
             OR (YEAR(A_BEGIN_DATE) = YEAR(tmp.A_EDATE) AND MONTH(A_BEGIN_DATE) < MONTH(tmp.A_EDATE))
             OR (YEAR(A_BEGIN_DATE) = YEAR(tmp.A_EDATE) AND MONTH(A_BEGIN_DATE) = MONTH(tmp.A_EDATE) AND DAY(A_BEGIN_DATE) <= DAY(tmp.A_EDATE))
             )
        AND (tmp.A_EDATE IS NULL
             OR A_END_DATE IS NULL
             OR YEAR(A_END_DATE) > YEAR(tmp.A_BDATE)
             OR (YEAR(A_END_DATE) = YEAR(tmp.A_BDATE) AND MONTH(A_END_DATE) > MONTH(tmp.A_BDATE))
             OR (YEAR(A_END_DATE) = YEAR(tmp.A_BDATE) AND MONTH(A_END_DATE) = MONTH(tmp.A_BDATE) AND DAY(A_END_DATE) >= DAY(tmp.A_BDATE))
             )                                     
       ) FV_HCVRATE,   
		(SELECT MAX(A_VALUE) 
         FROM PPR_FINANCE_VALUE
        WHERE (A_STATUS IS NULL OR A_STATUS = @activeStatusId)
        AND A_FINANCE_UNIT = SPR_NPD_MSP_CAT.A_FV_HCV_RATE_FAMILY
        AND (tmp.A_EDATE IS NULL
             OR A_BEGIN_DATE IS NULL
             OR YEAR(A_BEGIN_DATE) < YEAR(tmp.A_EDATE)
             OR (YEAR(A_BEGIN_DATE) = YEAR(tmp.A_EDATE) AND MONTH(A_BEGIN_DATE) < MONTH(tmp.A_EDATE))
             OR (YEAR(A_BEGIN_DATE) = YEAR(tmp.A_EDATE) AND MONTH(A_BEGIN_DATE) = MONTH(tmp.A_EDATE) AND DAY(A_BEGIN_DATE) <= DAY(tmp.A_EDATE))
             )
        AND (tmp.A_BDATE IS NULL
             OR A_END_DATE IS NULL
             OR YEAR(A_END_DATE) > YEAR(tmp.A_BDATE)
             OR (YEAR(A_END_DATE) = YEAR(tmp.A_BDATE) AND MONTH(A_END_DATE) > MONTH(tmp.A_BDATE))
             OR (YEAR(A_END_DATE) = YEAR(tmp.A_BDATE) AND MONTH(A_END_DATE) = MONTH(tmp.A_BDATE) AND DAY(A_END_DATE) >= DAY(tmp.A_BDATE))
             )                                     
         ) FV_HCVRATEFAMILY, 
        (SELECT MAX(A_VALUE) 
        FROM PPR_FINANCE_VALUE
        WHERE (A_STATUS IS NULL OR A_STATUS = @activeStatusId)
        AND A_FINANCE_UNIT = SPR_NPD_MSP_CAT.A_FV_HCV_RATE_RECIEPT
        AND (tmp.A_EDATE IS NULL
             OR A_BEGIN_DATE IS NULL
             OR YEAR(A_BEGIN_DATE) < YEAR(tmp.A_EDATE)
             OR (YEAR(A_BEGIN_DATE) = YEAR(tmp.A_EDATE) AND MONTH(A_BEGIN_DATE) < MONTH(tmp.A_EDATE))
             OR (YEAR(A_BEGIN_DATE) = YEAR(tmp.A_EDATE) AND MONTH(A_BEGIN_DATE) = MONTH(tmp.A_EDATE) AND DAY(A_BEGIN_DATE) <= DAY(tmp.A_EDATE))
             )
        AND (tmp.A_BDATE IS NULL
             OR A_END_DATE IS NULL
             OR YEAR(A_END_DATE) > YEAR(tmp.A_BDATE)
             OR (YEAR(A_END_DATE) = YEAR(tmp.A_BDATE) AND MONTH(A_END_DATE) > MONTH(tmp.A_BDATE))
             OR (YEAR(A_END_DATE) = YEAR(tmp.A_BDATE) AND MONTH(A_END_DATE) = MONTH(tmp.A_BDATE) AND DAY(A_END_DATE) >= DAY(tmp.A_BDATE))
             )                                     
       ) FV_HCV_RATE_RECIEPT
  FROM TMP_DEP_PC_NPDMSPCAT tmp
  INNER JOIN SPR_NPD_MSP_CAT 
  ON tmp.A_NPDMSPCAT = SPR_NPD_MSP_CAT.A_ID  
  WHERE tmp.A_PROCESSUUID = @uuid                             
) Q
WHERE TMP_DEP_PC_NPDMSPCAT.A_PROCESSUUID = @uuid AND TMP_DEP_PC_NPDMSPCAT.A_ID = Q.A_ID

/*Кол-во членов группы*/
UPDATE TMP_DEP_PC_NPDMSPCAT
SET A_ALL_PERSONS = ISNULL(
		(SELECT COUNT(DISTINCT link.A_TOID)
        FROM WM_GROUPHCS_PERSCARD link
        WHERE (link.A_STATUS IS NULL OR link.A_STATUS = @activeStatusId)
        AND TMP_DEP_PC_NPDMSPCAT.A_GROUPHCS = link.A_FROMID
		-- член группы в данный период
		AND (link.A_DATE_IN IS NULL 
		OR YEAR(link.A_DATE_IN) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		OR (YEAR(link.A_DATE_IN) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		AND MONTH(link.A_DATE_IN) < MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
		OR (YEAR(link.A_DATE_IN) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		AND MONTH(link.A_DATE_IN) = MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		AND DAY(link.A_DATE_IN) <= DAY(TMP_DEP_PC_NPDMSPCAT.A_BDATE))		
		)
		AND (link.A_DATE_OUT IS NULL 
		OR YEAR(link.A_DATE_OUT) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		OR (YEAR(link.A_DATE_OUT) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		AND MONTH(link.A_DATE_OUT) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
		)
        ) ,0)
WHERE A_PROCESSUUID = @uuid

/*Раcсчитываем стандарт стоимости ЖКУ*/
DECLARE depPcCur CURSOR  
FOR 
SELECT A_BDATE as beginDate
FROM TMP_DEP_PC_NPDMSPCAT
WHERE A_PROCESSUUID = @uuid
GROUP BY A_BDATE 

OPEN depPcCur
FETCH NEXT FROM depPcCur INTO @beginDate

WHILE @@FETCH_STATUS = 0
BEGIN
	UPDATE TMP_DEP_PC_NPDMSPCAT 
	SET A_SAHCS = ISNULL(QUERY.SSHCS, 0)
	FROM (SELECT * FROM GET_REGSTANDARTHCS_PROC(@beginDate, @uuid)) QUERY				   
    WHERE A_PROCESSUUID = @uuid
    AND QUERY.HCS_GROUP_ID = TMP_DEP_PC_NPDMSPCAT.A_GROUPHCS
    AND @beginDate = TMP_DEP_PC_NPDMSPCAT.A_BDATE
    
    FETCH NEXT FROM depPcCur INTO @beginDate 
END 
CLOSE depPcCur
DEALLOCATE depPcCur

/*Определяем наличие квитанций на конкретный период*/
UPDATE TMP_DEP_PC_NPDMSPCAT
SET A_RCPT_AMOUNT_SUM = ISNULL(
	
(SELECT	
SUM(CASE WHEN amount <= norm OR norm IS NULL 
		THEN amount
		ELSE norm
	END )
	
	
FROM (SELECT 	
	  min(isnull(cast(tarif.amount AS NUMERIC(18,2)),0) * 		
		isnull(cast(CASE WHEN  sprHscTypes.A_CODE = '58830' 
						then socNorm.A_NORM			
						else hcsNorm.amount
					END 		
		 AS NUMERIC(18,2)),0) *	
		cast(			
			CASE 
				WHEN socNorm.A_OUID IS NOT NULL THEN isnull(socNorm.A_PERSNUM,0)
				WHEN hcsNorm.A_NORMTYPE = 'family'  THEN 1
				WHEN hcsNorm.A_NORMTYPE = 'person'  THEN isnull(hcsNorm.A_NUMPEOPLE,0)
				ELSE 0
			END  AS NUMERIC(18,2))/*	*
		cast(			
			CASE WHEN hcsNorm.A_NORMTYPE = 'metr'
				THEN isnull(socNorm.A_NORM,0)
				ELSE 1
			END  AS NUMERIC(18,2))*/	
			
							
	) AS norm,
	SUM(rcptAmount.A_PAY) as  amount
	
	FROM WM_RECEIPT rcpt	
	INNER JOIN WM_RECEIPT_AMOUNT rcptAmount ON rcptAmount.A_RECEIPT = rcpt.A_OUID
		AND (rcptAmount.A_STATUS IS NULL OR rcptAmount.A_STATUS = @activeStatusId)		
	INNER JOIN SPR_HSC_TYPES sprHscTypes ON sprHscTypes.A_ID = rcptAmount.A_NAME_AMOUNT
		AND (sprHscTypes.A_STATUS IS NULL OR sprHscTypes.A_STATUS = @activeStatusId)	
	
	LEFT JOIN (SELECT 
				hcs.A_OUID hcsId,
				sprTownMo.A_MO ,
				flatCond.A_ROOM,
				ROW_NUMBER () OVER ( PARTITION BY hcs.A_OUID ORDER BY sprTownMo.A_MO desc) num 
				FROM WM_GROUP_HCS hcs
				INNER JOIN WM_ADDRESS addr ON hcs.A_ADRESS = addr.OUID
					AND(addr.A_STATUS = @activeStatusId OR addr.A_STATUS IS NULL)			
				LEFT JOIN WM_FLAT_CONDITION flatCond ON addr.OUID = flatCond.A_FLAT
					AND (flatCond.A_STATUS = @activeStatusId OR flatCond.A_STATUS IS NULL)
				INNER JOIN SPR_TOWN sprTown ON sprTown.OUID = addr.A_TOWN	
				INNER JOIN (SELECT 
							sprTownMo.A_TOWN,
							sprTownMo.A_MO,
							ROW_NUMBER () OVER ( PARTITION BY sprTownMo.A_TOWN ORDER BY sprTownMo.A_DATE_START DESC) num 
							FROM SPR_TOWN_MOHISTORY sprTownMo
							WHERE 	(DATEDIFF(DAY,sprTownMo.A_DATE_START,TMP_DEP_PC_NPDMSPCAT.A_BDATE) >= 0 OR	sprTownMo.A_DATE_START IS NULL)
								AND (DATEDIFF(DAY,TMP_DEP_PC_NPDMSPCAT.A_BDATE,sprTownMo.A_DATE_END)   >= 0 OR sprTownMo.A_DATE_END   IS NULL)			
				) sprTownMo ON sprTownMo.A_TOWN = sprTown.OUID AND sprTownMo.num = 1	
				WHERE (hcs.A_STATUS = @activeStatusId OR hcs.A_STATUS IS NULL)		
	) flatCond ON flatCond.hcsId = TMP_DEP_PC_NPDMSPCAT.A_GROUPHCS
		AND flatCond.num = 1		
		
	LEFT JOIN(  SELECT 
				socNorm.A_OUID,
				socNorm.A_PERSNUM,
				socNorm.A_NORM,
				ROW_NUMBER () OVER ( PARTITION BY socNorm.A_PERSNUM ORDER BY socNorm.A_BDATE DESC) num
				FROM SPR_SOCNORM socNorm		
				WHERE (socNorm.A_STATUS IS NULL OR socNorm.A_STATUS = @activeStatusId)
					AND DATEDIFF(DAY,socNorm.A_BDATE,TMP_DEP_PC_NPDMSPCAT.A_BDATE)>=0
					AND (DATEDIFF(DAY,TMP_DEP_PC_NPDMSPCAT.A_BDATE,socNorm.A_EDATE)>=0 OR socNorm.A_EDATE IS NULL)	
	) socNorm ON socNorm.A_PERSNUM = TMP_DEP_PC_NPDMSPCAT.A_ALL_PERSONS		
		AND socNorm.num = 1		
		
	LEFT JOIN (	SELECT 
				sprHcsNorm.A_MO,
				sprHcsNorm.A_HCSTYPE,	
				socNormHcs.A_NORMTYPE,
				socNormHcs.A_VALUE amount, 
				socNormHcs.A_NUMPEOPLE,	
				socNormHcs.A_ROOM_NUMBER,			
				ROW_NUMBER () OVER ( PARTITION BY sprHcsNorm.A_HCSTYPE,socNormHcs.A_NORMTYPE,sprHcsNorm.A_MO,socNormHcs.A_ROOM_NUMBER ORDER BY CASE WHEN (socNormHcs.A_NUMPEOPLE = 2 OR socNormHcs.A_NORMTYPE = 'family') THEN 0 ELSE 1 END,  socNormHcs.A_START_DATE DESC) num		
				FROM SPR_HCSNORM sprHcsNorm 		
				INNER JOIN SPR_HCS_NORM_AM socNormHcs ON socNormHcs.A_HCS_TYPE = sprHcsNorm.A_OUID
					AND  DATEDIFF(DAY,socNormHcs.A_START_DATE,TMP_DEP_PC_NPDMSPCAT.A_BDATE)>=0
					AND (DATEDIFF(DAY,TMP_DEP_PC_NPDMSPCAT.A_BDATE,socNormHcs.A_FINISH_DATE)>=0 OR socNormHcs.A_FINISH_DATE IS NULL)
 	) hcsNorm ON hcsNorm.A_HCSTYPE = sprHscTypes.A_ID 
 		AND hcsNorm.A_MO = flatCond.A_MO
 		AND (flatCond.A_ROOM = hcsNorm.A_ROOM_NUMBER OR (hcsNorm.A_ROOM_NUMBER IS NULL  ))
		AND hcsNorm.num = 1
		
	LEFT JOIN(	SELECT 
				sprTarif.A_TYPE,
				sprTarif.A_MO,
				sprTarifperiod.A_AMOUNT amount,
				sprTarif.A_SUPPLIER,
				ROW_NUMBER () OVER ( PARTITION BY sprTarif.A_MO,sprTarif.A_TYPE,sprTarif.A_SUPPLIER ORDER BY sprTarifperiod.A_START_DATE )num 		
				FROM SPR_TARIF sprTarif 		
				INNER JOIN SPR_TARIF_PERIOD sprTarifperiod ON sprTarifperiod.A_SERV = sprTarif.OUID
					AND (sprTarifperiod.A_STATUS IS NULL OR sprTarifperiod.A_STATUS = @activeStatusId)
					AND datediff(day,sprTarifperiod.A_START_DATE,TMP_DEP_PC_NPDMSPCAT.A_BDATE)>=0
					AND (datediff(day,TMP_DEP_PC_NPDMSPCAT.A_BDATE,sprTarifperiod.A_FIN_DATE)>=0 OR sprTarifperiod.A_FIN_DATE IS NULL)
				WHERE (sprTarif.A_STATUS IS NULL OR sprTarif.A_STATUS = @activeStatusId)
	) tarif ON tarif.A_TYPE = sprHscTypes.A_ID		
	 	AND tarif.A_MO = flatCond.A_MO
	 	AND (tarif.A_SUPPLIER = rcptAmount.A_COMPANY OR (tarif.A_SUPPLIER IS NULL AND rcptAmount.A_COMPANY IS NULL))
		AND tarif.num = 1
		
	WHERE (rcpt.A_STATUS IS NULL OR rcpt.A_STATUS = @activeStatusId)
	AND @isAutoReceipt = 1	
	-- квитанция имеет требуемый тип из МСП-ЛК-НПД
	AND rcpt.A_RECEIPT_TYPE IN (
		SELECT TOID
		FROM SPR_LINK_MSP_RTYPE
		WHERE FROMID = TMP_DEP_PC_NPDMSPCAT.A_NPDMSPCAT
    )
	-- квитанция принадлежит члену группы
	AND rcpt.A_PAYER IN (
		SELECT link.A_TOID 
        FROM WM_GROUPHCS_PERSCARD link
        WHERE (link.A_STATUS IS NULL OR link.A_STATUS = @activeStatusId)
        AND TMP_DEP_PC_NPDMSPCAT.A_GROUPHCS = link.A_FROMID
		-- член группы в данный период
		AND (link.A_DATE_IN IS NULL 
		OR YEAR(link.A_DATE_IN) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		OR (YEAR(link.A_DATE_IN) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		AND MONTH(link.A_DATE_IN) < MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
		OR (YEAR(link.A_DATE_IN) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		AND MONTH(link.A_DATE_IN) = MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		AND DAY(link.A_DATE_IN) <= DAY(TMP_DEP_PC_NPDMSPCAT.A_BDATE))			
		)
		AND (link.A_DATE_OUT IS NULL 
		OR YEAR(link.A_DATE_OUT) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		OR (YEAR(link.A_DATE_OUT) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
		AND MONTH(link.A_DATE_OUT) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
		)
	)
	-- квитанция попадает в период
	AND (TMP_DEP_PC_NPDMSPCAT.A_BDATE IS NULL 
	OR YEAR(rcpt.A_PAYMENT_DATE) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
	OR (YEAR(rcpt.A_PAYMENT_DATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
	AND MONTH(rcpt.A_PAYMENT_DATE) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
	)
	AND (TMP_DEP_PC_NPDMSPCAT.A_EDATE IS NULL 
	OR YEAR(rcpt.A_PAYMENT_DATE) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
	OR (YEAR(rcpt.A_PAYMENT_DATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
	AND MONTH(rcpt.A_PAYMENT_DATE) <= MONTH(TMP_DEP_PC_NPDMSPCAT.A_EDATE))
	)
	 GROUP BY sprHscTypes.A_ID
	)tmp
	
	
	)
	, 0)
WHERE A_PROCESSUUID = @uuid

/** 
 * Принудительно указываем область распространенния
 * 1. Заполняем из области распространения заявления (если оно есть) 
 * 2. Заполняем из области распространения назначения (если оно есть) 
 * 3. Заполняем из агрегации имеющегося назначения(в случае наличия квитанция. См. перерасчет по квитанциям)
 */
INSERT INTO TMP_DEP_PC_LINK (    
    A_FROMID,
    A_TOID,
    A_PROCESSUUID)
SELECT DISTINCT TMP_DEP_PC_NPDMSPCAT.A_ID,
       gp.A_TOID,
       @uuid
FROM TMP_DEP_PC_NPDMSPCAT
INNER JOIN WM_GROUPHCS_PERSCARD gp ON TMP_DEP_PC_NPDMSPCAT.A_GROUPHCS = gp.A_FROMID
AND (gp.A_STATUS IS NULL OR gp.A_STATUS = @activeStatusId)     
AND (gp.A_NOTFAMILYUSE IS NULL OR gp.A_NOTFAMILYUSE = 0)
AND (gp.A_DATE_IN IS NULL 
OR YEAR(gp.A_DATE_IN) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
OR (YEAR(gp.A_DATE_IN) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
AND MONTH(gp.A_DATE_IN) < MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
OR (YEAR(gp.A_DATE_IN) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
AND MONTH(gp.A_DATE_IN) = MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
AND DAY(gp.A_DATE_IN) <= DAY(TMP_DEP_PC_NPDMSPCAT.A_BDATE))		
)
AND (gp.A_DATE_OUT IS NULL 
OR YEAR(gp.A_DATE_OUT) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
OR (YEAR(gp.A_DATE_OUT) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
AND MONTH(gp.A_DATE_OUT) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
)		
WHERE TMP_DEP_PC_NPDMSPCAT.A_PROCESSUUID = @uuid
-- сам НЕ учитывается
AND (gp.A_TOID <> TMP_DEP_PC_NPDMSPCAT.A_PERSON) 
-- ЛД не льготник
AND (gp.A_TOID NOT IN (SELECT tmp.A_PERSON
                            FROM TMP_DEP_PC_NPDMSPCAT tmp
                            WHERE tmp.A_COMBINATION = TMP_DEP_PC_NPDMSPCAT.A_COMBINATION
                            AND tmp.A_PROCESSUUID = @uuid))
AND(
    (TMP_DEP_PC_NPDMSPCAT.A_SPHERE = 'family' -- член семьи
	OR (TMP_DEP_PC_NPDMSPCAT.A_SPHERE = 'dependent' -- нетрудоспособный член семьи
		AND EXISTS (SELECT *
					FROM WM_RELATEDRELATIONSHIPS rs
					WHERE rs.A_ID1 = TMP_DEP_PC_NPDMSPCAT.A_PERSON
					AND (rs.A_STATUS IS NULL OR rs.A_STATUS = @activeStatusId)
					AND rs.A_ID2 = gp.A_TOID
					AND rs.A_MAINTENANCE = 1)))
	AND (
		-- ИЛИ входит в область распространенния заявления
		(TMP_DEP_PC_NPDMSPCAT.A_PETITION IS NOT NULL
		AND gp.A_TOID IN (SELECT TOID 
							   FROM SPR_LINK_PET_PC
							   WHERE FROMID = TMP_DEP_PC_NPDMSPCAT.A_PETITION
		))
		-- ИЛИ входит в область распространенния назначения
		OR ((@isAutoReceipt = 0 OR TMP_DEP_PC_NPDMSPCAT.A_RCPT_AMOUNT_SUM = 0) 
		AND TMP_DEP_PC_NPDMSPCAT.A_SERVSERV IS NOT NULL
		AND gp.A_TOID IN (SELECT TOID 
							   FROM SPR_LINK_MSP_PERSON
							   WHERE FROMID = TMP_DEP_PC_NPDMSPCAT.A_SERVSERV
							AND (SPR_LINK_MSP_PERSON.A_START_DATE IS NULL 
							OR YEAR(SPR_LINK_MSP_PERSON.A_START_DATE) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							OR (YEAR(SPR_LINK_MSP_PERSON.A_START_DATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND MONTH(SPR_LINK_MSP_PERSON.A_START_DATE) < MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
							OR (YEAR(SPR_LINK_MSP_PERSON.A_START_DATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND MONTH(SPR_LINK_MSP_PERSON.A_START_DATE) = MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND DAY(SPR_LINK_MSP_PERSON.A_START_DATE) <= DAY(TMP_DEP_PC_NPDMSPCAT.A_BDATE))	
							)
							AND (SPR_LINK_MSP_PERSON.A_END_DATE IS NULL 
							OR YEAR(SPR_LINK_MSP_PERSON.A_END_DATE) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							OR (YEAR(SPR_LINK_MSP_PERSON.A_END_DATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND MONTH(SPR_LINK_MSP_PERSON.A_END_DATE) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
							)
		))
		-- ИЛИ указан в старой агрегации, если перерасчет и есть квитанция
		OR (@isAutoReceipt = 1 
		AND TMP_DEP_PC_NPDMSPCAT.A_RCPT_AMOUNT_SUM > 0
		AND TMP_DEP_PC_NPDMSPCAT.A_SERVSERV IS NOT NULL
		AND gp.A_TOID IN (SELECT link.A_TOID 
							   FROM LINK_PERSON_SERVHCSAGR link
							   INNER JOIN ESRN_SERV_HCS_AGR agr ON link.A_FROMID = agr.A_OUID 
							   AND (agr.A_STATUS IS NULL OR agr.A_STATUS = @activeStatusId)
							   INNER JOIN WM_SERVPAYAMOUNT spa ON spa.A_ID = agr.A_SERV_PAY
							   AND (spa.A_STATUS IS NULL OR spa.A_STATUS = @activeStatusId)
							   AND spa.A_MSP = TMP_DEP_PC_NPDMSPCAT.A_SERVSERV
							   AND (spa.A_DATESTART IS NULL 
								OR YEAR(spa.A_DATESTART) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
								OR (YEAR(spa.A_DATESTART) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
								AND MONTH(spa.A_DATESTART) < MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
								OR (YEAR(spa.A_DATESTART) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
								AND MONTH(spa.A_DATESTART) = MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
								AND DAY(spa.A_DATESTART) <= DAY(TMP_DEP_PC_NPDMSPCAT.A_BDATE))									
								)
								AND (spa.A_DATELAST IS NULL 
								OR YEAR(spa.A_DATELAST) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
								OR (YEAR(spa.A_DATELAST) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
								AND MONTH(spa.A_DATELAST) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
								) ))
	)
)
GROUP BY TMP_DEP_PC_NPDMSPCAT.A_ID, gp.A_TOID
	
/* Распределяем оставшихся членов семей*/
INSERT INTO TMP_DEP_PC_LINK (
    A_PROCESSUUID,
    A_FROMID,
    A_TOID)
SELECT @uuid,
       TMP_DEP_PC_NPDMSPCAT.A_ID,
       gp.A_TOID
FROM TMP_DEP_PC_NPDMSPCAT
INNER JOIN WM_GROUPHCS_PERSCARD gp ON TMP_DEP_PC_NPDMSPCAT.A_GROUPHCS = gp.A_FROMID
AND (gp.A_STATUS IS NULL OR gp.A_STATUS = @activeStatusId)     
AND (gp.A_NOTFAMILYUSE IS NULL OR gp.A_NOTFAMILYUSE = 0)
AND (gp.A_DATE_IN IS NULL 
OR YEAR(gp.A_DATE_IN) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
OR (YEAR(gp.A_DATE_IN) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
AND MONTH(gp.A_DATE_IN) < MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
OR (YEAR(gp.A_DATE_IN) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
AND MONTH(gp.A_DATE_IN) = MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
AND DAY(gp.A_DATE_IN) <= DAY(TMP_DEP_PC_NPDMSPCAT.A_BDATE))		
)
AND (gp.A_DATE_OUT IS NULL 
OR YEAR(gp.A_DATE_OUT) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
OR (YEAR(gp.A_DATE_OUT) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
AND MONTH(gp.A_DATE_OUT) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
)
WHERE TMP_DEP_PC_NPDMSPCAT.A_PROCESSUUID = @uuid
-- сам НЕ учитывается
AND (gp.A_TOID <> TMP_DEP_PC_NPDMSPCAT.A_PERSON) 
AND (TMP_DEP_PC_NPDMSPCAT.A_SPHERE = 'family' -- член семьи
	OR (TMP_DEP_PC_NPDMSPCAT.A_SPHERE = 'dependent' -- нетрудоспособный член семьи
		AND EXISTS (SELECT *
					FROM WM_RELATEDRELATIONSHIPS rs
					WHERE rs.A_ID1 = TMP_DEP_PC_NPDMSPCAT.A_PERSON
					AND (rs.A_STATUS IS NULL OR rs.A_STATUS = @activeStatusId)
					AND rs.A_ID2 = gp.A_TOID
					AND rs.A_MAINTENANCE = 1)))
-- ЛД не льготник
AND (gp.A_TOID NOT IN (SELECT tmp.A_PERSON
                            FROM TMP_DEP_PC_NPDMSPCAT tmp
                            WHERE tmp.A_COMBINATION = TMP_DEP_PC_NPDMSPCAT.A_COMBINATION
                            AND tmp.A_PROCESSUUID = @uuid))
-- не вошел в какую-то ОР
AND (gp.A_TOID NOT IN (SELECT TMP_DEP_PC_LINK.A_TOID
                            FROM TMP_DEP_PC_LINK 
                            INNER JOIN TMP_DEP_PC_NPDMSPCAT tmp ON TMP_DEP_PC_LINK.A_FROMID = tmp.A_ID
                            AND tmp.A_PROCESSUUID = @uuid
                            AND tmp.A_GROUPHCS = TMP_DEP_PC_NPDMSPCAT.A_GROUPHCS
                            AND tmp.A_COMBINATION = TMP_DEP_PC_NPDMSPCAT.A_COMBINATION
                            AND (tmp.A_BDATE IS NULL 
							OR YEAR(tmp.A_BDATE) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							OR (YEAR(tmp.A_BDATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND MONTH(tmp.A_BDATE) <= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
							)
							AND (tmp.A_EDATE IS NULL 
							OR YEAR(tmp.A_EDATE) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							OR (YEAR(tmp.A_EDATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND MONTH(tmp.A_EDATE) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
							)                            
                            WHERE TMP_DEP_PC_LINK.A_PROCESSUUID = @uuid))
-- входит в ОР назначения
AND (TMP_DEP_PC_NPDMSPCAT.A_SERVSERV IS NULL
    OR gp.A_TOID NOT IN (SELECT TOID 
					      FROM SPR_LINK_MSP_PERSON
						  WHERE FROMID = TMP_DEP_PC_NPDMSPCAT.A_SERVSERV)
	OR gp.A_TOID IN (SELECT TOID 
					      FROM SPR_LINK_MSP_PERSON
						  WHERE FROMID = TMP_DEP_PC_NPDMSPCAT.A_SERVSERV
							AND (SPR_LINK_MSP_PERSON.A_START_DATE IS NULL 
							OR YEAR(SPR_LINK_MSP_PERSON.A_START_DATE) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							OR (YEAR(SPR_LINK_MSP_PERSON.A_START_DATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND MONTH(SPR_LINK_MSP_PERSON.A_START_DATE) < MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
							OR (YEAR(SPR_LINK_MSP_PERSON.A_START_DATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND MONTH(SPR_LINK_MSP_PERSON.A_START_DATE) = MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND DAY(SPR_LINK_MSP_PERSON.A_START_DATE) <= DAY(TMP_DEP_PC_NPDMSPCAT.A_BDATE))	
							)
							AND (SPR_LINK_MSP_PERSON.A_END_DATE IS NULL 
							OR YEAR(SPR_LINK_MSP_PERSON.A_END_DATE) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							OR (YEAR(SPR_LINK_MSP_PERSON.A_END_DATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
							AND MONTH(SPR_LINK_MSP_PERSON.A_END_DATE) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
							)
))
-- с максимальным коэффициентом для членов семей
AND (TMP_DEP_PC_NPDMSPCAT.A_HCVRATEFAMILY = (SELECT MAX(tmp.A_HCVRATEFAMILY)
                                             FROM TMP_DEP_PC_NPDMSPCAT tmp
                                             WHERE tmp.A_PROCESSUUID = @uuid
                                             AND (tmp.A_ID = TMP_DEP_PC_NPDMSPCAT.A_ID
                                             OR tmp.A_PERSON <> TMP_DEP_PC_NPDMSPCAT.A_PERSON)
                                             AND tmp.A_GROUPHCS = TMP_DEP_PC_NPDMSPCAT.A_GROUPHCS
                                             AND tmp.A_COMBINATION = TMP_DEP_PC_NPDMSPCAT.A_COMBINATION
											AND (tmp.A_BDATE IS NULL 
											OR YEAR(tmp.A_BDATE) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
											OR (YEAR(tmp.A_BDATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
											AND MONTH(tmp.A_BDATE) <= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
											)
											AND (tmp.A_EDATE IS NULL 
											OR YEAR(tmp.A_EDATE) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
											OR (YEAR(tmp.A_EDATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
											AND MONTH(tmp.A_EDATE) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
											) ))
GROUP BY TMP_DEP_PC_NPDMSPCAT.A_ID, gp.A_TOID

/*кол-во людей в области распространенния*/
UPDATE TMP_DEP_PC_NPDMSPCAT
SET A_AREA_COUNT = (SELECT COUNT(*) 
                    FROM TMP_DEP_PC_LINK 
                    WHERE TMP_DEP_PC_LINK.A_FROMID = TMP_DEP_PC_NPDMSPCAT.A_ID
                    AND TMP_DEP_PC_LINK.A_PROCESSUUID = @uuid)
WHERE A_PROCESSUUID = @uuid

/* Подсчитываем коэффициент членов семей */
UPDATE TMP_DEP_PC_NPDMSPCAT
SET A_FACTOR = ISNULL((SELECT SUM(CASE WHEN query.count = 0 
                                THEN CAST(0.0 as FLOAT)
								WHEN query.count = 1
                                THEN CAST(1.0 as FLOAT)
								WHEN query.count > 1	
                                THEN CAST((1.0/query.count) as FLOAT)
                           END)
                FROM TMP_DEP_PC_LINK 
                INNER JOIN (SELECT COUNT(distinct subQuery.A_PERSON) count,  
                                   subQuery.A_COMBINATION combination, 
                                   subQuery.A_TOID pcId,
                                   yFromDate, mFromDate, yToDate, mToDate
                            FROM (  SELECT tmp.A_PERSON AS A_PERSON,
                                    link.A_TOID AS A_TOID,
                                    tmp.A_COMBINATION AS A_COMBINATION,
                                    YEAR(tmp.A_BDATE) yFromDate, MONTH(tmp.A_BDATE) mFromDate,
                                    YEAR(tmp.A_EDATE) yToDate, MONTH(tmp.A_EDATE) mToDate
                                    FROM TMP_DEP_PC_LINK link
                                    INNER JOIN TMP_DEP_PC_NPDMSPCAT tmp
                                    ON link.A_FROMID = tmp.A_ID
                                    AND tmp.A_PROCESSUUID = @uuid
                                    AND (tmp.A_ID = TMP_DEP_PC_NPDMSPCAT.A_ID
									OR tmp.A_PERSON <> TMP_DEP_PC_NPDMSPCAT.A_PERSON)
									AND (tmp.A_ID = TMP_DEP_PC_NPDMSPCAT.A_ID
									OR (TMP_DEP_PC_NPDMSPCAT.A_SERVSERV IS NOT NULL
									AND tmp.A_SERVSERV <> TMP_DEP_PC_NPDMSPCAT.A_SERVSERV)
									OR (TMP_DEP_PC_NPDMSPCAT.A_PETITION IS NOT NULL
									AND tmp.A_PETITION <> TMP_DEP_PC_NPDMSPCAT.A_PETITION))
									AND (TMP_DEP_PC_NPDMSPCAT.A_EDATE IS NULL
									OR YEAR(tmp.A_BDATE) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
									OR (YEAR(tmp.A_BDATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
									AND MONTH(tmp.A_BDATE) <= MONTH(TMP_DEP_PC_NPDMSPCAT.A_EDATE)))
									AND (tmp.A_EDATE IS NULL
									OR YEAR(tmp.A_EDATE) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
									OR (YEAR(tmp.A_EDATE) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
									AND MONTH(tmp.A_EDATE) >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)))
                                    WHERE link.A_PROCESSUUID = @uuid   
                                    GROUP BY tmp.A_PERSON, link.A_TOID, tmp.A_COMBINATION, 
                                    YEAR(tmp.A_BDATE), MONTH(tmp.A_BDATE), YEAR(tmp.A_EDATE), MONTH(tmp.A_EDATE)
                            ) subQuery                                             
                            LEFT JOIN WM_ACTDOCUMENTS ON WM_ACTDOCUMENTS.PERSONOUID = subQuery.A_TOID
                            AND (WM_ACTDOCUMENTS.A_STATUS IS NULL OR WM_ACTDOCUMENTS.A_STATUS = @activeStatusId)
                            AND WM_ACTDOCUMENTS.DOCUMENTSTYPE = (SELECT A_ID FROM PPR_DOC WHERE PPR_DOC.A_CODE = 'getHcsAnotherInstitution')
                            AND (TMP_DEP_PC_NPDMSPCAT.A_EDATE IS NULL
                            OR WM_ACTDOCUMENTS.A_PERIODSTART IS NULL 
                            OR YEAR(WM_ACTDOCUMENTS.A_PERIODSTART) < YEAR(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
                            OR (YEAR(WM_ACTDOCUMENTS.A_PERIODSTART) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
                            AND MONTH(WM_ACTDOCUMENTS.A_PERIODSTART) < MONTH(TMP_DEP_PC_NPDMSPCAT.A_EDATE))
                            OR (YEAR(WM_ACTDOCUMENTS.A_PERIODSTART) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
                            AND MONTH(WM_ACTDOCUMENTS.A_PERIODSTART) = MONTH(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
                            AND DAY(WM_ACTDOCUMENTS.A_PERIODSTART) <= DAY(TMP_DEP_PC_NPDMSPCAT.A_EDATE)))
                            AND (WM_ACTDOCUMENTS.A_PERIODFINISH IS NULL
                            OR YEAR(WM_ACTDOCUMENTS.A_PERIODFINISH) > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
                            OR (YEAR(WM_ACTDOCUMENTS.A_PERIODFINISH) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
                            AND MONTH(WM_ACTDOCUMENTS.A_PERIODFINISH) > MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE))
                            OR (YEAR(WM_ACTDOCUMENTS.A_PERIODFINISH) = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
                            AND MONTH(WM_ACTDOCUMENTS.A_PERIODFINISH) = MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
                            AND DAY(WM_ACTDOCUMENTS.A_PERIODFINISH) >= DAY(TMP_DEP_PC_NPDMSPCAT.A_BDATE)))                             
                            WHERE WM_ACTDOCUMENTS.OUID IS NULL
                            GROUP BY subQuery.A_COMBINATION,subQuery.A_TOID,
                            yFromDate, mFromDate, yToDate, mToDate) query 
                ON query.pcId = TMP_DEP_PC_LINK.A_TOID 
                AND	query.combination = TMP_DEP_PC_NPDMSPCAT.A_COMBINATION
                AND (TMP_DEP_PC_NPDMSPCAT.A_EDATE IS NULL
                OR (yFromDate < YEAR(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
                OR yFromDate = YEAR(TMP_DEP_PC_NPDMSPCAT.A_EDATE)
                AND mFromDate <= MONTH(TMP_DEP_PC_NPDMSPCAT.A_EDATE)))
                AND (yToDate IS NULL
                OR yToDate > YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
                OR (yToDate = YEAR(TMP_DEP_PC_NPDMSPCAT.A_BDATE)
                AND mToDate >= MONTH(TMP_DEP_PC_NPDMSPCAT.A_BDATE)))
                WHERE TMP_DEP_PC_LINK.A_FROMID = TMP_DEP_PC_NPDMSPCAT.A_ID
                AND TMP_DEP_PC_LINK.A_PROCESSUUID = @uuid), 0)
WHERE TMP_DEP_PC_NPDMSPCAT.A_PROCESSUUID = @uuid


SELECT 0 AS CODE, 'Расчет ЖКУ по стандартам стоимости завершен' AS MSG

go

