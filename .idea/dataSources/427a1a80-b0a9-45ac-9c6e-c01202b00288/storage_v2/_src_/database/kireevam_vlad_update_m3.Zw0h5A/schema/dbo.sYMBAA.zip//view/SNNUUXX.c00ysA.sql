/* SNNUUXX.DBF */
create view SNNUUXX
as
SELECT CURRENT_TIMESTAMP as DZ, 0 as VID, sber.A_NAME as NF, UPPER(pname.[A_Name]+' '+psndname.[A_Name]+' '+psurname.[A_NAME]) as FIO,
rekvizit.AccountingCount as CHE, viplati.Amount as SVK,  
case when nachislenie.A_MONTH<10 then SUBSTRING(CAST(nachislenie.A_YEAR as varchar(4)),3,2)+'0'+CAST(nachislenie.A_MONTH as varchar(1))
else SUBSTRING(CAST(nachislenie.A_YEAR as varchar(4)),3,2)+CAST(nachislenie.A_MONTH as varchar(1))
end as MG
FROM WM_PAIDAMOUNTS as viplati 
INNER JOIN WM_PAYMENT_BOOK as viplatdelo
ON viplati.A_PAYACCOUNT=viplatdelo.OUID
INNER JOIN WM_PAYMENT as rekvizit
on viplatdelo.A_REQUISIT=rekvizit.OUID
INNER JOIN SPR_DELIVERTYPES as dtypes
on rekvizit.DeliveryWay=dtypes.ouid
LEFT JOIN SPR_BANKS as sber
on rekvizit.BanksBranch=sber.OUID
INNER JOIN WM_PERSONAL_CARD as persona
on viplati.PERSONOUID=persona.OUID
LEFT JOIN SPR_FIO_NAME as pname
on persona.[Name]=pname.OUID
LEFT JOIN SPR_FIO_SECONDNAME as psndname
on persona.Secondname=psndname.OUID
LEFT JOIN SPR_FIO_SURNAME as psurname
on persona.Surname=psurname.OUID
LEFT JOIN WM_PAY_CALC as nachislenie
on viplati.A_PAYCALC=nachislenie.OUID
WHERE rekvizit.A_LASTDATE > CURRENT_TIMESTAMP
AND dtypes.[Name]='Сбербанк'
go

