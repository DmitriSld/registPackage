
CREATE FUNCTION [dbo].[GET_POE_EVENT_TYPE_TREE]()
RETURNS TABLE 
AS
RETURN 
(
	WITH EVENT_TREE (ouid, childOuid, lvl) as (
		SELECT A_OUID, A_OUID, 0 AS lvl FROM SPR_PAY_EVENT ev
		INNER JOIN ESRN_SERV_STATUS st ON st.A_STATUSCODE = 'act'
		WHERE (ev.A_STATUS = st.A_ID OR ev.A_STATUS IS NULL)
		UNION ALL
		SELECT evTree.ouid, ev.A_OUID, evTree.lvl + 1 FROM SPR_PAY_EVENT ev
		INNER JOIN EVENT_TREE evTree ON ev.A_PARENT = evTree.childOuid
		INNER JOIN ESRN_SERV_STATUS st ON st.A_STATUSCODE = 'act'
		WHERE (ev.A_STATUS = st.A_ID OR ev.A_STATUS IS NULL)
	)
	SELECT ev.A_OUID AS ouid, ev.A_CODE AS code, evChild.A_OUID AS childOuid, evChild.A_CODE AS childCode, evTree.lvl
	FROM SPR_PAY_EVENT ev
	INNER JOIN EVENT_TREE evTree ON ev.A_OUID = evTree.ouid
	INNER JOIN SPR_PAY_EVENT evChild ON evTree.childOuid = evChild.A_OUID
)
 
--   sx.datastore.db.SXDb.execute:-1 
--   sx.common.replication.DoReplication.installPatch:-1 
--   sx.common.replication.SXPatchInstallParams.installPatch:-1 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:-1 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:597 
--   sx.admin.AdmDispatchAction.dispatchMethod:-1 
--   sx.admin.AdmDispatchAction.execute:-1 
--   sx.admin.AdmServletUtil.processAction:-1 
--   sx.admin.AdmServlet.doGet:-1 
--   sx.admin.AdmServlet.doPost:-1 
--   javax.servlet.http.HttpServlet.service:709
go

