CREATE PROCEDURE [dbo].[PROCESS_DUPLICATE_OBJECTS]
AS
BEGIN

/*
CREATE TABLE #DUPLICATE_OBJECTS (
		num INT IDENTITY(1,1), 
		objClass VARCHAR(128), -- кодовое имя класса
		mainOuid INT,		   -- основной идентификатор
		dupOuid INT,		   -- идентификатор дубля
		delType INT			   -- 0 - не удаляем, 1 - удаляем физически, 2 - удаляем логически
)
*/


IF OBJECT_ID('tempdb..#PDO_CLASS_TREE') IS NOT NULL
	DROP TABLE #PDO_CLASS_TREE 

CREATE TABLE #PDO_CLASS_TREE (
	clsId INT,
	clsName VARCHAR(255),
	parentClsId INT,
	parentClsName VARCHAR(255),
	lvl INT
)

;WITH CLS_TREE(id,parentId,lvl) as (
	SELECT OUID, OUID,  0
	FROM SXCLASS 
	WHERE DATASTORE IS NULL
	UNION ALL
	SELECT clsTree.id,tree.PARENT_OUID, clsTree.lvl + 1
	FROM CLS_TREE clsTree
	INNER JOIN SXTREE tree ON clsTree.parentId = tree.OUID
	WHERE tree.PARENT_OUID IS NOT NULL
)
INSERT INTO #PDO_CLASS_TREE(clsId,clsName,parentClsId,parentClsName,lvl)
SELECT cls.OUID, cls.[NAME], parentCls.OUID, parentCls.[NAME], tree.lvl
FROM CLS_TREE tree
INNER JOIN SXCLASS cls ON tree.id = cls.OUID
INNER JOIN SXCLASS parentCls ON tree.parentId = parentCls.OUID


DECLARE @objClass AS VARCHAR(128), @objClassMap AS VARCHAR(128), @ouidAttrMap AS VARCHAR(128)
	, @statusAttrMap AS VARCHAR(128), @tsAttrMap AS VARCHAR(128), @guidAttrMap AS VARCHAR(128)
	, @clsMap AS VARCHAR(128), @attrMap AS VARCHAR(128), @tsAttrMapDup AS VARCHAR(128)
	, @toAttrMap AS VARCHAR(128), @fromAttrMap AS VARCHAR(128)
	, @toClass AS VARCHAR(128), @fromClass AS VARCHAR(128)
	, @delAttrOuid INT

SELECT @delAttrOuid = A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'delete'

-- чистим от виртуальных классов
DELETE FROM #DUPLICATE_OBJECTS
FROM #DUPLICATE_OBJECTS dup
INNER JOIN SXCLASS cls ON dup.objClass = cls.NAME
	AND cls.ISVIRTUAL = 1

DECLARE linkClass_cursor CURSOR STATIC FOR
SELECT DISTINCT linkCls.[NAME], linkCls.MAP, ouidAttr.MAP, fromAttr.MAP, toAttr.MAP, fromCls.[NAME], toCls.[NAME]
FROM SXCLASS linkCls 
INNER JOIN SXAttr ouidAttr ON ouidAttr.OUIDSXCLASS = linkCls.OUID AND ouidAttr.PKEY = 1
INNER JOIN SXAttr fromAttr ON fromAttr.OUIDSXCLASS = linkCls.OUID AND fromAttr.[name] = 'fromId'
INNER JOIN SXAttr toAttr ON toAttr.OUIDSXCLASS = linkCls.OUID AND toAttr.[name] = 'toId'
INNER JOIN SXCLASS fromCls ON fromAttr.REF_CLASS = fromCls.OUID
INNER JOIN SXCLASS toCls ON toAttr.REF_CLASS = toCls.OUID
LEFT JOIN SXATTR guidAttr ON guidAttr.OUIDSXCLASS = linkCls.OUID
	AND guidAttr.A_ISGUID = 1
WHERE (linkCls.ISVIRTUAL = 0 OR linkCls.ISVIRTUAL IS NULL)
	AND linkCls.MAP IS NOT NULL AND ouidAttr.MAP IS NOT NULL 
	AND fromAttr.MAP IS NOT NULL AND toAttr.MAP IS NOT NULL
	AND guidAttr.OUID IS NULL
AND (fromCls.[name] IN (SELECT objClass FROM #DUPLICATE_OBJECTS) 
	OR toCls.[name] IN (SELECT objClass FROM #DUPLICATE_OBJECTS))

OPEN linkClass_cursor

FETCH NEXT FROM linkClass_cursor 
INTO @objClass, @objClassMap, @ouidAttrMap, @fromAttrMap, @toAttrMap, @fromClass, @toClass
WHILE @@FETCH_STATUS = 0
BEGIN
	BEGIN TRY
	EXECUTE('
	/*
	SELECT main.id, ISNULL(dupFrom.dupOuid,main.fromId) as fromId, ISNULL(dupTo.dupOuid,main.toId) as toId
	INTO #TEMP_DUP_MAIN
	FROM (
		SELECT MIN(obj.[' + @ouidAttrMap + ']) as id, ISNULL(dupFrom.mainOuid,obj.[' + @fromAttrMap + ']) as fromId, ISNULL(dupTo.mainOuid,obj.[' + @toAttrMap + ']) as toId  
		FROM [' + @objClassMap + '] obj
		LEFT JOIN #DUPLICATE_OBJECTS dupFrom ON dupFrom.objClass = ''' + @fromClass + ''' AND dupFrom.dupOuid = obj.[' + @fromAttrMap + ']
		LEFT JOIN #DUPLICATE_OBJECTS dupTo ON dupTo.objClass = ''' + @toClass + ''' AND dupTo.dupOuid = obj.[' + @toAttrMap + ']
		WHERE dupFrom.mainOuid IS NOT NULL OR dupFrom.mainOuid IS NOT NULL
		GROUP BY ISNULL(dupFrom.mainOuid,obj.[' + @fromAttrMap + ']), ISNULL(dupTo.mainOuid,obj.[' + @toAttrMap + ']) 
	) main 
	LEFT JOIN #DUPLICATE_OBJECTS dupFrom ON dupFrom.objClass = ''' + @fromClass + ''' AND dupFrom.mainOuid = main.fromId
	LEFT JOIN #DUPLICATE_OBJECTS dupTo ON dupTo.objClass = ''' + @toClass + ''' AND dupTo.mainOuid = main.toId
	*/
	SELECT MIN(obj.[' + @ouidAttrMap + ']) OVER(PARTITION BY ISNULL(dupFrom.mainOuid,obj.[' + @fromAttrMap + ']), ISNULL(dupTo.mainOuid,obj.[' + @toAttrMap + '])) as id, 
		obj.[' + @fromAttrMap + '] as fromId, obj.[' + @toAttrMap + '] as toId
	INTO #TEMP_DUP_MAIN
	FROM [' + @objClassMap + '] obj
	LEFT JOIN #DUPLICATE_OBJECTS dupFrom ON dupFrom.objClass = ''' + @fromClass + ''' AND obj.[' + @fromAttrMap + '] IN (dupFrom.dupOuid,dupFrom.mainOuid)
	LEFT JOIN #DUPLICATE_OBJECTS dupTo ON dupTo.objClass = ''' + @toClass + ''' AND obj.[' + @toAttrMap + '] IN (dupTo.dupOuid,dupTo.mainOuid)
	WHERE dupFrom.mainOuid IS NOT NULL OR dupTo.mainOuid IS NOT NULL


	INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
	SELECT ''' + @objClass + ''', main.id, obj.[' + @ouidAttrMap + '], 2
	FROM [' + @objClassMap + '] obj
	INNER JOIN #TEMP_DUP_MAIN main 
	ON obj.[' + @ouidAttrMap + '] != main.id
		AND obj.[' + @fromAttrMap + '] = main.fromId
		AND obj.[' + @toAttrMap + '] = main.toId
		
	DROP TABLE #TEMP_DUP_MAIN
	')
	END TRY
	BEGIN CATCH
		PRINT 'Error while update @objClass=' + ISNULL(@objClass,'null') + 
			', @objClassMap=' + ISNULL(@objClassMap,'null') + ', @ouidAttrMap=' + ISNULL(@ouidAttrMap,'null') + 
			', @fromAttrMap=' + ISNULL(@fromAttrMap,'null') + ', @toAttrMap=' + ISNULL(@toAttrMap,'null') + 
			', @fromClass=' + ISNULL(@fromClass,'null') + ', @toClass=' + ISNULL(@toClass,'null')
	END CATCH

	FETCH NEXT FROM linkClass_cursor 
	INTO @objClass, @objClassMap, @ouidAttrMap, @fromAttrMap, @toAttrMap, @fromClass, @toClass

END

CLOSE linkClass_cursor
DEALLOCATE linkClass_cursor


DECLARE objClass_cursor CURSOR STATIC FOR
SELECT DISTINCT dups.objClass, cls.MAP, ouidAttr.MAP, statusAttr.MAP, tsAttr.MAP, guidAttr.MAP
FROM #DUPLICATE_OBJECTS dups
INNER JOIN #PDO_CLASS_TREE clsTree ON clsTree.clsName = dups.objClass
INNER JOIN SXCLASS cls ON cls.[NAME] = dups.objClass
INNER JOIN SXAttr ouidAttr ON ouidAttr.OUIDSXCLASS = clsTree.parentClsId AND ouidAttr.PKEY = 1
LEFT JOIN SXAttr statusAttr ON statusAttr.OUIDSXCLASS = cls.OUID AND statusAttr.[NAME] = 'status'
	AND statusAttr.MAP IS NOT NULL
LEFT JOIN SXAttr tsAttr ON tsAttr.OUIDSXCLASS = cls.OUID AND tsAttr.A_ISTIMESTAMP = 1
	AND tsAttr.MAP IS NOT NULL
LEFT JOIN SXAttr guidAttr ON guidAttr.OUIDSXCLASS = cls.OUID AND guidAttr.A_ISGUID = 1
	AND guidAttr.MAP IS NOT NULL
WHERE cls.MAP IS NOT NULL AND ouidAttr.MAP IS NOT NULL


OPEN objClass_cursor

FETCH NEXT FROM objClass_cursor 
INTO @objClass, @objClassMap, @ouidAttrMap, @statusAttrMap, @tsAttrMap, @guidAttrMap
  WHILE @@FETCH_STATUS = 0
  BEGIN

  	/**
	 * Тут мы производим пересвязывание всех дублей на основной объект
	 */
	DECLARE dupUpdate_cursor CURSOR FOR
	SELECT cls.MAP, attr.MAP, tsAttr.MAP FROM SXAttr attr
	INNER JOIN SXClass cls ON attr.OUIDSXCLASS = cls.OUID
	INNER JOIN SXClass refCls ON attr.REF_CLASS = refCls.OUID AND refCls.[NAME] = @objClass
	LEFT JOIN SXAttr tsAttr ON tsAttr.OUIDSXCLASS = cls.OUID AND tsAttr.A_ISTIMESTAMP = 1
	WHERE cls.MAP IS NOT NULL AND attr.MAP IS NOT NULL 
		AND cls.DATASTORE IS NULL

	OPEN dupUpdate_cursor
	FETCH NEXT FROM dupUpdate_cursor
	INTO @clsMap, @attrMap, @tsAttrMapDup
	  WHILE @@FETCH_STATUS = 0
	  BEGIN

		IF(@tsAttrMapDup IS NOT NULL)
			EXECUTE('
				UPDATE [' + @clsMap + '] SET [' + @clsMap + '].[' + @attrMap + '] = dups.mainOuid, [' + @clsMap + '].[' + @tsAttrMapDup + '] = GETDATE()
				FROM #DUPLICATE_OBJECTS dups
				WHERE [' + @clsMap + '].[' + @attrMap + '] = dups.dupOuid AND dups.objClass = ''' + @objClass + '''
			')
		ELSE
			EXECUTE('
				UPDATE [' + @clsMap + '] SET [' + @clsMap + '].[' + @attrMap + '] = dups.mainOuid 
				FROM #DUPLICATE_OBJECTS dups
				WHERE [' + @clsMap + '].[' + @attrMap + '] = dups.dupOuid AND dups.objClass = ''' + @objClass + '''
			')
	    
	    FETCH NEXT FROM dupUpdate_cursor 
	    INTO @clsMap, @attrMap, @tsAttrMapDup
	  END
	
	CLOSE dupUpdate_cursor
	DEALLOCATE dupUpdate_cursor

	/**
	 * Тут мы дополняем основной объект данными из дублей
	 */
	DECLARE @flCast VARCHAR(1), @query VARCHAR(MAX)  
	 
	DECLARE appendMain_cursor CURSOR FOR
	SELECT cls.MAP, attr.MAP, CASE WHEN attrType.LOGICNAME = 'boolean' THEN NULL ELSE '' END AS flCast FROM SXAttr attr
	INNER JOIN SXClass cls ON attr.OUIDSXCLASS = cls.OUID AND cls.[NAME] = @objClass
	INNER JOIN SXDATATYPE attrType ON attr.OUIDDATATYPE = attrType.OUID		 
	WHERE cls.MAP IS NOT NULL AND attr.MAP IS NOT NULL 
		AND cls.DATASTORE IS NULL
		AND (attr.PKEY != 1 OR attr.PKEY IS NULL)
		AND attr.[NAME] != 'status' 
		AND (attr.A_ISTIMESTAMP != 1 OR attr.A_ISTIMESTAMP IS NULL)

	OPEN appendMain_cursor
	FETCH NEXT FROM appendMain_cursor
	INTO @clsMap, @attrMap, @flCast
	  WHILE @@FETCH_STATUS = 0
	  BEGIN
	  	BEGIN TRY
	  	SET @query = '
	  		UPDATE [' + @clsMap + '] SET [' + @attrMap + '] = x.[' + @attrMap + ']
	  		FROM (SELECT dups.mainOuid AS mainOuid, MIN(' + ISNULL( @flCast,' CAST(') + 'obj.[' + @attrMap + '] '+ ISNULL(@flCast,' AS INT)') +') AS ' + @attrMap + '	  		
	  		      FROM #DUPLICATE_OBJECTS dups 
	  		      INNER JOIN ' + @clsMap + ' obj ON obj.[' + @ouidAttrMap + '] = dups.dupOuid AND dups.objClass = ''' + @objClass + '''
	  		      WHERE obj.[' + @attrMap + '] IS NOT NULL
	  		      GROUP BY dups.mainOuid) x
	  		WHERE [' + @clsMap + '].[' + @ouidAttrMap + '] = x.mainOuid AND [' + @clsMap + '].[' + @attrMap + '] IS NULL'
	  	EXECUTE(@query)
	  	END TRY
	  	BEGIN CATCH
	  	PRINT('Can''t update [' + @clsMap + '].[' + @attrMap + ']')
	  	END CATCH
	  	
	    FETCH NEXT FROM appendMain_cursor 
	    INTO @clsMap, @attrMap, @flCast
	  END

	CLOSE appendMain_cursor
	DEALLOCATE appendMain_cursor	


	IF OBJECT_ID('SX_MERGE_TRACK') IS NOT NULL AND @guidAttrMap IS NOT NULL BEGIN
		EXECUTE('
			DECLARE @lastNumber INT
			SELECT @lastNumber = MAX(A_NUMBER) 
			FROM SX_MERGE_TRACK
		
			INSERT INTO SX_MERGE_TRACK(A_NUMBER,A_CLASS_NAME,A_MAIN_GUID,A_DUP_GUID,A_MAIN_ID,A_DUP_ID,A_CREATEDATE,A_TS,[GUID])
			SELECT ISNULL(@lastNumber,1), ''' + @objClass + ''', mainObj.[' + @guidAttrMap + '], dupObj.[' + @guidAttrMap + '],
				mainObj.[' + @ouidAttrMap + '], dupObj.[' + @ouidAttrMap + '], GETDATE(), GETDATE(), NEWID()
			FROM #DUPLICATE_OBJECTS dups 
			INNER JOIN [' + @objClassMap + '] mainObj ON dups.mainOuid = mainObj.[' + @ouidAttrMap + ']
			INNER JOIN [' + @objClassMap + '] dupObj ON dups.dupOuid = dupObj.[' + @ouidAttrMap + ']
			WHERE dups.objClass = ''' + @objClass + '''
		')
	END
	

	/**
	 * А тут мы удаляем дубли, ну или помечаем на удаление, в зависимости от типа
	 * 0 - ничего не делать
	 * 1 - удалять физически
	 * 2 - удалять логически (если статуса не будет, со сотрет физически)
	 */
	 PRINT('Удаляем объекты класса ' + @objClassMap)
	 EXECUTE('
		DELETE FROM [' + @objClassMap + '] WHERE [' + @ouidAttrMap + '] IN (
			SELECT dups.dupOuid FROM #DUPLICATE_OBJECTS dups WHERE dups.delType = 1 AND dups.objClass = ''' + @objClass + '''
		)
	 ')
	 IF(@statusAttrMap IS NULL)
	 EXECUTE('
		DELETE FROM [' + @objClassMap + '] WHERE [' + @ouidAttrMap + '] IN (
			SELECT dups.dupOuid FROM #DUPLICATE_OBJECTS dups WHERE dups.delType = 2 AND dups.objClass = ''' + @objClass + '''
		)
	 ')
	 ELSE BEGIN
		EXECUTE('
			UPDATE [' + @objClassMap + '] SET [' + @statusAttrMap + '] = ' + @delAttrOuid + '
			WHERE [' + @ouidAttrMap + '] IN (
				SELECT dups.dupOuid FROM #DUPLICATE_OBJECTS dups WHERE dups.delType = 2 AND dups.objClass = ''' + @objClass + '''
			)
		')
	 END
	 
	 IF(@tsAttrMap IS NOT NULL)
	 EXECUTE('
			UPDATE [' + @objClassMap + '] SET [' + @tsAttrMap + '] = GETDATE()
			WHERE [' + @ouidAttrMap + '] IN (
				SELECT dups.dupOuid FROM #DUPLICATE_OBJECTS dups WHERE dups.delType = 2 AND dups.objClass = ''' + @objClass + '''
				UNION ALL
				SELECT dups.mainOuid FROM #DUPLICATE_OBJECTS dups WHERE dups.delType = 2 AND dups.objClass = ''' + @objClass + '''
			)
	 ')
	
	
    FETCH NEXT FROM objClass_cursor 
    INTO @objClass, @objClassMap, @ouidAttrMap, @statusAttrMap, @tsAttrMap, @guidAttrMap
  END

CLOSE objClass_cursor
DEALLOCATE objClass_cursor

END
go

