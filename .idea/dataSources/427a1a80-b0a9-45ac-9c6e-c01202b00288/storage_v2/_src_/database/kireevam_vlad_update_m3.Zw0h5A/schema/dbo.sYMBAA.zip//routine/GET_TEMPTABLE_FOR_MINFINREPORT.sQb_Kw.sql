CREATE FUNCTION [dbo].[GET_TEMPTABLE_FOR_MINFINREPORT](@year int,@quartal int,@typeRep int)
RETURNS @tmpTableMinFinReport TABLE 
(
name varchar(255),
kod VARCHAR(3),
countPeopel INT,
nouPay NUMERIC(10,2),
fixPay NUMERIC(10,2),
cassPay NUMERIC(10,2),
zadolg NUMERIC(10,2)
)
AS
  BEGIN
	

     
     
     
     
/**************************************************/

/*********************************************************************
*Получаем периуды для отчета 
*
*@startDate -начало периуда 
*@endDate -окончание периуда
*
**********************************************************************/
--дата начала
DECLARE @startDate datetime,@endDate datetime,@month int
SET @month=(@quartal-1)*3+1
SET @startDate=cast(@year AS varchar)+'-'+cast(CASE WHEN len(@month)=1 THEN '0'+@month  ELSE @month END  AS varchar )+'-01'
--дата окончания
SET @month=@month+3
IF @month=13
BEGIN
	SET @year=@year+1
	SET	@month=1
END
SET @endDate=cast(@year AS varchar)+'-'+cast(CASE WHEN len(@month)=1 THEN '0'+@month  ELSE @month END  AS varchar )+'-01'
SET @endDate=CONVERT(datetime,@endDate)-1
IF @quartal IS NULL OR @quartal=0
begin
SET @startDate=cast(@year AS varchar)+'01'+'01'
SET @endDate=cast(@year AS varchar)+'12'+'31'
END

/****************************************************************
*Статусы Объектов
*
*@closePay - статус выплаты  Выплочено(Закрыто)
*@sformirPayCalc - статус начислений Выплата сформирована
*@nepPayCalc - статус начислений Неполная выплата
*@actPc - Действующие ЛД
*@actObject - Действующие Объект
*@actDoc - Действующий документ
*
*****************************************************************/
--Статусы выплат
DECLARE @closePay int
	--Выплочено(Закрыто)
	SELECT @closePay=a_id FROM SPR_STATUS_PAYMENT WHERE a_code=10
--Статусы начислений
DECLARE @sformirPayCalc int,@nepPayCalc int
	--Выплата сформирована
	SELECT @sformirPayCalc=a_id FROM SPR_STATUS_PROCESS WHERE a_code=11
	--Неполная выплата
	SELECT @nepPayCalc=a_id FROM SPR_STATUS_PROCESS WHERE a_code=9		
--Действующие Объекты
DECLARE @actPc int ,@actObject int ,@actDoc int
	--Действующие ЛД
	SELECT @actPc=ouid FROM SPR_PC_STATUS WHERE a_code=1
	--Действующие Объект
	SELECT @actObject=A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE='act'
	--Действующий документ
	SELECT @actDoc=a_ouid FROM SPR_DOC_STATUS WHERE a_code='active'


/***********************************************************************
*Заполнение временной таблице необходимых документов
************************************************************************/
INSERT INTO @tmpTableMinFinReport (kod,countPeopel,nouPay,fixPay,cassPay,name)
SELECT  max(a_str_num)AS a_str_num,0,0,0,0,A_NAMESTR FROM SETTING_MINFIN_REPORT GROUP BY A_NAMESTR



/*************************************************************************************
*Подготовка данных во временную талицу
***************************************************************************************/
DECLARE @tmpTable TABLE(
pc int ,--ЛД
codeDoc int,--ДОК
Msp int ,--МСП
Cat int,--КАТ
--начисление
payCalc int ,--начисление
datePayCalc datetime,--дата начисления
sumPayCalc numeric(10,2),--сумма начисления
--выплата
Pay int,--выплата
sumPay numeric(10,2),--суммма выплаты
dostSum numeric(10,2)--стоимость доставки
)




INSERT  INTO @tmpTable
--Подготовка
SELECT
WM_PERSONAL_CARD.ouid AS pc,--ЛД
PPR_DOC.a_id AS codeDoc,--ДОК
PPR_SERV.a_id AS Msp,--МСП
ppr_cat.a_id AS Cat,--КАТ
--начисление
WM_PAY_CALC.ouid AS payCalc,--начисление
WM_PAY_CALC.paiddate AS datePayCalc ,--дата начисления
WM_PAY_CALC.A_RESIDUEPAY AS sumPayCalc,--сумма начисления
--выплата
WM_PAIDAMOUNTS.OUID AS Pay,--выплата
WM_PAIDAMOUNTS.AMOUNT AS sumPay,--суммма выплаты
dbo.GET_FINANCE_VALUE(wm_payment.DELIVERYWAY,wm_payment.A_DELIVERY_TYPES,PPR_SERV.a_id,wm_payment.A_PAYMENTORG,WM_PAIDAMOUNTS.AMOUNT,wm_address.A_TOWN,WM_PAIDAMOUNTS.PAIDDATE) AS dostSum--стоимость доставки
FROM WM_PERSONAL_CARD
--Назначение
INNER JOIN esrn_serv_serv 
ON WM_PERSONAL_CARD.OUID=esrn_serv_serv.A_PERSONOUID
--МСП-ЛК-НПД
INNER JOIN SPR_NPD_MSP_CAT 
ON SPR_NPD_MSP_CAT.A_ID =esrn_serv_serv.A_SERV
--МСП
INNER JOIN PPR_SERV 
ON PPR_SERV.A_ID=SPR_NPD_MSP_CAT.A_MSP
INNER JOIN ppr_cat 
ON SPR_NPD_MSP_CAT.A_CATEGORY=ppr_cat.A_ID
--начисление
INNER  JOIN WM_PAY_CALC 
ON WM_PAY_CALC.A_MSP=esrn_serv_serv.OUID 
--выплата
INNER JOIN WM_PAIDAMOUNTS 
ON WM_PAY_CALC.ouid=WM_PAIDAMOUNTS.A_PAYCALC
AND EXISTS(SELECT PAYHISTORY.a_id fROM PAYHISTORY WHERE PAYHISTORY.A_PAIDAMOUNT=WM_PAIDAMOUNTS.OUID AND(PAYHISTORY.a_status=@actObject OR PAYHISTORY.a_status IS NULL)AND PAYHISTORY.a_date between @startDate AND @endDate)
--Реквизиты
LEFT JOIN wm_payment 
ON wm_payment.ouid=WM_PAIDAMOUNTS.a_payment
--Документ
LEFT JOIN WM_ACTDOCUMENTS
ON WM_ACTDOCUMENTS.PERSONOUID=WM_PERSONAL_CARD.OUID 
AND (WM_ACTDOCUMENTS.a_status=@actObject OR WM_ACTDOCUMENTS.a_status IS NULL) 
AND WM_ACTDOCUMENTS.A_DOCSTATUS=@actDoc
--ппрДок
LEFT JOIN PPR_DOC ON
PPR_DOC.A_ID=WM_ACTDOCUMENTS.DOCUMENTSTYPE 
AND (PPR_DOC.a_status=@actObject OR PPR_DOC.a_status IS NULL)
--Адресс
LEFT JOIN wm_address 
ON WM_PERSONAL_CARD.a_regflat=wm_address.ouid
WHERE 
(WM_PERSONAL_CARD.a_status=@actObject OR WM_PERSONAL_CARD.a_status IS NULL)
AND WM_PERSONAL_CARD.A_PCSTATUS=@actPc
AND(esrn_serv_serv.a_status=@actObject OR esrn_serv_serv.a_status IS NULL)
AND(SPR_NPD_MSP_CAT.a_status=@actObject OR SPR_NPD_MSP_CAT.a_status IS NULL)
AND(PPR_SERV.a_status=@actObject OR PPR_SERV.a_status IS NULL)
AND(WM_PAIDAMOUNTS.a_status=@actObject OR WM_PAIDAMOUNTS.a_status IS NULL)
AND (WM_PAY_CALC.a_status=@actObject OR WM_PAY_CALC.a_status IS NULL)
AND (WM_PAY_CALC.a_statusprivelege=@sformirPayCalc OR WM_PAY_CALC.a_statusprivelege=@nepPayCalc)
AND WM_PAIDAMOUNTS.a_statusprivelege=@closePay


--SELECT *FROM #tmpTable


/**************************************************************************
*Курсор по заполнению
***************************************************************************/
DECLARE @name varchar(255),@strNum varchar(3),@msp int,@cat int,@doc int

DECLARE  id_cursor CURSOR STATIC 
FOR 
SELECT A_NAMESTR,a_str_num,a_msp,a_cat,a_doc FROM SETTING_MINFIN_REPORT WHERE (a_type=@typeRep OR a_type IS NULL)
OPEN id_cursor 
FETCH NEXT FROM id_cursor 
INTO @name,@strNum, @msp, @cat, @doc;
WHILE @@FETCH_STATUS = 0
BEGIN
--Переменные для строки
DECLARE @countPeopel int,@nouPay int,@fixPay int,@cassPay int



--SELECT @strNum, @msp, @cat, @doc


--численность граждан
SELECT @countPeopel=count(pc)FROM 
(
SELECT DISTINCT pc FROM  @tmpTable 
WHERE 
    (Msp=@msp OR @msp IS NULL) 
AND (cat=@cat OR @cat IS NULL or cat IN (SELECT a_id FROM ppr_cat WHERE A_PARENT=@cat)) 
AND (codeDoc=@doc OR @doc IS NULL)
AND (@msp IS NOT NULL OR @cat iS NOT NULL OR @doc iS NOT NULL)
)
AS tmp




--Задолжность на начало отчетного периуда
SELECT @nouPay=sum(sumPayCalc)FROM 
(
SELECT payCalc,sumPayCalc FROM  @tmpTable 
WHERE 
    (Msp=@msp OR @msp IS NULL) 
AND (cat=@cat OR @cat IS NULL or cat IN (SELECT a_id FROM ppr_cat WHERE A_PARENT=@cat)) 
AND (codeDoc=@doc OR @doc IS NULL)
AND (@msp IS NOT NULL OR @cat iS NOT NULL OR @doc iS NOT NULL)
AND datePayCalc between @startDate AND @endDate
GROUP BY payCalc,sumPayCalc
)
AS tmp

--Фактические расходы
SELECT @fixPay=sum(sumPay)FROM 
(
SELECT sumPay,Pay FROM  @tmpTable 
WHERE 
    (Msp=@msp OR @msp IS NULL) 
AND (cat=@cat OR @cat IS NULL or cat IN (SELECT a_id FROM ppr_cat WHERE A_PARENT=@cat)) 
AND (codeDoc=@doc OR @doc IS NULL)
AND (@msp IS NOT NULL OR @cat iS NOT NULL OR @doc iS NOT NULL)
GROUP BY sumPay,Pay
)
AS tmp

--????
--Кассовые расходы
SELECT @cassPay=sum(dostSum)FROM 
(
SELECT dostSum,Pay FROM  @tmpTable 
WHERE 
    (Msp=@msp OR @msp IS NULL) 
AND (cat=@cat OR @cat IS NULL or cat IN (SELECT a_id FROM ppr_cat WHERE A_PARENT=@cat)) 
AND (codeDoc=@doc OR @doc IS NULL)
AND (@msp IS NOT NULL OR @cat iS NOT NULL OR @doc iS NOT NULL)
GROUP BY dostSum,Pay
)
AS tmp

--Обновление временной таблице
UPDATE @tmpTableMinFinReport SET 
countPeopel=countPeopel+isnull(@countPeopel,0),
nouPay =nouPay+isnull(@nouPay ,0),
fixPay =fixPay+isnull(@fixPay,0),
cassPay =cassPay+isnull(@cassPay,0),
name=@name
WHERE kod=@strNum

FETCH NEXT FROM id_cursor INTO @name,@strNum, @msp, @cat, @doc; 
END
CLOSE id_cursor
DEALLOCATE id_cursor 


UPDATE @tmpTableMinFinReport set
countPeopel=(SELECT SUM(countPeopel) FROM @tmpTableMinFinReport WHERE kod IN('141','142','143','144','145')),
nouPay=(SELECT SUM(nouPay) FROM @tmpTableMinFinReport WHERE kod IN('141','142','143','144','145')),
fixPay =(SELECT SUM(fixPay) FROM @tmpTableMinFinReport WHERE kod IN('141','142','143','144','145')),
cassPay =(SELECT SUM(cassPay) FROM @tmpTableMinFinReport WHERE kod IN('141','142','143','144','145'))
WHERE kod='140'


 
UPDATE @tmpTableMinFinReport SET zadolg =nouPay+fixPay-cassPay
 

 

 
      
   RETURN
END
 
--   sx.datastore.db.SXDb.execute:410 
--   sx.common.replication.DoReplication.installPatch:3136 
--   sx.common.replication.SXPatchInstallParams.installPatch:93 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:88 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:138 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:709
go

