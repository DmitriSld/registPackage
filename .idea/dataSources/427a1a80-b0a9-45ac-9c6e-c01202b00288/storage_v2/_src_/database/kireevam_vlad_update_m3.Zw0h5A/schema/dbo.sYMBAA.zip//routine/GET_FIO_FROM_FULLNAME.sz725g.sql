CREATE FUNCTION [dbo].[GET_FIO_FROM_FULLNAME]
(
	@name varchar(255)
)
RETURNS varchar(255)
AS
BEGIN
	
select	@name = case when charindex(' ',@name) > 0 then
		 substring(@name,1,charindex(' ',@name)-1) + 
	case when charindex(' ',substring(@name,charindex(' ',@name)+1,datalength(@name))) > 0 then 
		 ' ' + substring(substring(substring(@name,charindex(' ',@name)+1,datalength(@name)),1,
		 charindex(' ',substring(@name,charindex(' ',@name)+1,datalength(@name)))-1),1,1)+'.'
		 + ' ' +
		 substring(substring(substring(@name,charindex(' ',@name)+1,datalength(@name)),
		 charindex(' ',substring(@name,charindex(' ',@name)+1,datalength(@name)))+1,
		 datalength(@name)),1,1)+'.'
		 else ' ' + substring(substring(@name,charindex(' ',@name)+1,datalength(@name)),1,1) + '.' end		
    else @name end
    
    RETURN @name	

END

go

