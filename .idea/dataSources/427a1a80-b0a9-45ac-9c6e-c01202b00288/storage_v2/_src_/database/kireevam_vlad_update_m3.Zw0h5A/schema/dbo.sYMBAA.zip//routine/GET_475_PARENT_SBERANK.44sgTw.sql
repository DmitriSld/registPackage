CREATE FUNCTION GET_475_PARENT_SBERANK
(
@orgId int
)
RETURNS int
AS
BEGIN
  DECLARE @parentId int -- идентификатор самой вышестоящей организации
  DECLARE @tmpId int
  DECLARE @sberId varchar(30)

  SET @parentId = @orgId
  SET @tmpId = @orgId

  WHILE @tmpId IS NOT NULL BEGIN
    SELECT @tmpId = A_PARENT FROM SPR_ORG_BANKS WHERE OUID = @parentId
    IF (@tmpId IS NOT NULL) BEGIN
      SELECT @sberId = A_SBERID FROM SPR_ORG_BANKS WHERE OUID = @tmpId
      IF (@sberId = 'sb') BEGIN         
        RETURN @parentId
      END ELSE BEGIN
        SET @parentId = @tmpId
      END
    END
  END

  RETURN @parentId
END
go

