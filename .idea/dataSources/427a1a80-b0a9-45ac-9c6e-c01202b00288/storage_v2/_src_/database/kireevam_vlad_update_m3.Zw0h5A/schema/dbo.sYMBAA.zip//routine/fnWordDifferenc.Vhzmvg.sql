
CREATE FUNCTION [dbo].[fnWordDifferenc] (
	 @First		VarChar(256)
	,@Second	VarChar(256)
	,@Difference	TinyInt	= NULL
) RETURNS TABLE AS RETURN	-- SELECT * FROM dbo.fnWordDifference('012345679012','012456789012',3)
WITH Line (Line,PosX,[Char],[Len],PosY) AS (
	SELECT	 Replicate(' ',Len(@Second))
		,1
		,SubString(@First,1,1)
		,Len(@Second)
		,1
	WHERE	   @First	IS NOT NULL
		AND @Second	IS NOT NULL
		AND(@Difference	IS NULL
		 OR @Difference >= Abs(DataLength(@First) - DataLength(@Second)))
UNION ALL
	SELECT	 X.Line
		,X.PosX
		,X.[Char]
		,L.[Len]
		,X.PosY
	FROM	Line	L
		CROSS APPLY(SELECT NullIf(CharIndex(L.[Char],@Second,L.PosY ),0)	) C(Pos)
		CROSS APPLY(SELECT NullIf(CharIndex('*'     ,L.Line ,C.Pos  ),0)	) T(Pos)
		CROSS APPLY(SELECT NullIf(CharIndex(' '     ,L.Line ,T.Pos+1),0)
					,Stuff(L.Line,C.Pos,1,'*')			) N(Pos,Line)
		CROSS APPLY(SELECT N.Pos,Stuff(N.Line,T.Pos,1,SubString(L.Line,C.Pos,1)),L.PosX	,L.[Char]			WHERE N.Pos IS NOT NULL
		UNION ALL   SELECT CharIndex(' ',IsNull(N.Line,L.Line))
						,IsNull(N.Line,L.Line)			,NullIf(L.PosX,L.[Len])+1
												,SubString(@First,L.PosX+1,1)	WHERE N.Pos IS     NULL
											) X(PosY,Line,PosX,[Char])
	WHERE	    L.PosY IS NOT NULL
		AND L.PosX IS NOT NULL
)	SELECT	Top(1)
		 @First		AS [First]
		,@Second	AS [Second]
		,D.[Difference]
	FROM	Line L CROSS APPLY(SELECT
			L.[Len] + Len(@First) - 2 * Len(Replace(Line,' ',''))
		) D([Difference])
	WHERE	    L.PosX IS NULL
		AND(@Difference >= D.[Difference]
		 OR @Difference IS NULL)
go

