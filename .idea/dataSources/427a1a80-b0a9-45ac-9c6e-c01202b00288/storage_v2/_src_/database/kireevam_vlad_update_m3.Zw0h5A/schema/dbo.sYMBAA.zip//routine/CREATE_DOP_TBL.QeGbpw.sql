




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROC [dbo].[CREATE_DOP_TBL]  
AS
DECLARE @lngTabCount INT
DECLARE @lngLoopCount INT
DECLARE @oszn_esrn_serv_serv INT
DECLARE @year_esrn_serv_serv VARCHAR(20)
DECLARE @year_register_config VARCHAR(20)
DECLARE @year VARCHAR(4)
DECLARE @a_regpaybooknum INT
DECLARE @a_regpaybooknum_str VARCHAR(50)
DECLARE @curr_year varchar(4)
BEGIN
--формирование номера выплатного документа
--создание временной таблицы - REGISTER_CONFIG
	CREATE TABLE #temp_tbl_register_config(numIdRC INT IDENTITY(1,1), a_regpaybooknum INT, a_reglastpaybookdate DATETIME)
	INSERT INTO #temp_tbl_register_config
	SELECT dbo.REGISTER_CONFIG.A_REGPAYBOOKNUM,  dbo.REGISTER_CONFIG.A_REGLASTPAYBOOKDATE 		
	from dbo.REGISTER_CONFIG

--создание временной таблицы - ESRN_SERV_SERV
	CREATE TABLE #temp_tbl_esrn_serv_serv(numIdPS INT IDENTITY(1,1), a_orgname INT, a_servdate DATETIME)
	INSERT INTO #temp_tbl_esrn_serv_serv
	SELECT dbo.ESRN_SERV_SERV.A_ORGNAME,  dbo.ESRN_SERV_SERV.A_SERVDATE 		
	from dbo.ESRN_SERV_SERV

	--переменные для подсчета строк
	SET @lngTabCount = @@ROWCOUNT 
	SET @lngLoopCount = 0
	SET @a_regpaybooknum = 0
--	SET @year_register_config = (SELECT A_REGLASTPAYBOOKDATE FROM #temp_tbl_register_config)
	--забиваем значение в выходные переменные
	WHILE @lngTabCount <> @lngLoopCount 
	BEGIN		
		SET @oszn_esrn_serv_serv = (SELECT A_ORGNAME FROM #temp_tbl_esrn_serv_serv WHERE numIdPS = @lngLoopCount AND A_ORGNAME IS NOT NULL) 
		SET @year_esrn_serv_serv = (SELECT A_SERVDATE FROM #temp_tbl_esrn_serv_serv WHERE numIdPS = @lngLoopCount)
		SET @curr_year = DATEPART(YYYY,GETDATE());
		--PRINT @oszn_esrn_serv_serv
		--забиваем доп. таблицу полями: ОСЗН, год, номер в пределах этого года.
		--if (substring(@year_esrn_serv_serv,8,4) = @curr_year) SET @year = substring(@year_register_config,8,4) ELSE 
		SET	@year = substring(@year_esrn_serv_serv,8,4)
		IF (@oszn_esrn_serv_serv IS NOT NULL) BEGIN
			SET @a_regpaybooknum = @a_regpaybooknum + 1;
			SET @a_regpaybooknum_str = @a_regpaybooknum;
			IF (datalength(@a_regpaybooknum_str) = 1) 					
				SET @a_regpaybooknum_str = '0000' + @a_regpaybooknum_str;
			IF (datalength(@a_regpaybooknum_str) = 2) 					
				SET @a_regpaybooknum_str = '000' + @a_regpaybooknum_str;								
			IF (datalength(@a_regpaybooknum_str) = 3) 					
				SET @a_regpaybooknum_str = '00' + @a_regpaybooknum_str;								
			IF (datalength(@a_regpaybooknum_str) = 4) 					
				SET @a_regpaybooknum_str = '0' + @a_regpaybooknum_str;										 		
			INSERT INTO dbo.GEN_NUMB_PAYMENT(dbo.GEN_NUMB_PAYMENT.A_OSZN, dbo.GEN_NUMB_PAYMENT.A_YEAR, dbo.GEN_NUMB_PAYMENT.A_NUMB_CURR_YEAR)
			VALUES (@oszn_esrn_serv_serv, @year, @a_regpaybooknum_str);		
			SET @lngLoopCount = @lngLoopCount + 1			
		END ELSE BEGIN
			SET @lngLoopCount = @lngLoopCount +1
			CONTINUE;
		END
	END

	DROP TABLE #temp_tbl_esrn_serv_serv	 
END



go

