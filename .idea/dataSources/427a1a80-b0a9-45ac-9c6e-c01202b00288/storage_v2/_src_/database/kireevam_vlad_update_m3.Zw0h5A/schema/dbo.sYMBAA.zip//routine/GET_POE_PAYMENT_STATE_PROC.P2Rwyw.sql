CREATE PROCEDURE [dbo].[GET_POE_PAYMENT_STATE_PROC] 
	@exportId INT, --Идентификатор выгрузки	
	@endMonthReg BIT 
AS
BEGIN


	DECLARE 
	@exportRegDate       DATETIME, -- дата регистрации выгрузки
	@exportDate          DATETIME, -- дата выгрузки
	@status              INT,      -- статус действует	 
	@payStartEvent       INT,       -- Начало выплаты,
	@endMonth            INT,
	@noPay               INT,
	@payStartSingle      INT,
	@payStartSingleNoPay INT
	
	 
	SELECT @status              = A_ID   FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act' -- статус действует
	SELECT @payStartEvent       = a_ouid FROM SPR_PAY_EVENT    WHERE A_CODE = '011'       -- Начало выплаты
	SELECT @endMonth            = a_ouid FROM SPR_PAY_EVENT    WHERE A_CODE = '11'   --  окончание месяца  
	SELECT @noPay               = a_ouid FROM SPR_PAY_EVENT    WHERE A_CODE = '07'   --  Невыплаченная сумма   
	SELECT @payStartSingle      = a_ouid FROM SPR_PAY_EVENT    WHERE A_CODE = '012'  --  Разовая Начало выплаты 	
	SELECT @payStartSingleNoPay = a_ouid FROM SPR_PAY_EVENT    WHERE A_CODE = '013'  --  Разовая Начало выплаты неоплаты	                                                                            --  
	                                                                              
	 	 
	DECLARE @regMode INT,@regModeEndMonth INT  	
	SET @regMode = 0
	SET @regModeEndMonth = 0
	SELECT  
	@regMode = 	 payMode.A_EVENT_REG_MODE					
	FROM WM_PAY_MODE payMode
	INNER JOIN WM_PAY_EXPORT payExport ON payExport.A_PAYMODE = payMode.A_OUID
		AND (payExport.A_STATUS = @status OR payExport.A_STATUS IS NULL)
	WHERE  (payMode.A_STATUS = @status OR payMode.A_STATUS IS NULL)
		AND payExport.A_OUID = @exportId		
		AND payMode.A_EVENT_REG_MODE IS NOT NULL 		 
		
	SET @regModeEndMonth = CASE @regMode
								WHEN 0 THEN 1
								WHEN 1 THEN 1
								WHEN 2 THEN 1
								WHEN 5 THEN 1
							END 	
		
	IF @endMonthReg = 1
	BEGIN 
		SET @regMode = 0
	END 
	
	
	 
	SELECT @exportRegDate = A_REG_DATE FROM WM_PAY_EXPORT WHERE A_OUID = @exportId   -- дата регистрации выгрузки
	SELECT @exportDate = A_EXPORT_DATA FROM WM_PAY_EXPORT WHERE A_OUID = @exportId   -- дата выгрузки
	

	-- Раскручиваем дерево событий
	CREATE TABLE #TEMP_EVENT_TREE  ( 
		ouid      INT,         -- 
		code      VARCHAR(50), -- 
		childOuid INT,         -- 
		childCode VARCHAR(50)  -- 
	);
	CREATE INDEX [ouid_IDX] ON #TEMP_EVENT_TREE(ouid ASC)
	CREATE INDEX [code_IDX] ON #TEMP_EVENT_TREE(code ASC)
	CREATE INDEX [childOuid_IDX] ON #TEMP_EVENT_TREE(childOuid ASC)
	CREATE INDEX [childCode_IDX] ON #TEMP_EVENT_TREE(childCode ASC)
	INSERT INTO #TEMP_EVENT_TREE(ouid,code,childOuid,childCode)
	SELECT ouid,code,childOuid,childCode FROM GET_POE_EVENT_TYPE_TREE()
	ORDER BY code, lvl, childCode
	--Заполнение таблицы с обрабатываемыми выплатными делами
	CREATE TABLE #TEMP_STATE_PAY_BOOK (
		payBookId INT
	);
	CREATE INDEX [payBookId_IDX] ON #TEMP_STATE_PAY_BOOK(payBookId ASC)
	INSERT INTO #TEMP_STATE_PAY_BOOK(payBookId)
	SELECT DISTINCT linkPayBook.A_TOID
	FROM WM_PAY_EXPORT payExport 		
	INNER JOIN LINK_PAY_EXPORT_PAYBOOK linkPayBook ON linkPayBook.A_FROMID = payExport.A_OUID			 
	WHERE payExport.A_OUID = @exportId	
		AND (payExport.A_STATUS = @status OR payExport.A_STATUS IS NULL)
		

     --Фильтрация мертвых людей
	SELECT payBookT.payBookId
	INTO #DEATH_PC
	FROM #TEMP_STATE_PAY_BOOK payBookT
	INNER JOIN WM_PAYMENT_BOOK payBook ON payBook.OUID = payBookT.payBookId
		AND (payBook.A_STATUS = @status OR payBook.A_STATUS IS NULL)
	INNER JOIN WM_PAYMENT payment ON payment.OUID = payBook.A_ACTREQUISIT
		AND (payment.A_STATUS = @status OR payment.A_STATUS IS NULL)
	INNER JOIN WM_PERSONAL_CARD deathPc ON ( deathPc.OUID = payBook.PERSONALOUID OR deathPc.OUID = payment.PERSONOUID)
		AND (deathPc.A_STATUS = @status OR deathPc.A_STATUS IS NULL)		
	LEFT JOIN (	SELECT 
				doc.PERSONOUID pc,
				doc.OUID,
				ROW_NUMBER () OVER ( PARTITION BY doc.PERSONOUID ORDER BY doc.OUID desc) num
				FROM WM_ACTDOCUMENTS doc
				INNER JOIN PPR_DOC pprDoc ON doc.DOCUMENTSTYPE = pprDoc.A_ID AND pprDoc.A_CODE IN ('deathSprav','deathCertificate')
           		WHERE 	(doc.A_STATUS = @status OR doc.A_STATUS IS NULL)
	) deathDoc ON deathDoc.pc = deathPc.OUID AND deathDoc.num = 1				
	WHERE (deathPc.A_DEATHDATE IS NOT NULL OR deathDoc.OUID IS NOT NULL )   
	CREATE INDEX [payBookId_IDX] ON #DEATH_PC(payBookId ASC) 


		
	--	Заполнение таблицы с закрытыми чуваками
	CREATE TABLE #TEMP_STATE_ENDMONTH (
		payBookId INT,
		regDate DATETIME,
	);
	CREATE INDEX [payBookId_IDX] ON #TEMP_STATE_ENDMONTH(payBookId ASC)
	INSERT INTO #TEMP_STATE_ENDMONTH(payBookId,regDate)			
	SELECT payBook.payBookId,payEvent.A_EVENT_REGDATE
	FROM #TEMP_STATE_PAY_BOOK payBook
	INNER JOIN WM_PAY_EVENT_UNIT payEventUnit ON payEventUnit.A_PAYMENT_BOOK = payBook.payBookId
		AND (payEventUnit.A_STATUS = @status OR payEventUnit.A_STATUS IS NULL )
	INNER JOIN WM_PAY_EVENT payEvent ON  payEventUnit.A_EVENT = payEvent.A_OUID
       AND (payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL )
    INNER JOIN #TEMP_EVENT_TREE evType ON payEvent.A_EVENT_TYPE = evType.childOuid
			AND evType.code IN ('11')
	LEFT JOIN #DEATH_PC deathPc ON deathPc.payBookId = payBook.payBookId
	WHERE  datediff(day,payEvent.A_EVENT_DATE,@exportDate) = 0
		 AND @regMode NOT IN (3 ,4, 5) 		 
		 AND deathPc.payBookId IS NULL 
	
		
	--Таблица с соыбиями начало выплаты
	CREATE TABLE #TEMP_STATE_PAYSTART ( 
		id            INT IDENTITY(1,1) PRIMARY KEY CLUSTERED,     
		payBookId     INT,         -- 
		additionalPaymentBookId INT,    --Дополнительное выплатное дело
		eventTypeId   INT,         -- 
		eventTypeCode VARCHAR(50), -- 
		unitId        INT,         -- 
		eventId       INT,         -- 
		eventExportId INT,         -- 
		eventRegDate  DATETIME,    -- 
		eventDate     DATETIME     -- 
	);
	CREATE INDEX [payBookId_IDX] ON #TEMP_STATE_PAYSTART(payBookId ASC)
	CREATE INDEX [additionalPaymentBookId_IDX] ON #TEMP_STATE_PAYSTART(additionalPaymentBookId ASC)
	CREATE INDEX [eventExportId_IDX] ON #TEMP_STATE_PAYSTART(eventExportId ASC)
	
	INSERT INTO #TEMP_STATE_PAYSTART(payBookId,additionalPaymentBookId, eventTypeId, eventTypeCode, unitId, eventId,
				eventExportId, eventRegDate,eventDate)
	SELECT payBookId,additionalPaymentBookId, eventTypeId, eventTypeCode,
		   unitId, eventId, eventExportId, eventRegDate,eventDate
	FROM (
		SELECT evUnit.A_PAYMENT_BOOK as payBookId,evUnit.A_ADDIT_PAYMENT_BOOK as additionalPaymentBookId,ev.A_EXPORT AS eventExportId, 
			ev.A_EVENT_TYPE as eventTypeId, evType.code as eventTypeCode,
			evUnit.A_OUID as unitId, ev.A_OUID AS eventId, ev.A_EVENT_REGDATE AS eventRegDate,ev.A_EVENT_DATE eventDate ,
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK,evUnit.A_ADDIT_PAYMENT_BOOK,ev.A_EVENT_TYPE  ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM WM_PAY_EVENT_UNIT evUnit 
		INNER JOIN #TEMP_STATE_PAY_BOOK payBook ON evUnit.A_PAYMENT_BOOK = payBook.payBookId
		INNER JOIN WM_PAY_EVENT ev ON evUnit.A_EVENT = ev.A_OUID
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
		INNER JOIN #TEMP_EVENT_TREE evType ON ev.A_EVENT_TYPE = evType.childOuid
			AND evType.code IN ('01'/*,'05'*/)
			AND (ev.A_EXPORT = @exportId OR datediff(day,ev.A_EVENT_DATE,@exportDate) > 0 OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND (@regMode <> 4 OR @endMonthReg = 0)))
		LEFT JOIN #TEMP_STATE_ENDMONTH endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK
			AND (@endMonthReg = 1 OR (@regModeEndMonth = 1 AND endMonth.regDate < ev.A_EVENT_REGDATE))
			AND  datediff(day,ev.A_EVENT_DATE , @exportDate) = 0
		WHERE endMonth.payBookId IS NULL 	
	) lastPay 
	WHERE lastPay.num = 1 AND lastPay.eventTypeCode NOT IN ('05') 	
    --Фильтрация    
    DELETE FROM #TEMP_STATE_PAYSTART     
    WHERE eventExportId <> @exportId
		AND payBookId IN (SELECT payBookId FROM #TEMP_STATE_PAYSTART WHERE eventExportId = @exportId)     
    DELETE FROM #TEMP_STATE_PAYSTART    
    WHERE eventTypeId<>@payStartEvent
		AND payBookId IN (SELECT payBookId FROM #TEMP_STATE_PAYSTART WHERE eventTypeId = @payStartEvent)
	DELETE FROM #TEMP_STATE_PAYSTART    
    WHERE  id NOT IN (SELECT MIN(id) id FROM #TEMP_STATE_PAYSTART GROUP BY payBookId,additionalPaymentBookId)  	
		
	
	--Таблица с событиями Изменение личных данных
	CREATE TABLE #TEMP_STATE_UNIT_CH ( 
		payBookId     INT,      -- 
		eventExportId INT,      -- 
		eventRegDate  DATETIME, -- 
		chClass       INT,      -- 
		chOldId       INT,      -- 
		chNewId       INT       -- 
	);
	CREATE INDEX [payBookId_IDX] ON #TEMP_STATE_UNIT_CH(payBookId ASC)
	INSERT INTO #TEMP_STATE_UNIT_CH(payBookId, eventExportId, eventRegDate, chClass,
				chOldId, chNewId)
	SELECT payBookId, eventExportId, eventRegDate, chClass, chOldId, chNewId
	FROM (
		SELECT payStart.payBookId, isnull(payDate.epid,ev.A_EXPORT) AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			evUnitCh.A_CLASS AS chClass, evUnitCh.A_OLD_OUID AS chOldId, evUnitCh.A_NEW_OUID AS chNewId,
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK, evUnitCh.A_CLASS ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM #TEMP_STATE_PAYSTART payStart
		INNER JOIN WM_PAY_EVENT_UNIT_PERS_CHANGE evUnitCh 
			INNER JOIN WM_PAY_EVENT_UNIT evUnit ON evUnit.A_OUID = evUnitCh.A_OUID
				AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
		AND (ev.A_EXPORT = @exportId OR datediff(day,ev.A_EVENT_DATE,@exportDate) > 0 OR (datediff(month,ev.A_EVENT_DATE,@exportDate) = 0 AND @endMonthReg = 0)							
			--OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND (@regMode <> 4 OR @endMonthReg = 0))
		)
		LEFT JOIN WM_PAY_TEMPDATA payDate ON payDate.eventUnitId = evUnit.A_OUID
		--LEFT JOIN #TEMP_STATE_ENDMONTH endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK 
		--	AND (@endMonthReg = 1 OR (@regModeEndMonth = 1 AND endMonth.regDate < ev.A_EVENT_REGDATE))
		--	AND  datediff(day,ev.A_EVENT_DATE , @exportDate) = 0
		--WHERE endMonth.payBookId IS NULL 	
	) x WHERE x.num = 1
	--Таблица с событиями Изменение перода предоставления
	CREATE TABLE #TEMP_STATE_UNIT_PERIOD ( 
		payBookId     INT,      --
		eventExportId INT,      --
		eventRegDate  DATETIME, --
		dateStart     DATETIME, --
		dateEnd       DATETIME  --
	);
	CREATE INDEX [payBookId_IDX] ON #TEMP_STATE_UNIT_PERIOD(payBookId ASC)
	INSERT INTO #TEMP_STATE_UNIT_PERIOD(payBookId, eventExportId, eventRegDate, dateStart, dateEnd)
	SELECT payBookId, eventExportId, eventRegDate, dateStart, dateEnd
	FROM (
		SELECT payStart.payBookId, ev.A_EXPORT AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			ev.A_EVENT_TYPE as eventTypeId, evUnit.A_OUID AS unitId,
			evUnitPeriod.A_START_DATE AS dateStart, evUnitPeriod.A_END_DATE AS dateEnd,
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM #TEMP_STATE_PAYSTART payStart
		INNER JOIN WM_PAY_EVENT_UNIT_NEW_PERIOD evUnitPeriod 
			INNER JOIN WM_PAY_EVENT_UNIT evUnit
				INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
			ON evUnit.A_OUID = evUnitPeriod.A_OUID
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
			AND (ev.A_EXPORT = @exportId OR datediff(day,ev.A_EVENT_DATE,@exportDate) > 0 OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND (@regMode <> 4 OR @endMonthReg = 0)))
		LEFT JOIN #TEMP_STATE_ENDMONTH endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK 
			AND (@endMonthReg = 1 OR (@regModeEndMonth = 1 AND endMonth.regDate < ev.A_EVENT_REGDATE))
			AND  datediff(day,ev.A_EVENT_DATE , @exportDate) = 0
		WHERE endMonth.payBookId IS NULL 	
	) x WHERE x.num = 1
	
	--Таблица с событиями Прекращение
	CREATE TABLE #TEMP_STATE_CLOSE ( 
		payBookId     INT,     --
		eventExportId INT,     --
		eventRegDate  DATETIME --
	);
	CREATE INDEX [payBookId_IDX] ON #TEMP_STATE_CLOSE(payBookId ASC)
	INSERT INTO #TEMP_STATE_CLOSE(payBookId, eventExportId, eventRegDate)
	SELECT payBookId, eventExportId, eventRegDate
	FROM (
		SELECT payStart.payBookId, ev.A_EXPORT AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			ev.A_EVENT_TYPE as eventTypeId, evUnit.A_OUID AS unitId,			
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM #TEMP_STATE_PAYSTART payStart
		INNER JOIN WM_PAY_EVENT_UNIT_STOP_PAY stopPay
			INNER JOIN WM_PAY_EVENT_UNIT evUnit
				INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
			ON evUnit.A_OUID = stopPay.A_OUID
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
			AND (ev.A_EXPORT = @exportId OR datediff(day,ev.A_EVENT_DATE,@exportDate) > 0 OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND (@regMode <> 4 OR @endMonthReg = 0)))			
			AND payStart.eventDate < ev.A_EVENT_DATE		
			--AND DATEDIFF(MONTH,ev.A_EVENT_DATE,@exportDate)>0
		LEFT JOIN #TEMP_STATE_ENDMONTH endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK 
			AND (@endMonthReg = 1 OR (@regModeEndMonth = 1 AND endMonth.regDate < ev.A_EVENT_REGDATE))
			AND  datediff(day,ev.A_EVENT_DATE , @exportDate) = 0
		WHERE endMonth.payBookId IS NULL 

	) x WHERE x.num = 1
	--Таблица с событиями последние
	CREATE TABLE #TEMP_STATE_LAST ( 
		payBookId     INT,      --
		eventExportId INT,      --
		eventRegDate  DATETIME, -- 
		eventTypeId   INT       --
	);
	CREATE INDEX [payBookId_IDX] ON #TEMP_STATE_LAST(payBookId ASC)
	INSERT INTO #TEMP_STATE_LAST(payBookId, eventExportId, eventRegDate, eventTypeId)
	SELECT payBookId, eventExportId, eventRegDate, eventTypeId
	FROM (
		SELECT payStart.payBookId, ev.A_EXPORT AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			ev.A_EVENT_TYPE as eventTypeId, evUnit.A_OUID AS unitId,			
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM #TEMP_STATE_PAYSTART payStart
			INNER JOIN WM_PAY_EVENT_UNIT evUnit
				INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
			AND (ev.A_EXPORT = @exportId OR datediff(day,ev.A_EVENT_DATE,@exportDate) > 0 OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND (@regMode <> 4 OR @endMonthReg = 0)))
		LEFT JOIN #TEMP_STATE_ENDMONTH endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK 
			AND (@endMonthReg = 1 OR (@regModeEndMonth = 1 AND endMonth.regDate < ev.A_EVENT_REGDATE))
			AND  datediff(day,ev.A_EVENT_DATE , @exportDate) = 0
		WHERE endMonth.payBookId IS NULL 
			AND ev.A_EVENT_TYPE <> @endMonth
			AND ev.A_EVENT_TYPE <> @noPay
			AND ev.A_EVENT_TYPE <> @payStartSingle
			AND ev.A_EVENT_TYPE <> @payStartSingleNoPay	
	) x WHERE x.num = 1	
	
	--Таблица с событиями изменение размера
	CREATE TABLE #TEMP_STATE_UNIT_AMOUNT ( 
		payBookId     INT,           -- 
		eventExportId INT,           -- 
		eventRegDate  DATETIME,		 -- 
		curAmount     NUMERIC(18,2), -- 
		curAddAmount  NUMERIC(18,2), -- 
		amountStart   DATETIME       -- 
	);
	CREATE INDEX [payBookId_IDX] ON #TEMP_STATE_UNIT_AMOUNT(payBookId ASC)
	INSERT INTO #TEMP_STATE_UNIT_AMOUNT(payBookId, eventExportId, eventRegDate, curAmount, curAddAmount,amountStart)
	SELECT payBookId, eventExportId, eventRegDate, amount, addAmount,startAmount
	FROM (
		SELECT payStart.payBookId, ev.A_EXPORT AS eventExportId, ev.A_EVENT_REGDATE AS eventRegDate, 
			ev.A_EVENT_TYPE as eventTypeId, evUnit.A_OUID AS unitId,			
			evUnitAmount.A_NEWSIZE amount,
			CASE WHEN ev.A_EXPORT = @exportId
				then evUnitAmount.A_R1 
				ELSE 0
			END addAmount,			
			ev.A_EVENT_DATE startAmount,			
			ROW_NUMBER() OVER(PARTITION BY evUnit.A_PAYMENT_BOOK ORDER BY ev.A_EVENT_DATE DESC, ev.A_EVENT_REGDATE DESC) as num
		FROM #TEMP_STATE_PAYSTART payStart
		INNER JOIN WM_PAY_EVENT_UNIT_NEW_SIZE evUnitAmount 
			INNER JOIN WM_PAY_EVENT_UNIT evUnit
				INNER JOIN WM_PAY_EVENT ev ON ev.A_OUID = evUnit.A_EVENT
			ON evUnit.A_OUID = evUnitAmount.A_OUID
		ON payStart.payBookId = evUnit.A_PAYMENT_BOOK
			AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)
			AND (ev.A_EXPORT = payStart.eventExportId OR ev.A_EVENT_DATE > payStart.eventDate OR (DATEDIFF(month,ev.A_EVENT_DATE,payStart.eventDate)=0 and ev.A_EVENT_REGDATE > payStart.eventRegDate))
			AND (ev.A_EXPORT = @exportId OR datediff(day,ev.A_EVENT_DATE,@exportDate) > 0 OR (DATEDIFF(month,ev.A_EVENT_DATE,@exportDate)=0 AND ev.A_EVENT_REGDATE < @exportRegDate AND (@regMode <> 4 OR @endMonthReg = 0)))
		LEFT JOIN #TEMP_STATE_ENDMONTH endMonth ON endMonth.payBookId = evUnit.A_PAYMENT_BOOK 
			AND (@endMonthReg = 1 OR (@regModeEndMonth = 1 AND endMonth.regDate < ev.A_EVENT_REGDATE))
			AND  datediff(day,ev.A_EVENT_DATE , @exportDate) = 0
		WHERE endMonth.payBookId IS NULL 
	) x WHERE x.num = 1	

	--Таблица Результатом
	INSERT INTO #TEMP_POE_PAYMENT_STATE(exportId,payBookId,additionalPaymentBookId, paymentId, prevPaymentId, fioId, prevFioId,
		addrId, prevAddrId, idDocId, prevIdDocId, payStartDate, payEndDate,mspLkNpdId,prevmspLkNpdId,
		curAmount, curAddAmount,amountStart,eventTypeLast,		
		startEventType,startEventDate,startEventId,startEventUnitId,activePay 	
	)
	SELECT @exportId,payStart.payBookId,evUnit.A_ADDIT_PAYMENT_BOOK additionalPaymentBookId,
		evUnitPay.A_PAYMENT, CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_PAYMENT END, 
		evUnitPay.A_FIO, CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_FIO END,
		evUnitPay.A_ADDRESS, CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_ADDRESS END,
		evUnitPay.A_ID_DOC, CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_ID_DOC END,
		
		CASE WHEN evUnitPeriod.payBookId IS NOT NULL 
			THEN evUnitPeriod.dateStart
			ELSE evUnitPay.A_START_DATE
		END ,
		CASE WHEN evUnitPeriod.payBookId IS NOT NULL 
			THEN evUnitPeriod.dateEnd
			ELSE evUnitPay.A_END_DATE
		END,
		evUnitPay.A_MSP_LK_NPD, 
		CASE WHEN payStart.eventExportId = @exportId THEN NULL ELSE evUnitPay.A_MSP_LK_NPD END,
		evUnitPay.A_SUM curAmount, 
		case when payStart.eventExportId = @exportId then evUnitPay.A_R1 else 0 end curAddAmount,
		evUnitPay.A_START_DATE amountStart,
		evLast.eventTypeId,
		payStart.eventTypeId startEventType,		
		payStart.eventDate startEventDate,payStart.eventId startEventId,payStart.unitId startEventUnitId,
		CASE WHEN evClose.payBookId	IS NOT NULL THEN 0 ELSE 1 END  activePay
	FROM #TEMP_STATE_PAYSTART payStart 
	INNER JOIN WM_PAY_EVENT_UNIT_NEWSERV evUnitPay ON payStart.unitId = evUnitPay.A_OUID 	
	INNER JOIN WM_PAY_EVENT_UNIT evUnit ON evUnit.A_OUID = evUnitPay.A_OUID
		AND (evUnit.A_STATUS = @status OR evUnit.A_STATUS IS NULL)				
	LEFT JOIN #TEMP_STATE_UNIT_PERIOD evUnitPeriod ON payStart.payBookId = evUnitPeriod.payBookId		
	LEFT JOIN #TEMP_STATE_LAST evLast ON payStart.payBookId = evLast.payBookId		
	LEFT JOIN #TEMP_STATE_CLOSE evClose ON payStart.payBookId = evClose.payBookId	
	--
	UPDATE #TEMP_POE_PAYMENT_STATE SET curAmount = evUnitAmount.curAmount,curAddAmount = evUnitAmount.curAddAmount,amountStart = evUnitAmount.amountStart
	FROM #TEMP_STATE_PAYSTART payStart
	INNER JOIN #TEMP_STATE_UNIT_AMOUNT evUnitAmount ON payStart.payBookId = evUnitAmount.payBookId
	WHERE [#TEMP_POE_PAYMENT_STATE].payBookId = payStart.payBookId
	--
	UPDATE #TEMP_POE_PAYMENT_STATE SET paymentId = evUnitCh.chNewId, prevPaymentId = 
		CASE WHEN evUnitCh.eventExportId = @exportId 
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM #TEMP_STATE_PAYSTART payStart
	INNER JOIN #TEMP_STATE_UNIT_CH evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'wmPayment'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [#TEMP_POE_PAYMENT_STATE].payBookId = payStart.payBookId
	--
	UPDATE #TEMP_POE_PAYMENT_STATE SET fioId = evUnitCh.chNewId, prevFioId = 
		CASE WHEN evUnitCh.eventExportId = @exportId 
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM #TEMP_STATE_PAYSTART payStart
	INNER JOIN #TEMP_STATE_UNIT_CH evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'pcFIOHistory'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [#TEMP_POE_PAYMENT_STATE].payBookId = payStart.payBookId
	--
	UPDATE #TEMP_POE_PAYMENT_STATE SET addrId = evUnitCh.chNewId, prevAddrId = 
		CASE WHEN evUnitCh.eventExportId = @exportId 
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM #TEMP_STATE_PAYSTART payStart
	INNER JOIN #TEMP_STATE_UNIT_CH evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'wmAddress'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [#TEMP_POE_PAYMENT_STATE].payBookId = payStart.payBookId

	--
	UPDATE #TEMP_POE_PAYMENT_STATE SET idDocId = evUnitCh.chNewId, prevIdDocId = 
		CASE WHEN evUnitCh.eventExportId = @exportId
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM #TEMP_STATE_PAYSTART payStart
	INNER JOIN #TEMP_STATE_UNIT_CH evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'wmActDocuments'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [#TEMP_POE_PAYMENT_STATE].payBookId = payStart.payBookId
	--
	UPDATE #TEMP_POE_PAYMENT_STATE SET mspLkNpdId = evUnitCh.chNewId, prevmspLkNpdId = 
		CASE WHEN evUnitCh.eventExportId = @exportId
			THEN evUnitCh.chOldId 
			ELSE evUnitCh.chNewId
		END 
	FROM #TEMP_STATE_PAYSTART payStart
	INNER JOIN #TEMP_STATE_UNIT_CH evUnitCh 
		INNER JOIN SXCLASS cls ON cls.OUID = evUnitCh.chClass
			AND cls.NAME = 'sprNpdMspCat'
	ON payStart.payBookId = evUnitCh.payBookId
	WHERE [#TEMP_POE_PAYMENT_STATE].payBookId = payStart.payBookId

	RETURN

END
go

