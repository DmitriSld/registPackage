CREATE FUNCTION dbo.CHAES_INFOOBMEN_MAIN_TABLE (@year INT,	       --Год
@month INT,		   --Месяц
@regionCode VARCHAR(255),  --Код региона
@org INT,		   --Организация
@mspList VARCHAR(2550),  --Список МСП
@typePay INT,	       --Направление выплаты
@TYPE BIT			   --Тип выплаты(по решению суда/без решения суда)
)
RETURNS @table TABLE (
	id INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED
	,INC VARCHAR(255)
	,  --Номер пункта списка
	EXPPNR VARCHAR(255)
	,  --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
	CODE VARCHAR(255)
	,  --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
	payYear INT
	,		   --Год
	payMonth INT
	,		   --Месяц
	SURNAME VARCHAR(255)
	,  --Фамилия получателя
	NAME VARCHAR(255)
	,  --Имя получателя
	SECONDNAME VARCHAR(255)
	,  --Отчество получателя
	DOC VARCHAR(255)
	,  --Наименование документа, подтверждающего личность
	SERIES VARCHAR(255)
	,  --Серия документа, подтверждающего личность
	NUMBER VARCHAR(255)
	,  --Номер документа, подтверждающего личность
	DATAISSUE VARCHAR(255)
	,  --Кем и когда выдан документ, подтверждающий личность
	/**
	* Для Сбербанка
	**/
	expBank VARCHAR(255)
	,  --Номер отделения Сбербанка
	/**
	* Для банков России
	**/
	rootBankName VARCHAR(255)
	,  --Наименование территориального банка
	bik VARCHAR(255)
	,  --БИК банка получателя
	corraccount VARCHAR(255)
	,  --Корреспондентский счет банка получателя
	bankName VARCHAR(255)
	,  --Наименование банка
	BANK VARCHAR(255)
	,  --Номер территориального банка
	OSB VARCHAR(255)
	,  --Номер ОСБ
	DEPT VARCHAR(255)
	,  --Номер внутреннего структурного подразделения
	/**
	* Для почты
	**/
	postIndex VARCHAR(255)
	,  --Индекс
	postAddress VARCHAR(255)
	,  --Адресс
	reasonCode VARCHAR(2555)
	, --Коды причин изменения данных
	sumAssign DECIMAL(12, 2)
	, --Размер денежной компенсации
	notes VARCHAR(4000)
	, --Примечание
	accountcount VARCHAR(255)
	,  --Номер лицевого счета в Сбербанке России
	/**
	* Для создания выплаты
	**/
	payCalc INT
	,		   --Начисление
	paidAmount INT
	,		   --Выплата
	/**
	* Для дока реш. суд.
	**/
	orgDoc VARCHAR(255)
	,  --Организация выдавшая док.
	DOCBASENUMBER VARCHAR(255)
	,  --Номер документа
	DOCBASEDATE DATETIME
	,	   --Дата основания
	A_DOCBASESTARTDATE DATETIME
	,      --Дата начала
	A_DOCBASEFINISHDATE DATETIME
	,      --Дата окончания
	A_AMOUNTADD NUMERIC(12, 2)
	, --Доплата из дока
	typePay INT
	,		   --Тип выплаты 1 начисление 2 доплата
	pcId INT
	,           --Идентификатор ЛД
	mspId INT
	,           --Идентификатор МСП
	addrId INT			   --Идентификатор адреса регистрации
)
AS
BEGIN
	DECLARE @lngth INT

	SET @lngth = 1
	IF (LEN(@regionCode) = 2)
		SET @lngth = 3
	ELSE
		SET @regionCode = ''

	--Статус Утверждено
	DECLARE	@statusUtv INT
					,@vipSform INT
	SELECT
		@statusUtv = a_id
	FROM SPR_STATUS_PROCESS
	WHERE A_CODE = '100'
	--Выплата сфомирована
	SELECT
		@vipSform = a_id
	FROM SPR_STATUS_PROCESS
	WHERE A_CODE = '11'


	-- Статус действует
	DECLARE @actstatus INT
	SELECT
		@actstatus = A_ID
	FROM ESRN_SERV_STATUS
	WHERE A_STATUSCODE = 'act'
	--Статус документа действует
	DECLARE @docStatus INT
	SELECT
		@docStatus = a_ouid
	FROM SPR_DOC_STATUS
	WHERE A_CODE = 'active'

	--Основная таблица
	INSERT INTO @table
		SELECT
			'$id' AS INC
			,               --Номер пункта списка
			ISNULL((SELECT TOP 1
					a_persnum
				FROM WM_PERSNUM_SEND
				WHERE A_TARGETORG = 10
					AND (A_STATUS = @actstatus
					OR A_STATUS IS NULL)
					AND a_pc = WM_PERSONAL_CARD.ouid)
			,
			REPLICATE('0', 2 - LEN(@regionCode)) + @regionCode + REPLICATE('0', 2 - LEN(ESRN_OSZN_DEP.A_OSZNCODE)) + ESRN_OSZN_DEP.A_OSZNCODE +
																																																																					CASE
																																																																						WHEN LEN(WM_PAYMENT_BOOK.A_NUMPB) > 0
																																																																						THEN SUBSTRING(WM_PAYMENT_BOOK.A_NUMPB, CHARINDEX('-', WM_PAYMENT_BOOK.A_NUMPB, CHARINDEX('-', WM_PAYMENT_BOOK.A_NUMPB) + 1)
																																																																							+ 1, LEN(WM_PAYMENT_BOOK.A_NUMPB) - CHARINDEX('-', WM_PAYMENT_BOOK.A_NUMPB, CHARINDEX('-', WM_PAYMENT_BOOK.A_NUMPB) + 1)
																																																																							- 3)
																																																																						ELSE STUFF(STUFF(WM_PERSONAL_CARD.A_SPUNID, 1, @lngth, @regionCode), 5, 1, '')
																																																																					END
			) AS EXPPNR
			,            --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
			--(SELECT TOP 1 a_persnum
			--FROM   WM_PERSNUM_SEND
			--WHERE  A_TARGETORG = 986
			--	AND a_persnum IS NOT NULL
			--	AND (A_STATUS = @actstatus OR A_STATUS IS NULL)
			--	AND a_pc = WM_PERSONAL_CARD.ouid) AS CODE,            --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
			CASE
				WHEN LEN(WM_PERSONAL_CARD.A_SNILS) >= 9
				THEN ISNULL(LEFT(WM_PERSONAL_CARD.A_SNILS, 9), '')
				ELSE ISNULL(WM_PERSONAL_CARD.A_SNILS, '')
			END AS CODE
			,             --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны

			WM_PAY_CALC.A_YEAR AS payYear
			,           --Год
			WM_PAY_CALC.A_MONTH AS payMonth
			,          --Месяц
			ISNULL(SPR_FIO_SURNAME.A_NAME, '') AS SURNAME
			,           --Фамилия получателя
			ISNULL(SPR_FIO_NAME.A_NAME, '') AS NAME
			,              --Имя получателя
			ISNULL(SPR_FIO_SECONDNAME.A_NAME, '') AS SECONDNAME
			,        --Отчество получателя
			ISNULL(passport.docTypeTitle, '') AS DOC
			,				--Наименование документа, подтверждающего личность
			ISNULL(passport.docSer, '') AS SERIES
			,			--Серия документа, подтверждающего личность
			ISNULL(passport.docNum, '') AS NUMBER
			,			--Номер документа, подтверждающего личность
			ISNULL(passport.orgTitle, '')
			+ ISNULL(' ' + CONVERT(VARCHAR, passport.docDate, 104), '') AS DATAISSUE
			, --Кем и когда выдан документ, подтверждающий личность
			REPLACE(
			ISNULL(SPACE(4 - LEN(SUBSTRING(SPR_ORG_BANKS.A_SBERID, 4, 4))), '') +
			SUBSTRING(SPR_ORG_BANKS.A_SBERID, 4, 4) +
			'/' +
			ISNULL(SPACE(5 - LEN(SUBSTRING(SPR_ORG_BANKS.A_SBERID, 8, LEN(SPR_ORG_BANKS.A_SBERID)))), '') +
			SUBSTRING(SPR_ORG_BANKS.A_SBERID, 8, LEN(SPR_ORG_BANKS.A_SBERID)),
			' ',
			'0'
			) AS bank_dep
			,            --Номер отделения Сбербанка
			rootOrgBase.A_NAME1 AS rootBankName
			,childOrg.A_BIK AS bik
			,                 --БИК банка получателя
			childBank.A_CORRACCOUNT AS corraccount
			,         --Корреспондентский счет банка получателя
			SPR_ORG_BASE.A_NAME1 AS bankName
			,            --Наименование банка

			SUBSTRING(SPR_ORG_BANKS.A_SBERID, 2, 2) AS [BANK]
			,				--Номер территориального банка
			SUBSTRING(SPR_ORG_BANKS.A_SBERID, 4, 4) AS OSB
			,					--Номер ОСБ
			CASE
				WHEN LEN(SPR_ORG_BANKS.A_SBERID) > 7
				THEN SUBSTRING(SPR_ORG_BANKS.A_SBERID, 8, 5)
				ELSE NULL
			END AS DEPT
			,					--Номер внутреннего структурного подразделения

			ISNULL(SPR_MAIL_PHONE.A_INDEX, '') AS postIndex
			,           --Индекс

			ISNULL(ISNULL(SPR_FBTYPE.A_NAME + ' ', '') + SPR_FEDERATIONBOROUGHT.A_NAME + ', ', '') +
			ISNULL(ISNULL(SPR_TOWN_TYPE.A_NAME + '. ', '') + SPR_TOWN.A_NAME + ', ', '') +
			ISNULL(ISNULL(SPR_STEET_TYPE.A_NAME + '. ', '') + SPR_STREET.A_NAME + ', ', '') +
			ISNULL('д.' + WM_ADDRESS.A_HOUSENUMBER, '') +
			ISNULL(', к.' + WM_ADDRESS.A_BUILDING, '') +
			ISNULL(', кв.' + WM_ADDRESS.A_FLATNUMBER, '')
			AS postAddress
			,         --Адресс
			--CASE WHEN WM_PAYMENT.OUID != prevPay.A_PAYMENT OR  beforePay.A_PAYACCOUNT IS NOT NULL
			--	THEN SUBSTRING(SPR_EXPORT_CHAES.A_CODE,1,2) + '2'
			--	ELSE SPR_EXPORT_CHAES.A_CODE
			--END

			SPR_EXPORT_CHAES.A_CODE AS reason
			,              --Коды причин изменения данных
			WM_PAY_CALC.A_SUMASSIGN AS A_SUMASSIGN
			,         --Размер денежной компенсации
			ISNULL(CONVERT(VARCHAR, WM_PAY_CALC.A_COMMENT), (SELECT
					A_REASON
				FROM SPR_ROSTRUD_REASONS
				WHERE A_CODE =
											CASE
												WHEN WM_PAYMENT.OUID != prevPay.A_PAYMENT
												THEN 1
												WHEN beforePay.A_PAYACCOUNT IS NOT NULL
												THEN 2
												ELSE NULL
											END)
			) AS notes
			,               --Примечание
			WM_PAYMENT.ACCOUNTINGCOUNT AS accountcount
			,		   --Номер лицевого счета в Сбербанке России
			z.OUID AS payCalc
			,             --Начисление
			z.wpamount AS paidAmount
			,          --Выплата
			actDoc.orgDoc AS orgDoc
			,              --Организация выдавшая док.
			actDoc.DOCBASENUMBER AS DOCBASENUMBER
			,       --Номер документа
			actDoc.DOCBASEDATE AS DOCBASEDATE
			,		   --Дата основания
			actDoc.A_DOCBASESTARTDATE AS A_DOCBASESTARTDATE
			,  --Дата начала
			actDoc.A_DOCBASEFINISHDATE AS A_DOCBASEFINISHDATE
			, --Дата окончания
			NULL AS A_AMOUNTADD
			,         --Размер доплаты
			1 AS typePay
			,             --тип 1 начисление
			WM_PERSONAL_CARD.OUID AS pcId
			,                --Идентификатор ЛД
			SPR_NPD_MSP_CAT.A_MSP AS mspId
			,               --Идентификатор МСП
			WM_PERSONAL_CARD.A_REGFLAT AS addrId			   --Идентификатор адреса регистрации

		FROM WM_PERSONAL_CARD
		--ФИО
		LEFT JOIN SPR_FIO_NAME
			ON SPR_FIO_NAME.OUID = WM_PERSONAL_CARD.A_NAME
		LEFT JOIN SPR_FIO_SURNAME
			ON SPR_FIO_SURNAME.OUID = WM_PERSONAL_CARD.SURNAME
		LEFT JOIN SPR_FIO_SECONDNAME
			ON SPR_FIO_SECONDNAME.OUID = WM_PERSONAL_CARD.A_SECONDNAME
		--Документ, удостоверяющий личность
		LEFT JOIN (SELECT
				doc.PERSONOUID AS pcId
				,doc.OUID AS docId
				,doc.DOCUMENTSNUMBER AS docNum
				,doc.DOCUMENTSERIES AS docSer
				,doc.ISSUEEXTENSIONSDATE AS docDate
				,doc.DOCUMENTSTYPE AS docType
				,docType.A_CODE AS docTypeCode
				,docType.A_NAME AS docTypeTitle
				,ISNULL(ISNULL(org.A_SHORTNAME, org.A_NAME1), '') AS orgTitle
				,ROW_NUMBER() OVER (PARTITION BY doc.PERSONOUID ORDER BY CASE
				docType.A_CODE
					WHEN 'rusPassport'
					THEN 0
					ELSE 1
				END,
				CASE
					WHEN (doc.ISSUEEXTENSIONSDATE IS NULL OR
						YEAR(doc.ISSUEEXTENSIONSDATE) * 100 + MONTH(doc.ISSUEEXTENSIONSDATE) <= @year * 100 + @month) AND
						(doc.COMPLETIONSACTIONDATE IS NULL OR
						YEAR(doc.COMPLETIONSACTIONDATE) * 100 + MONTH(doc.COMPLETIONSACTIONDATE) >= @year * 100 + @month)
					THEN 0
					ELSE 1
				END, doc.ISSUEEXTENSIONSDATE DESC, doc.OUID) AS num
			FROM WM_ACTDOCUMENTS doc
			INNER JOIN PPR_DOC docType
				ON doc.DOCUMENTSTYPE = docType.A_ID
				AND docType.A_ISIDENTITYCARD = 1
			LEFT JOIN SPR_ORG_BASE org
				ON doc.GIVEDOCUMENTORG = org.OUID
			WHERE (doc.A_STATUS = @actstatus
				OR doc.A_STATUS IS NULL)) passport
			ON WM_PERSONAL_CARD.OUID = passport.pcId
			AND passport.num = 1
		--Реквизиты
		INNER JOIN WM_PAYMENT
			ON WM_PAYMENT.PersonOUID = WM_PERSONAL_CARD.ouid
			AND WM_PAYMENT.A_PAYMENTORG IS NOT NULL
		--Выплатное дело
		INNER JOIN WM_PAYMENT_BOOK
			ON WM_PAYMENT.OUID = WM_PAYMENT_BOOK.A_ACTREQUISIT
		LEFT JOIN (SELECT DISTINCT
				paid.A_PAYACCOUNT
				,paid.A_PAYMENT
			FROM WM_PAIDAMOUNTS paid
			WHERE (paid.A_STATUS = @actstatus
				OR paid.A_STATUS IS NULL)
				AND paid.A_YEAR =
													CASE
														WHEN @month - 1 = 0
														THEN @year - 1
														ELSE @year
													END
				AND paid.A_MONTH =
													CASE
														WHEN @month - 1 = 0
														THEN 12
														ELSE @month - 1
													END) prevPay
			ON WM_PAYMENT_BOOK.OUID = prevPay.A_PAYACCOUNT
		LEFT JOIN (SELECT DISTINCT
				paid.A_PAYACCOUNT
			FROM WM_PAIDAMOUNTS paid
			WHERE (paid.A_STATUS = @actstatus
				OR paid.A_STATUS IS NULL)
				AND paid.A_YEAR > 1000
				AND paid.A_MONTH BETWEEN 1 AND 12
				AND CONVERT(DATETIME, '01.' + CAST(paid.A_MONTH AS VARCHAR) + '.' + CAST(paid.A_YEAR AS VARCHAR), 104)
				< DATEADD(MONTH, -1, CONVERT(DATETIME, '01.' + CAST(@month AS VARCHAR) + '.' + CAST(@year AS VARCHAR), 104))) beforePay
			ON WM_PAYMENT_BOOK.OUID = beforePay.A_PAYACCOUNT
			AND prevPay.A_PAYMENT IS NULL
		--Назначение
		INNER JOIN ESRN_SERV_SERV
		INNER JOIN ESRN_OSZN_DEP
			ON ESRN_OSZN_DEP.OUID = ESRN_SERV_SERV.a_orgname
		--МСП-ЛК-НПД
		INNER JOIN SPR_NPD_MSP_CAT
			ON ESRN_SERV_SERV.A_SERV = SPR_NPD_MSP_CAT.A_ID
			AND CHARINDEX(',' + CONVERT(VARCHAR, SPR_NPD_MSP_CAT.a_id) + ',', ',' + @mspList + ',') > 0
			ON ESRN_SERV_SERV.A_PAYMENTBOOK = WM_PAYMENT_BOOK.OUID
			AND (ESRN_SERV_SERV.a_orgname = @org
			OR @org IS NULL
			OR @org = '-1')
		--Начисление
		INNER JOIN WM_PAY_CALC
			ON ESRN_SERV_SERV.OUID = WM_PAY_CALC.A_MSP
		--Фильтр на начисление
		INNER JOIN (SELECT
				wpc.OUID
				,NULL AS wpamount
			FROM WM_PAY_CALC wpc
			WHERE (wpc.A_YEAR * 100 + wpc.A_MONTH) <= (@year * 100 + @month)
				AND (wpc.A_STATUS = @actstatus
				OR wpc.A_STATUS IS NULL)
				AND wpc.A_STATUSPRIVELEGE = @statusUtv
			UNION ALL
			SELECT
				wpc.OUID
				,wp3.OUID AS wpamount
			FROM WM_PAIDAMOUNTS wp3
			INNER JOIN SPR_STATUS_PAYMENT ssp
				ON wp3.A_STATUSPRIVELEGE = ssp.A_ID
				AND ssp.A_CODE = 2
			INNER JOIN WM_PAY_CALC wpc
				ON wp3.A_PAYCALC = wpc.OUID
			WHERE (wp3.A_YEAR * 100 + wp3.A_MONTH) <= (@year * 100 + @month)
				AND (wp3.A_STATUS = @actstatus
				OR wp3.A_STATUS IS NULL)
				AND (wpc.A_STATUS = @actstatus
				OR wpc.A_STATUS IS NULL)
				AND wpc.A_STATUSPRIVELEGE = @vipSform) z
			ON WM_PAY_CALC.OUID = z.OUID
		-- Документы о судебном решениии
		LEFT JOIN (SELECT
				actDoc.OUID
				,actDoc.PERSONOUID
				,actDoc.A_MSP
				,actDoc.A_POSOB_AMOUNT
				,actDoc.DOCBASENUMBER
				,actDoc.DOCBASEDATE
				,actDoc.A_DOCBASESTARTDATE
				,actDoc.A_DOCBASEFINISHDATE
				,orgD.A_NAME1 AS orgDoc
				,ROW_NUMBER() OVER (PARTITION BY actDoc.PERSONOUID, actDoc.A_MSP, actDoc.A_POSOB_AMOUNT ORDER BY actDoc.DOCBASEDATE) AS num
			FROM WM_ACTDOCUMENTS AS actDoc
			INNER JOIN PPR_DOC
				ON actDoc.DOCUMENTSTYPE = PPR_DOC.A_ID
				AND PPR_DOC.A_CODE = 'courtDecisionMSP'
			LEFT JOIN SPR_ORG_BASE orgD
				ON orgD.ouid = actDoc.GIVEDOCUMENTORG
				AND (orgD.A_STATUS = @actstatus
				OR orgD.A_STATUS IS NULL)
			WHERE actDoc.A_DOCSTATUS = @docStatus
				AND (actDoc.A_STATUS = @actstatus
				OR actDoc.A_STATUS IS NULL)) actDoc
			ON actDoc.PERSONOUID = WM_PERSONAL_CARD.OUID
			AND actDoc.A_MSP = SPR_NPD_MSP_CAT.A_MSP
			AND actDoc.A_POSOB_AMOUNT <= WM_PAY_CALC.A_SUMASSIGN
			AND actDoc.DOCBASEDATE <= WM_PAY_CALC.A_FROMDATE
			AND actDoc.num = 1
		--Коды ЧАЭС
		LEFT JOIN (SELECT DISTINCT
				chaesTable.A_CODE
				,SPR_LINK_EXPORT_CHAES.TOID
				,chaesTable.A_SUD
			FROM SPR_EXPORT_CHAES chaesTable
			INNER JOIN SPR_LINK_EXPORT_CHAES
				ON chaesTable.A_OUID = SPR_LINK_EXPORT_CHAES.FROMID) SPR_EXPORT_CHAES
			ON SPR_NPD_MSP_CAT.A_ID = SPR_EXPORT_CHAES.TOID
			AND (
			((SPR_EXPORT_CHAES.A_SUD = 0
			OR SPR_EXPORT_CHAES.A_SUD IS NULL)
			AND (@TYPE = 0
			AND actDoc.OUID IS NULL))
			OR (SPR_EXPORT_CHAES.A_SUD = 1
			AND ((@TYPE = 0
			AND actDoc.OUID IS NOT NULL)
			OR @TYPE = 1))
			)
		--Фильтр на направление выплат
		INNER JOIN SPR_PAY_TYPE
			ON WM_PAYMENT.DELIVERYWAY = SPR_PAY_TYPE.A_ID
			AND (
			((SPR_PAY_TYPE.A_COD = 'NR2'
			AND @typePay = 1)
			OR (@typePay = 2
			AND SPR_PAY_TYPE.A_COD NOT IN ('NR1', 'NR2')))
			OR (SPR_PAY_TYPE.A_COD = 'NR1'
			AND @typePay = 3)
			)
		--Банк
		LEFT JOIN SPR_ORG_BANKS
		INNER JOIN SPR_ORG_BASE
			ON SPR_ORG_BASE.OUID = SPR_ORG_BANKS.OUID
			AND (SPR_ORG_BASE.A_STATUS = @actstatus
			OR SPR_ORG_BASE.A_STATUS IS NULL)
			ON (
			(WM_PAYMENT.A_PAYMENTORG = SPR_ORG_BANKS.OUID
			--AND SPR_ORG_BANKS.A_TYPEBANK = 'sberbank'
			AND @typePay = 1)
			OR (dbo.GET_PARENT_ORG(WM_PAYMENT.A_PAYMENTORG) = SPR_ORG_BANKS.OUID
			AND (SPR_ORG_BANKS.A_TYPEBANK IS NULL
			OR SPR_ORG_BANKS.A_TYPEBANK <> 'sberbank')
			AND @typePay = 2)
			)
		--Банк
		LEFT JOIN SPR_ORG_BANKS childBank
		INNER JOIN SPR_ORG_BASE childOrg
			ON childOrg.OUID = childBank.OUID
			AND (childOrg.A_STATUS = @actstatus
			OR childOrg.A_STATUS IS NULL)
			ON WM_PAYMENT.A_PAYMENTORG = childBank.OUID
		--Территориальный банк
		LEFT JOIN SPR_ORG_BANKS rootBank
		INNER JOIN SPR_ORG_BASE rootOrgBase
			ON rootOrgBase.OUID = rootBank.OUID
			AND (rootOrgBase.A_STATUS = @actstatus
			OR rootOrgBase.A_STATUS IS NULL)
			ON SPR_ORG_BANKS.A_PARENT = rootBank.OUID
		--Индекс и Адрес
		LEFT JOIN SPR_MAIL_PHONE
		INNER JOIN SPR_ORG_BASE mailBase
			ON mailBase.OUID = SPR_MAIL_PHONE.OUID
			AND (mailBase.A_STATUS = @actstatus
			OR mailBase.A_STATUS IS NULL)
			ON WM_PAYMENT.A_PAYMENTORG = SPR_MAIL_PHONE.OUID
		LEFT JOIN WM_ADDRESS
			ON ISNULL(WM_PAYMENT.ALTERNATIVEADDRESSDEIVERY, WM_PERSONAL_CARD.a_regflat) = WM_ADDRESS.OUID
			AND (WM_ADDRESS.A_STATUS = @actstatus
			OR WM_ADDRESS.A_STATUS IS NULL)
		LEFT JOIN SPR_COUNTRY
			ON SPR_COUNTRY.OUID = WM_ADDRESS.A_COUNTRY
		LEFT JOIN SPR_SUBJFED
			ON SPR_SUBJFED.OUID = WM_ADDRESS.A_SUBFED
		LEFT JOIN SPR_SUBJFEDTYPE
			ON SPR_SUBJFEDTYPE.A_ID = SPR_SUBJFED.A_TYPE
		LEFT JOIN SPR_FEDERATIONBOROUGHT
			ON SPR_FEDERATIONBOROUGHT.OUID = WM_ADDRESS.A_FEDBOROUGH
		LEFT JOIN SPR_FBTYPE
			ON SPR_FBTYPE.A_ID = SPR_FEDERATIONBOROUGHT.A_TYPE
		LEFT JOIN SPR_TOWN
			ON SPR_TOWN.OUID = WM_ADDRESS.A_TOWN
		LEFT JOIN SPR_TOWN_TYPE
			ON SPR_TOWN_TYPE.OUID = SPR_TOWN.A_TOWNTYPE
		LEFT JOIN SPR_STREET
			ON SPR_STREET.OUID = WM_ADDRESS.A_STREET
		LEFT JOIN SPR_STEET_TYPE
			ON SPR_STEET_TYPE.OUID = SPR_STREET.A_STREETTYPE

		WHERE (
			(@typePay IN (1, 2)
			AND SPR_ORG_BANKS.OUID IS NOT NULL
			AND childBank.OUID IS NOT NULL)
			OR (@typePay = 3
			AND SPR_MAIL_PHONE.OUID IS NOT NULL)
			)
			AND (WM_PERSONAL_CARD.A_STATUS = @actstatus
			OR WM_PERSONAL_CARD.A_STATUS IS NULL)
			AND (WM_PAYMENT.A_STATUS = @actstatus
			OR WM_PAYMENT.A_STATUS IS NULL)
			AND (WM_PAYMENT_BOOK.A_STATUS = @actstatus
			OR WM_PAYMENT_BOOK.A_STATUS IS NULL)
			AND (ESRN_SERV_SERV.A_STATUS = @actstatus
			OR ESRN_SERV_SERV.A_STATUS IS NULL)
			AND (WM_PAY_CALC.A_STATUS = @actstatus
			OR WM_PAY_CALC.A_STATUS IS NULL)
			AND (SPR_NPD_MSP_CAT.A_STATUS = @actstatus
			OR SPR_NPD_MSP_CAT.A_STATUS IS NULL)
		ORDER BY	SPR_FIO_SURNAME.A_NAME
							,SPR_FIO_NAME.A_NAME
							,SPR_FIO_SECONDNAME.A_NAME

	--Запись доплат
	INSERT INTO @table
		SELECT
			tempT.INC AS INC
			,                 --Номер пункта списка
			tempT.EXPPNR AS EXPPNR
			,              --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
			tempT.CODE AS CODE
			,                --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
			WM_ADDPAY_CALC.A_YEAR AS payYear
			,             --Год
			WM_ADDPAY_CALC.A_MONTH AS payMonth
			,            --Месяц
			tempT.SURNAME AS SURNAME
			,             --Фамилия получателя
			tempT.NAME AS NAME
			,                --Имя получателя
			tempT.SECONDNAME AS SECONDNAME
			,          --Отчество получателя
			tempT.DOC AS DOC
			,				 --Наименование документа, подтверждающего личность
			tempT.SERIES AS SERIES
			,			     --Серия документа, подтверждающего личность
			tempT.NUMBER AS NUMBER
			,				 --Номер документа, подтверждающего личность
			tempT.DATAISSUE AS DATAISSUE
			,			 --Кем и когда выдан документ, подтверждающий личность

			tempT.expBank AS bank_dep
			,            --Номер отделения Сбербанка
			tempT.rootBankName AS rootBankName
			,        --Наименование территориального банка
			tempT.bik AS bik
			,                 --БИК банка получателя
			tempT.corraccount AS corraccount
			,         --Корреспондентский счет банка получателя
			tempT.bankName AS bankName
			,            --Наименование банка

			tempT.BANK AS [BANK]
			,				 --Номер территориального банка
			tempT.OSB AS OSB
			,				 --Номер ОСБ
			tempT.DEPT AS DEPT
			,				 --Номер внутреннего структурного подразделения

			tempT.postIndex AS postIndex
			,           --Индекс
			tempT.postAddress AS postAddress
			,         --Адресс
			SUBSTRING(tempT.reasonCode, 1, 2) + '2'
			AS reason
			,              --Коды причин изменения данных
			WM_ADDPAY_CALC.A_AMOUNT AS A_AMOUNT
			,            --Размер денежной компенсации
			ISNULL(CONVERT(VARCHAR,
			WM_ADDPAY_CALC.A_ADDITIONAL_NOTE), '')
			AS A_ADDITIONAL_NOTE
			,   --Примечание
			tempT.accountcount AS accountcount
			,        --Номер лицевого счета в Сбербанке России
			tempT.payCalc AS payCalc
			,             --Начисление
			tempT.paidAmount AS paidAmount
			,          --Выплата
			tempT.orgDoc AS orgDoc
			,              --Организация выдавшая док.
			tempT.DOCBASENUMBER AS DOCBASENUMBER
			,       --Номер документа
			tempT.DOCBASEDATE AS DOCBASEDATE
			,		 --Дата основания
			tempT.A_DOCBASESTARTDATE AS A_DOCBASESTARTDATE
			,  --Дата начала
			tempT.A_DOCBASEFINISHDATE AS A_DOCBASEFINISHDATE
			, --Дата окончания
			tempT.A_AMOUNTADD AS A_AMOUNTADD
			,         --Размер доплаты
			2 AS typePay
			,             --тип 2 Доплата
			tempT.pcId AS pcId
			,                --Идентификатор ЛД
			tempT.mspId AS mspId
			,		         --Идентификатор МСП-ЛК-НПД
			tempT.addrId AS addrId				 --Идентификатор адреса регистрации

		FROM WM_ADDPAY_CALC
		INNER JOIN @table tempT
			ON tempT.payCalc = WM_ADDPAY_CALC.A_PAYCALC
		WHERE (WM_ADDPAY_CALC.A_STATUS = @actstatus
			OR WM_ADDPAY_CALC.A_STATUS IS NULL)

	--Простановка данных для документа о реш суда
	UPDATE @table
		SET	DOCBASENUMBER					= x.DOCBASENUMBER
				,DOCBASEDATE					= x.DOCBASEDATE
				,A_DOCBASESTARTDATE		= x.A_DOCBASESTARTDATE
				,A_DOCBASEFINISHDATE	= x.A_DOCBASEFINISHDATE
				,A_AMOUNTADD					= x.docSum
				,orgDoc								= x.orgDoc
	FROM (SELECT
				mainT.id AS ID_T
				,                --Идентификатор таблицы
				actDoc.DOCBASENUMBER AS DOCBASENUMBER
				,       --Номер документа
				actDoc.DOCBASEDATE AS DOCBASEDATE
				,		   --Дата основания
				actDoc.A_DOCBASESTARTDATE AS A_DOCBASESTARTDATE
				,  --Дата начала
				actDoc.A_DOCBASEFINISHDATE AS A_DOCBASEFINISHDATE
				, --Дата окончания
				actDoc.A_AMOUNTADD AS docSum
				,               --Доплата
				(SELECT
						SPR_ORG_BASE.A_NAME1
					FROM SPR_ORG_BASE
					WHERE ouid = actDoc.GIVEDOCUMENTORG
						AND (SPR_ORG_BASE.A_STATUS = @actstatus
						OR SPR_ORG_BASE.A_STATUS IS NULL))
				AS orgDoc               --Организация
			FROM @table mainT
			--Документ решение суда
			LEFT JOIN WM_ACTDOCUMENTS AS actDoc
			INNER JOIN PPR_DOC
				ON actDoc.DOCUMENTSTYPE = PPR_DOC.A_ID
				AND PPR_DOC.A_CODE = 'courtDecisionMSP'
				ON actDoc.PERSONOUID = mainT.pcId
				AND actDoc.A_MSP = mainT.mspId
				AND (actDoc.A_STATUS = @actstatus
				OR actDoc.A_STATUS IS NULL)
				AND actDoc.A_DOCSTATUS = @docStatus
			WHERE YEAR(actDoc.A_DOCBASESTARTDATE) = mainT.payYear
				AND MONTH(actDoc.A_DOCBASESTARTDATE) = mainT.payMonth) AS x
	WHERE x.ID_T = id
		AND sumAssign >= x.docSum

	--Удаление ненужных данных
	IF @TYPE = 0
	BEGIN
		DELETE FROM @table
		WHERE sumAssign = A_AMOUNTADD

		UPDATE @table
			SET sumAssign = sumAssign - ISNULL(A_AMOUNTADD, 0)
	END
	ELSE
	BEGIN
		DELETE FROM @table
		WHERE (NOT sumAssign >= A_AMOUNTADD)
			OR A_AMOUNTADD IS NULL
		UPDATE @table
			SET sumAssign = A_AMOUNTADD
	END
	--Обновление месяца,года
	UPDATE @table
		SET	payMonth	= @month
				,payYear	= @year
	--Суммирование доплат в 1 строку.

	IF @TYPE = 0
	BEGIN

		DECLARE @payCalcId INT
		DECLARE cur CURSOR STATIC FOR
		SELECT DISTINCT
			payCalc
		FROM @table
		OPEN cur

		FETCH NEXT FROM cur
		INTO @payCalcId
		WHILE
			(@@FETCH_STATUS = 0)
		BEGIN

			DECLARE	@message VARCHAR(255)
							,@sumAdd NUMERIC(12, 2)
			SET @message = '';
			SET @sumAdd = 0;
			--Получаем сумму доплат начисления и объединения их сообщений
			SELECT
				@message = @message + ';' + notes
				,@sumAdd = @sumAdd + ISNULL(sumAssign, 0)
			FROM @table
			WHERE payCalc = @payCalcId
				AND typePay = 2
			--Удаление первого символа
			SET @message = SUBSTRING(@message, 2, 4000)
			--Обновление суммы доплат и их сообщений
			UPDATE @table
				SET	notes				= @message
						,sumAssign	= @sumAdd
			WHERE payCalc = @payCalcId
				AND typePay = 2
			--Получаем 1-й идентификатор доплаты для начисления
			DECLARE @idAddPay INT
			SELECT TOP 1
				@idAddPay = id
			FROM @table
			WHERE payCalc = @payCalcId
				AND typePay = 2
			--Удаление всех доплат кроме первой
			DELETE FROM @table
			WHERE payCalc = @payCalcId
				AND typePay = 2
				AND id <> @idAddPay
			FETCH NEXT FROM cur
			INTO @payCalcId
		END

		CLOSE cur
		DEALLOCATE cur

	END


	RETURN;
END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40
go

