CREATE 
FUNCTION [dbo].[HASOTHERADD_FOR_ADD]
(
	@servServId INT		-- id Назначения
	, @payCalcId INT	-- id Начисления
	, @addId INT		-- id Доплаты
	, @monthAdd INT		-- Месяц доплаты
	, @yearAdd INT		-- Год доплаты
	, @monthPayCalc INT		-- Месяц начисления
	, @yearPayCalc INT		-- Год начисления
)
RETURNS INT
AS
BEGIN
		DECLARE @result INT
		SET @result = 0
		
		DECLARE @result1 INT
		SET @result1 = 0
		
		DECLARE @status INT		-- Статус объекта "Действует"
		SELECT @status = ESRN_SERV_STATUS.A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act'
		
		SELECT @result1 = 1 WHERE
		EXISTS(-- Ищем другое начисление
			SELECT otherPayCalc1.OUID 
			FROM WM_PAY_CALC otherPayCalc1 
			WHERE otherPayCalc1.A_MSP = @servServId
			      AND ISNULL(otherPayCalc1.A_STATUS,@status) = @status
					AND otherPayCalc1.A_MONTH = @monthAdd
					AND otherPayCalc1.A_YEAR = @yearAdd
					AND otherPayCalc1.OUID <> @payCalcId)
		
		SELECT @result = 1 WHERE 		
		@result1 = 1 OR
			EXISTS(-- Ищем другую доплату на месяц доплаты
			SELECT otherPayCalc.OUID
			FROM WM_PAY_CALC otherPayCalc 
				INNER JOIN WM_ADDPAY_CALC otherAdd 
					INNER JOIN WM_ADDPAYCALCTYPE otherAddtype ON otherAdd.A_ADDTYPE = otherAddtype.A_OUID
				ON otherAdd.A_PAYCALC = otherPayCalc.OUID
					AND ISNULL(otherAdd.A_STATUS,@status) = @status
					AND otherAddtype.A_CODE = 'early'
			WHERE otherPayCalc.A_MSP = @servServId
					AND otherPayCalc.A_STATUS = @status
					AND otherPayCalc.A_MONTH < @monthPayCalc
					AND otherPayCalc.A_YEAR = @yearPayCalc
					AND otherAdd.A_MONTH = @monthAdd
					AND otherAdd.A_YEAR = @yearAdd
					AND otherPayCalc.OUID <> @payCalcId)
					
		RETURN @result
END
go

