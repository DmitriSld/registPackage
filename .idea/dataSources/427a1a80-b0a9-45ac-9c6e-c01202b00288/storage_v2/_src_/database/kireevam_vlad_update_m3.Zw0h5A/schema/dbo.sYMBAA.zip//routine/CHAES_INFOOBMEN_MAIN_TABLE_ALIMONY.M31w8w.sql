CREATE FUNCTION dbo.CHAES_INFOOBMEN_MAIN_TABLE_ALIMONY (@year INT,	       --Год
@month INT,		   --Месяц
@regionCode VARCHAR(255),  --Код региона
@org INT,		   --Организация
@mspList VARCHAR(255),  --Список МСП
@alTypePay INT		       --Направление выплаты у получателя алиментов
)
RETURNS @table TABLE (
	id INT IDENTITY (1, 1) PRIMARY KEY CLUSTERED
	,INC VARCHAR(255)
	,  --Номер пункта списка
	EXPPNR VARCHAR(255)
	,  --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
	CODE VARCHAR(255)
	,  --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
	payYear INT
	,		   --Год
	payMonth INT
	,		   --Месяц
	SURNAME VARCHAR(255)
	,  --Фамилия получателя
	NAME VARCHAR(255)
	,  --Имя получателя
	SECONDNAME VARCHAR(255)
	,  --Отчество получателя
	DOC VARCHAR(255)
	,  --Наименование документа, подтверждающего личность
	SERIES VARCHAR(255)
	,  --Серия документа, подтверждающего личность
	NUMBER VARCHAR(255)
	,  --Номер документа, подтверждающего личность
	DATAISSUE VARCHAR(255)
	,  --Кем и когда выдан документ, подтверждающий личность
	/**
	* Для Сбербанка
	**/
	expBank VARCHAR(255)
	,  --Номер отделения Сбербанка
	/**
	* Для банков России
	**/
	rootBankName VARCHAR(255)
	,  --Наименование территориального банка
	bik VARCHAR(255)
	,  --БИК банка получателя
	corraccount VARCHAR(255)
	,  --Корреспондентский счет банка получателя
	bankName VARCHAR(255)
	,  --Наименование банка
	BANK VARCHAR(255)
	,  --Номер территориального банка
	OSB VARCHAR(255)
	,  --Номер ОСБ
	DEPT VARCHAR(255)
	,  --Номер внутреннего структурного подразделения
	/**
	* Для почты
	**/
	postIndex VARCHAR(255)
	,  --Индекс
	postAddress VARCHAR(255)
	,  --Адресс
	reasonCode VARCHAR(2555)
	, --Коды причин изменения данных
	sumAssign DECIMAL(12, 2)
	, --Размер денежной компенсации
	notes VARCHAR(4000)
	, --Примечание
	accountcount VARCHAR(255)
	,  --Номер лицевого счета в Сбербанке России
	/**
	* Для создания выплаты
	**/
	payCalc INT
	,		   --Начисление
	paidAmount INT
	,		   --Выплата
	/**
	* Для дока реш. суд.
	**/
	orgDoc VARCHAR(255)
	,  --Организация выдавшая док.
	DOCBASENUMBER VARCHAR(255)
	,  --Номер документа
	DOCBASEDATE DATETIME
	,	   --Дата основания
	A_DOCBASESTARTDATE DATETIME
	,      --Дата начала
	A_DOCBASEFINISHDATE DATETIME
	,      --Дата окончания
	A_AMOUNTADD NUMERIC(12, 2)
	, --Доплата из дока
	typePay INT
	,		   --Тип выплаты 1 начисление 2 доплата
	pcId INT
	,           --Идентификатор ЛД
	mspId INT
	,           --Идентификатор МСП
	addrId INT
	,		   --Идентификатор адреса регистрации
	al_CODE VARCHAR(255)
	,  --Личный номер получателя алиментов
	al_SURNAME VARCHAR(255)
	,  --Фамилия получателя
	al_NAME VARCHAR(255)
	,  --Имя получателя
	al_SECONDNAME VARCHAR(255)
	,  --Отчество получателя
	al_DOC VARCHAR(255)
	,  --Наименование документа, подтверждающего личность
	al_SERIES VARCHAR(255)
	,  --Серия документа, подтверждающего личность
	al_NUMBER VARCHAR(255)
	,  --Номер документа, подтверждающего личность
	al_DATAISSUE VARCHAR(255)
	,  --Кем и когда выдан документ, подтверждающий личность
	al_SNILS VARCHAR(255)
	,  --СНИЛС полячателя алиментов
	alimony DECIMAL(12, 2)
	, --Размер алиментов
	/**
	* Для банков России
	**/
	al_BANK VARCHAR(255)
	,  --Номер территориального банка
	al_OSB VARCHAR(255)
	,  --Номер ОСБ
	al_DEPT VARCHAR(255)
	,  --Номер внутреннего структурного подразделения
	al_accountcount VARCHAR(255)
	,  --Номер лицевого счета в Сбербанке России
	/**
	* Для почты
	**/
	al_postIndex VARCHAR(255)
	,  --Индекс
	al_postAddress VARCHAR(255)
	,  --Адресс

	al_pcId INT
	,           --Идентификатор ЛД
	al_addrId INT   		   --Идентификатор адреса регистрации
)
AS
BEGIN

	-- Статус действует
	DECLARE @actstatus INT
	SELECT
		@actstatus = A_ID
	FROM ESRN_SERV_STATUS
	WHERE A_STATUSCODE = 'act'


	/* Доработка по алиментам */
	INSERT INTO @table
		SELECT
			mainTable.INC AS INC
			,                 --Номер пункта списка
			mainTable.EXPPNR AS EXPPNR
			,              --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
			mainTable.CODE AS CODE
			,                --Личный номер получателя, присваиваемый органами соцзащиты по следующей схеме: код региона + код  органа соцзащиты, в котором стоит на учете получатель + № личного дела получателя. Личные номера не должны повторяться в рамках региона и страны
			mainTable.payYear AS payYear
			,             --Год
			mainTable.payMonth AS payMonth
			,            --Месяц
			mainTable.SURNAME AS SURNAME
			,             --Фамилия получателя
			mainTable.NAME AS NAME
			,                --Имя получателя
			mainTable.SECONDNAME AS SECONDNAME
			,          --Отчество получателя
			mainTable.DOC AS DOC
			,				 --Наименование документа, подтверждающего личность
			mainTable.SERIES AS SERIES
			,			     --Серия документа, подтверждающего личность
			mainTable.NUMBER AS NUMBER
			,				 --Номер документа, подтверждающего личность
			mainTable.DATAISSUE AS DATAISSUE
			,			 --Кем и когда выдан документ, подтверждающий личность

			mainTable.expBank AS expBank
			,             --Номер отделения Сбербанка
			mainTable.rootBankName AS rootBankName
			,        --Наименование территориального банка
			mainTable.bik AS bik
			,                 --БИК банка получателя
			mainTable.corraccount AS corraccount
			,         --Корреспондентский счет банка получателя
			mainTable.bankName AS bankName
			,            --Наименование банка
			mainTable.BANK AS [BANK]
			,				 --Номер территориального банка
			mainTable.OSB AS OSB
			,				 --Номер ОСБ
			mainTable.DEPT AS DEPT
			,				 --Номер внутреннего структурного подразделения

			mainTable.postIndex AS postIndex
			,           --Индекс
			mainTable.postAddress AS postAddress
			,         --Адресс
			mainTable.reasonCode AS reasonCode
			,			 --Коды причин изменения данных
			mainTable.sumAssign AS sumAssign
			,           --Размер денежной компенсации
			mainTable.accountcount AS accountcount
			,        --Номер лицевого счета в Сбербанке России
			mainTable.notes AS notes
			,               --Примечание

			mainTable.payCalc AS payCalc
			,             --Начисление
			mainTable.paidAmount AS paidAmount
			,          --Выплата
			mainTable.orgDoc AS orgDoc
			,              --Организация выдавшая док.

			mainTable.DOCBASENUMBER AS DOCBASENUMBER
			,       --Номер документа
			mainTable.DOCBASEDATE AS DOCBASEDATE
			,		 --Дата основания
			mainTable.A_DOCBASESTARTDATE AS A_DOCBASESTARTDATE
			,  --Дата начала
			mainTable.A_DOCBASEFINISHDATE AS A_DOCBASEFINISHDATE
			, --Дата окончания
			mainTable.A_AMOUNTADD AS A_AMOUNTADD
			,         --Размер доплаты
			mainTable.typePay AS typePay
			,             --тип 2 Доплата
			mainTable.pcId AS pcId
			,                --Идентификатор ЛД
			mainTable.mspId AS mspId
			,		         --Идентификатор МСП-ЛК-НПД
			mainTable.addrId AS addrId
			,				 --Идентификатор адреса регистрации

			--(SELECT TOP 1 a_persnum
			--	FROM   WM_PERSNUM_SEND
			--	WHERE  A_TARGETORG = 986
			--		AND a_persnum IS NOT NULL
			--		AND (A_STATUS = @actstatus OR A_STATUS IS NULL)
			--		AND a_pc = WM_PERSONAL_CARD.OUID) AS al_CODE,             --Личный номер получателя алиментов
			CASE
				WHEN LEN(WM_PERSONAL_CARD.A_SNILS) >= 9
				THEN ISNULL(LEFT(WM_PERSONAL_CARD.A_SNILS, 9), '')
				ELSE ISNULL(WM_PERSONAL_CARD.A_SNILS, '')
			END AS al_CODE
			,             --Личный номер получателя алиментов

			ISNULL(SPR_FIO_SURNAME.A_NAME, '') AS al_SURNAME
			,          --Фамилия получателя алиментов
			ISNULL(SPR_FIO_NAME.A_NAME, '') AS al_NAME
			,             --Имя получателя
			ISNULL(SPR_FIO_SECONDNAME.A_NAME, '') AS al_SECONDNAME
			,       --Отчество получателя
			ISNULL(passport.docTypeTitle, '') AS al_DOC
			,			     --Наименование документа, подтверждающего личность
			ISNULL(passport.docSer, '') AS al_SERIES
			,		     --Серия документа, подтверждающего личность
			ISNULL(passport.docNum, '') AS al_NUMBER
			,		     --Номер документа, подтверждающего личность

			ISNULL(passport.orgTitle, '') + ISNULL(' ' + CONVERT(VARCHAR, passport.docDate, 104), '')
			AS al_DATAISSUE
			,        --Кем и когда выдан документ, подтверждающий личность
			WM_PERSONAL_CARD.A_SNILS AS al_SNILS
			,            --СНИЛС получателя алиментов
			x.alimony AS alimony
			,             --Размер алиментов
			/**
			* Для банков России
			**/
			SUBSTRING(SPR_ORG_BANKS.A_SBERID, 2, 2) AS al_BANK
			,	         --Номер территориального банка
			SUBSTRING(SPR_ORG_BANKS.A_SBERID, 4, 4) AS al_OSB
			,    	     --Номер ОСБ
			CASE
				WHEN LEN(SPR_ORG_BANKS.A_SBERID) > 7
				THEN SUBSTRING(SPR_ORG_BANKS.A_SBERID, 8, 5)
				ELSE NULL
			END AS al_DEPT
			,			 --Номер внутреннего структурного подразделения
			WM_PAYMENT.ACCOUNTINGCOUNT AS al_accountcount
			,    --Номер лицевого счета в Сбербанке России
			/**
			* Для почты
			**/
			ISNULL(SPR_MAIL_PHONE.A_INDEX, '') AS al_postIndex
			,       --Индекс
			ISNULL(ISNULL(SPR_FBTYPE.A_NAME + ' ', '') + SPR_FEDERATIONBOROUGHT.A_NAME + ', ', '') +
			ISNULL(ISNULL(SPR_TOWN_TYPE.A_NAME + '. ', '') + SPR_TOWN.A_NAME + ', ', '') +
			ISNULL(ISNULL(SPR_STEET_TYPE.A_NAME + '. ', '') + SPR_STREET.A_NAME + ', ', '') +
			ISNULL('д.' + WM_ADDRESS.A_HOUSENUMBER, '') +
			ISNULL(', к.' + WM_ADDRESS.A_BUILDING, '') +
			ISNULL(', кв.' + WM_ADDRESS.A_FLATNUMBER, '')
			AS al_postAddress
			,     --Адресс

			WM_PERSONAL_CARD.OUID AS al_pcId
			,            --Идентификатор ЛД
			WM_PERSONAL_CARD.A_REGFLAT AS al_addrId		     --Идентификатор адреса регистрации


		FROM (SELECT
				*
			FROM dbo.[CHAES_INFOOBMEN_MAIN_TABLE](@year, @month, @regionCode, @org, @mspList, 1, 0)
			UNION ALL
			SELECT
				*
			FROM dbo.[CHAES_INFOOBMEN_MAIN_TABLE](@year, @month, @regionCode, @org, @mspList, 1, 1)
			UNION ALL
			SELECT
				*
			FROM dbo.[CHAES_INFOOBMEN_MAIN_TABLE](@year, @month, @regionCode, @org, @mspList, 3, 0)
			UNION ALL
			SELECT
				*
			FROM dbo.[CHAES_INFOOBMEN_MAIN_TABLE](@year, @month, @regionCode, @org, @mspList, 3, 1)) mainTable
		INNER JOIN (SELECT
				WM_DEDUCTION_LOG.A_PAYCALC
				,WM_DEDUCTION.A_PERSONALCARD_PAY AS al_paymentId
				,SUM(WM_DEDUCTION_LOG.A_AMOUNT) AS alimony
			FROM WM_DEDUCTION_LOG
			INNER JOIN WM_DEDUCTION
				ON WM_DEDUCTION_LOG.A_DEDUCTION = WM_DEDUCTION.A_ID
			WHERE WM_DEDUCTION_LOG.A_DEDUCTION_TYPE = '1'
				AND (WM_DEDUCTION.A_STATUS = @actstatus
				OR WM_DEDUCTION.A_STATUS IS NULL)
				AND (WM_DEDUCTION_LOG.A_STATUS = @actstatus
				OR WM_DEDUCTION_LOG.A_STATUS IS NULL)
			GROUP BY	WM_DEDUCTION_LOG.A_PAYCALC
								,WM_DEDUCTION.A_PERSONALCARD_PAY) x
			ON mainTable.payCalc = x.A_PAYCALC
			AND mainTable.typePay = 1

		INNER JOIN WM_PAYMENT
			ON x.al_paymentId = WM_PAYMENT.OUID
		INNER JOIN SPR_PAY_TYPE
			ON WM_PAYMENT.DELIVERYWAY = SPR_PAY_TYPE.A_ID
		INNER JOIN WM_PERSONAL_CARD
			ON WM_PAYMENT.PERSONOUID = WM_PERSONAL_CARD.OUID
		LEFT JOIN SPR_FIO_NAME
			ON SPR_FIO_NAME.OUID = WM_PERSONAL_CARD.A_NAME
		LEFT JOIN SPR_FIO_SURNAME
			ON SPR_FIO_SURNAME.OUID = WM_PERSONAL_CARD.SURNAME
		LEFT JOIN SPR_FIO_SECONDNAME
			ON SPR_FIO_SECONDNAME.OUID = WM_PERSONAL_CARD.A_SECONDNAME
		LEFT JOIN (SELECT
				doc.PERSONOUID AS pcId
				,doc.OUID AS docId
				,doc.DOCUMENTSNUMBER AS docNum
				,doc.DOCUMENTSERIES AS docSer
				,doc.ISSUEEXTENSIONSDATE AS docDate
				,doc.DOCUMENTSTYPE AS docType
				,docType.A_CODE AS docTypeCode
				,docType.A_NAME AS docTypeTitle
				,ISNULL(ISNULL(org.A_SHORTNAME, org.A_NAME1), '') AS orgTitle
				,ROW_NUMBER() OVER (PARTITION BY doc.PERSONOUID ORDER BY CASE
				docType.A_CODE
					WHEN 'rusPassport'
					THEN 0
					ELSE 1
				END,
				CASE
					WHEN (doc.ISSUEEXTENSIONSDATE IS NULL OR
						YEAR(doc.ISSUEEXTENSIONSDATE) * 100 + MONTH(doc.ISSUEEXTENSIONSDATE) <= @year * 100 + @month) AND
						(doc.COMPLETIONSACTIONDATE IS NULL OR
						YEAR(doc.COMPLETIONSACTIONDATE) * 100 + MONTH(doc.COMPLETIONSACTIONDATE) >= @year * 100 + @month)
					THEN 0
					ELSE 1
				END, doc.ISSUEEXTENSIONSDATE DESC, doc.OUID) AS num
			FROM WM_ACTDOCUMENTS doc
			INNER JOIN PPR_DOC docType
				ON doc.DOCUMENTSTYPE = docType.A_ID
				AND docType.A_ISIDENTITYCARD = 1
			LEFT JOIN SPR_ORG_BASE org
				ON doc.GIVEDOCUMENTORG = org.OUID
			WHERE (doc.A_STATUS = @actstatus
				OR doc.A_STATUS IS NULL)) passport
			ON WM_PERSONAL_CARD.OUID = passport.pcId
			AND passport.num = 1
		LEFT JOIN SPR_ORG_BANKS
		INNER JOIN SPR_ORG_BASE
			ON SPR_ORG_BASE.OUID = SPR_ORG_BANKS.OUID
			AND (SPR_ORG_BASE.A_STATUS = @actstatus
			OR SPR_ORG_BASE.A_STATUS IS NULL)
			ON ((WM_PAYMENT.A_PAYMENTORG = SPR_ORG_BANKS.OUID)
			OR (dbo.GET_PARENT_ORG(WM_PAYMENT.A_PAYMENTORG) = SPR_ORG_BANKS.OUID
			AND (SPR_ORG_BANKS.A_TYPEBANK IS NULL
			OR SPR_ORG_BANKS.A_TYPEBANK <> 'sberbank'))
			)
		--Индекс и Адрес
		LEFT JOIN SPR_MAIL_PHONE
		INNER JOIN SPR_ORG_BASE mailBase
			ON mailBase.OUID = SPR_MAIL_PHONE.OUID
			AND (mailBase.A_STATUS = @actstatus
			OR mailBase.A_STATUS IS NULL)
			ON WM_PAYMENT.A_PAYMENTORG = SPR_MAIL_PHONE.OUID
		LEFT JOIN WM_ADDRESS
			ON ISNULL(WM_PAYMENT.ALTERNATIVEADDRESSDEIVERY, WM_PERSONAL_CARD.a_regflat) = WM_ADDRESS.OUID
			AND (WM_ADDRESS.A_STATUS = @actstatus
			OR WM_ADDRESS.A_STATUS IS NULL)
		LEFT JOIN SPR_COUNTRY
			ON SPR_COUNTRY.OUID = WM_ADDRESS.A_COUNTRY
		LEFT JOIN SPR_SUBJFED
			ON SPR_SUBJFED.OUID = WM_ADDRESS.A_SUBFED
		LEFT JOIN SPR_SUBJFEDTYPE
			ON SPR_SUBJFEDTYPE.A_ID = SPR_SUBJFED.A_TYPE
		LEFT JOIN SPR_FEDERATIONBOROUGHT
			ON SPR_FEDERATIONBOROUGHT.OUID = WM_ADDRESS.A_FEDBOROUGH
		LEFT JOIN SPR_FBTYPE
			ON SPR_FBTYPE.A_ID = SPR_FEDERATIONBOROUGHT.A_TYPE
		LEFT JOIN SPR_TOWN
			ON SPR_TOWN.OUID = WM_ADDRESS.A_TOWN
		LEFT JOIN SPR_TOWN_TYPE
			ON SPR_TOWN_TYPE.OUID = SPR_TOWN.A_TOWNTYPE
		LEFT JOIN SPR_STREET
			ON SPR_STREET.OUID = WM_ADDRESS.A_STREET
		LEFT JOIN SPR_STEET_TYPE
			ON SPR_STEET_TYPE.OUID = SPR_STREET.A_STREETTYPE
		WHERE (WM_PAYMENT.A_STATUS = @actstatus
			OR WM_PAYMENT.A_STATUS IS NULL)
			AND (WM_PERSONAL_CARD.A_STATUS = @actstatus
			OR WM_PERSONAL_CARD.A_STATUS IS NULL)
			AND ((SPR_PAY_TYPE.A_COD = 'NR2'
			AND @alTypePay = 1)
			OR (SPR_PAY_TYPE.A_COD = 'NR1'
			AND @alTypePay = 3)
			OR (SPR_PAY_TYPE.A_COD NOT IN ('NR1', 'NR2')
			AND @alTypePay = 2))

	RETURN;
END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40
go

