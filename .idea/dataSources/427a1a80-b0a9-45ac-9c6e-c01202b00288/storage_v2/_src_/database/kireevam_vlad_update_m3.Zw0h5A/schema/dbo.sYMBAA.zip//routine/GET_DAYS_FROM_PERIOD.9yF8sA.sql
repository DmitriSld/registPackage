CREATE FUNCTION dbo.GET_DAYS_FROM_PERIOD(@beginDate DATE, @endDate DATE)
RETURNS @result TABLE (aDay DATE) AS
  BEGIN
    DECLARE @day DATE SET @day = @beginDate
    SET @endDate = ISNULL(@endDate, GETDATE())

    WHILE @day <= @endDate 
    BEGIN
      INSERT @result (aDay) VALUES (@day)
      SET @day = DATEADD(DAY, 1, @day)
    END 

    RETURN
  END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40
go

