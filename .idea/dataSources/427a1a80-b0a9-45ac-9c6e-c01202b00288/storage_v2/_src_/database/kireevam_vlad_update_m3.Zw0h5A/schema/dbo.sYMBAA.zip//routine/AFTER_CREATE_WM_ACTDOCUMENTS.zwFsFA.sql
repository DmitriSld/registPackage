CREATE PROCEDURE [dbo].[AFTER_CREATE_WM_ACTDOCUMENTS](@obj int, @vid int)
	
AS
BEGIN

--declare @obj int, @vid int
--set @obj=59579
--set @vid=3210

declare @docStatus int
select @docStatus=A_DOC_STATUS from PPR_DOC 
where a_id=@vid
if (@docStatus is not null)
begin
update WM_ACTDOCUMENTS
set A_DOCSTATUS=@docStatus
where OUID=@obj

declare @docStatProekt int
select @docStatProekt=A_OUID from SPR_DOC_STATUS where A_CODE='project'

/*Для документа "Заключение комисси"*/
update zakl 
set A_TYPE_CON_COMM_SOC=case when isnull(WM_PETITION.A_ISVERIFIED, 1)=1 then 10 else 20 end
/*, A_SUM=case when isnull(WM_PETITION.A_ISVERIFIED, 1)=1 
then case
 when isnull(A_SOULPOPULATIONPM, 0.00)-isnull(A_SDD, 0.00)<5000 then 5000  
 when (isnull(A_SOULPOPULATIONPM, 0.00)-isnull(A_SDD, 0.00))*ISNULL(zakl.A_SROC, 1)>60000 
 then round(cast(60000 as float)/ISNULL(zakl.A_SROC, 1),2)
--when isnull(A_SOULPOPULATIONPM, 0.00)-isnull(A_SDD, 0.00)<0.00 then 0.00
else isnull(A_SOULPOPULATIONPM, 0.00)-isnull(A_SDD, 0.00) end
end
*/
--разница между суммами величинами прожиточного минимума семьи (по социально-демографическим группам)  и доходом семьи и возможность установления индивидуального размера для 2-го и последующих месяцев выплаты, исходя из мероприятий программы (например: разница между величинами ПМ по СДД и доходом семьи 45000,00руб, в этом случае сумма 1-го месяца = 45000,00руб., 2-4 месяца по 5000,00руб.) 
,a_refuse=case when isnull(WM_PETITION.A_ISVERIFIED, 1)!=1 then WM_PETITION.A_REFUSEREASON end 
from WM_ACTDOCUMENTS zakl
inner join PPR_DOC tZakl on tZakl.A_ID=@vid
and ISNULL(tZakl.a_code, '')='ConCommissionSoc'
inner join WM_ACTDOCUMENTS contr on contr.OUID=zakl.A_SOC_CONTRACT_DOC
inner join PPR_DOC on contr.DOCUMENTSTYPE=PPR_DOC.A_ID
and ISNULL(PPR_DOC.A_CODE, '')='SocContract'
and isnull(contr.A_DOCSTATUS, 1)=@docStatProekt
inner join WM_PERSONAL_CARD pc on pc.OUID=contr.PERSONOUID
inner join WM_PETITION on WM_PETITION.A_MSPHOLDER=pc.OUID
inner join WM_APPEAL_NEW on WM_PETITION.OUID=  WM_APPEAL_NEW.OUID
and ISNULL(WM_APPEAL_NEW.A_STATUS, 10)=10
inner join PPR_SERV msp on msp.a_id=WM_PETITION.A_MSP
and ISNULL(msp.A_COD, '')='egemesSocContract'
where zakl.ouid=@obj

declare @docStatusZakl int
,@docTypeZakl varchar(255)
,@docTypeConCommSoc int  
,@sum1 float -- сумма за первый период
,@sroc int -- срок
 
 
 
 select 
 @docStatusZakl=A_DOCSTATUS
 ,@docTypeZakl=ISNULL(PPR_DOC.A_CODE, '')
 , @docTypeConCommSoc=ISNULL(A_TYPE_CON_COMM_SOC, 10)
, @sroc=ISNULL(A_SROC, 12) 
 from WM_ACTDOCUMENTS
 inner join PPR_DOC on WM_ACTDOCUMENTS.DOCUMENTSTYPE=PPR_DOC.A_ID
 where WM_ACTDOCUMENTS.OUID=@obj
 
/*Если Заключение комисси в статусе "Проект" и тип "о назначении" и сумма не менялась, обновлям суммы по периодам*/
if (@docStatusZakl=@docStatProekt and @docTypeZakl='ConCommissionSoc' and @docTypeConCommSoc=10)
begin

update SUM_DOC_PERIOD
set a_Status=70
,a_ts=GETDATE()
where a_Doc =@obj
and SUM_DOC_PERIOD.A_EDITOR is  null
and ISNULL(a_Status, 10)=10


insert into SUM_DOC_PERIOD
(a_status, A_DOC, A_SUM,	A_NUM_MONTH,	A_DETAIL)
select distinct 10, zakl.ouid, 
case when isnull(A_SUMGROUPPM,0.00)-isnull(A_SUMGROUPPROFIT, 0.00)<5000 then 5000
 when isnull(A_SUMGROUPPM, 0.00)-isnull(A_SUMGROUPPROFIT, 0.00)>60000 then 60000
else isnull(A_SUMGROUPPM-A_SUMGROUPPROFIT, 0.00)
end
,1
,case when isnull(A_SUMGROUPPM,0.00)-isnull(A_SUMGROUPPROFIT, 0.00)<5000 
then 'Разница между ПМ и СДД '+CAST(isnull(A_SUMGROUPPM,0.00)-isnull(A_SUMGROUPPROFIT, 0.00) AS varchar(255))+' меньше  5000'
 when isnull(A_SUMGROUPPM, 0.00)-isnull(A_SUMGROUPPROFIT, 0.00)>60000 then 
 'Разница между ПМ и СДД '+CAST(isnull(A_SUMGROUPPM,0.00)-isnull(A_SUMGROUPPROFIT, 0.00) AS varchar(255))+' больше  60000'
else  'Разница между ПМ и СДД '+CAST(isnull(A_SUMGROUPPM,0.00)-isnull(A_SUMGROUPPROFIT, 0.00) AS varchar(255))
end

from WM_ACTDOCUMENTS zakl
inner join PPR_DOC tZakl on tZakl.A_ID=@vid
and ISNULL(tZakl.a_code, '')='ConCommissionSoc'
inner join WM_ACTDOCUMENTS contr on contr.OUID=zakl.A_SOC_CONTRACT_DOC
inner join PPR_DOC on contr.DOCUMENTSTYPE=PPR_DOC.A_ID
and ISNULL(PPR_DOC.A_CODE, '')='SocContract'
and isnull(contr.A_DOCSTATUS, 1)=@docStatProekt
inner join WM_PERSONAL_CARD pc on pc.OUID=contr.PERSONOUID
inner join WM_PETITION on WM_PETITION.A_MSPHOLDER=pc.OUID
inner join WM_APPEAL_NEW on WM_PETITION.OUID=  WM_APPEAL_NEW.OUID
and ISNULL(WM_APPEAL_NEW.A_STATUS, 10)=10
inner join PPR_SERV msp on msp.a_id=WM_PETITION.A_MSP
and ISNULL(msp.A_COD, '')='egemesSocContract'
left join SUM_DOC_PERIOD on SUM_DOC_PERIOD.A_DOC=zakl.ouid
and ISNULL(SUM_DOC_PERIOD.a_Status, 10)=10
and SUM_DOC_PERIOD.A_NUM_MONTH=1
where zakl.ouid=@obj
and SUM_DOC_PERIOD.a_ouid is null


select @sum1=SUM_DOC_PERIOD.A_SUM
from WM_ACTDOCUMENTS zakl
inner join PPR_DOC tZakl on tZakl.A_ID=@vid
and ISNULL(tZakl.a_code, '')='ConCommissionSoc'
inner join WM_ACTDOCUMENTS contr on contr.OUID=zakl.A_SOC_CONTRACT_DOC
inner join PPR_DOC on contr.DOCUMENTSTYPE=PPR_DOC.A_ID
and ISNULL(PPR_DOC.A_CODE, '')='SocContract'
and isnull(contr.A_DOCSTATUS, 1)=@docStatProekt
inner join WM_PERSONAL_CARD pc on pc.OUID=contr.PERSONOUID
inner join WM_PETITION on WM_PETITION.A_MSPHOLDER=pc.OUID
inner join WM_APPEAL_NEW on WM_PETITION.OUID=  WM_APPEAL_NEW.OUID
and ISNULL(WM_APPEAL_NEW.A_STATUS, 10)=10
inner join PPR_SERV msp on msp.a_id=WM_PETITION.A_MSP
and ISNULL(msp.A_COD, '')='egemesSocContract'
inner join SUM_DOC_PERIOD on SUM_DOC_PERIOD.A_DOC=zakl.ouid
and ISNULL(SUM_DOC_PERIOD.a_Status, 10)=10
and SUM_DOC_PERIOD.A_NUM_MONTH=1
where zakl.ouid=@obj



/*суммы за остальные месяца*/



insert into SUM_DOC_PERIOD
(a_status, A_DOC, A_SUM,	A_NUM_MONTH,	A_DETAIL)
select 
distinct 
10, @obj
,case when 60000-allSum<=0 then 0.00
when 60000-allSum<sumPet*(minNum -2)
then case when ROUND(cast(60000-allSum as float)/(minNum-2),2)<5000 then 5000
else ROUND(cast(60000-allSum as float)/(minNum-2),2) end
when sumPet<5000 then 5000
else sumPet
end
, 2
, case when 60000-isnulL(allSum, 0.00)<=0 then 'Сумма не должна превышать 60000'
when 60000-isnull(allSum, 0.00)<sumPet*(minNum -1)
then
 case when ROUND(cast(60000-allSum as float)/(minNum-2),2)<5000 
 then 'Ежемесячная сумма не может быть менее 5000'
else 
 'остаток суммы от 60000' end
when sumPet<5000 then 'Ежемесячная сумма не может быть менее 5000'
else 'Разница между ПМ и СДД в заявлении '+cast(sumPet as varchar(255))
end

from
(
select 
SUM(isnull(a_Sum, 0.00)*(isnull(A_NUM_MONTH_END,0)-isnull(A_NUM_MONTH,0)+1))+isnull(@sum1, 0.00) allSum
, MIN(case when isnull(A_NUM_MONTH,A_SROC+1)=1 then A_SROC+1 else isnull(A_NUM_MONTH, A_SROC+1) end)  minNum
, min(isnull(A_SUMGROUPPM, 0.00)-isnull(A_SUMGROUPPROFIT, 0.00)) sumPet
from
(select
SUM_DOC_PERIOD.a_doc, SUM_DOC_PERIOD.a_ouid, SUM_DOC_PERIOD.A_SUM, SUM_DOC_PERIOD.A_NUM_MONTH
,isnull(isnull(min(period.A_NUM_MONTH)-1, max(zakl.A_SROC)), 12) A_NUM_MONTH_END
, min(A_SUMGROUPPM) A_SUMGROUPPM
, min(A_SUMGROUPPROFIT) A_SUMGROUPPROFIT
, min(isnull(zakl.A_SROC, 12)) A_SROC
from WM_ACTDOCUMENTS zakl
inner join PPR_DOC tZakl on tZakl.A_ID=@vid
and ISNULL(tZakl.a_code, '')='ConCommissionSoc'
inner join WM_ACTDOCUMENTS contr on contr.OUID=zakl.A_SOC_CONTRACT_DOC
inner join PPR_DOC on contr.DOCUMENTSTYPE=PPR_DOC.A_ID
and ISNULL(PPR_DOC.A_CODE, '')='SocContract'
and isnull(contr.A_DOCSTATUS, 1)=@docStatProekt
inner join WM_PERSONAL_CARD pc on pc.OUID=contr.PERSONOUID
inner join WM_PETITION on WM_PETITION.A_MSPHOLDER=pc.OUID
inner join WM_APPEAL_NEW on WM_PETITION.OUID=  WM_APPEAL_NEW.OUID
and ISNULL(WM_APPEAL_NEW.A_STATUS, 10)=10
inner join PPR_SERV msp on msp.a_id=WM_PETITION.A_MSP
and ISNULL(msp.A_COD, '')='egemesSocContract'
left join SUM_DOC_PERIOD on SUM_DOC_PERIOD.A_DOC=zakl.ouid
and ISNULL(SUM_DOC_PERIOD.a_Status, 10)=10
and ISNULL(SUM_DOC_PERIOD.A_NUM_MONTH, 0)!=1
left join SUM_DOC_PERIOD period on period.A_DOC=zakl.ouid
and ISNULL(period.a_Status, 10)=10
and period.A_NUM_MONTH>SUM_DOC_PERIOD.A_NUM_MONTH
where zakl.ouid=@obj
group by SUM_DOC_PERIOD.a_doc, SUM_DOC_PERIOD.a_ouid, SUM_DOC_PERIOD.A_SUM, SUM_DOC_PERIOD.A_NUM_MONTH
)t1

)t2
where isnull(minNum, 0)!=2

declare @summ2 float
select @summ2=ISNULL(SUM_DOC_PERIOD.A_SUM,0.00)*(isnull(WM_ACTDOCUMENTS.A_SROC, 12) -1)
from WM_ACTDOCUMENTS
inner join PPR_DOC on PPR_DOC.A_ID=@vid
and ISNULL(PPR_DOC.a_code, '')='ConCommissionSoc'
inner join SUM_DOC_PERIOD on SUM_DOC_PERIOD.A_DOC=WM_ACTDOCUMENTS.ouid
and ISNULL(SUM_DOC_PERIOD.A_NUM_MONTH, 0)!=1
where WM_ACTDOCUMENTS.ouid=@obj




if (@summ2+@sum1>60000)
begin
update WM_ACTDOCUMENTS
set A_SROC=ceiling((cast(60000 as float)-@sum1)/5000)
where OUID=@obj
end
update SUM_DOC_PERIOD
set a_Status=70
,a_ts=GETDATE()
where a_Doc =@obj
and SUM_DOC_PERIOD.A_EDITOR is  null
and isnull(SUM_DOC_PERIOD.A_NUM_MONTH, 1)!=1
and ISNULL(a_Status, 10)=10



/*суммы за остальные месяца*/



insert into SUM_DOC_PERIOD
(a_status, A_DOC, A_SUM,	A_NUM_MONTH,	A_DETAIL)
select 
distinct 
10, @obj
,case when 60000-allSum<=0 then 0.00
when 60000-allSum<sumPet*(minNum -2)
then case when ROUND(cast(60000-allSum as float)/(minNum-2),2)<5000 then 5000
else ROUND(cast(60000-allSum as float)/(minNum-2),2) end
when sumPet<5000 then 5000
else sumPet
end
, 2
, case when 60000-isnulL(allSum, 0.00)<=0 then 'Сумма не должна превышать 60000'
when 60000-isnull(allSum, 0.00)<sumPet*(minNum -1)
then
 case when ROUND(cast(60000-allSum as float)/(minNum-2),2)<5000 
 then 'Ежемесячная сумма не может быть менее 5000'
else 
 'остаток суммы от 60000' end
when sumPet<5000 then 'Ежемесячная сумма не может быть менее 5000'
else 'Разница между ПМ и СДД в заявлении '+cast(sumPet as varchar(255))
end

from
(
select 
SUM(isnull(a_Sum, 0.00)*(isnull(A_NUM_MONTH_END,0)-isnull(A_NUM_MONTH,0)+1))+isnull(@sum1, 0.00) allSum
, MIN(case when isnull(A_NUM_MONTH,A_SROC+1)=1 then A_SROC+1 else isnull(A_NUM_MONTH, A_SROC+1) end)  minNum
, min(isnull(A_SUMGROUPPM, 0.00)-isnull(A_SUMGROUPPROFIT, 0.00)) sumPet
from
(select
SUM_DOC_PERIOD.a_doc, SUM_DOC_PERIOD.a_ouid, SUM_DOC_PERIOD.A_SUM, SUM_DOC_PERIOD.A_NUM_MONTH
,isnull(isnull(min(period.A_NUM_MONTH)-1, max(zakl.A_SROC)), 12) A_NUM_MONTH_END
, min(A_SUMGROUPPM) A_SUMGROUPPM
, min(A_SUMGROUPPROFIT) A_SUMGROUPPROFIT
, min(isnull(zakl.A_SROC, 12)) A_SROC
from WM_ACTDOCUMENTS zakl
inner join PPR_DOC tZakl on tZakl.A_ID=@vid
and ISNULL(tZakl.a_code, '')='ConCommissionSoc'
inner join WM_ACTDOCUMENTS contr on contr.OUID=zakl.A_SOC_CONTRACT_DOC
inner join PPR_DOC on contr.DOCUMENTSTYPE=PPR_DOC.A_ID
and ISNULL(PPR_DOC.A_CODE, '')='SocContract'
and isnull(contr.A_DOCSTATUS, 1)=@docStatProekt
inner join WM_PERSONAL_CARD pc on pc.OUID=contr.PERSONOUID
inner join WM_PETITION on WM_PETITION.A_MSPHOLDER=pc.OUID
inner join WM_APPEAL_NEW on WM_PETITION.OUID=  WM_APPEAL_NEW.OUID
and ISNULL(WM_APPEAL_NEW.A_STATUS, 10)=10
inner join PPR_SERV msp on msp.a_id=WM_PETITION.A_MSP
and ISNULL(msp.A_COD, '')='egemesSocContract'
left join SUM_DOC_PERIOD on SUM_DOC_PERIOD.A_DOC=zakl.ouid
and ISNULL(SUM_DOC_PERIOD.a_Status, 10)=10
and ISNULL(SUM_DOC_PERIOD.A_NUM_MONTH, 0)!=1
left join SUM_DOC_PERIOD period on period.A_DOC=zakl.ouid
and ISNULL(period.a_Status, 10)=10
and period.A_NUM_MONTH>SUM_DOC_PERIOD.A_NUM_MONTH
where zakl.ouid=@obj
group by SUM_DOC_PERIOD.a_doc, SUM_DOC_PERIOD.a_ouid, SUM_DOC_PERIOD.A_SUM, SUM_DOC_PERIOD.A_NUM_MONTH
)t1

)t2
where isnull(minNum, 0)!=2

end
/*Срок не должен превышать сумму*/

update
SUM_DOC_PERIOD
set GUID=NEWID()
where GUID is null

end

	SET NOCOUNT ON;


END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40
go

