/*Функция формирования представления идентификатора отделения/филиала сбербанка вида 8634/00234 
На вход принимается минимимум семизначное значение, в противном случае вернется 0000/00000
*/
CREATE FUNCTION GETSBERIDFORDBF (@SBERID VARCHAR(30))
RETURNS VARCHAR(30)
AS
BEGIN
	DECLARE @LEN AS INT /*Содержит длину пришедшего аргумента*/
	DECLARE @SUBID VARCHAR(30) /*Хранит часть после слэша*/
	DECLARE @OTDELENIE VARCHAR(30) /*Хранит часть до слэша*/
	SET @OTDELENIE=SUBSTRING(@SBERID,4,4) /*достаем 4,5,6,7 символ - идентификатор отделения*/
	SET @LEN=LEN(@SBERID)
	IF (@LEN>7) /*Если длина идентификатора больше 7, значит это филиал отделения сбербанка, то достаем его идентифтикатор, и заполняем нулями до 5 символов*/
	BEGIN
		SET @SUBID=SUBSTRING(@SBERID,8,@LEN-7)					
		WHILE (LEN(@SUBID)<5)
		BEGIN
			SET @SUBID='0'+@SUBID
		END
		
	END
	IF (LEN(@SBERID)=7) /*Если длина 7, значит это отделение сбербанка*/
	BEGIN
		SET @SUBID='0'+@OTDELENIE
	END

	DECLARE @RESULT VARCHAR(30)
	IF (@LEN>=7)
	BEGIN
		SET @RESULT=@OTDELENIE+'/'+@SUBID
	END
	ELSE 
	BEGIN
		SET @RESULT='0000/00000'
	END
	RETURN(@RESULT)
END
go

