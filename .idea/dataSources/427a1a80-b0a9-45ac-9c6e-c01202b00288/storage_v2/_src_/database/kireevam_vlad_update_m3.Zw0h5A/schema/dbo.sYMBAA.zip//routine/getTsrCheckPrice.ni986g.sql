CREATE FUNCTION dbo.getTsrCheckPrice(
 @checkId as INT
) RETURNS NUMERIC(10,4)
AS
BEGIN
 -- "Количество фактически предоставленных ТСР" в "Спецификация ТСР по моделям"
DECLARE @result NUMERIC(10,4)
SELECT @result = 
ISNULL(CASE WHEN priceGroup.A_OUID IS NULL THEN priceServ.A_PRICE ELSE priceGroup.A_PRICE END,0)
FROM TSR_CHECK tsrCheck
	INNER JOIN WM_ACTDOCUMENTS docs
		ON tsrCheck.A_WM_ACT_DOC = docs.OUID
	LEFT JOIN SPR_TSR_PRICE priceGroup
		ON priceGroup.A_TSR = docs.A_TSR_GROUP
			AND priceGroup.A_START_DATE <= docs.A_DATE_BUY
			AND (priceGroup.A_END_DATE >= docs.A_DATE_BUY OR priceGroup.A_END_DATE IS NULL)
	LEFT JOIN SPR_TSR_PRICE priceServ
		ON priceServ.A_SERV = docs.A_TSR_SERV
			AND priceServ.A_START_DATE <= docs.A_DATE_BUY
			AND (priceServ.A_END_DATE >= docs.A_DATE_BUY OR priceServ.A_END_DATE IS NULL)

WHERE (docs.A_STATUS = 10 OR docs.A_STATUS IS NULL)
AND (tsrCheck.A_STATUS = 10 OR tsrCheck.A_STATUS IS NULL)
AND (priceGroup.A_STATUS = 10 OR priceGroup.A_STATUS IS NULL)
AND (priceServ.A_STATUS = 10 OR priceServ.A_STATUS IS NULL)                               
AND (tsrCheck.A_OUID = @checkId)
RETURN @result
END;
 
--   sx.datastore.db.SXDb.execute:-1 
--   sx.common.replication.DoReplication.installPatch:-1 
--   sx.common.replication.SXPatchInstallParams.installPatch:-1 
--   sx.common.replication.DoReplication.installPatch:-1 
--   sx.common.replication.SXPatchInstallParams.installPatch:-1 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:-1 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:-1 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:597 
--   sx.admin.AdmDispatchAction.dispatchMethod:-1 
--   sx.admin.AdmDispatchAction.execute:-1 
--   sx.admin.AdmServletUtil.processAction:-1
go

