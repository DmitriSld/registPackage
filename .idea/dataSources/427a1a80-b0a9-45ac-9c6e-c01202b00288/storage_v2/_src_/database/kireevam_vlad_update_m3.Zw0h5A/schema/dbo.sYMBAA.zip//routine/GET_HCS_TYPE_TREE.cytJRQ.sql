-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION GET_HCS_TYPE_TREE()
RETURNS TABLE 
AS
RETURN (
	WITH HCS_TREE (id, childId, lvl) as (
		SELECT A_ID, A_ID, 0
		FROM SPR_HSC_TYPES
		UNION ALL
		SELECT tree.id, hcs.A_ID, tree.lvl + 1
		FROM SPR_HSC_TYPES hcs
		INNER JOIN HCS_TREE tree ON hcs.A_PARENT = tree.childId
	)
	SELECT * FROM HCS_TREE
)
go

