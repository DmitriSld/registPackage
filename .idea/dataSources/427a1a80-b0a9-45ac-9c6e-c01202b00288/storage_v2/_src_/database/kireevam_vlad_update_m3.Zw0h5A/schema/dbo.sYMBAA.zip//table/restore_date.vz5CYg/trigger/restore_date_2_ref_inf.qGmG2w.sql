CREATE TRIGGER dbo.restore_date_2_ref_inf
   ON  restore_date
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

UPDATE ri
  SET A_RESTORE_DATE = rd.restore_date
  FROM reference_inf ri
  JOIN inserted rd ON ri.a_ouid = rd.rayouid

END
go

