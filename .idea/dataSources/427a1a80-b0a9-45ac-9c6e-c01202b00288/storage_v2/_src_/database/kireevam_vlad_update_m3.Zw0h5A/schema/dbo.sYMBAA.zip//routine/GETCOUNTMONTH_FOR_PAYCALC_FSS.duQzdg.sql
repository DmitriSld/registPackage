-- Функция для подсчета месяцев начисления в Отчете о расходах средств ФСС
--CREATE 
CREATE FUNCTION [dbo].[GETCOUNTMONTH_FOR_PAYCALC_FSS]
(
@payCalcId INT, -- id начисления
@servServId int	-- id назначения
)
RETURNS INT
AS
BEGIN
	DECLARE @result INT,
		@sumSign INT,	-- размер начисления
		@countAdd INT,	-- количество нужных доплат
		@status INT		-- Статус объекта "Действует"
	SELECT @status = ESRN_SERV_STATUS.A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act'
	
	SET @result = 0
	SET @countAdd = 0
	SELECT @sumSign = A_SUMASSIGN FROM WM_PAY_CALC WHERE OUID = @payCalcId
	IF @sumSign <> 0 BEGIN SET @result = @result + 1 END
	
	SELECT @countAdd = COUNT(DISTINCT WM_ADDPAY_CALC.OUID )
	FROM WM_ADDPAY_CALC 
		INNER JOIN WM_ADDPAYCALCTYPE ON WM_ADDPAY_CALC.A_ADDTYPE = WM_ADDPAYCALCTYPE.A_OUID
			AND WM_ADDPAYCALCTYPE.A_CODE = 'early'
		-- Ищем начисление на месяц доплаты
		LEFT JOIN WM_PAY_CALC otherPayCalc1 ON otherPayCalc1.A_MSP = @servServId
			AND otherPayCalc1.A_STATUS = @status
			AND otherPayCalc1.A_MONTH = WM_ADDPAY_CALC.A_MONTH
			AND otherPayCalc1.A_YEAR = WM_ADDPAY_CALC.A_YEAR
			AND otherPayCalc1.OUID <> @payCalcId
		-- Ищем другую доплату на месяц доплаты
		LEFT JOIN WM_PAY_CALC otherPayCalc 
			INNER JOIN WM_ADDPAY_CALC otherAdd 
				INNER JOIN WM_ADDPAYCALCTYPE otherAddtype ON otherAdd.A_ADDTYPE = otherAddtype.A_OUID
					AND otherAddtype.A_CODE = 'early'
			ON otherAdd.A_PAYCALC = otherPayCalc.OUID
				AND otherAdd.A_STATUS = @status
		ON otherPayCalc.A_MSP = @servServId
			AND otherPayCalc.A_STATUS = @status
			AND otherPayCalc.A_MONTH < WM_ADDPAY_CALC.A_MONTH
			AND otherPayCalc.A_YEAR = WM_ADDPAY_CALC.A_YEAR
			AND otherAdd.A_MONTH = WM_ADDPAY_CALC.A_MONTH
			AND otherAdd.A_YEAR = WM_ADDPAY_CALC.A_YEAR
			AND otherPayCalc.OUID <> @payCalcId
	WHERE WM_ADDPAY_CALC.A_PAYCALC = @payCalcId
		AND WM_ADDPAY_CALC.A_STATUS = @status
		AND (otherPayCalc1.OUID IS NULL AND otherPayCalc.OUID IS NULL)
	
	SET @result = @result + @countAdd
	
	RETURN ISNULL(@result,0)
END
go

