CREATE FUNCTION [dbo].[GET_MSP_FINANCE_VALUES] (	
	@code varchar(128), @year int, @month int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT msp.A_ID AS [msp], pfv.A_VALUE AS [value]
	FROM PPR_SERV msp
	LEFT JOIN PPR_FINANCE_UNIT pfu
	ON pfu.A_CODE = @code
	LEFT JOIN SPR_SERV_FINANCE_UNIT_MASK mask
		INNER JOIN SPR_SERV_FIN_UNIT_LINK maskLink 
		ON mask.A_OUID = maskLink.A_FROMID
	ON msp.A_ID = maskLink.A_TOID AND pfu.A_ID = mask.A_FINANCE_UNIT
	INNER JOIN PPR_FINANCE_VALUE pfv
	ON pfv.A_FINANCE_UNIT = ISNULL(mask.A_FINANCE_UNIT_MASK,pfu.A_ID)
		AND ((pfv.A_BEGIN_DATE IS NULL OR (YEAR(pfv.A_BEGIN_DATE) < @year OR (YEAR(pfv.A_BEGIN_DATE) = @year AND MONTH(pfv.A_BEGIN_DATE) <= @month)))
		AND (pfv.A_END_DATE IS NULL OR (YEAR(pfv.A_END_DATE) > @year OR (YEAR(pfv.A_END_DATE) = @year AND MONTH(pfv.A_END_DATE) >= @month))))
)
 
--   sx.datastore.db.SXDb.execute:410 
--   sx.common.replication.DoReplication.installPatch:2883 
--   sx.common.replication.SXPatchInstallParams.installPatch:93 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:99 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:140 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:710
go

