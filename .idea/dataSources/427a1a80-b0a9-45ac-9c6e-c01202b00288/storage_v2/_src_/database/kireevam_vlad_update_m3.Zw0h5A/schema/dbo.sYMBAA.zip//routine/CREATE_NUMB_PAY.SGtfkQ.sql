

--формирование выплатного номера
CREATE PROC [dbo].[CREATE_NUMB_PAY]
AS

DECLARE @id INT
DECLARE @kod_ray VARCHAR(100)
DECLARE @kod_msp VARCHAR(100)
DECLARE @year_wmpaymentbook_create VARCHAR(100)
DECLARE @year_wmpaymentbook_ts VARCHAR(100)
DECLARE @a_numpb VARCHAR(100)
DECLARE @plat_delo VARCHAR(100)
DECLARE @toid INT
DECLARE @a_requisit INT

DECLARE @a_servdate_str_ess VARCHAR(100)
DECLARE @a_orgname_int INT
DECLARE @year_wmpaymentbook VARCHAR(100)
DECLARE @posl_nom INT
DECLARE @posl_nom_str VARCHAR(100)
DECLARE @posl_nom_ INT
DECLARE @posl_nom_str_ VARCHAR(100)

--курсор по выплатным делам
DECLARE  id_cursor CURSOR STATIC 
FOR SELECT dbo.WM_PAYMENT_BOOK.OUID, dbo.WM_PAYMENT_BOOK.A_CREATEDATE, 
		   dbo.WM_PAYMENT_BOOK.TS, dbo.WM_PAYMENT_BOOK.A_NUMPB, 
			dbo.WM_PAYMENT_BOOK.A_ACTREQUISIT
	FROM dbo.WM_PAYMENT_BOOK 


OPEN id_cursor 

FETCH NEXT FROM id_cursor 
INTO @id, @year_wmpaymentbook_create, @year_wmpaymentbook_ts, @a_numpb, @a_requisit;

WHILE @@FETCH_STATUS = 0
BEGIN
	--вытаскиваем из конфигурационного проекта СоцРегистр - КОД РАЙОНА 
	SET @kod_ray = (SELECT dbo.REGISTER_CONFIG.A_REGREGIONCODE FROM dbo.REGISTER_CONFIG) 			
	--вытаскиваем из МСП цифровой код
	SET @kod_msp = (SELECT TOP 1 dbo.PPR_SERV.A_CODFIG FROM dbo.PPR_SERV WHERE dbo.PPR_SERV.A_ID = 
					(SELECT TOP 1 dbo.SPR_NPD_MSP_CAT.A_MSP FROM dbo.SPR_NPD_MSP_CAT WHERE dbo.SPR_NPD_MSP_CAT.A_ID = 
					(SELECT TOP 1 dbo.ESRN_SERV_SERV.A_PAYMENTBOOK FROM dbo.ESRN_SERV_SERV WHERE dbo.ESRN_SERV_SERV.A_PAYMENTBOOK = 
					(SELECT TOP 1 dbo.WM_PAYMENT_BOOK.OUID FROM dbo.WM_PAYMENT_BOOK WHERE dbo.WM_PAYMENT_BOOK.OUID = @id)))) 
	--формируем запись XXX
	IF (@kod_msp IS NULL) SET @kod_msp = '000'		
	IF (datalength(@kod_msp) = 1) 					
		SET @kod_msp = '00' + @kod_msp;
	IF (datalength(@kod_msp) = 2) 					
		SET @kod_msp = '0' + @kod_msp;								
	
	----ФОРМИРОВАНИЕ ПОЛЯ "ПОСЛЕДОВАТЕЛЬНЫЙ НОМЕР"
	IF (@id IS NOT NULL OR @id != '') BEGIN
		--вытаскиваем из табл. назначенные МСП дату и время создания
		SET @a_servdate_str_ess = (SELECT TOP 1 dbo.ESRN_SERV_SERV.A_SERVDATE FROM dbo.ESRN_SERV_SERV WHERE dbo.ESRN_SERV_SERV.A_PAYMENTBOOK = @id AND dbo.ESRN_SERV_SERV.A_SERVDATE IS NOT NULL) 
	END
	--формируем год создания
	SET @a_servdate_str_ess = substring(@a_servdate_str_ess, 8,4);
	--вытаскиваем из табл. назначенные МСП ОСЗН
	SET @a_orgname_int = (SELECT TOP 1 dbo.ESRN_SERV_SERV.A_ORGNAME FROM dbo.ESRN_SERV_SERV WHERE dbo.ESRN_SERV_SERV.A_PAYMENTBOOK = @id AND dbo.ESRN_SERV_SERV.A_ORGNAME IS NOT NULL) 	
	--ЕСЛИ поля "дата и время создания" и "Дата и время последнего изменения" пустые, переходим НА СЛЕДУЮЩую запись
	IF (@year_wmpaymentbook_create IS NULL AND @year_wmpaymentbook_ts IS NULL) BEGIN 
		FETCH NEXT FROM id_cursor INTO @id, @year_wmpaymentbook_create, @year_wmpaymentbook_ts, @a_numpb, @a_requisit; 
	END;
	--если только поле "дата создания" пустая, берем дату последнего изменения иначе дату создания
	IF ((@year_wmpaymentbook_create IS NULL) or (@year_wmpaymentbook_create = '')) SET @year_wmpaymentbook = @year_wmpaymentbook_ts ELSE BEGIN
		SET @year_wmpaymentbook = @year_wmpaymentbook_create
	END
	-- формируем год 
	SET @year_wmpaymentbook = substring(@year_wmpaymentbook, 8,4);

	--ЕСЛИ ТЕКУЩИЙ ГОД инкрементируем в табл. "Конфигурационный проект СоцРегистр"  поле "Номер выплатного дела в пределах года"
	IF (@year_wmpaymentbook = DATEPART(YYYY,GETDATE()))	BEGIN		
		SET @posl_nom = (SELECT dbo.REGISTER_CONFIG.A_REGPAYBOOKNUM FROM dbo.REGISTER_CONFIG)		
		SET @posl_nom = @posl_nom + 1;
		
		UPDATE dbo.REGISTER_CONFIG
		SET dbo.REGISTER_CONFIG.A_REGPAYBOOKNUM = @posl_nom
		-- если номер дела в табл. "Выплатное дело" пустая запись, тогда формируем номер выплатного дела @plat_delo и вбиваем его в номер дела.
		IF ((@a_numpb IS NULL) or (@a_numpb = '')) BEGIN
			SET @posl_nom_str = @posl_nom
			SET @plat_delo = @kod_ray + '-' + @kod_msp + '-' + @posl_nom_str + '-' + @year_wmpaymentbook;
			UPDATE dbo.WM_PAYMENT_BOOK
			SET dbo.WM_PAYMENT_BOOK.A_NUMPB = @plat_delo
			WHERE dbo.WM_PAYMENT_BOOK.OUID = @id
		END 
	END ELSE BEGIN		
			--ВЫВОДИМ НОМЕР ИЗ ТАБЛ. СООТВЕТСТВИЯ GEN_NUMB_PAYMENT
			SET @posl_nom = (SELECT MAX(A_NUMB_CURR_YEAR) FROM dbo.GEN_NUMB_PAYMENT)	
			SET @posl_nom_ = @posl_nom
			SET @posl_nom_str_ = @posl_nom;
			--формируем запись вида xxxxx 
			if (datalength(@posl_nom_str_) = 1) 					
				SET @posl_nom_str_ = '0000' + @posl_nom_str_;
			if (datalength(@posl_nom_str_) = 2) 					
				SET @posl_nom_str_ = '000' + @posl_nom_str_;										
			if (datalength(@posl_nom_str_) = 3) 					
				SET @posl_nom_str_ = '00' + @posl_nom_str_;										
			if (datalength(@posl_nom_str_) = 4) 					
				SET @posl_nom_str_ = '0' + @posl_nom_str_;										
			--инкрементируем номер из табл. соответствия.
			SET @posl_nom_ = @posl_nom_ + 1						
			SET @posl_nom_str = @posl_nom_;
			if (datalength(@posl_nom_str) = 1) 					
				SET @posl_nom_str = '0000' + @posl_nom_str;
			if (datalength(@posl_nom_str) = 2) 					
				SET @posl_nom_str = '000' + @posl_nom_str;										
			if (datalength(@posl_nom_str) = 3) 					
				SET @posl_nom_str = '00' + @posl_nom_str;										
			if (datalength(@posl_nom_str) = 4) 					
				SET @posl_nom_str = '0' + @posl_nom_str;
				--обновляем в табл. соответствия поле номер 						
				UPDATE dbo.GEN_NUMB_PAYMENT
				SET dbo.GEN_NUMB_PAYMENT.A_NUMB_CURR_YEAR = @posl_nom_str
				WHERE dbo.GEN_NUMB_PAYMENT.A_NUMB_CURR_YEAR = @posl_nom_str_										
				--обновление WM_PAYMENT_BOOK.A_NUMPB(номер дела)
				SET @plat_delo = @kod_ray + '-' + @kod_msp + '-' + @posl_nom_str_ + '-' + @year_wmpaymentbook;
				UPDATE dbo.WM_PAYMENT_BOOK
				SET dbo.WM_PAYMENT_BOOK.A_NUMPB = @plat_delo
				WHERE dbo.WM_PAYMENT_BOOK.OUID = @id

	END
	--формирование актуальных реквизитов 
	IF (@a_requisit IS NULL OR @a_requisit = '') BEGIN		
		SET @toid = (SELECT TOP 1 dbo.WM_PAYMENT.OUID FROM dbo.WM_PAYMENT WHERE dbo.WM_PAYMENT.OUID = (SELECT  TOP 1 dbo.SPR_PAYBOOK_PAY.TOID FROM dbo.SPR_PAYBOOK_PAY WHERE dbo.SPR_PAYBOOK_PAY.FROMID = @id) ORDER BY dbo.WM_PAYMENT.A_LASTDATE DESC)
		UPDATE dbo.WM_PAYMENT_BOOK
		SET dbo.WM_PAYMENT_BOOK.A_ACTREQUISIT = @toid
		WHERE dbo.WM_PAYMENT_BOOK.OUID = @id
	END
	FETCH NEXT FROM id_cursor INTO @id, @year_wmpaymentbook_create, @year_wmpaymentbook_ts, @a_numpb, @a_requisit; 
END
CLOSE id_cursor
DEALLOCATE id_cursor



go

