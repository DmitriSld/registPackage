
CREATE VIEW [dbo].[SPR_HCS_TREE_VIEW]
AS 
WITH SPR_HCS (id, idchild, code, lev) AS (
	SELECT A_ID, A_ID, A_CODE , 0 FROM SPR_HSC_TYPES
	UNION ALL
	SELECT tree.id, A_ID, ISNULL(code,A_CODE), lev + 1 FROM SPR_HSC_TYPES hcs
	INNER JOIN SPR_HCS tree ON hcs.A_PARENT = tree.idchild 
)
SELECT * FROM SPR_HCS;
 
--   sx.datastore.db.SXDb.execute:433 
--   sx.common.replication.DoReplication.installPatch:2939 
--   sx.common.replication.SXPatchInstallParams.installPatch:82 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:200 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:180 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:57 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:43 
--   java.lang.reflect.Method.invoke:601 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:153 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160
go

