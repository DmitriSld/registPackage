CREATE FUNCTION dbo.getPCMainSKOCat(
 @pcId as INT
) RETURNS int
AS
BEGIN
    DECLARE @result int

    SET @result = (SELECT TOP 1 pprTemp.A_ID
    FROM WM_CATEGORY
    INNER JOIN PPR_REL_NPD_CAT on PPR_REL_NPD_CAT.A_ID =  WM_CATEGORY.A_NAME
    INNER JOIN PPR_CAT pprTemp on pprTemp.A_ID = PPR_REL_NPD_CAT.A_CAT
    AND pprTemp.A_STATUS = (SELECT A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act')
    INNER JOIN PPR_CAT pprParent on pprParent.A_ID = pprTemp.A_PARENT AND pprParent.GUID = '4c2f26cc-6bcd-4e8e-95d8-cf14d4e315c3' --Материнская категория СКО
    WHERE WM_CATEGORY.PERSONOUID = @pcId 
    AND WM_CATEGORY.A_STATUS = (SELECT A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act')
    ORDER BY pprTemp.A_CODE)

    RETURN @result
END;
 
--   sx.datastore.db.SXDb.getStackTraceAsString:2954 
--   sx.datastore.db.SXDb.execute:464 
--   sx.common.replication.DoReplication.installPatch:2996 
--   sx.common.replication.SXPatchInstallParams.installPatch:84 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:191 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:171 
--   sun.reflect.GeneratedMethodAccessor642.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:597 
--   sx.admin.AdmDispatchAction.dispatchMethod:96 
--   sx.admin.AdmDispatchAction.execute:51 
--   sx.admin.AdmServletUtil.processAction:153 
--   sx.admin.AdmServlet.doGet:78 
--   sx.admin.AdmServlet.doPost:158
go

