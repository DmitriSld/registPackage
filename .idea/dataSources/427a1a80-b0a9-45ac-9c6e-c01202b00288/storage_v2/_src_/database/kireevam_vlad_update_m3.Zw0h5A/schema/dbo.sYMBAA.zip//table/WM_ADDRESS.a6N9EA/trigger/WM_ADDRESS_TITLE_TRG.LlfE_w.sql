CREATE TRIGGER WM_ADDRESS_TITLE_TRG
   ON  dbo.WM_ADDRESS
   AFTER INSERT,UPDATE
AS 
BEGIN
	SET NOCOUNT ON;

	UPDATE WM_ADDRESS SET A_ADRTITLE = 
	      ISNULL(' ' + addrPost.A_INDEX,'')
		+ ISNULL(CASE WHEN addrPost.A_INDEX IS NOT NULL THEN ', ' ELSE '' END + addrCountry.A_NAME, '') 
		+ ISNULL(', ' + addrSubjfed.A_NAME + ISNULL(' ' + addrSubjfedtype.A_NAME, ''), '')
		+ ISNULL(', ' + addrFedbrought.A_NAME + ISNULL(' ' + addrFedbroughtType.A_NAME, ''), '') 
    + ISNULL(', ' + ISNULL(addrTownTypeSuper.A_NAME + '. ','') +  addrTownSuper.A_NAME, '')
		+ ISNULL(', ' + ISNULL(addrTownType.A_NAME + '. ','') +  addrTown.A_NAME, '')
		+ ISNULL(', ' + addrTownregion.A_NAME + ' р-н н.п.', '')
		+ ISNULL(', ' + addrStreetType.A_NAME + '.' + ISNULL(' ' + addrStreet.A_NAME, ''), '')
		+ ISNULL(', д. ' + addr.A_HOUSENUMBER, '') + ISNULL(', корп. ' + addr.A_BUILDING, '')
		+ ISNULL(', кв. ' + addr.A_FLATNUMBER, '')
	FROM INSERTED addr 
	LEFT JOIN SPR_COUNTRY addrCountry ON addr.A_COUNTRY = addrCountry.OUID
	LEFT JOIN SPR_SUBJFED addrSubjfed ON addr.A_SUBFED = addrSubjfed.OUID
	LEFT JOIN SPR_SUBJFEDTYPE addrSubjfedtype ON addrSubjfed.A_TYPE = addrSubjfedtype.A_ID
	LEFT JOIN SPR_FEDERATIONBOROUGHT addrFedbrought	ON addr.A_FEDBOROUGH = addrFedbrought.OUID
	LEFT JOIN SPR_FBTYPE addrFedbroughtType	ON addrFedbrought.A_TYPE = addrFedbroughtType.A_ID
	LEFT JOIN SPR_TOWN addrTown	ON addr.A_TOWN = addrTown.OUID
	LEFT JOIN SPR_TOWN_TYPE addrTownType ON addrTown.A_TOWNTYPE = addrTownType.OUID

  LEFT JOIN SPR_TOWN addrTownSuper	ON addr.A_SUPERTOWN = addrTownSuper.OUID
	LEFT JOIN SPR_TOWN_TYPE addrTownTypeSuper ON addrTownSuper.A_TOWNTYPE = addrTownTypeSuper.OUID   

	LEFT JOIN SPR_BOROUGH addrTownregion ON addr.A_TOWNBOROUGH = addrTownregion.OUID
		AND addrTownregion.A_TOWNID = addr.A_TOWN
	LEFT JOIN SPR_STREET addrStreet ON addr.A_STREET = addrStreet.OUID
	LEFT JOIN SPR_STEET_TYPE addrStreetType	ON addrStreet.A_STREETTYPE = addrStreetType.OUID
	LEFT JOIN SPR_RESPZONE_RESUCH addrRespZone ON addr.A_DOST_UCH_RES = addrRespZone.OUID
	LEFT JOIN SPR_RESIVE_UCH addrResiveUch ON addrRespZone.A_RECEIVE_UCH = addrResiveUch.OUID
	LEFT JOIN SPR_MAIL_PHONE addrPost ON addrResiveUch.A_SVZ = addrPost.OUID
	WHERE WM_ADDRESS.OUID = addr.OUID
END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40
go

