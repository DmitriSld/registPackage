create TRIGGER [dbo].[UPDATE_HIST_ZAJ]
   ON  [dbo].[WM_PAIDAMOUNTS]
   AFTER UPDATE
 AS
BEGIN

update LINK_ZAJ_PAID
set a_DEV=WM_PAYMENT.DELIVERYWAY
from LINK_ZAJ_PAID
inner join inserted on inserted.OUID=LINK_ZAJ_PAID.A_VYP
and ISNULL(LINK_ZAJ_PAID.A_STATUS, 10)=10
inner join WM_PAYMENT on WM_PAYMENT.ouid=inserted.A_PAYMENT

  
 update LINK_ZAJ_PAID
 set A_SUM_BANK=  A_VALUE / 100*A_SUM
 
 --	A_NDS
  from LINK_ZAJ_PAID
inner join inserted on inserted.OUID=LINK_ZAJ_PAID.A_VYP
and ISNULL(LINK_ZAJ_PAID.A_STATUS, 10)=10
inner join wm_Pay_calc on wm_Pay_calc.ouid=inserted.A_PAYCALC
and ISNULL(wm_Pay_calc.a_status, 10)=10
inner join ESRN_SERV_SERV on ESRN_SERV_SERV.ouid=wm_Pay_calc.A_MSP
and isnull(ESRN_SERV_SERV.a_Status, 10)=10
inner join SPR_NPD_MSP_CAT on SPR_NPD_MSP_CAT.a_ID=ESRN_SERV_SERV.a_serv
inner join SPR_BANK_SERV_LINK on SPR_BANK_SERV_LINK.A_TOID = SPR_NPD_MSP_CAT.A_MSP
inner join SPR_BANK_SERV  ON SPR_BANK_SERV.OUID = SPR_BANK_SERV_LINK.A_FROMID
INNER JOIN SPR_ORG_BASE sob ON sob.OUID= SPR_BANK_SERV.A_ORGANIZATION  
LEFT JOIN SPR_MAIL_PHONE phone on phone.OUID=sob.OUID
LEFT JOIN SPR_ORG_BANKS bank ON bank.OUID=sob.OUID
INNER JOIN SPR_PAY_TYPE  on SPR_PAY_TYPE.A_ID=ISNULL(phone.A_PAYTYPE_COD,bank.A_PAYTYPE_COD)
and SPR_PAY_TYPE.A_ID=LINK_ZAJ_PAID.A_DEV
  INNER JOIN PPR_FINANCE_UNIT  ON SPR_BANK_SERV.A_FIN_VALUE = PPR_FINANCE_UNIT.A_ID
  INNER JOIN PPR_FINANCE_VALUE  ON PPR_FINANCE_VALUE.A_FINANCE_UNIT = PPR_FINANCE_UNIT.A_ID  AND ISNULL(PPR_FINANCE_VALUE.A_STATUS, 10) = 10
  AND DATEDIFF(DAY, PPR_FINANCE_VALUE.A_BEGIN_DATE, CONVERT(DATETIME, ('01.' + CONVERT(VARCHAR, inserted.A_MONTH) + '.' + CONVERT(VARCHAR, inserted.A_YEAR)), 104)) >= 0
  AND DATEDIFF(DAY, ISNULL(PPR_FINANCE_VALUE.A_END_DATE, CONVERT(DATETIME, ('01.' + CONVERT(VARCHAR, inserted.A_MONTH) + '.' + CONVERT(VARCHAR, inserted.A_YEAR)), 104)), CONVERT(DATETIME, ('01.' + CONVERT(VARCHAR, inserted.A_MONTH) + '.' + CONVERT(VARCHAR, inserted.A_YEAR)), 104)) <= 0
 
 update 
 LINK_ZAJ_PAID
 set A_NDS=PPR_FINANCE_VALUE.A_VALUE / 100*LINK_ZAJ_PAID.A_SUM_BANK
 from LINK_ZAJ_PAID
inner join inserted on inserted.OUID=LINK_ZAJ_PAID.A_VYP
and ISNULL(LINK_ZAJ_PAID.A_STATUS, 10)=10
inner join SPR_PAY_TYPE on SPR_PAY_TYPE.A_ID=LINK_ZAJ_PAID.a_DEV
and SPR_PAY_TYPE.A_COD='NR1'
inner join  PPR_FINANCE_UNIT on PPR_FINANCE_UNIT.A_CODE = 'addCostTax'
and ISNULL(PPR_FINANCE_UNIT.A_STATUS, 10)=10
 INNER JOIN PPR_FINANCE_VALUE ON PPR_FINANCE_VALUE.A_FINANCE_UNIT = PPR_FINANCE_UNIT.A_ID
  AND DATEDIFF(DAY, PPR_FINANCE_VALUE.A_BEGIN_DATE, CONVERT(DATETIME, ('01.' + CONVERT(VARCHAR,  inserted.A_MONTH) + '.' + CONVERT(VARCHAR, inserted.A_YEAR)), 104)) >= 0
  AND DATEDIFF(DAY, ISNULL(PPR_FINANCE_VALUE.A_END_DATE, CONVERT(DATETIME, ('01.' + CONVERT(VARCHAR,  inserted.A_MONTH) + '.' + CONVERT(VARCHAR, inserted.A_YEAR)), 104)), CONVERT(DATETIME, ('01.' + CONVERT(VARCHAR,  inserted.A_MONTH) + '.' + CONVERT(VARCHAR, inserted.A_YEAR)), 104)) <= 0
and ISNULL(PPR_FINANCE_VALUE.A_STATUS, 10)=10

END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.common.replication.DoReplication.installPatchFileStep:3047 
--   sx.common.replication.DoReplication.installPatch:2612 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1
go

