	CREATE VIEW ADDR_VIEW AS 
		(SELECT 
			address.*, 
			CASE 
				WHEN town.A_NAME IS NULL 
				THEN '' 
				ELSE 'г. ' + town.A_NAME 
			END + 
			CASE 
				WHEN street.A_NAME IS NULL 
				THEN '' 
				ELSE ' ул. ' + street.A_NAME 
			END + 
			CASE 
				WHEN address.A_HOUSENUMBER IS NULL 
				THEN '' 
				ELSE ' д.' + address.A_HOUSENUMBER 
			END + 
			CASE 
				WHEN address.A_BUILDING IS NULL 
				THEN '' 
				ELSE ' к.' + address.A_BUILDING 
			END + 
			CASE 
				WHEN address.A_FLATNUMBER IS NULL 
				THEN '' 
				ELSE ' кв.' + address.A_FLATNUMBER 
			END AS addr
		FROM 
			WM_ADDRESS address 
			left join SPR_COUNTRY country ON address.A_COUNTRY = country.OUID
			left join SPR_TOWN town ON address.A_TOWN = town.OUID 
			left join SPR_BOROUGH townregion ON address.A_TOWNBOROUGH = townregion.OUID 
			left join SPR_MUNIREG munireg ON address.A_MUNREGION = munireg.OUID 
			left join SPR_STREET street ON address.A_STREET = street.OUID 
			left join SPR_MAIL_PHONE postoffice ON address.A_POSTOFFICE = postoffice.OUID
		)
    go

