CREATE PROC CONVERT_TUTOR_TASK
@user INT
AS
BEGIN
DECLARE @ld_id INT,@count_child INT,@ldop_id INT,@code INT,@date datetime,@dateLast datetime;
select @code=OUId from SPR_GROUP_TYPE where A_CODE='family';
-- курсор по личным делам опекунов
DECLARE  ld_cursor CURSOR STATIC 
FOR select distinct personal.OUID from wm_personal_card personal
inner join
(SELECT a_pc_tutor from WM_incapable_citizen where a_pc_tutor is not null)pp ON personal.OUID=pp.a_pc_tutor;

OPEN ld_cursor
  FETCH NEXT FROM ld_cursor INTO @ld_id;
  -- итерации по личным делам опекунов
  WHILE @@FETCH_STATUS = 0
  BEGIN
      -- достаем число детей-сирот в группе
        select @count_child=(count (distinct category.PERSONOUID)) from WM_CATEGORY category
	inner join PPR_REL_NPD_CAT prnc ON category.A_NAME =prnc.A_ID
	inner join PPR_CAT pprc ON prnc.A_CAT =pprc.A_ID and (A_CODE ='childOrphan' or A_CODE='childWithoutCare' )
	inner join WM_RELGROUPPC rel ON rel.A_TOID=category.PERSONOUID
	inner join WM_GROUP_INFO info ON info.OUID= rel.A_fromid
	inner join WM_RELGROUPPC relg ON info.OUID =relg.A_fromid  and relg.A_TOID=@ld_id and info.A_GROUP_TYPE=@code
         
       -- если количество опекаемых больше 0 
      IF (@count_child > 0)    
        begin          
	            -- курсор  по личным делам дитей сирот (опекаемых)
		DECLARE  ldop_cursor CURSOR STATIC 
		FOR     select distinct category.PERSONOUID,category.A_DATE,category.A_DATELAST from WM_CATEGORY category
			inner join PPR_REL_NPD_CAT prnc ON category.A_NAME =prnc.A_ID
			inner join PPR_CAT pprc ON prnc.A_CAT =pprc.A_ID and (A_CODE ='childOrphan' or A_CODE='childWithoutCare' )
			inner join WM_RELGROUPPC rel ON rel.A_TOID=category.PERSONOUID
			inner join WM_GROUP_INFO info ON info.OUID= rel.A_fromid
			inner join WM_RELGROUPPC relg ON info.OUID =relg.A_fromid  and relg.A_TOID=@ld_id and info.A_GROUP_TYPE=@code		         	    
	          -- удаляем запись об опекуне 
	         delete from WM_INCAPABLE_CITIZEN where A_PC_TUTOR =@ld_id;
	         OPEN ldop_cursor         
	          FETCH NEXT FROM ldop_cursor INTO @ldop_id,@date,@dateLast;                   
	          -- итерации по личным делам опекаемых
	          WHILE @@FETCH_STATUS = 0        
	          BEGIN                          
	             insert into  WM_INCAPABLE_CITIZEN 
	             (A_CROWNER,A_CREATEDATE,A_EDITOWNER,TS,A_STATUS,A_GUID,A_PC_TUTOR,A_PC_CITIZEN,A_INCAP_P_START,A_INCAP_P_END) 	             
	             values(@user,GETDATE(),@user,GETDATE(),10,NEWID(),@ld_id,@ldop_id,@date,@dateLast);  
	             FETCH NEXT FROM ldop_cursor INTO @ldop_id,@date,@dateLast; 
	          END;             
	         CLOSE ldop_cursor;
                 DEALLOCATE ldop_cursor; 
       end;
   FETCH NEXT FROM ld_cursor INTO @ld_id ; 
  END;
CLOSE ld_cursor;
DEALLOCATE ld_cursor;
END
go

