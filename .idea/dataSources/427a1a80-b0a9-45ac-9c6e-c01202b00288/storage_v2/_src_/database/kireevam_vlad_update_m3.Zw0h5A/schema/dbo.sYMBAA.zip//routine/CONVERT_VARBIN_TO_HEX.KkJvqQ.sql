
CREATE FUNCTION CONVERT_VARBIN_TO_HEX(
     @binvalue varbinary(255)
) RETURNS VARCHAR(255)
AS
BEGIN 
   declare @charvalue varchar(255)
   declare @i int
   declare @length int
   declare @hexstring char(16)

   select @charvalue = ''
   select @i = 1
   select @length = datalength(@binvalue)
   select @hexstring = '0123456789abcdef'

   while (@i <= @length)
   begin

     declare @tempint int
     declare @firstint int
     declare @secondint int

     select @tempint = convert(int, substring(@binvalue,@i,1))
     select @firstint = floor(@tempint/16)
     select @secondint = @tempint - (@firstint*16)

     select @charvalue = @charvalue +
       substring(@hexstring, @firstint+1, 1) +
       substring(@hexstring, @secondint+1, 1)

     select @i = @i + 1

   END
	
   RETURN @charvalue
	
END
go

