CREATE PROCEDURE [dbo].[MERGE_PC_FILL_DUPS]
AS
BEGIN

/*
CREATE TABLE #DUPLICATE_OBJECTS (
		num INT IDENTITY(1,1), 
		objClass VARCHAR(128), -- кодовое имя класса
		mainOuid INT,		   -- основной идентификатор
		dupOuid INT,		   -- идентификатор дубля
		delType INT			   -- 0 - не удаляем, 1 - удаляем физически, 2 - удаляем логически
)	
*/
SET ANSI_NULLS OFF

DECLARE @delType INT
SET @delType = 2

DECLARE @actAttrOuid INT
SELECT @actAttrOuid = A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act'

SELECT DISTINCT dups.mainOuid AS mainOuid, dups.dupOuid AS dupOuid 
INTO #TEMP_TABLE
FROM #DUPLICATE_OBJECTS dups
WHERE dups.objClass = 'wmPersonalCard'
UNION ALL
SELECT DISTINCT dups.mainOuid AS mainOuid, dups.mainOuid AS dupOuid 
FROM #DUPLICATE_OBJECTS dups
WHERE dups.objClass = 'wmPersonalCard'

--SELECT cls.MAP, cls.[NAME] FROM SXClass cls WHERE cls.MAP IN ('WM_ACTDOCUMENTS','WM_RELATEDRELATIONSHIPS','WM_ACTSOCIALCATEGORIES','WM_GROUP_INFO','WM_RELGROUPPC','WM_INCAPABLE_CITIZEN','WM_HEALTHPICTURE','WM_PAYMENT','SPR_PAYBOOK_PAY','WM_CATEGORY')

-- получаем дубликаты документов
INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
SELECT DISTINCT 'wmActDocuments', minId, id, @delType 
FROM (
	SELECT obj.OUID id, MIN(obj.OUID) OVER(PARTITION BY dups.mainOuid, obj.DOCUMENTSTYPE, obj.DOCUMENTSERIES, obj.DOCUMENTSNUMBER,
		obj.A_REGFLAT, obj.A_AMOUNT_PERSON, obj.ISSUEEXTENSIONSDATE, obj.A_MANY_FLAT) AS minId
	FROM WM_ACTDOCUMENTS obj
	INNER JOIN #TEMP_TABLE dups ON obj.PERSONOUID = dups.dupOuid AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)
) main
WHERE main.id != main.minId

-- получаем дубликаты семейных отношений
INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
SELECT DISTINCT 'wmRelatedrelationships', main.OUID, obj.OUID, @delType FROM WM_RELATEDRELATIONSHIPS obj 
INNER JOIN (
	SELECT dups.mainOuid, MIN(obj.OUID) AS OUID, obj.A_RELATED_RELATIONSHIP, obj.A_ID2
	FROM WM_RELATEDRELATIONSHIPS obj
	INNER JOIN #TEMP_TABLE dups ON obj.A_ID1 = dups.dupOuid AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)
	GROUP BY dups.mainOuid, obj.A_RELATED_RELATIONSHIP, obj.A_ID2
) main
ON obj.OUID != main.OUID AND obj.A_RELATED_RELATIONSHIP = main.A_RELATED_RELATIONSHIP AND obj.A_ID2 = main.A_ID2
	AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)	
INNER JOIN #TEMP_TABLE dups ON obj.A_ID1 = dups.dupOuid AND dups.mainOuid = main.mainOuid

-- получаем дубликаты признаков учета
INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
SELECT DISTINCT 'wmActSocialCategories', main.OUID, obj.OUID, @delType FROM WM_ACTSOCIALCATEGORIES obj 
INNER JOIN (
	SELECT dups.mainOuid, MIN(obj.OUID) AS OUID, obj.CATEGORYOUID, convert(varchar,obj.A_START_DATE,104) AS A_START_DATE, convert(varchar,obj.A_STOP_DATE,104) AS A_STOP_DATE
	FROM WM_ACTSOCIALCATEGORIES obj
	INNER JOIN #TEMP_TABLE dups ON obj.PERSONOUID = dups.dupOuid AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)
	GROUP BY dups.mainOuid, obj.CATEGORYOUID, convert(varchar,obj.A_START_DATE,104), convert(varchar,obj.A_STOP_DATE,104)
) main
ON obj.OUID != main.OUID AND obj.CATEGORYOUID = main.CATEGORYOUID AND convert(varchar,obj.A_START_DATE,104) = main.A_START_DATE AND convert(varchar,obj.A_STOP_DATE,104) = main.A_STOP_DATE
	AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)	
INNER JOIN #TEMP_TABLE dups ON obj.PERSONOUID = dups.dupOuid AND dups.mainOuid = main.mainOuid


-- получаем дубликаты опекунства
INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
SELECT DISTINCT 'incapableCitizen', main.A_ID, obj.A_ID, @delType FROM WM_INCAPABLE_CITIZEN obj 
INNER JOIN (
	SELECT dups.mainOuid, MIN(obj.A_ID) AS A_ID, obj.A_PC_TUTOR, obj.A_PC_CITIZEN, convert(varchar,obj.A_INCAP_P_START,104) AS A_INCAP_P_START, convert(varchar,obj.A_INCAP_P_END,104) AS A_INCAP_P_END
	FROM WM_INCAPABLE_CITIZEN obj
	INNER JOIN #TEMP_TABLE dups ON obj.A_PC_CITIZEN = dups.dupOuid AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)
	GROUP BY dups.mainOuid, obj.A_PC_TUTOR, obj.A_PC_CITIZEN, convert(varchar,obj.A_INCAP_P_START,104), convert(varchar,obj.A_INCAP_P_END,104)
) main
ON obj.A_ID != main.A_ID AND obj.A_PC_TUTOR = main.A_PC_TUTOR AND obj.A_PC_CITIZEN = main.A_PC_CITIZEN AND convert(varchar,obj.A_INCAP_P_START,104) = main.A_INCAP_P_START AND convert(varchar,obj.A_INCAP_P_END,104) = main.A_INCAP_P_END
	AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)	
INNER JOIN #TEMP_TABLE dups ON obj.A_PC_CITIZEN = dups.dupOuid AND dups.mainOuid = main.mainOuid

-- получаем дубли здоровья
INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
SELECT DISTINCT 'wmHealthpicture', main.OUID, obj.OUID, @delType FROM WM_HEALTHPICTURE obj 
INNER JOIN (
	SELECT dups.mainOuid, MIN(obj.OUID) AS OUID, obj.A_INVALID_GROUP, convert(varchar,obj.A_DETERMINATIONS_DATE,104) AS A_DETERMINATIONS_DATE, convert(varchar,obj.A_DATE_NEXT,104) AS A_DATE_NEXT, convert(varchar,obj.A_REMOVING_DATE,104) AS A_REMOVING_DATE,
			obj.A_REFERENCE, obj.A_DEGREE_WORKABILITIES, obj.A_DISEASES_TYPE, obj.A_DISEASE2, obj.A_ADD_DES, obj.A_OG_OB, obj.A_OG_OBU, obj.A_OG_TRU	
	FROM WM_HEALTHPICTURE obj
	INNER JOIN #TEMP_TABLE dups ON obj.PERSONOUID = dups.dupOuid AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)
	GROUP BY dups.mainOuid, obj.A_INVALID_GROUP, convert(varchar,obj.A_DETERMINATIONS_DATE,104), convert(varchar,obj.A_DATE_NEXT,104), convert(varchar,obj.A_REMOVING_DATE,104),
		obj.A_REFERENCE, obj.A_DEGREE_WORKABILITIES, obj.A_DISEASES_TYPE, obj.A_DISEASE2, obj.A_ADD_DES, obj.A_OG_OB, obj.A_OG_OBU, obj.A_OG_TRU	
) main
ON obj.OUID != main.OUID AND obj.A_INVALID_GROUP = main.A_INVALID_GROUP AND convert(varchar,obj.A_DETERMINATIONS_DATE,104) = main.A_DETERMINATIONS_DATE AND convert(varchar,obj.A_DATE_NEXT,104) = main.A_DATE_NEXT AND convert(varchar,obj.A_REMOVING_DATE,104) = main.A_REMOVING_DATE 
	AND obj.A_REFERENCE = main.A_REFERENCE AND obj.A_DEGREE_WORKABILITIES = main.A_DEGREE_WORKABILITIES AND obj.A_DISEASES_TYPE = main.A_DISEASES_TYPE AND obj.A_DISEASE2 = main.A_DISEASE2 AND obj.A_ADD_DES = main.A_ADD_DES AND obj.A_OG_OB = main.A_OG_OB AND obj.A_OG_OBU = main.A_OG_OBU AND obj.A_OG_TRU = main.A_OG_TRU
	AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)	
INNER JOIN #TEMP_TABLE dups ON obj.PERSONOUID = dups.dupOuid AND dups.mainOuid = main.mainOuid

-- получаем дубликаты выплатных реквизитов
INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
SELECT DISTINCT 'wmPayment', main.OUID, obj.OUID, @delType FROM WM_PAYMENT obj 
INNER JOIN (
	SELECT dups.mainOuid, MIN(obj.OUID) AS OUID, obj.DELIVERYWAY, obj.A_DELIVERY_TYPES, obj.A_DOCSTATUS, obj.ACCOUNTINGCOUNT, obj.A_PAYMENTORG, obj.ALTERNATIVEADDRESSDEIVERY
	FROM WM_PAYMENT obj
	INNER JOIN #TEMP_TABLE dups ON obj.PERSONOUID = dups.dupOuid AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)
	GROUP BY dups.mainOuid, obj.DELIVERYWAY, obj.A_DELIVERY_TYPES, obj.A_DOCSTATUS, obj.ACCOUNTINGCOUNT, obj.A_PAYMENTORG, obj.ALTERNATIVEADDRESSDEIVERY
) main
ON obj.OUID != main.OUID AND obj.DELIVERYWAY = main.DELIVERYWAY AND obj.A_DELIVERY_TYPES = main.A_DELIVERY_TYPES AND obj.A_DOCSTATUS = main.A_DOCSTATUS AND obj.ACCOUNTINGCOUNT = main.ACCOUNTINGCOUNT AND obj.A_PAYMENTORG = main.A_PAYMENTORG AND obj.ALTERNATIVEADDRESSDEIVERY = main.ALTERNATIVEADDRESSDEIVERY 
	AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL) 
INNER JOIN #TEMP_TABLE dups ON obj.PERSONOUID = dups.dupOuid AND dups.mainOuid = main.mainOuid

-- получаем дубликаты льготных категорий
INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
SELECT DISTINCT 'wmCategory', main.OUID, obj.OUID, @delType FROM WM_CATEGORY obj 
INNER JOIN (
	SELECT dups.mainOuid, MIN(obj.OUID) AS OUID, obj.A_NAME, obj.A_METHOD, obj.A_LCSTATUS, convert(varchar,obj.A_DATE,104) AS A_DATE, convert(varchar,obj.A_DATELAST,104) AS A_DATELAST
	FROM WM_CATEGORY obj
	INNER JOIN #TEMP_TABLE dups ON obj.PERSONOUID = dups.dupOuid AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)
	GROUP BY dups.mainOuid, obj.A_NAME, obj.A_METHOD, obj.A_LCSTATUS, convert(varchar,obj.A_DATE,104), convert(varchar,obj.A_DATELAST,104)
) main
ON obj.OUID != main.OUID AND obj.A_NAME = main.A_NAME AND obj.A_METHOD = main.A_METHOD AND obj.A_LCSTATUS = main.A_LCSTATUS AND convert(varchar,obj.A_DATE,104) = main.A_DATE AND convert(varchar,obj.A_DATELAST,104) = main.A_DATELAST
	AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)	
INNER JOIN #TEMP_TABLE dups ON obj.PERSONOUID = dups.dupOuid AND dups.mainOuid = main.mainOuid

-- получаем дубликаты групп
INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
SELECT DISTINCT 'wmGroupInfo', main.OUID, obj.OUID, @delType FROM WM_GROUP_INFO obj 
INNER JOIN (
	SELECT MIN(obj.OUID) AS OUID, obj.A_GROUP_TYPE, dups.mainOuid AS A_MAIN
	FROM WM_GROUP_INFO obj
	INNER JOIN #TEMP_TABLE dups ON dups.dupOuid = obj.A_MAIN
	WHERE (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)
	GROUP BY obj.A_GROUP_TYPE, dups.mainOuid
) main
INNER JOIN #TEMP_TABLE dups ON dups.mainOuid = main.A_MAIN
ON obj.OUID != main.OUID AND obj.A_GROUP_TYPE = main.A_GROUP_TYPE AND obj.A_MAIN = dups.dupOuid
	AND (obj.A_STATUS = @actAttrOuid OR obj.A_STATUS IS NULL)	


DROP TABLE #TEMP_TABLE

END
go

