CREATE FUNCTION [dbo].[GETNUMBER_FOR_CHILD_31_FORDATE]
(     
      @childId INT 
      , @date DATETIME 
)
RETURNS INT
AS
BEGIN

      DECLARE @result INT
             
      DECLARE @tmpChildFSS TABLE(number INT, id INT) 
      
      DECLARE @status INT          
      SELECT @status = ESRN_SERV_STATUS.A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act'

      INSERT INTO @tmpChildFSS (number, id) (
      SELECT  ROW_NUMBER() OVER (ORDER BY WM_PERSONAL_CARD.BIRTHDATE, WM_PERSONAL_CARD.OUID) AS number 
            , WM_PERSONAL_CARD.OUID AS id
      FROM WM_RELATEDRELATIONSHIPS 
            INNER JOIN SPR_GROUP_ROLE ON WM_RELATEDRELATIONSHIPS.A_RELATED_RELATIONSHIP = SPR_GROUP_ROLE.OUID 
            INNER JOIN WM_RELATEDRELATIONSHIPS OtherChildren ON OtherChildren.A_ID1 = WM_RELATEDRELATIONSHIPS.A_ID2
            AND (OtherChildren.A_STATUS = @status OR OtherChildren.A_STATUS IS NULL)
            INNER JOIN SPR_GROUP_ROLE OtherChildrenRole ON OtherChildren.A_RELATED_RELATIONSHIP = OtherChildrenRole.OUID
            INNER JOIN WM_PERSONAL_CARD ON WM_PERSONAL_CARD.OUID = OtherChildren.A_ID2
            AND (WM_PERSONAL_CARD.A_STATUS = @status OR WM_PERSONAL_CARD.A_STATUS IS NULL)
            LEFT JOIN WM_HISTORYPARENTALRIGHTS parentRight ON OtherChildren.OUID = parentRight.A_PERSONALCARD
                  AND DATEDIFF(day, parentRight.A_REGDATE, @date) >= 0
                  AND (DATEDIFF(day, parentRight.A_REMREGDATE, @date) <= 0 OR parentRight.A_REMREGDATE IS NULL)
      WHERE WM_RELATEDRELATIONSHIPS.A_ID1 = @childId
            AND SPR_GROUP_ROLE.A_COD = 'mother'
            AND (OtherChildrenRole.A_COD = 'son' OR OtherChildrenRole.A_COD = 'daughter')
            AND (WM_RELATEDRELATIONSHIPS.A_STATUS = @status OR WM_RELATEDRELATIONSHIPS.A_STATUS IS NULL)
            AND parentRight.A_OUID IS NULL
      )
      SELECT @result = number 
      FROM @tmpChildFSS
      WHERE id = @childId
      
      RETURN ISNULL(@result, 1)
END
go

