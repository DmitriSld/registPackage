CREATE TRIGGER set_user ON pack
  AFTER INSERT
  AS
UPDATE p
  SET p.CROWNER = ccu.userid
--SELECT p.[user],ccu.[name] 
  FROM pack p 
  JOIN INSERTED i ON p.ouid = i.ouid
  JOIN conv_corr_users ccu ON p.[user] = ccu.[name]
  WHERE p.CROWNER = 6656
go

