
create procedure PERM_STOP_SERV
/* Для всех Назначений со статусом "Утверждено",
у которых "Дата окончания периода предоставления МСП" <= "Текущему месяцу"
процедура изменяет статус на "Постоянное прекращение" */
as
begin
	update ESRN_SERV_SERV
	set A_STATUSPRIVELEGE = 2 
	from
	ESRN_SERV_SERV serv
	inner join SPR_STATUS_PROCESS stat on serv.A_STATUSPRIVELEGE = stat.A_ID
	inner join SPR_SERV_PERIOD period on period.A_SERV = serv.OUID
	where
	A_STATUSPRIVELEGE = 13 and
	year(period.A_LASTDATE) = year(GETDATE()) and
	month(period.A_LASTDATE) <= month(GETDATE())
end
go

