CREATE FUNCTION [dbo].[getSkoRequestQueue](
	 @reqId	AS INT,
	 @mode	AS SMALLINT
) RETURNS INT
AS

BEGIN
DECLARE @result		INT
DECLARE @pos		INT
DECLARE @typePos	INT
DECLARE @disPos		INT
DECLARE @mspType	INT
DECLARE @status		INT

SELECT @status = A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act'
SELECT @mspType = A_OUID FROM SPR_MSP_TYPE WHERE A_CODE = '333'

SELECT @pos = x.pos, @typePos = x.typePos, @disPos = x.disPos FROM 
	(	SELECT req.A_OUID,
			ROW_NUMBER() OVER(ORDER BY A_DATE_REG) AS pos,
			ROW_NUMBER() OVER(PARTITION BY serv.A_COD ORDER BY CASE WHEN A_PRIVILEGE IS NULL THEN 30 ELSE A_PRIVILEGE END, A_DATE_REG) AS typePos,
			ROW_NUMBER() OVER(PARTITION BY A_DISEASE_TYPE ORDER BY A_DATE_REG) AS disPos
		FROM SKO_REQUEST req
		INNER JOIN SPR_ST_SKO_REQ st ON req.A_STATE = st.A_OUID
			AND (st.A_CODE = 1)
		LEFT JOIN SPR_NPD_MSP_CAT npdMspCat ON npdMspCat.A_ID = req.A_MSPCATNPD
			AND (npdMspCat.A_STATUS = @status OR npdMspCat.A_STATUS IS NULL)
		LEFT JOIN PPR_SERV serv ON serv.A_ID = npdMspCat.A_MSP
			AND (serv.A_MSP_TYPE = @mspType)
			AND (serv.A_COD IN ('childToursHK', 'childZOLToursHK', 'childCampHK'))
			AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
		 WHERE (req.A_STATUS = @status OR req.A_STATUS IS NULL)
	) x
WHERE A_OUID = @reqId

IF(@mode = 1)
	SET @result = @disPos
ELSE IF(@mode = 2)
	SET @result = @typePos
ELSE
	SET @result = @pos

RETURN @result;
END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:2954 
--   sx.datastore.db.SXDb.execute:464 
--   sx.common.replication.DoReplication.installPatch:3010 
--   sx.common.replication.SXPatchInstallParams.installPatch:84 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:191 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:171 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:597 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40 
--   sx.admin.AdmServletUtil.processAction:153 
--   sx.admin.AdmServlet.doGet:78
go

