CREATE FUNCTION dbo.getTsrContrFactSum(
 @contractId as INT
) RETURNS FLOAT
AS
BEGIN
 -- Фактическая сумма, руб." в "Контракт с поставщиком ТСР"	
 DECLARE @resultTsr FLOAT
 DECLARE @resultServ FLOAT
 SELECT @resultTsr = ISNULL(SUM(TSR_NOMENC_INCONTR.A_SUM_FACT),0)
 FROM TSR_NOMENC_INCONTR
 WHERE TSR_NOMENC_INCONTR.A_CONTRACT = @contractId
 AND (TSR_NOMENC_INCONTR.A_STATUS IS NULL OR TSR_NOMENC_INCONTR.A_STATUS = (SELECT ESRN_SERV_STATUS.A_ID FROM ESRN_SERV_STATUS WHERE ESRN_SERV_STATUS.A_STATUSCODE = 'act'))
 
 SELECT @resultServ = ISNULL(SUM(TSR_SERV_INCONTR.A_SUM_FACT),0)
 FROM TSR_SERV_INCONTR
 WHERE TSR_SERV_INCONTR.A_CONTRACT = @contractId 
 AND (TSR_SERV_INCONTR.A_STATUS IS NULL OR TSR_SERV_INCONTR.A_STATUS = (SELECT ESRN_SERV_STATUS.A_ID FROM ESRN_SERV_STATUS WHERE ESRN_SERV_STATUS.A_STATUSCODE = 'act'))
 
 RETURN @resultTsr + @resultServ
END;
 
--   sx.datastore.db.SXDb.execute:-1 
--   sx.common.replication.DoReplication.installPatch:-1 
--   sx.common.replication.SXPatchInstallParams.installPatch:-1 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:-1 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:-1 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:597 
--   sx.admin.AdmDispatchAction.dispatchMethod:-1 
--   sx.admin.AdmDispatchAction.execute:-1 
--   sx.admin.AdmServletUtil.processAction:-1 
--   sx.admin.AdmServlet.doGet:-1 
--   sx.admin.AdmServlet.doPost:-1
go

