CREATE PROCEDURE [dbo].[CHANGESTATUS_VIPSFOR_ONPAYCALC]
	(@tableName VARCHAR(255), -- Название временной таблицы, в которой находятся идентификаторы начислений
	@attrName1 VARCHAR(255), -- Название поля временной таблицы, в которой находятся идентификаторы начислений
	@attrName2 VARCHAR(255) -- Название поля временной таблицы, в которой находятся идентификаторы выплат
	)
AS
BEGIN
	DECLARE @sql VARCHAR(8000)

	/* меням статус на выплата сформирована */
	SET @sql = 'UPDATE WM_PAY_CALC SET A_ISPAY = 1, A_RESIDUEPAY = 0, A_STATUSPRIVELEGE = SPR_STATUS_PROCESS.A_ID
	FROM SPR_STATUS_PROCESS
	WHERE SPR_STATUS_PROCESS.A_CODE=11 AND WM_PAY_CALC.OUID IN
	(SELECT ' + @tableName + '.' + @attrName1 + '
	FROM ' + @tableName + '
	WHERE ' + @tableName + '.' + @attrName2 + ' IS NULL)'

	EXEC(@sql)
END
go

