CREATE PROCEDURE [dbo].[CHANGESTATUS_PRVPORG_ONPAIDAMOUNTS]
	(@file VARCHAR(255), -- Название файла, куда произошла выгрузка данных
	@curAccount INT, -- Пользователь, который запустил выгрузку
	@tableName VARCHAR(255), -- Название временной таблицы, в которой находятся идентификаторы выплат
	@attrName VARCHAR(255) -- Название поля временной таблицы, в которой находятся идентификаторы выплат
	)
AS
BEGIN
	DECLARE @statusPrVpOrg INT, @sql VARCHAR(8000)
	SET @statusPrVpOrg = (SELECT TOP 1 ssp.A_ID FROM SPR_STATUS_PAYMENT ssp WHERE ssp.A_CODE = 4)

	/* меням статус на передано в выплатную организацию */
	SET @sql = 'UPDATE WM_PAIDAMOUNTS SET
		A_STATUSPRIVELEGE = ' + ISNULL(cast(@statusPrVpOrg AS varchar),'NULL') + ',
		A_LISTNUM = ' + ISNULL(char(39) + @file + char(39),'NULL') + ',
		A_EDITOWNER = ' + ISNULL(cast(@curAccount AS varchar),'NULL') + ',
		TS = GETDATE()
	WHERE WM_PAIDAMOUNTS.OUID IN
	(SELECT wp3.OUID
	FROM ' + @tableName + '
		INNER JOIN WM_PAIDAMOUNTS wp3 ON ' + @tableName + '.' + @attrName + ' = wp3.OUID
	WHERE ' + @tableName + '.' + @attrName + ' IS NOT NULL)'
	EXEC(@sql)
END
 
--   sx.datastore.db.SXDb.execute:404 
--   sx.common.replication.DoReplication.installPatch:3713 
--   sx.common.replication.SXPatchInstallParams.installPatch:89 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:89 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:585 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:128 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:709
 
--   sx.datastore.db.SXDb.execute:411 
--   sx.common.replication.DoReplication.installPatch:3131 
--   sx.common.replication.SXPatchInstallParams.installPatch:89 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:89 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:128 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:709
go

