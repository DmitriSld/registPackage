CREATE PROCEDURE [dbo].[CREATE_PAIDAMOUNT_ONPAYCALC]
	(@file VARCHAR(255), -- Название файла, куда произошла выгрузка данных
	@curAccount INT, -- Пользователь, который запустил выгрузку
	@tableName VARCHAR(255), -- Название временной таблицы, в которой находятся идентификаторы начислений
	@attrName1 VARCHAR(255), -- Название поля временной таблицы, в которой находятся идентификаторы начислений
	@attrName2 VARCHAR(255) -- Название поля временной таблицы, в которой находятся идентификаторы выплат
	)
AS
BEGIN
	DECLARE @statusPrVpOrg INT, @status INT, @sql VARCHAR(8000)
	SET @statusPrVpOrg = (SELECT TOP 1 ssp.A_ID FROM SPR_STATUS_PAYMENT ssp WHERE ssp.A_CODE = 4)
	SET @status = (SELECT TOP 1 A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act')
	
	/* создаем выплаты */
	SET @sql = 'INSERT INTO WM_PAIDAMOUNTS
	(
		A_PAYCALC, 
		PERSONOUID,
		PAIDDATE,
		A_MONTH,
		A_YEAR,
		AMOUNT,
		A_STATUSPRIVELEGE,
		A_LISTNUM,
		A_PAYACCOUNT,
		A_PAYMENT,
		A_CROWNER,
		A_CREATEDATE,
		A_STATUS,
		GUID,
		A_PAYNAME,
		TS
	)
	SELECT
		wpc.OUID,
		wpc.PERSONOUID,
		GETDATE(),
		wpc.A_MONTH,
		wpc.A_YEAR,
		wpc.AMOUNT,'
		+ ISNULL(cast(@statusPrVpOrg AS varchar),'NULL') + ','
		+ ISNULL(char(39) + @file + char(39),'NULL') + ',
		wpc.A_PAYACCOUNT,
		wpb.A_ACTREQUISIT,'
		+ ISNULL(cast(@curAccount AS varchar),'NULL') + ',
		GETDATE(),'
		+ ISNULL(cast(@status AS varchar),'NULL') + ',
		NEWID(),
		snmc.A_MSP,
		GETDATE()
	FROM ' + @tableName + '
		INNER JOIN WM_PAY_CALC wpc ON ' + @tableName + '.' + @attrName1 + ' = wpc.OUID
		INNER JOIN WM_PAYMENT_BOOK wpb ON wpc.A_PAYACCOUNT = wpb.OUID AND (wpb.A_STATUS = '+ ISNULL(cast(@status AS varchar),'NULL') +' OR wpb.A_STATUS IS NULL)
		INNER JOIN ESRN_SERV_SERV ess ON wpc.A_MSP = ess.OUID AND (ess.A_STATUS = '+ ISNULL(cast(@status AS varchar),'NULL') +' OR ess.A_STATUS IS NULL)
		INNER JOIN SPR_NPD_MSP_CAT snmc ON ess.A_SERV = snmc.A_ID
	WHERE ' + @tableName + '.' + @attrName2 + ' IS NULL'
	EXEC(@sql)
END
 
--   sx.datastore.db.SXDb.execute:404 
--   sx.common.replication.DoReplication.installPatch:3713 
--   sx.common.replication.SXPatchInstallParams.installPatch:89 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:89 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:585 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:128 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:709
 
--   sx.datastore.db.SXDb.execute:411 
--   sx.common.replication.DoReplication.installPatch:3131 
--   sx.common.replication.SXPatchInstallParams.installPatch:89 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:89 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:128 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:709
go

