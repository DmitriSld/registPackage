CREATE FUNCTION dbo.getSkoContrSumFactAt(
 @contractId as INT
) RETURNS FLOAT
AS
BEGIN
 -- "Фактическая стоимость после поездки, руб." в "Контракт с поставщиком ТСР"	
 DECLARE @result float
 SELECT @result = ISNULL(SUM(WM_TOURS.A_SUM_FACT),0)
 FROM WM_TOURS
 WHERE WM_TOURS.A_CONTRACT = @contractId
 AND (WM_TOURS.A_STATUS IS NULL OR WM_TOURS.A_STATUS = (SELECT ESRN_SERV_STATUS.A_ID FROM ESRN_SERV_STATUS WHERE ESRN_SERV_STATUS.A_STATUSCODE = 'act'))
 AND WM_TOURS.A_GRANT IS NOT NULL
  
 RETURN @result
END;
 
--   sx.datastore.db.SXDb.execute:-1 
--   sx.common.replication.DoReplication.installPatch:-1 
--   sx.common.replication.SXPatchInstallParams.installPatch:-1 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:-1 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:-1 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:597 
--   sx.admin.AdmDispatchAction.dispatchMethod:-1 
--   sx.admin.AdmDispatchAction.execute:-1 
--   sx.admin.AdmServletUtil.processAction:-1 
--   sx.admin.AdmServlet.doGet:-1 
--   sx.admin.AdmServlet.doPost:-1
go

