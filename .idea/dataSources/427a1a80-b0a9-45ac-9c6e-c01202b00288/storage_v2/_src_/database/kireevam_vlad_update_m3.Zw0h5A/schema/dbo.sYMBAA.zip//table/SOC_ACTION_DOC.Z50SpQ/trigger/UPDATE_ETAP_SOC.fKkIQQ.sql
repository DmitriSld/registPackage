CREATE TRIGGER [dbo].[UPDATE_ETAP_SOC]
   ON  [dbo].[SOC_ACTION_DOC]
 AFTER INSERT,DELETE,UPDATE
AS 
BEGIN
/*Заменяем этап обработки только в действ/недейств соц.контр*/
declare @getdate datetime
set @getdate=GETDATE()

update contr
set A_ETAP='50'
, ts=@getdate
from inserted
inner join WM_ACTDOCUMENTS prog on prog.OUID=inserted.A_DOC
and ISNULL(prog.A_STATUS, 10)=10
inner join WM_ACTDOCUMENTS contr on contr.OUID= prog.A_SOC_CONTRACT_DOC
and ISNULL(contr.A_STATUS, 10)=10
inner join SPR_DOC_STATUS on contr.A_DOCSTATUS=SPR_DOC_STATUS.A_OUID
and SPR_DOC_STATUS.a_code!='project'
inner join WM_ACTDOCUMENTS zakl on zakl.A_SOC_CONTRACT_DOC=contr.OUID
and ISNULL(zakl.A_STATUS, 10)=10
inner join PPR_DOC tZakl on tZakl.A_ID=zakl.DOCUMENTSTYPE
and isnull(tZakl.A_CODE, '')='ConCommissionSoc'
inner join WM_ACTDOCUMENTS pricaz on pricaz.A_ZAKL=zakl.OUID
and ISNULL(pricaz.A_STATUS, 10)=10
and isnull(pricaz.A_TYPE_CON_COMM_SOC, '')='40'
inner join PPR_DOC tPricaz on tPricaz.a_id=pricaz.DOCUMENTSTYPE
and isnull(tPricaz.A_CODE, '')='pricazDepSoc'

update contr
set A_ETAP='40'
, ts=@getdate
from inserted
inner join WM_ACTDOCUMENTS prog on prog.OUID=inserted.A_DOC
and ISNULL(prog.A_STATUS, 10)=10
inner join WM_ACTDOCUMENTS contr on contr.OUID= prog.A_SOC_CONTRACT_DOC
and ISNULL(contr.A_STATUS, 10)=10
and not (contr.ts=@getdate and isnull(contr.A_ETAP, '10')in('50'))
inner join SPR_DOC_STATUS on contr.A_DOCSTATUS=SPR_DOC_STATUS.A_OUID
and SPR_DOC_STATUS.a_code!='project'
inner join SOC_ACTION_DOC on SOC_ACTION_DOC.A_DOC=prog.OUID
and ISNULL(SOC_ACTION_DOC.A_STATUS, 10)=10
and SOC_ACTION_DOC.a_ouid!=inserted.A_OUID
where SOC_ACTION_DOC.A_DATE_ISP is null and DATEDIFF(DAY,SOC_ACTION_DOC.END_DATE, @getdate)>0

update contr
set A_ETAP='40'
, ts=@getdate
from inserted
inner join WM_ACTDOCUMENTS prog on prog.OUID=inserted.A_DOC
and ISNULL(prog.A_STATUS, 10)=10
inner join WM_ACTDOCUMENTS contr on contr.OUID= prog.A_SOC_CONTRACT_DOC
and ISNULL(contr.A_STATUS, 10)=10
and not (contr.ts=@getdate and isnull(contr.A_ETAP, '10')in('50', '40'))
inner join SPR_DOC_STATUS on contr.A_DOCSTATUS=SPR_DOC_STATUS.A_OUID
and SPR_DOC_STATUS.a_code!='project'
inner join SOC_ACTION_DOC on SOC_ACTION_DOC.A_DOC=prog.OUID
and ISNULL(SOC_ACTION_DOC.A_STATUS, 10)=10
and SOC_ACTION_DOC.a_ouid!=inserted.A_OUID
where inserted.A_DATE_ISP is null and DATEDIFF(DAY,inserted.END_DATE, @getdate)>0
and isnull(inserted.A_STATUS, 10)=10

update WM_ACTDOCUMENTS
set A_ETAP=case when isnull(t1.vsego, 0)=ISNULL(ispol, 0) and ISNULL(ispol, 0)!=0 then '30' 
when ISNULL(ispol, 0)=0 then '10'
else '20'
end 
, TS=@getdate
from
(select contr.OUID
,COUNT(distinct SOC_ACTION_DOC.A_OUID)+case when isnull(inserted.A_STATUS, 10)=10 then 1 else 0 end vsego--всего
,COUNT(distinct case when SOC_ACTION_DOC.A_DATE_ISP IS not null then SOC_ACTION_DOC.A_OUID else null end) 
+case when isnull(inserted.A_STATUS, 10)=10 and inserted.A_DATE_ISP IS not null  then 1 else 0 end --исполнено
ispol
from inserted
inner join WM_ACTDOCUMENTS prog on prog.OUID=inserted.A_DOC
and ISNULL(prog.A_STATUS, 10)=10
inner join WM_ACTDOCUMENTS contr on contr.OUID= prog.A_SOC_CONTRACT_DOC
and ISNULL(contr.A_STATUS, 10)=10
and not (contr.ts=@getdate and isnull(contr.A_ETAP, '10')in('50', '40'))
inner join SPR_DOC_STATUS on contr.A_DOCSTATUS=SPR_DOC_STATUS.A_OUID
and SPR_DOC_STATUS.a_code!='project'
inner join SOC_ACTION_DOC on SOC_ACTION_DOC.A_DOC=prog.OUID
and ISNULL(SOC_ACTION_DOC.A_STATUS, 10)=10
and SOC_ACTION_DOC.a_ouid!=inserted.A_OUID
group by contr.ouid, inserted.A_STATUS, inserted.A_DATE_ISP
)t1
inner join WM_ACTDOCUMENTS on WM_ACTDOCUMENTS.ouid=t1.ouid
SET NOCOUNT ON;

END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.common.replication.DoReplication.installPatchFileStep:3047 
--   sx.common.replication.DoReplication.installPatch:2612 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1
go

