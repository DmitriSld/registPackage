-- 
CREATE FUNCTION GET_DISTKOLL_PAYCALC_CHILDREN
(
@year int,
@month int,
@month2 int,
@finValue int,
@codeMsp1 varchar(255),
@codeMsp2 varchar(255),
@countChild int,
@codeStatusPrivilege varchar(255)
)
RETURNS float
AS
BEGIN
declare @statusCode int 
select @statusCode=a_id from ESRN_SERV_STATUS where a_statuscode='act'
  DECLARE @koll float
select @koll=count(*) from(
select WM_PAY_CALC.personouid from WM_PAY_CALC
inner join wm_personal_card on(wm_personal_card.ouid=WM_PAY_CALC.personouid)
inner join SPR_STATUS_PROCESS 
on(WM_PAY_CALC.A_STATUSPRIVELEGE=SPR_STATUS_PROCESS.A_ID and SPR_STATUS_PROCESS.a_code=@codeStatusPrivilege

)
inner join ESRN_SERV_SERV on(WM_PAY_CALC.a_msp=ESRN_SERV_SERV.ouid)
inner join SPR_NPD_MSP_CAT on(ESRN_SERV_SERV.a_serv=SPR_NPD_MSP_CAT.a_id and ((SPR_NPD_MSP_CAT.A_CODE=@codeMsp1 and @codeMsp1 is not null) or (SPR_NPD_MSP_CAT.A_CODE=@codeMsp2 and @codeMsp2 is not null)))
inner join tmpTableKollChildr on(tmpTableKollChildr.ouidPAIDAMOUNTS=WM_PAY_CALC.ouid and ((tmpTableKollChildr.kolChildren=2 or tmpTableKollChildr.kolChildren=1)))

where  (ESRN_SERV_SERV.a_status=@statusCode or ESRN_SERV_SERV.a_status is null)
and (SPR_NPD_MSP_CAT.a_status=@statusCode or SPR_NPD_MSP_CAT.a_status is null)
and (WM_PAY_CALC.a_status=@statusCode or WM_PAY_CALC.a_status is null)
and (wm_personal_card.a_status=@statusCode or wm_personal_card.a_status is null)
and (WM_PAY_CALC.a_year=@year and (WM_PAY_CALC.a_month>=@month and WM_PAY_CALC.a_month<=@month2))
and ESRN_SERV_SERV.A_CHILD in(
select 
ESRN_SERV_SERV.A_CHILD
from
WM_PAY_CALC
inner join wm_personal_card on(wm_personal_card.ouid=WM_PAY_CALC.personouid)
inner join SPR_STATUS_PROCESS
on(WM_PAY_CALC.A_STATUSPRIVELEGE=SPR_STATUS_PROCESS.A_ID and SPR_STATUS_PROCESS.a_code='100')
inner join ESRN_SERV_SERV on(WM_PAY_CALC.a_msp=ESRN_SERV_SERV.ouid)
inner join SPR_NPD_MSP_CAT on(ESRN_SERV_SERV.a_serv=SPR_NPD_MSP_CAT.a_id and SPR_NPD_MSP_CAT.A_CODE in ('childVacation1_5noFSS','childVacation1_5Rel'))
and (WM_PAY_CALC.a_year=@year and (WM_PAY_CALC.a_month>=@month and WM_PAY_CALC.a_month<=@month2))
)
group by WM_PAY_CALC.personouid ) as lol
if @koll is null
begin 
RETURN 0
end

RETURN @koll

END
go

