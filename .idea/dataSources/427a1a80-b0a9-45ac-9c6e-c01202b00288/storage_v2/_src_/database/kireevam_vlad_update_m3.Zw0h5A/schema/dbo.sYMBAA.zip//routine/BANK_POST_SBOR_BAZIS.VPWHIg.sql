CREATE FUNCTION dbo.BANK_POST_SBOR_BAZIS
(
@payType INT,
@msplknpd INT,
@orgId INT,
@curdate DATETIME 
)
RETURNS float
AS
BEGIN
declare @result float

SELECT @result=  A_VALUE / 100 
  --,SPR_BANK_SERV.A_DATA_PART AS DATA_PART
  --,SPR_PAY_TYPE.A_COD AS delivery 
  --,msplknpd.A_ID msplknpd
  --,msplknpd.A_MSP msp
  --,msplknpd.A_CATEGORY cats

FROM SPR_BANK_SERV
INNER JOIN SPR_BANK_SERV_LINK  ON SPR_BANK_SERV.OUID = SPR_BANK_SERV_LINK.A_FROMID
  INNER JOIN SPR_NPD_MSP_CAT msplknpd  ON SPR_BANK_SERV_LINK.A_TOID = msplknpd.A_MSP and mspLkNpd.a_id=@msplknpd 
 -- AND (msplknpd.A_DATA_PART = SPR_BANK_SERV.A_DATA_PART OR isnull(A_CONSIDERSECTION,0)=0)
  INNER JOIN SPR_ORG_BASE sob ON sob.OUID= SPR_BANK_SERV.A_ORGANIZATION  
  LEFT JOIN SPR_MAIL_PHONE phone on phone.OUID=sob.OUID
  LEFT JOIN SPR_ORG_BANKS bank ON bank.OUID=sob.OUID
  INNER JOIN SPR_PAY_TYPE  on SPR_PAY_TYPE.A_ID=ISNULL(phone.A_PAYTYPE_COD,bank.A_PAYTYPE_COD)
  INNER JOIN PPR_FINANCE_UNIT  ON SPR_BANK_SERV.A_FIN_VALUE = PPR_FINANCE_UNIT.A_ID
  INNER JOIN PPR_FINANCE_VALUE  ON PPR_FINANCE_VALUE.A_FINANCE_UNIT = PPR_FINANCE_UNIT.A_ID  AND ISNULL(PPR_FINANCE_VALUE.A_STATUS, 10) = 10
  AND DATEDIFF(DAY, PPR_FINANCE_VALUE.A_BEGIN_DATE, @curdate) >= 0
  AND DATEDIFF(DAY, ISNULL(PPR_FINANCE_VALUE.A_END_DATE, @curdate), @curdate) <= 0
  
	and SPR_PAY_TYPE.A_ID=@payType

RETURN ISNULL(@result,0)
END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40
go

