-- Возвращает самую верхнюю организацию
CREATE FUNCTION GET_PARENT_ORG
(
@orgId int
)
RETURNS int
AS
BEGIN
  DECLARE @parentId int -- идентификатор самой вышестоящей организации
  DECLARE @tmpId int

  SET @parentId = @orgId
  SET @tmpId = @orgId

  WHILE @tmpId IS NOT NULL BEGIN
  SET @tmpId=NULL
    SELECT @tmpId = A_PARENT FROM SPR_ORG_BANKS WHERE OUID = @parentId
    IF (@tmpId IS NOT NULL) BEGIN
      SET @parentId = @tmpId
    END
  END

  RETURN @parentId
END
go

