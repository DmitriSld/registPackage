CREATE PROCEDURE [dbo].[PREPARE_FOR_RECALC_HCS]
	@uuid varchar(100)
AS
/* Таблица, содержащая периоды для расчета (группа ЖКУ, дата начала периода, дата окончания периода) */
DECLARE @periodsTable           TABLE(groupId INT, beginDate DATETIME, endDate DATETIME)
/* Таблица, содержащая промежуточную информацию для формирвания периодов. Даты начала периодов, по измению состояний групп ЖКУ(группа ЖКУ, даты начала периодов) */
DECLARE @periodsAgrTable        TABLE(groupId INT, perDate DATETIME)
/* Таблица, в которую идет расчет коэффициента. Т.к. один и тот же член семьи может входить в разные области распространения, необходимо посчитать долю вхождения (группа ЖКУ, комбинация, услуга, льготник, члены группы из области распространения, коэффициент, 
   дата начала периода, дата окончания периода) */
DECLARE @factorTable            TABLE(groupId INT,
         combination INT,
         hcs INT,
         personId INT,
         relatedPerson INT,
         factor FLOAT,
         beginDate DATETIME,
         endDate DATETIME)
/* Таблица, в которой идет распределения членов группы между областями распределения (вариант, группа ЖКУ, услуга, комбинация, процент, льготник, распределяемый член группы,
   дата начала периода, дата окончания периода) */
DECLARE @relatedPersonTable     TABLE(variation INT,
         groupId INT,
         hcs INT,
         combination INT,
         cPercent FLOAT,
         personId INT,
         relatedPersonId INT,
         beginDate DATETIME,
         endDate DATETIME)
/* Таблица, в которую выбираются члены группы, из области распространения в заявлении между областями распределения (льготник, распределяемый член группы, МСП-ЛК-НПД, группа ЖКУ) */
DECLARE @relatedPetPersonTable  TABLE(personId INT,
         relatedPerson INT,
         npdMspCat INT,
         hcsGroup INT,
		 hcs INT)
/* Таблица, в которую расчитывается количество льготников с одинаковым процентом по услуге (группа ЖКУ, комбинация, услуга, процент, кол-во)*/
DECLARE @sameTable              TABLE(groupId INT,
         combination INT,
         hcs INT,
         cPercent FLOAT,
         sameCounter INT)
/* Таблица в которую отбираются все актуальные члены группы, нельготники (группа ЖКУ, идентификатор нельготника, дата начала периода, дата окончания периода) */ 
DECLARE @persTable              TABLE(groupId INT,
         personId INT,
         dateIn DATETIME,
         dateOut DATETIME)
/* Таблица для временных расчетов распределения (группа ЖКУ, вариация, позиция, вариант)*/
DECLARE @tmpGroupTable          TABLE(groupId INT,
         variant VARCHAR(100),
         position INT,
         variantId INT,
         beginDate DATETIME,
         endDate DATETIME)
/* Таблица, содержащая подготовленные данные для расчетов (группа ЖКУ, идетификатор связи, услуги, связанные, область распространения, процент, вид расчета, признак использования норматива, общая площадь,
   отапливаемая площадь, тариф, комбинация, признак использования  долей, признак использования норм, идентификатор алгоритма вычисления, 
   дата начала периода, дата окончания периода)*/
DECLARE @forCalcTable           TABLE(groupId INT,
         relation INT,
         hcs INT,
         relatedPersons VARCHAR(255),
         areaOfDistr VARCHAR(15),
         cPercent FLOAT,
         calcType VARCHAR(15),
         norm BIT,
         totalSquare FLOAT,
         heatedSquare FLOAT,
         tarif FLOAT,
         combination INT,
         usePortion BIT,
         useNorm BIT,
         algId INT,
         beginDate DATETIME,
         endDate DATETIME,
         allPersons INT)
/* Таблица с подготвленными даными для всавки в результирующую таблицу(TMP_DEP_PC_NPDMSPCAT) (идентификатор записи, групп ЖКУ, льготник, МСП-ЛК-НПД, услуга, процент, вид расчета, общая площадь,
   отапливаемая площадь, тариф, комбинация, члены группы из области распространения, номатив, тип области распространения, дата начала периода, дата окончания периода)*/
DECLARE @resTable               TABLE(resId INT IDENTITY(1, 1) PRIMARY KEY,
         groupId INT,
         personId INT,
         npdMspCat INT,
         hcs INT,
         cPercent FLOAT,
         calcType INT,
         totalSquare FLOAT,
         heatedSquare FLOAT,
         tarif FLOAT,
         combination INT,
         norm FLOAT,
         areaOfDistr VARCHAR(15),
         personCount INT,
         beginDate DATETIME,
         endDate DATETIME) 
/* Таблица для квитанций по группам ЖКУ */         
DECLARE @receiptTable TABLE(groupId INT, rcptId INT, payDate DATETIME, rcptAmountId INT,
 hcs INT, pay FLOAT, useRcptNorm INT, org INT, mspLkNpd INT)   

/* Переменные для курсоров */
DECLARE @oldHcs                 INT,
        @oldGroupId             INT,
        @oldPersonId            INT,
        @oldPersonId2			INT,  
        @personId               INT,
        @oldPercent             INT,
        @sameCounter            FLOAT,
        @hcs                    INT,
        @groupHCS               INT,
        @variant                VARCHAR(255),
        @areaOfDistr            VARCHAR(15),
        @npdMspCat              INT,
        @combination            INT,
        @position               INT,
        @oldPosition            INT,
        @calcPercent            FLOAT,
        @oldCombination         INT,
        @area                   INT,
        @variantId              INT,
        @toVar                  VARCHAR(100),
        @pos                    INT,
        @pos2                   INT,
        @posFromTable           INT,
        @beginDate              DATETIME,
        @endDate                DATETIME,
        @oldBeginDate           DATETIME,
        @oldEndDate             DATETIME,
        @calcType               VARCHAR(50),
        @isNorm                 BIT,
        @totalSquare            FLOAT,
        @heatedSquare           FLOAT,
        @needTotalSquare        FLOAT,
        @needHeatedSquare       FLOAT,
        @relatedPersonId        INT,
        @norma                  FLOAT,
        @freeTotalSquare        FLOAT,
        @freeHeatedSquare       FLOAT,
        @tarif                  FLOAT,
        @fullNorm               FLOAT,
        @preparedVariant        VARCHAR(100),
        @resId                  INT,
        @algId                  INT,
        @partTotalSquare        FLOAT,
        @partHeatedSquare       FLOAT,
        @partRelTotalSquare     FLOAT,
        @partRelHeatedSquare    FLOAT,
        @groupId                INT,
        @personCount            INT,
        @usePortion             BIT,
        @useNorm                BIT,
        @socNorm                FLOAT,
        @relatedCount           INT,
        @activeStatusId         INT,
        @hcsType                INT,
        @servDate               DATETIME,
        @factor					FLOAT,
        @isAutoReceipt			SMALLINT

set  @isAutoReceipt = (SELECT TOP 1 A_AUTO_RECEIPT FROM TMP_PC_NPDMSPCAT WHERE A_PROCESSUUID = @uuid)


SELECT
ROW_NUMBER() OVER(PARTITION BY  A_GROUPHCS, beginDate
						 ORDER BY A_GROUPHCS, beginDate, A_PERIODSTART DESC, ISSUEEXTENSIONSDATE DESC) AS id,
tpn.A_GROUPHCS, docs.A_PERIODSTART, pt.beginDate, docs.ISSUEEXTENSIONSDATE, isnull(docs.A_AMOUNT_PERSON, COUNT( DISTINCT lnk.A_TOID)) AS cnt
INTO #temp
FROM TMP_PC_NPDMSPCAT tpn
	INNER JOIN @periodsTable pt
		ON pt.groupId = tpn.A_GROUPHCS
	LEFT JOIN ESRN_SERV_SERV ess
		ON tpn.A_SERVSERV = ess.OUID
	LEFT JOIN WM_PETITION wp
		ON ISNULL(tpn.A_PETITION, ess.A_REQUEST) = wp.OUID
	LEFT JOIN SPR_LINK_APPEAL_DOC petLnk
		ON petLnk.FROMID = wp.OUID
 	LEFT JOIN WM_ACTDOCUMENTS docs
 		INNER JOIN PPR_DOC pd
 			ON docs.DOCUMENTSTYPE = pd.A_ID AND pd.A_CODE = 'regFlatPersonList'
 				AND (pd.A_STATUS = @activeStatusId OR pd.A_STATUS IS NULL)
 		ON petLnk.TOID = docs.OUID
 		AND (docs.A_STATUS = @activeStatusId OR docs.A_STATUS IS NULL)
 	LEFT JOIN LINK_ACTDOC_PC lnk
 		INNER JOIN WM_PERSONAL_CARD wpc
 			ON wpc.OUID = lnk.A_TOID
 				AND (wpc.A_STATUS = @activeStatusId OR wpc.A_STATUS IS NULL)
 		ON lnk.A_FROMID = docs.OUID
WHERE tpn.A_PROCESSUUID = @uuid AND (docs.A_PERIODSTART <= pt.beginDate
	AND (docs.A_PERIODFINISH >= pt.beginDate OR docs.A_PERIODFINISH IS NULL))
GROUP BY  tpn.A_GROUPHCS, docs.A_PERIODSTART, pt.beginDate, docs.ISSUEEXTENSIONSDATE, docs.A_AMOUNT_PERSON
ORDER BY A_GROUPHCS, beginDate, A_PERIODSTART DESC, ISSUEEXTENSIONSDATE DESC



SELECT DISTINCT gp.A_OUID, gp.A_FROMID, gp.A_TOID, 
		DATEADD(DAY,DATEDIFF(DAY,0,
			case when day(gp.A_DATE_IN) < 15
			then dateadd(day,-day(gp.A_DATE_IN)+1,gp.A_DATE_IN)
			else dateadd(month,1,dateadd(day,-day(gp.A_DATE_IN)+1,gp.A_DATE_IN)) END		
		),0) AS A_DATE_IN,
		DATEADD(DAY,DATEDIFF(DAY,0,
			case when day(gp.A_DATE_OUT) < 15
			then dateadd(day,-day(gp.A_DATE_OUT)+1,gp.A_DATE_OUT)
			else dateadd(month,1,dateadd(day,-day(gp.A_DATE_OUT)+1,gp.A_DATE_OUT)) END
		),0) AS A_DATE_OUT,
		gp.A_STATUS
INTO #WM_GROUPHCS_PERSCARD
FROM TMP_PC_NPDMSPCAT pm
	INNER JOIN WM_GROUPHCS_PERSCARD gptmp
		ON  pm.A_PERSON = gptmp.A_TOID 
	INNER JOIN WM_GROUPHCS_PERSCARD gp
		ON gp.A_FROMID = gptmp.A_FROMID
	INNER JOIN ESRN_SERV_STATUS ess
		ON (gp.A_STATUS = ess.A_ID OR gp.A_STATUS IS null) 
		AND (gptmp.A_STATUS = ess.A_ID OR gptmp.A_STATUS IS null) 
		AND (ess.a_statuscode = 'act')	
WHERE pm.A_PROCESSUUID = @uuid	


/* дерево услуг */
WITH HCS_TREE (A_ID, childOuid, lvl) as (
SELECT A_ID, A_ID, 0 AS lvl FROM SPR_HSC_TYPES ev
WHERE (ev.A_STATUS = 10 OR ev.A_STATUS IS NULL)
UNION ALL
SELECT evTree.A_ID, ev.A_ID, evTree.lvl + 1 FROM SPR_HSC_TYPES ev
INNER JOIN HCS_TREE evTree ON ev.A_PARENT = evTree.childOuid
WHERE (ev.A_STATUS = 10 OR ev.A_STATUS IS NULL)
)
SELECT A_ID, childOuid INTO #HCS_TYPES FROM HCS_TREE




/* Заполняем таблицу квитанций по группам ЖКУ */
INSERT INTO @receiptTable
SELECT distinct gptmp.A_FROMID AS groupId, wr.A_OUID AS rcptId,
 CONVERT(DATETIME, CONVERT(VARCHAR(8), wr.A_PAYMENT_DATE, 112)) AS payDate,
 wra.A_OUID, hs.OUID AS hcs, wra.A_PAY AS pay, 
 ISNULL(CASE WHEN nm.A_NORM IS NULL OR nm.A_NORM = 0 THEN mspLnk.A_NORM ELSE nm.A_NORM END,0) as useNorm,
 wra.A_COMPANY, nm.A_ID AS mspLkNpd
FROM TMP_PC_NPDMSPCAT pm
	INNER JOIN WM_GROUPHCS_PERSCARD gptmp
		ON  pm.A_PERSON = gptmp.A_TOID AND @isAutoReceipt = 1
	INNER JOIN WM_GROUPHCS_PERSCARD gp
		ON gp.A_FROMID = gptmp.A_FROMID
	INNER JOIN WM_RECEIPT wr 
		ON gp.A_TOID = wr.A_PAYER AND wr.A_FACT = 1
	INNER JOIN SPR_RECEIPT_TYPE srt 
		ON wr.A_RECEIPT_TYPE= srt.A_OUID
	INNER JOIN SPR_LINK_MSP_RTYPE mlnRcpt
		ON mlnRcpt.FROMID = pm.A_NPDMSPCAT AND mlnRcpt.TOID = srt.A_OUID
	INNER JOIN WM_HCS hs
		ON hs.A_GRHCS = gptmp.A_FROMID
	INNER JOIN  WM_RECEIPT_AMOUNT wra
		ON wra.A_RECEIPT = wr.A_OUID AND hs.A_HCSTYPE = wra.A_NAME_AMOUNT
		AND hs.A_ORG = wra.A_COMPANY
	INNER JOIN SPR_LINK_NPD_MSP_CAT_HCS mspLnk
		ON mspLnk.FROMID = pm.A_NPDMSPCAT 
    INNER JOIN #HCS_TYPES hcstps
		ON mspLnk.TOID = hcstps.A_ID   		
		AND hcstps.childOuid = wra.A_NAME_AMOUNT
	INNER JOIN SPR_NPD_MSP_CAT nm
		ON nm.A_ID = pm.A_NPDMSPCAT			
	INNER JOIN ESRN_SERV_STATUS ess
		ON (gp.A_STATUS = ess.A_ID OR gp.A_STATUS IS null)
		AND (gptmp.A_STATUS = ess.A_ID OR gptmp.A_STATUS IS null)
		AND (hs.A_STATUS = ess.A_ID OR hs.A_STATUS IS null) 
		AND (wra.A_STATUS = ess.A_ID OR wra.A_STATUS IS null) 
		AND (mspLnk.A_STATUS = ess.A_ID OR mspLnk.A_STATUS IS null) 
		AND (wr.A_STATUS = ess.A_ID OR wr.A_STATUS IS null) 
		AND (srt.A_STATUS = ess.A_ID OR srt.A_STATUS IS null) 
		AND (ess.a_statuscode = 'act')					
WHERE pm.A_PROCESSUUID = @uuid
AND (gp.A_DATE_OUT IS NULL OR  CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112)) <
        CONVERT(DATETIME, CONVERT(VARCHAR(8), pm.A_BEGINDATE, 112)))
		AND (srt.A_CODE LIKE '%hcs%' 
		AND  (wr.A_PAYMENT_DATE >= gp.A_DATE_IN 
		AND (wr.A_PAYMENT_DATE < gp.A_DATE_OUT OR gp.A_DATE_OUT IS NULL)))        
		AND wr.A_PAYMENT_DATE >= pm.A_BEGINDATE
        AND ( (hs.A_START_DATE IS NULL OR
                    	CONVERT(DATETIME, CONVERT(VARCHAR(8), case when day(hs.A_START_DATE) < 15
                    	then dateadd(day,-day(hs.A_START_DATE)+1,hs.A_START_DATE)
						ELSE dateadd(month,1,dateadd(day,-day(hs.A_START_DATE)+1,hs.A_START_DATE))
					  END, 112)) <= CONVERT(DATETIME, CONVERT(VARCHAR(8), dateadd(day,-day(wr.A_PAYMENT_DATE)+1,wr.A_PAYMENT_DATE), 112)))
                    AND 
                    (hs.A_FINISH_DATE IS NULL OR 
							CONVERT(DATETIME, CONVERT(VARCHAR(8), case when day(hs.A_FINISH_DATE) < 15
								 THEN dateadd(day,-day(hs.A_FINISH_DATE),hs.A_FINISH_DATE)
								ELSE dateadd(day,-day(dateadd(month,1,hs.A_FINISH_DATE)),
									 dateadd(month,1,hs.A_FINISH_DATE)) END, 112)) >=  CONVERT(DATETIME, CONVERT(VARCHAR(8), dateadd(day,-day(dateadd(month,1,wr.A_PAYMENT_DATE)),dateadd(month,1,wr.A_PAYMENT_DATE)), 112))
                     ))                      

/* статус активен */
SELECT @activeStatusId = es.A_ID
FROM   ESRN_SERV_STATUS es
WHERE  es.a_statuscode = 'act' 
/* курсор по группам ЖКУ(Группа ЖКУ, ЛЬГОТНИК, ЛЬГОТА) */
DECLARE groupsCur     CURSOR  
FOR
    SELECT DISTINCT gp.A_FROMID AS groupId,
           pm         .A_PERSON AS personId,
           pm         .A_NPDMSPCAT AS npdMspCat
    FROM   TMP_PC_NPDMSPCAT pm
           INNER JOIN #WM_GROUPHCS_PERSCARD gp
                ON  pm.A_PERSON = gp.A_TOID
    WHERE pm.A_PROCESSUUID = @uuid
    AND (gp.A_DATE_OUT IS NULL
           OR  CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112)) <
               CONVERT(DATETIME, CONVERT(VARCHAR(8), pm.A_BEGINDATE, 112)))
    GROUP BY
           gp.A_FROMID,
           pm         .A_PERSON,
           pm         .A_NPDMSPCAT

/* курсор по заявленным  в  группах услугах по периодам */
DECLARE groupWithHCS        CURSOR  
FOR
    SELECT hc.A_GRHCS AS groupId,
           hc.OUID,
           hc.A_HCSTYPE AS hcs,
           pt.beginDate,
           pt.endDate
    FROM   WM_HCS hc
           INNER JOIN @forCalcTable pt
                ON  hc.A_GRHCS = pt.groupId
                AND hc.OUID = pt.hcs
                AND (hc.A_STATUS = @activeStatusId OR hc.A_STATUS IS NULL)
    GROUP BY
           hc.A_GRHCS,
           hc.OUID,
           hc.A_HCSTYPE,
           pt.beginDate,
           pt.endDate  

/* курсор для  расчёта области льготника и причитающихся площадей */
DECLARE resultCursor  CURSOR  
FOR
    SELECT DISTINCT rt.resId AS resId,
           dp         .groupId AS groupHCS,
           rt         .personId AS personId,
           rt         .npdMspCat AS npdMspCat,
           rt         .hcs AS hcs,
           rt         .combination AS combination,
           dp         .cPercent AS calcPercent,
           dp         .areaOfDistr AS areaOfDistr,
           dp         .calcType AS calcType,
           dp         .norm AS isNorm,
           fc         .A_TOTAL_SQUARE AS totalSquare,
           fc         .A_HEATED_SQUARE AS heatedSquare,
           ha         .A_VALUE AS norma,
           dp         .tarif AS tarif,
           dp         .usePortion AS usePortion,
           dp         .useNorm AS useNorm,
           dp         .beginDate AS beginDate,
           dp         .endDate AS endDate,
           dp         .allPersons AS persons,
           dp         .algId AS algId
    FROM   @resTable rt
           INNER JOIN TMP_PC_NPDMSPCAT pn
           ON  (rt.npdMspCat = pn.A_NPDMSPCAT AND rt.personId = pn.A_PERSON)
           AND pn.A_PROCESSUUID = @uuid
           INNER JOIN @forCalcTable dp
                ON  (pn.A_ID = dp.relation AND rt.hcs = dp.hcs
					AND rt.beginDate = dp.beginDate 
					AND (rt.endDate = dp.endDate OR (rt.endDate IS NULL AND dp.endDate IS NULL)))  
           INNER JOIN WM_HCS hs
                ON  (dp.hcs = hs.OUID)
                AND (hs.A_STATUS = @activeStatusId OR hs.A_STATUS IS NULL)
           LEFT JOIN WM_FLAT_CONDITION fc
                ON  dp.groupId = fc.A_GROUP_HCS
                AND (fc.A_STATUS = @activeStatusId OR fc.A_STATUS IS NULL)
           LEFT JOIN SPR_HCSNORM hn
				ON hs.A_NORM = hn.A_OUID
           LEFT JOIN SPR_HCS_NORM_AM ha
                ON  hn.A_OUID = ha.A_HCS_TYPE
                AND (ha.A_STATUS = @activeStatusId OR ha.A_STATUS IS NULL)
                AND (ha.A_NUMPEOPLE = (SELECT MAX(h.A_NUMPEOPLE)
                                      FROM   SPR_HCS_NORM_AM h
                                      WHERE  dp.allPersons >= h.A_NUMPEOPLE
                                             AND (h.A_STATUS = @activeStatusId OR h.A_STATUS IS NULL)
                                             AND h.A_HCS_TYPE = ha.A_HCS_TYPE
                                      GROUP BY
                                             h.A_HCS_TYPE) OR ha.A_NUMPEOPLE IS NULL)
                AND DATEADD(DAY,DATEDIFF(DAY,0,ha.A_START_DATE),0) <= dp.beginDate
    WHERE  dp.calcType IS NOT NULL
--            AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), hs.A_START_DATE, 112)) 
--                 <= pn.A_BEGINDATE)
--            AND (hs.A_FINISH_DATE IS NULL
--                 OR CONVERT(DATETIME, CONVERT(VARCHAR(8), hs.A_FINISH_DATE, 112)) 
--                    > pn.A_BEGINDATE)
           AND (ha.A_OUID IS NULL
                OR ((ha.A_STATUS = @activeStatusId OR ha.A_STATUS IS NULL)
                    AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), ha.A_START_DATE, 112)) 
                         <= dp.beginDate)
                    AND NOT EXISTS (SELECT 1
                                    FROM   SPR_HCS_NORM_AM hq
                                    WHERE  hq.A_HCS_TYPE = ha.A_HCS_TYPE
                                           AND (hq.A_NUMPEOPLE = ha.A_NUMPEOPLE OR (hq.A_NUMPEOPLE IS NULL AND ha.A_NUMPEOPLE IS NULL))
                                           AND (hq.A_ROOM_NUMBER = ha.A_ROOM_NUMBER OR (hq.A_ROOM_NUMBER IS NULL AND ha.A_ROOM_NUMBER IS NULL))
                                           AND CONVERT(DATETIME, CONVERT(VARCHAR(8), hq.A_START_DATE, 112)) 
                                               <= pn.A_BEGINDATE
                                           AND hq.A_START_DATE > ha.A_START_DATE
                                           AND (hq.A_STATUS = @activeStatusId OR hq.A_STATUS IS NULL))))
               /* номера комнат */
               
               
           AND (fc.A_OUID IS NULL
                OR (CONVERT(DATETIME, CONVERT(VARCHAR(8), dateadd(day,-day(fc.A_START_DATE)+1,fc.A_START_DATE), 112)) 
                    <= pn.A_BEGINDATE
                     AND NOT EXISTS (SELECT *
                                     FROM   WM_FLAT_CONDITION fq
                                     WHERE  (dateadd(day,-day(fq.A_START_DATE)+1,fq.A_START_DATE) > dateadd(day,-day(fc.A_START_DATE)+1,fc.A_START_DATE)
                                             AND CONVERT(DATETIME, CONVERT(VARCHAR(8), dateadd(day,-day(fq.A_START_DATE)+1,fq.A_START_DATE), 112)) 
                                                 <= pn.A_BEGINDATE
                                             AND fq.A_GROUP_HCS = fc.A_GROUP_HCS
                                             AND (fq.A_STATUS = @activeStatusId OR fq.A_STATUS IS NULL)))))
/*           
                OR (CONVERT(DATETIME, CONVERT(VARCHAR(8), fc.A_START_DATE, 112)) 
                    <= pn.A_BEGINDATE
                    AND NOT EXISTS (SELECT *
                                    FROM   WM_FLAT_CONDITION fq
                                    WHERE  (fq.A_START_DATE > fc.A_START_DATE
                                            AND CONVERT(DATETIME, CONVERT(VARCHAR(8), fq.A_START_DATE, 112)) 
                                                <= pn.A_BEGINDATE
                                            AND fq.A_GROUP_HCS = fc.A_GROUP_HCS
                                            AND (fq.A_STATUS = @activeStatusId OR fq.A_STATUS IS NULL)))))
           AND (fc.A_ROOM IS NOT NULL
                AND ha.A_ROOM_NUMBER = (SELECT MAX(h.A_ROOM_NUMBER) room
                                        FROM   SPR_HCS_NORM_AM h
                                        WHERE  fc.A_ROOM >= h.A_ROOM_NUMBER
                                               AND h.A_HCS_TYPE = ha.A_HCS_TYPE
                                               AND h.A_NUMPEOPLE = ha.A_NUMPEOPLE
                                        GROUP BY
                                               h.A_HCS_TYPE)
                OR (fc.A_ROOM IS NULL
                    AND ha.A_ROOM_NUMBER = (SELECT MIN(h.A_ROOM_NUMBER) room
                                            FROM   SPR_HCS_NORM_AM h
                                            WHERE  h.A_HCS_TYPE = ha.A_HCS_TYPE
                                                   AND h.A_NUMPEOPLE = ha.A_NUMPEOPLE
                                            GROUP BY
                                                   h.A_HCS_TYPE))) */
                                                   
           AND (fc.A_ROOM IS NOT NULL
                AND (ha.A_ROOM_NUMBER = (SELECT MAX(h.A_ROOM_NUMBER) room
                                        FROM   SPR_HCS_NORM_AM h
                                        WHERE  fc.A_ROOM >= h.A_ROOM_NUMBER
                                               AND h.A_HCS_TYPE = ha.A_HCS_TYPE
                                               AND (h.A_NUMPEOPLE = ha.A_NUMPEOPLE OR (h.A_NUMPEOPLE IS NULL AND ha.A_NUMPEOPLE IS NULL))
                                        GROUP BY
                                               h.A_HCS_TYPE) OR ha.A_ROOM_NUMBER IS NULL)
                OR (fc.A_ROOM IS NULL
                    AND (ha.A_ROOM_NUMBER = (SELECT MIN(h.A_ROOM_NUMBER) room
                                            FROM   SPR_HCS_NORM_AM h
                                            WHERE  h.A_HCS_TYPE = ha.A_HCS_TYPE
                                                   AND (h.A_NUMPEOPLE = ha.A_NUMPEOPLE OR (h.A_NUMPEOPLE IS NULL AND ha.A_NUMPEOPLE IS NULL))
                                            GROUP BY
                                                   h.A_HCS_TYPE) OR ha.A_ROOM_NUMBER IS NULL ) ))                                                   
                                                   
    ORDER BY
           rt.combination,
           rt         .hcs,
           dp         .cPercent DESC,
           dp         .areaOfDistr 
 
  /* заполнение временной таблицы с периодами для перерасчёта назначений */
  INSERT INTO @periodsTable (groupId,beginDate,endDate)
  select distinct sq.groupId, case when day(sq.startDate) > 15 then DATEADD(month, 1, convert(datetime,substring(convert(varchar(8), sq.startDate, 112),1,6) + '01')) else convert(datetime,substring(convert(varchar(8), sq.startDate, 112),1,6) + '01') end as beginDate, 
  case when day(sq.finDate) > 15 then DATEADD(month, 1, convert(datetime,substring(convert(varchar(8), sq.finDate, 112),1,6) + '01')) else convert(datetime,substring(convert(varchar(8), sq.finDate, 112),1,6) + '01') end as endDate from (
  /* Диапазоны по тарифам */
  select hs.A_GRHCS as groupId, sp.a_start_date as startDate, sp.a_fin_date as finDate from SPR_TARIF_PERIOD sp
  INNER JOIN SPR_TARIF st on sp.A_SERV = st.OUID  
  INNER JOIN WM_HCS hs on st.OUID = hs.A_LNK_TARIF 
  INNER JOIN (SELECT gp.A_FROMID as groupId, pn.A_BEGINDATE as beginDate, pn.A_ENDDATE as endDate 
              FROM TMP_PC_NPDMSPCAT pn
              INNER JOIN #WM_GROUPHCS_PERSCARD gp on pn.A_PERSON = gp.A_TOID
              WHERE pn.A_PROCESSUUID = @uuid 
              AND (gp.A_DATE_IN <= pn.A_BEGINDATE and (gp.A_DATE_OUT is null or gp.A_DATE_OUT > pn.A_BEGINDATE))
              GROUP BY gp.A_FROMID, pn.A_BEGINDATE, pn.A_ENDDATE) mt on hs.A_GRHCS = mt.groupId
  where (sp.A_STATUS = @activeStatusId OR sp.A_STATUS IS NULL )AND ((mt.beginDate <= sp.a_start_date and (mt.endDate <= sp.a_start_date or mt.endDate is null)) or (mt.beginDate <= sp.a_fin_date and (mt.endDate <= sp.a_fin_date or mt.endDate is null))) 
	AND hs.A_HCSTYPE IN (
			SELECT distinct hcstps.childOuid
			FROM TMP_PC_NPDMSPCAT tm
			INNER JOIN SPR_LINK_NPD_MSP_CAT_HCS lnk
			ON tm.A_NPDMSPCAT = lnk.FROMID
			INNER JOIN #HCS_TYPES hcstps
					ON lnk.TOID = hcstps.A_ID   
                        WHERE tm.A_PROCESSUUID = @uuid)	    
  /* Диапазоны по нормативам */
  union
  select hs.A_GRHCS as groupId, hn.a_start_date as startDate, null as finDate from SPR_HCS_NORM_AM hn
  INNER JOIN SPR_HCSNORM sn on hn.A_HCS_TYPE = sn.A_OUID
  INNER JOIN WM_HCS hs on sn.A_OUID = hs.A_NORM
  INNER JOIN (SELECT gp.A_FROMID as groupId, pn.A_BEGINDATE as beginDate, pn.A_ENDDATE as endDate 
              FROM TMP_PC_NPDMSPCAT pn
              INNER JOIN #WM_GROUPHCS_PERSCARD gp on pn.A_PERSON = gp.A_TOID
              WHERE pn.A_PROCESSUUID = @uuid
              AND (gp.A_DATE_IN <= pn.A_BEGINDATE and (gp.A_DATE_OUT is null or gp.A_DATE_OUT > pn.A_BEGINDATE))
              GROUP BY gp.A_FROMID, pn.A_BEGINDATE, pn.A_ENDDATE) mt on hs.A_GRHCS = mt.groupId
  where (mt.beginDate <= hn.a_start_date and (mt.endDate <= hn.a_start_date or mt.endDate is null)) 
  /* Диапазоны по членам группы*/
  union
  select hs.A_GRHCS as groupId, gp.a_date_in as startDate, gp.a_date_out as finDate from #WM_GROUPHCS_PERSCARD gp
  INNER JOIN WM_HCS hs on gp.A_FROMID = hs.A_GRHCS
  INNER JOIN (SELECT gp.A_FROMID as groupId, pn.A_BEGINDATE as beginDate, pn.A_ENDDATE as endDate 
              FROM TMP_PC_NPDMSPCAT pn
              INNER JOIN #WM_GROUPHCS_PERSCARD gp on pn.A_PERSON = gp.A_TOID
              WHERE pn.A_PROCESSUUID = @uuid
              AND (gp.A_DATE_IN <= pn.A_BEGINDATE and (gp.A_DATE_OUT is null or gp.A_DATE_OUT > pn.A_BEGINDATE))
              GROUP BY gp.A_FROMID, pn.A_BEGINDATE, pn.A_ENDDATE) mt on hs.A_GRHCS = mt.groupId
  where (mt.beginDate <= gp.a_date_in) or (mt.beginDate <= gp.a_date_out and (mt.endDate <= gp.a_date_out or mt.endDate is null)) 
  /* Диапазоны по соц. нормативам */
  union
  select hs.A_GRHCS as groupId, ss.A_BDATE as  startDate, ss.A_EDATE as finDate FROM WM_HCS hs
  INNER JOIN SPR_TARIF st on hs.A_LNK_TARIF  = st.OUID
  INNER JOIN PPR_CALC_ALGORITHM  ca on (st.A_CALC_TYPE = ca.A_ID and (ca.A_STATUS = @activeStatusId or ca.A_STATUS is null))
  INNER JOIN (SELECT gp.A_FROMID as groupId, pn.A_BEGINDATE as beginDate, pn.A_ENDDATE as endDate 
              FROM TMP_PC_NPDMSPCAT pn
              INNER JOIN #WM_GROUPHCS_PERSCARD gp on pn.A_PERSON = gp.A_TOID
              WHERE pn.A_PROCESSUUID = @uuid
              AND (gp.A_DATE_IN <= pn.A_BEGINDATE and (gp.A_DATE_OUT is null or gp.A_DATE_OUT > pn.A_BEGINDATE))
              GROUP BY gp.A_FROMID, pn.A_BEGINDATE, pn.A_ENDDATE) mt on hs.A_GRHCS = mt.groupId
  INNER JOIN SPR_SOCNORM ss on (mt.beginDate <=  ss.A_BDATE and (mt.endDate <=  ss.A_BDATE or mt.endDate is null)) or ((mt.beginDate <= ss.A_EDATE and (mt.endDate <= ss.A_EDATE or mt.endDate is null))) 
  where ca.A_CODE like 'area%' or ca.A_CODE like 'heat%'
  /* Диапазоны по предоставлению услуг */
  union  
  select hs.A_GRHCS as groupId, hs.A_START_DATE as bDate, hs.A_FINISH_DATE as eDate FROM WM_HCS hs
  INNER JOIN (SELECT gp.A_FROMID as groupId, pn.A_BEGINDATE as beginDate, pn.A_ENDDATE as endDate 
              FROM TMP_PC_NPDMSPCAT pn
              INNER JOIN #WM_GROUPHCS_PERSCARD gp on pn.A_PERSON = gp.A_TOID
              WHERE pn.A_PROCESSUUID = @uuid
              AND (gp.A_DATE_IN <= pn.A_BEGINDATE and (gp.A_DATE_OUT is null or gp.A_DATE_OUT > pn.A_BEGINDATE))
              GROUP BY gp.A_FROMID, pn.A_BEGINDATE, pn.A_ENDDATE) mt on hs.A_GRHCS = mt.groupId
  where (mt.beginDate <= hs.a_start_date and (mt.endDate <= hs.a_start_date or mt.endDate is null)) or (mt.beginDate <= hs.a_finish_date and (mt.endDate <= hs.a_finish_date or mt.endDate is null))
  /* Диапазоны по иждевенцам (иждевенцев пересчитываем всегда) */ 
  union
  SELECT pn.A_GROUPHCS, pn.A_BEGINDATE, pn.A_ENDDATE 
  FROM TMP_PC_NPDMSPCAT pn
  INNER JOIN #WM_GROUPHCS_PERSCARD gp on pn.A_PERSON = gp.A_TOID 
  INNER JOIN WM_HCS hc on gp.A_FROMID = hc.A_GRHCS and (hc.A_STATUS = @activeStatusId or hc.A_STATUS is null)
  INNER JOIN SPR_NPD_MSP_CAT nm ON pn.A_NPDMSPCAT = nm.A_ID
  INNER JOIN SPR_LINK_NPD_MSP_CAT_HCS lh ON pn.A_NPDMSPCAT = lh.FROMID
  INNER JOIN #HCS_TYPES hcstps	ON lh.TOID = hcstps.A_ID and hc.A_HCSTYPE = hcstps.childOuid
  WHERE pn.A_PROCESSUUID = @uuid 
  AND'dependent' = isNull(nm.A_SPHERE, lh.A_HCV_AREA_OF_DISTRIB) 
  AND (gp.A_DATE_IN <= pn.A_BEGINDATE and (gp.A_DATE_OUT is null or gp.A_DATE_OUT > pn.A_BEGINDATE))
  UNION
  SELECT distinct groupId, dateadd(day,-day(payDate)+1,payDate), dateadd(month,1,dateadd(day,-day(payDate)+1,payDate))  FROM @receiptTable     
  /* изменение жилищных условий */
  UNION 
  select fc.A_GROUP_HCS as groupId, fc.a_start_date as startDate, null as finDate
  from WM_FLAT_CONDITION fc
  INNER JOIN (SELECT gp.A_FROMID as groupId, pn.A_BEGINDATE as beginDate, pn.A_ENDDATE as endDate 
              FROM TMP_PC_NPDMSPCAT pn
              INNER JOIN #WM_GROUPHCS_PERSCARD gp on pn.A_PERSON = gp.A_TOID
              WHERE pn.A_PROCESSUUID = @uuid
              AND (gp.A_DATE_IN <= pn.A_BEGINDATE and (gp.A_DATE_OUT is null or gp.A_DATE_OUT > pn.A_BEGINDATE))
              GROUP BY gp.A_FROMID, pn.A_BEGINDATE, pn.A_ENDDATE) mt on fc.A_GROUP_HCS = mt.groupId
  where (mt.beginDate <= fc.a_start_date and (mt.endDate <= fc.a_start_date or mt.endDate is null))   
  ) sq      

/* Проверяем наличие изменений. Если нет, то кидаем ошибку и прекращаем работу алгоритма */           
IF NOT EXISTS (SELECT 1 FROM @periodsTable) 
BEGIN 
	DROP TABLE #WM_GROUPHCS_PERSCARD
	DEALLOCATE groupsCur
	DEALLOCATE groupWithHCS
	DEALLOCATE resultCursor
  	
	SELECT 1 AS CODE, 'Не найдено изменений в тарифах, нормативах, услугах и членах группы ЖКУ с даты перерасчёта' AS MSG
  RETURN  
END          
  

/* Выстраиваем точки изменения периодов в ряд. Одним запросом не реально, так что пришлось разбить на две операции */
INSERT INTO @periodsAgrTable(
    groupId,
    perDate)
SELECT sq.groupId,
       sq.perDate
FROM   (SELECT groupId,
               beginDate AS perDate
        FROM   @periodsTable pt
        UNION
        SELECT groupId,
               endDate AS perDate
        FROM   @periodsTable pt) sq
       INNER JOIN #WM_GROUPHCS_PERSCARD gp
            ON  sq.groupId = gp.A_FROMID
       INNER JOIN TMP_PC_NPDMSPCAT pn
       ON gp.A_TOID = pn.A_PERSON
       AND pn.A_PROCESSUUID = @uuid
WHERE  sq.perDate >= pn.A_BEGINDATE
       AND (pn.A_ENDDATE IS NULL OR sq.perDate < pn.A_ENDDATE)
GROUP BY
       sq.groupId,
       sq.perDate

/* теперь создаём красивые периоды, в рамках которых и будет вестись перерасчёт назначений*/
DELETE 
FROM   @periodsTable

INSERT INTO @periodsTable(
    groupId,
    beginDate,
    endDate)
SELECT groupId,
       perDate AS beginDate,
       (SELECT TOP(1) (perDate - 1) AS endDate
        FROM   @periodsAgrTable pa
        WHERE  pt.groupId = pa.groupId
               AND pt.perDate < pa.perDate
        ORDER BY
               pa.perDate) AS endDate
FROM   @periodsAgrTable pt
ORDER BY
       groupId,
       perDate


/* заполняем временную таблицу для промежуточных рассчётов */
INSERT INTO @forCalcTable(
    groupId,
    relation,
    hcs,
    areaOfDistr,
    cPercent,
    calcType,
    norm,
    tarif,
    usePortion,
    useNorm,
    algId,
    beginDate,
    endDate,
    allPersons)
SELECT tt.groupId,
       tt.relation,
       tt.hcs,
       tt.areaOfDistr,
       tt.hcvPercent AS hcvPercent,
       tt.calcType AS calcType,
       tt.norm AS norm,
       tt.tarif AS tarif,
       tt.usePortion AS usePortion,
       tt.useNorm AS useNorm,
       tt.algId AS algId,
       tt.beginDate AS beginDate,
       tt.endDate AS endDate,
       tt.persons AS allPersons
FROM   (SELECT DISTINCT wp.A_FROMID AS groupId,
               pm.A_ID AS relation,
               hs.OUID AS hcs,
               ISNULL(nm.A_SPHERE, lh.A_HCV_AREA_OF_DISTRIB) AS areaOfDistr,
               ISNULL(CASE WHEN nm.A_PORTION IS NULL OR nm.A_PORTION = 0 THEN lh.A_PORTION ELSE nm.A_PORTION END,0) usePortion,
               ISNULL(CASE WHEN nm.A_SOC_NORM IS NULL OR nm.A_SOC_NORM = 0 THEN lh.A_SOC_NORM ELSE nm.A_SOC_NORM END,0) useNorm,
--               nm.A_PORTION usePortion,
--               nm.A_NORM useNorm,
               lh.A_HCV_RATE AS hcvPercent,
               ca.A_CODE calcType,
               lh.A_NORM AS norm,
               sp.A_AMOUNT AS tarif,
               ca.A_ID AS algId,
               pt.beginDate AS beginDate,
               pt.endDate AS endDate,
               ga.persons AS persons
        FROM   TMP_PC_NPDMSPCAT pm
               INNER JOIN SPR_NPD_MSP_CAT nm
                    ON  pm.A_NPDMSPCAT = nm.A_ID
               INNER JOIN #WM_GROUPHCS_PERSCARD wp
                    ON  pm.A_PERSON = wp.A_TOID
               INNER JOIN WM_HCS hs
                    ON  (wp.A_FROMID = hs.A_GRHCS
                         AND (hs.A_STATUS = @activeStatusId OR hs.A_STATUS IS NULL))
               INNER JOIN @periodsTable pt
                    ON  hs.A_GRHCS = pt.groupId
                    AND ( (hs.A_START_DATE IS NULL OR
                    	CONVERT(DATETIME, CONVERT(VARCHAR(8), case when day(hs.A_START_DATE) < 15
                    	then dateadd(day,-day(hs.A_START_DATE)+1,hs.A_START_DATE)
						ELSE dateadd(month,1,dateadd(day,-day(hs.A_START_DATE)+1,hs.A_START_DATE))
					  END, 112)) <= pt.beginDate)
                    AND 
                    (hs.A_FINISH_DATE IS NULL OR 
							CONVERT(DATETIME, CONVERT(VARCHAR(8), case when day(hs.A_FINISH_DATE) < 15
								 THEN dateadd(day,-day(hs.A_FINISH_DATE),hs.A_FINISH_DATE)
								ELSE dateadd(day,-day(dateadd(month,1,hs.A_FINISH_DATE)),
									 dateadd(month,1,hs.A_FINISH_DATE)) END, 112)) >= pt.endDate
                     ))                      
                    
                        /* добавляем внутреннюю агрегацию с кол-вом человек и с датами периода*/
               INNER JOIN (
               
					SELECT x.groupId, ISNULL(CASE WHEN t.cnt = 0 THEN NULL ELSE t.cnt END, x.persons) as persons, x.beginDate, x.endDate
						FROM 
               		(SELECT pt.groupId AS groupId,
                                  COUNT(gp.A_TOID) AS persons,
                                  pt.beginDate AS beginDate,
                                  pt.endDate AS endDate
                           FROM   @periodsTable pt
                                  INNER JOIN #WM_GROUPHCS_PERSCARD gp
                                       ON  pt.groupId = gp.A_FROMID
                                       AND (gp.A_STATUS = @activeStatusId OR gp.A_STATUS IS NULL)
                           WHERE  ((gp.A_DATE_OUT IS NULL
                                   OR CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112)) 
                                      > CONVERT(DATETIME, CONVERT(VARCHAR(8), pt.beginDate, 112)))
                                   AND (gp.A_DATE_IN IS NULL
                                        OR CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_IN, 112)) 
                                           <= CONVERT(DATETIME, CONVERT(VARCHAR(8), pt.beginDate, 112))))
                           GROUP BY
                                  pt.groupId,
                                  pt.beginDate,
                                  pt.endDate) x
                         LEFT JOIN  #temp t
							ON t.A_GROUPHCS = x.groupId AND t.id = 1 AND t.beginDate = @beginDate        
               
               ) ga
                    ON  hs.A_GRHCS = ga.groupId
						AND ga.beginDate = pt.beginDate 
						AND (ga.endDate = pt.endDate OR (ga.endDate IS NULL AND pt.endDate IS NULL))                     
               INNER JOIN SPR_LINK_NPD_MSP_CAT_HCS lh
                    ON  (nm.A_ID = lh.FROMID )
               INNER JOIN #HCS_TYPES hcstps
					ON lh.TOID = hcstps.A_ID AND hs.A_HCSTYPE = hcstps.childOuid                      
               INNER JOIN SPR_TARIF st
                    ON  hs.A_LNK_TARIF = st.OUID
               INNER JOIN PPR_CALC_ALGORITHM ca
                    ON  (st.A_CALC_TYPE = ca.A_ID
                         AND (ca.A_STATUS = @activeStatusId OR ca.A_STATUS IS NULL))
               INNER JOIN SPR_TARIF_PERIOD sp
                    ON  (st.OUID = sp.A_SERV
                         AND (sp.A_STATUS IS NULL OR sp.A_STATUS = @activeStatusId)
                         AND (sp.A_FIN_DATE IS NULL OR sp.A_FIN_DATE > pt.beginDate)
                         AND (DATEADD(DAY,DATEDIFF(DAY,0,sp.A_START_DATE),0) < pt.endDate OR pt.endDate IS NULL))
               WHERE pm.A_PROCESSUUID = @uuid) tt
GROUP BY
       tt.groupId,
       tt.relation,
       tt.hcs,
       tt.hcvPercent,
       tt.areaOfDistr,
       tt.calcType,
       tt.norm,
       tt.tarif,
       tt.usePortion,
       tt.useNorm,
       tt.algId,
       tt.beginDate,
       tt.endDate,
       tt.persons

SELECT DISTINCT tm.A_NPDMSPCAT, fc.hcs, fc.cPercent, ps.A_NAME AS MSP , pc.A_NAME AS LK, pna.A_NAME AS NPD
INTO #badMspLkNpd
FROM @forCalcTable fc
	INNER JOIN TMP_PC_NPDMSPCAT tm
	ON fc.relation = tm.A_ID
        AND tm.A_PROCESSUUID = @uuid
	INNER JOIN SPR_NPD_MSP_CAT snmc
		ON 	tm.A_NPDMSPCAT = snmc.A_ID 
	INNER JOIN PPR_SERV ps
		ON 	snmc.A_MSP = ps.A_ID
	LEFT JOIN PPR_CAT pc
		ON snmc.A_CATEGORY = pc.A_ID
	LEFT JOIN PPR_NPD_ARTICLE pna
		ON snmc.A_DOC = pna.A_ID
WHERE areaOfDistr IS NULL OR cPercent IS NULL OR cPercent <= 0 

IF EXISTS (SELECT 1 FROM #badMspLkNpd) BEGIN
	DROP TABLE #WM_GROUPHCS_PERSCARD
	DEALLOCATE groupsCur
	DEALLOCATE groupWithHCS
	DEALLOCATE resultCursor
	
	DECLARE @msg VARCHAR(2048)
	SELECT DISTINCT @msg = '"' + MSP + '" на основании ЛК "' + LK + '" и НПД "' + NPD + '"'
	FROM #badMspLkNpd

	DROP TABLE #badMspLkNpd
	SELECT 2 AS CODE, 'Ошибка в настройках МСП по основанию. Проверьте, что настроены все необходимые параметры (Размер компенсации, область распространения по услугам) в следущих связках: ' + @msg AS MSG
    RETURN  
END    

DROP TABLE #badMspLkNpd  


/* вытаскиваем данные по нельготникам (по периодам) во временную таблицу ибо они будут нужны по нескольким запросам */
INSERT INTO @persTable(
    groupId,
    personId,
    dateIn,
    dateOut)
SELECT gp.A_FROMID AS groupId,
       gp.A_TOID AS personId,
       td.beginDate AS dateIn,
       td.endDate AS dateOut
FROM   #WM_GROUPHCS_PERSCARD gp
       INNER JOIN WM_PERSONAL_CARD wp
            ON  (gp.A_TOID = wp.OUID
                 AND (wp.A_STATUS = @activeStatusId OR wp.A_STATUS IS NULL)
                 AND (wp.A_PCSTATUS = 1 OR wp.A_PCSTATUS IS NULL))
       INNER JOIN @forCalcTable td
            ON  gp.A_FROMID = td.groupId
WHERE  NOT EXISTS (SELECT A_ID
                   FROM TMP_PC_NPDMSPCAT pp
                   WHERE pp.A_PERSON = wp.OUID
                   AND pp.A_PROCESSUUID = @uuid)
          AND (
          	(CONVERT(VARCHAR(8), gp.A_DATE_IN, 112) <= CONVERT(VARCHAR(8), td.beginDate, 112))
          	AND (CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112) > CONVERT(VARCHAR(8), td.beginDate, 112)
          		OR gp.A_DATE_OUT IS NULL --OR td.endDate IS NULL
          	)
          )                     
--        AND (gp.A_DATE_OUT IS NULL
--             OR (CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112) > CONVERT(VARCHAR(8), td.beginDate, 112))
--             AND (CONVERT(VARCHAR(8), gp.A_DATE_IN, 112) <= CONVERT(VARCHAR(8), td.beginDate, 112)))
GROUP BY
       gp.A_FROMID,
       gp.A_TOID,
       td.beginDate,
       td.endDate
       
/* анализируем периоды назначения */
SET @needTotalSquare = NULL
SET @heatedSquare = NULL
SET @area = NULL
OPEN groupsCur

/* идём по группам, льготникам МСП-ЛК-НПД */
FETCH NEXT FROM groupsCur INTO @groupId,@personId,@npdMspCat
SET @combination = 0
WHILE @@FETCH_STATUS = 0
BEGIN
    /* Если изменилась группа ЖКУ, то сдвигаем позицию... */
    IF (@oldGroupId <> @groupId)
       OR @oldGroupId IS NULL
    BEGIN
        DELETE 
        FROM   @tmpGroupTable
        WHERE  position = (@position - 1)
               AND groupId = @oldGroupId
        
        SET @position = 1
        SET @oldGroupId = @groupId
        SET @oldPersonId = @personId
    END
    /*  Если изменился льготник, то меняем позицию */
    IF (@oldPersonId <> @personId)
    BEGIN
        DELETE 
        FROM   @tmpGroupTable
        WHERE  position = (@position - 1)
               AND groupId = @groupId
        
        SET @position = @position + 1
        SET @oldPersonId = @personId
    END
    /* курсор по комбинациям */
    DECLARE tmpCursor     CURSOR  
    FOR
        SELECT groupId,
               variant,
               position,
               variantId  
        FROM   @tmpGroupTable
        WHERE  position = @position -1
               AND groupId = @groupId
        ORDER BY
               groupId,
               variant    
    
    OPEN tmpCursor 
    FETCH NEXT FROM tmpCursor INTO @groupHCS, @variant, @posFromTable, @variantId                                                                              
    IF @@FETCH_STATUS <> 0
    BEGIN
        SET @combination = @combination + 1
        SET @preparedVariant = CONVERT(VARCHAR(10), @personId) + ':' + CONVERT(VARCHAR(10), @npdMspCat)
        INSERT INTO @tmpGroupTable(
            groupId,
            variant,
            position,
            variantId)
        VALUES(
            @groupId,
            @preparedVariant,
            @position,
            @combination)
    END
    ELSE
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @combination = @combination + 1
            SET @preparedVariant = @variant + ',' + CONVERT(VARCHAR(10), @personId) 
                + ':' + CONVERT(VARCHAR(10), @npdMspCat)
            
            INSERT INTO @tmpGroupTable(
                groupId,
                variant,
                position,
                variantId)
            VALUES(
                @groupId,
                @preparedVariant,
                @position,
                @combination)
            FETCH NEXT FROM tmpCursor INTO @groupHCS, @variant, @posFromTable, @variantId
        END
    
    CLOSE tmpCursor
    DEALLOCATE tmpCursor
    FETCH NEXT FROM groupsCur INTO @groupId, @personId, @npdMspCat
END
DELETE 
FROM   @tmpGroupTable
WHERE  position = (@position - 1)
       AND groupId = @oldGroupId
 
CLOSE groupsCur


/* парсим полученные комбинации, добавляем в них услуги и проценты */
/* идём по курсору с услугами для групп */
OPEN groupWithHCS /* услуги в группе */
FETCH NEXT FROM groupWithHCS INTO @groupId, @hcs, @hcsType, @beginDate, @endDate
WHILE @@FETCH_STATUS = 0
BEGIN
    DECLARE tmpCursor     CURSOR  
    FOR
        SELECT groupId,
               variant,
               position,
               variantId  
        FROM   @tmpGroupTable
        WHERE  groupId = @groupId
    
    OPEN tmpCursor 
    /* идём по курсорe с МСП-ЛК-НПД */
    FETCH NEXT FROM tmpCursor INTO @groupHCS, @variant, @position, @combination                                                                              
    WHILE @@FETCH_STATUS = 0
    BEGIN
        /* разбиваем */
        WHILE @variant != ''
        BEGIN
            SET @pos = CHARINDEX(',', @variant)
            /* вынимаем ЛЬГОТНИК:МСП-ЛК-НПД */
            SET @toVar = RTRIM(SUBSTRING(@variant, 0, @pos))
            /* удаляем вытащенное */
            SET @variant = LTRIM(SUBSTRING(@variant, @pos + 1, LEN(@variant)))
            /* для последней итерации */
            IF @toVar = ''
            BEGIN
                SET @toVar = @variant;
                SET @variant = '';
            END
            
            SET @pos2 = CHARINDEX(':', @toVar)
            /* ЛЬГОТНИК */
            SET @personId = CONVERT(INT, LEFT(@toVar, @pos2 -1))
            /* МСП-ЛК-НПД */
            SET @npdMspCat = CONVERT(INT, RIGHT(@toVar, LEN(@toVar) - @pos2))
            IF EXISTS (SELECT lh.A_OUID
                       FROM   SPR_LINK_NPD_MSP_CAT_HCS lh
								INNER JOIN #HCS_TYPES hcstps
									ON lh.TOID = hcstps.A_ID       
                       WHERE  lh.FROMID = @npdMspCat
                              AND hcstps.childOuid = @hcsType
                              AND (lh.A_STATUS IS NULL OR lh.A_STATUS = @activeStatusId) )

            BEGIN
                INSERT INTO @resTable(
                    groupId,
                    personId,
                    npdMspCat,
                    hcs,
                    combination,
                    cPercent,
                    calcType,
                    totalSquare,
                    heatedSquare,
                    tarif,
                    beginDate,
                    endDate)
                VALUES(
                    @groupId,
                    @personId,
                    @npdMspCat,
                    @hcs,
                    @combination,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    @beginDate,
                    @endDate)
            END
        END
        FETCH NEXT FROM tmpCursor INTO @groupHCS, @variant, @position, @combination
    END 
    CLOSE tmpCursor
    DEALLOCATE tmpCursor
    FETCH NEXT FROM groupWithHCS INTO @groupId, @hcs, @hcsType, @beginDate, @endDate
END
CLOSE groupWithHCS
	/* считаем одинаковый процент в комбинациях (для распределения площадей и людей )*/

/*
BEGIN

	INSERT INTO @sameTable(
	    groupId,
	    combination,
	    hcs,
	    cPercent,
	    sameCounter)
	SELECT tt.groupId,
	       tt.combination,
	       tt.hcs,
	       tt.cPercent,
	       COUNT(personId)
	FROM   (SELECT DISTINCT rt.groupId,
	               rt.combination,
	               dp.hcs,
	               dp.cPercent,
	               rt.personId
	        FROM   @resTable rt
	               INNER JOIN TMP_PC_NPDMSPCAT pn
	               ON rt.npdMspCat = pn.A_NPDMSPCAT 
                       AND rt.personId = pn.A_PERSON
                       AND pn.A_PROCESSUUID = @uuid
	               INNER JOIN @forCalcTable dp
	               ON pn.A_ID = dp.relation 
                       AND rt.hcs = dp.hcs) tt
	GROUP BY
	       tt.groupId,
	       tt.combination,
	       tt.cPercent,
	       tt.hcs
	HAVING COUNT(*) > 1
END
*/
SET @oldHcs = NULL

/* проверяем есть ли заполненные люди в заявлении - для них другой расчёт */ 
INSERT INTO @relatedPetPersonTable(
    personId,
    relatedPerson,
    npdMspCat,
    hcsGroup,
	hcs)
SELECT pe.A_MSPHOLDER,
       lp.TOID,
       pn.A_NPDMSPCAT,
       gp.A_FROMID,
       ctb.hcs
FROM   TMP_PC_NPDMSPCAT pn
       INNER JOIN SPR_NPD_MSP_CAT nm
            ON  pn.A_NPDMSPCAT = nm.A_ID
       INNER JOIN WM_PETITION pe
            ON  (pn.A_PERSON = pe.A_MSPHOLDER
                 AND nm.A_MSP = pe.A_MSP)
--                 AND nm.A_CATEGORY = pe.A_SERVCODE)
       INNER JOIN SPR_STATUS_PROCESS sp
            ON  (pe.A_STATUSPRIVELEGE = sp.A_ID AND sp.A_CODE = 100)
       INNER JOIN SPR_LINK_PET_PC lp
            ON  lp.FROMID = pe.OUID
       INNER JOIN @forCalcTable ctb
			ON ctb.relation = pn.A_ID --AND pn.A_GROUPHCS = ctb.groupId 
				and ctb.areaOfDistr IN ('family','dependent')              
       INNER JOIN #WM_GROUPHCS_PERSCARD gp
            ON  pe.A_MSPHOLDER = gp.A_TOID
            AND ctb.groupId = gp.A_FROMID
WHERE  pn.A_PROCESSUUID = @uuid
AND (gp.A_STATUS IS NULL OR gp.A_STATUS = @activeStatusId)
AND (pe.A_STATUS IS NULL OR pe.A_STATUS = @activeStatusId)
AND (nm.A_STATUS IS NULL OR nm.A_STATUS = @activeStatusId)

SET @relatedCount = 0


drop table #WM_GROUPHCS_PERSCARD


--SELECT * FROM @relatedPetPersonTable       
--SELECT * FROM @forCalcTable   
--SELECT * FROM @relatedPetPersonTable
---------------------------------------------------------------------------------
OPEN resultCursor
FETCH NEXT FROM resultCursor INTO @resId, @groupHCS, @personId, @npdMspCat, @hcs, 
@combination, @calcPercent, @areaOfDistr,
@calcType, @isNorm, @totalSquare, @heatedSquare, @norma, @tarif, @usePortion, @useNorm, 
@beginDate, @endDate, @personCount, @algId 

WHILE @@FETCH_STATUS = 0
BEGIN
	IF (@areaOfDistr = 'family' OR @areaOfDistr = 'dependent')
    BEGIN
        /* т.к. режим перерасчета, то закреплённых за льготниками членов группы ЖКУ оставляем им же */ 
        
        INSERT INTO @relatedPersonTable(
            groupId,
            hcs,
            combination,
            cPercent,
            personId,
            relatedPersonId,
            beginDate,
            endDate)
SELECT DISTINCT ct.groupId,
               ct.hcs,
               @combination, --ct.combination,
               ct.cPercent,
               pn.A_PERSON,
               pt.personId,
               ct.beginDate,
               ct.endDate
        FROM   TMP_PC_NPDMSPCAT pn
               INNER JOIN SPR_NPD_MSP_CAT nm
                    ON  pn.A_NPDMSPCAT = nm.A_ID
               INNER JOIN ESRN_SERV_SERV ss
                    ON  pn.A_PERSON = ss.A_PERSONOUID
                    AND pn.A_NPDMSPCAT = ss.A_SERV
                    AND (ss.A_STATUS = @activeStatusId OR ss.A_STATUS IS NULL)
                    AND ss.A_STATUSPRIVELEGE <> (SELECT A_ID
                                                 FROM   SPR_STATUS_PROCESS
                                                 WHERE  A_CODE = 2)
               INNER JOIN ESRN_SERV_HCS_AGR sh
                    ON  ss.OUID = sh.A_SERV
                    AND (sh.A_STATUS = @activeStatusId OR sh.A_STATUS IS NULL)
                    AND sh.A_SERV_PAY 
                     IN (SELECT DISTINCT A_OUID 
 							FROM WM_SERVPAYAMOUNT 
 						 WHERE A_STATUS = @activeStatusId OR A_STATUS IS NULL AND A_MSP = sh.A_SERV)
               INNER JOIN WM_HCS wh
					ON wh.A_HCSTYPE = sh.A_HCS     
               INNER JOIN LINK_PERSON_SERVHCSAGR lp
                    ON  sh.A_OUID = lp.A_FROMID
               INNER JOIN @persTable pt
                    ON  lp.A_TOID = pt.personId
               INNER JOIN @forCalcTable ct
                    ON pn.A_ID = ct.relation
                    AND  ct.hcs = wh.OUID
                    AND ct.hcs = @hcs
                    AND pt.dateIn = ct.beginDate
                    AND (pt.dateOut = ct.endDate OR (pt.dateOut IS NULL AND ct.endDate IS NULL))
        WHERE  pn.A_PROCESSUUID = @uuid
        AND ct.beginDate = @beginDate
        AND (ct.endDate = @endDate OR (@endDate IS NULL AND ct.endDate IS NULL))
        AND pn.A_PERSON = @personId



        DECLARE relatedPersonsCursor CURSOR  
        FOR
            SELECT DISTINCT pt.personId AS relatedPerson
            FROM   @persTable pt
            WHERE  pt.groupId = @groupHCS
				   AND pt.dateIn = @beginDate
				   AND (pt.dateOut = @endDate OR pt.dateOut IS NULL AND @endDate IS NULL)
                   AND NOT EXISTS(SELECT *
                                  FROM   @relatedPersonTable rp
                                  WHERE  groupId = pt.groupId
                                         AND hcs = @hcs
                                         AND personId = @personId
                                         AND combination = @combination
                                         AND cPercent = @calcPercent
                                         AND relatedPersonId = pt.personId
                                         AND beginDate = @beginDate
                                         AND (endDate = @endDate OR (endDate IS NULL AND @endDate IS NULL)))				               
                   AND NOT EXISTS(SELECT *
                                  FROM   @relatedPersonTable rp
                                  WHERE  groupId = pt.groupId
                                         AND hcs = @hcs
                                         AND combination = @combination
                                         AND cPercent > @calcPercent
                                         AND relatedPersonId = pt.personId
                                         AND beginDate = @beginDate
                                         AND (endDate = @endDate OR (endDate IS NULL AND @endDate IS NULL)))
                   AND (NOT EXISTS(SELECT *
                                   FROM   @relatedPetPersonTable
                                   WHERE  hcsGroup = @groupHCS AND hcs = @hcs)
                        OR (NOT EXISTS(SELECT *
                                       FROM   @relatedPetPersonTable pp
                                       WHERE  /*pp.personId != @personId
                                              AND*/ pp.relatedPerson = pt.personId
                                              --AND pp.npdMspCat = @npdMspCat
											  AND pp.hcs = @hcs)
                            /*AND NOT EXISTS(SELECT *
                                           FROM   @relatedPetPersonTable pp
                                           WHERE  pp.personId = @personId
										   AND pp.hcs = @hcs)*/)
                        OR EXISTS(SELECT *
                                  FROM   @relatedPetPersonTable pp
                                  WHERE  pp.personId = @personId
                                         AND pp.relatedPerson = pt.personId
                                         AND pp.npdMspCat = @npdMspCat
										 AND pp.hcs = @hcs))
        
        OPEN relatedPersonsCursor
        
        FETCH NEXT FROM relatedPersonsCursor INTO @relatedPersonId
        
        WHILE @@FETCH_STATUS = 0
        BEGIN
            /* если область распространения на иждевенцев, то проверяем является ли иждевенцем */
            IF ((@areaOfDistr = 'dependent')
                AND EXISTS(SELECT *
                           FROM   WM_RELATEDRELATIONSHIPS rs
                           WHERE  rs.A_ID1 = @personId
                                  AND rs.A_ID2 = @relatedPersonId
                                  AND rs.A_MAINTENANCE = 1))
               OR (@areaOfDistr = 'family')
            BEGIN
                SET @relatedCount = @relatedCount + 1 
                INSERT INTO @relatedPersonTable(
                    groupId,
                    hcs,
                    combination,
                    cPercent,
                    personId,
                    relatedPersonId,
                    beginDate,
                    endDate)
                VALUES(
                    @groupHCS,
                    @hcs,
                    @combination,
                    @calcPercent,
                    @personId,
                    @relatedPersonId,
                    @beginDate,
                    @endDate)
            END
            
            FETCH NEXT FROM relatedPersonsCursor INTO @relatedPersonId
        END
        CLOSE relatedPersonsCursor 
        DEALLOCATE relatedPersonsCursor

    	
    	
    	
	END
	
	
    FETCH NEXT FROM resultCursor INTO @resId, @groupHCS, @personId, @npdMspCat, 
    @hcs, @combination, @calcPercent, @areaOfDistr,
    @calcType, @isNorm, @totalSquare, @heatedSquare, @norma, @tarif, @usePortion, 
    @useNorm, @beginDate, @endDate, @personCount, @algId
END
CLOSE resultCursor

drop table #HCS_TYPES

/* считаем коэффициент */
INSERT INTO @factorTable(
    groupId,
    combination,
    hcs,
    personId,
    relatedPerson,
    factor,
    beginDate,
    endDate)
SELECT tt.groupId,
       tt.combination,
       tt.hcs,
       rt.personId,
       tt.relatedPersonId,
       1.0 / tt.factor,
       tt.beginDate,
       tt.endDate AS factor
FROM   (SELECT groupId,
               combination,
               hcs,
               relatedPersonId,
               COUNT(*) AS factor,
               beginDate,
               endDate
        FROM   @relatedPersonTable
        GROUP BY
               groupId,
               combination,
               hcs,
               cPercent,
               relatedPersonId,
               beginDate,
               endDate) tt
       INNER JOIN @relatedPersonTable rt
            ON  tt.groupId = rt.groupId
            AND tt.combination = rt.combination
            AND tt.hcs = rt.hcs
            AND tt.relatedPersonId = rt.relatedPersonId
            AND tt.beginDate = rt.beginDate
            AND (tt.endDate = rt.endDate OR (tt.endDate IS NULL AND rt.endDate IS NULL))


---------------------------------------------------------------------------------
OPEN resultCursor
FETCH NEXT FROM resultCursor INTO @resId, @groupHCS, @personId, @npdMspCat, @hcs, 
@combination, @calcPercent, @areaOfDistr,
@calcType, @isNorm, @totalSquare, @heatedSquare, @norma, @tarif, @usePortion, @useNorm, 
@beginDate, @endDate, @personCount, @algId 

WHILE @@FETCH_STATUS = 0
BEGIN
    /* в зависимости от процента распределяем людей между льготниками запросом */
/*    
    IF (@areaOfDistr = 'family' OR @areaOfDistr = 'dependent')
    BEGIN
        IF (@oldHcs IS NULL
            OR @oldHcs <> @hcs
            OR @oldPersonId <> @personId
            OR @oldPersonId IS NULL
            OR @oldBeginDate <> @beginDate
            OR @oldBeginDate IS NULL)
        BEGIN
            SET @oldPersonId = @personId
            SET @oldBeginDate = @beginDate
        END

        /* т.к. режим перерасчета, то закреплённых за льготниками членов группы ЖКУ оставляем им же */
/*         
        SET @relatedCount = 0
        
        INSERT INTO @relatedPersonTable(
            groupId,
            hcs,
            combination,
            cPercent,
            personId,
            relatedPersonId,
            beginDate,
            endDate)
        SELECT DISTINCT ct.groupId,
               ct.hcs,
               ct.combination,
               ct.cPercent,
               pn.A_PERSON,
               pt.personId,
               ct.beginDate,
               ct.endDate
        FROM   TMP_PC_NPDMSPCAT pn
               INNER JOIN SPR_NPD_MSP_CAT nm
                    ON  pn.A_NPDMSPCAT = nm.A_ID
               INNER JOIN ESRN_SERV_SERV ss
                    ON  pn.A_PERSON = ss.A_PERSONOUID
                    AND pn.A_NPDMSPCAT = ss.A_SERV
                    AND (ss.A_STATUS = @activeStatusId OR ss.A_STATUS IS NULL)
                    AND ss.A_STATUSPRIVELEGE <> (SELECT A_ID
                                                 FROM   SPR_STATUS_PROCESS
                                                 WHERE  A_CODE = 2)
               INNER JOIN ESRN_SERV_HCS_AGR sh
                    ON  ss.OUID = sh.A_SERV
                    AND (sh.A_STATUS = @activeStatusId OR sh.A_STATUS IS NULL)
               INNER JOIN LINK_PERSON_SERVHCSAGR lp
                    ON  sh.A_OUID = lp.A_FROMID
               INNER JOIN @persTable pt
                    ON  lp.A_TOID = pt.personId
               INNER JOIN @forCalcTable ct
                    ON  sh.a_hcs = ct.hcs
                    AND pn.A_ID = ct.relation
                    AND pt.dateIn = ct.beginDate
                    AND pt.dateOut = ct.endDate
        WHERE pn.A_PROCESSUUID = @uuid
        AND ct.beginDate = @beginDate
        AND ct.endDate = @endDate 
        
        DECLARE relatedPersonsCursor CURSOR  
        FOR
            SELECT DISTINCT pt.personId AS relatedPerson
            FROM   @persTable pt
            WHERE  pt.groupId = @groupHCS
                   AND NOT EXISTS(SELECT *
                                  FROM   @relatedPersonTable rp
                                  WHERE  groupId = pt.groupId
                                         AND hcs = @hcs
                                         AND combination = @combination
                                         AND cPercent > @calcPercent
                                         AND relatedPersonId = pt.personId
                                         AND beginDate = @beginDate
                                         AND endDate = @endDate)
                   AND (NOT EXISTS(SELECT *
                                   FROM   @relatedPetPersonTable
                                   WHERE  hcsGroup = @groupHCS)
                        OR (NOT EXISTS(SELECT *
                                       FROM   @relatedPetPersonTable pp
                                       WHERE  pp.personId != @personId
                                              AND pp.relatedPerson = pt.personId
                                              AND pp.npdMspCat = @npdMspCat)
                            AND NOT EXISTS(SELECT *
                                           FROM   @relatedPetPersonTable pp
                                           WHERE  pp.personId = @personId))
                        OR EXISTS(SELECT *
                                  FROM   @relatedPetPersonTable pp
                                  WHERE  pp.personId = @personId
                                         AND pp.relatedPerson = pt.personId
                                         AND pp.npdMspCat = @npdMspCat))
        
        OPEN relatedPersonsCursor
        
        FETCH NEXT FROM relatedPersonsCursor INTO @relatedPersonId
        
        WHILE @@FETCH_STATUS = 0
        BEGIN
            /* если область распространения на иждевенцев, то проверяем является ли иждевенцем */
            IF ((@areaOfDistr = 'dependent')
                AND EXISTS(SELECT *
                           FROM   WM_RELATEDRELATIONSHIPS rs
                           WHERE  rs.A_ID1 = @personId
                                  AND rs.A_ID2 = @relatedPersonId
                                  AND rs.A_MAINTENANCE = 1))
               OR (@areaOfDistr = 'family')
            BEGIN
                SET @relatedCount = @relatedCount + 1 
                INSERT INTO @relatedPersonTable(
                    groupId,
                    hcs,
                    combination,
                    cPercent,
                    personId,
                    relatedPersonId)
                VALUES(
                    @groupHCS,
                    @hcs,
                    @combination,
                    @calcPercent,
                    @personId,
                    @relatedPersonId)
            END
            
            FETCH NEXT FROM relatedPersonsCursor INTO @relatedPersonId
        END
        CLOSE relatedPersonsCursor 
        DEALLOCATE relatedPersonsCursor
*/        
    END
*/   
    /* если расчёт зависит от площадей, то распределяем площади */
    IF (@calcType LIKE 'area%' OR @calcType LIKE 'heat%')
    BEGIN
        IF (@oldHcs <> @hcs
            OR @oldHcs IS NULL
            OR @oldCombination <> @combination
            OR @oldCombination IS NULL
        	OR @personId <> @oldPersonId2
			OR @oldPersonId2 IS NULL
			OR @beginDate <> @oldBeginDate
			OR @oldBeginDate IS NULL			
        )
        BEGIN
            SET @oldCombination = @combination
            SET @oldBeginDate = @beginDate
            SET @freeTotalSquare = @totalSquare
            SET @freeHeatedSquare = @heatedSquare
            /* вытаскиваем соц норму */
            SELECT TOP 1 @socNorm = ss.A_NORM
            FROM   SPR_SOCNORM ss
            WHERE  ss.A_PERSNUM <= @personCount
                   AND (ss.A_BDATE IS NULL
                        OR (ss.A_BDATE <= @beginDate
                            AND (@endDate IS NULL OR ss.A_BDATE <= @endDate))
                        AND (ss.A_EDATE IS NULL
                             OR (ss.A_EDATE >= @endDate
                                 AND @endDate IS NULL
                                 AND ss.A_EDATE >= @endDate)))
            ORDER BY
                   ss.A_PERSNUM DESC
                   
            /* в  случае, когда использовать и доли и нормативы, у льготников по долям, у остальных по нормативам */ 
            /* для льготников */
            SET @partTotalSquare = @totalSquare / @personCount 
            SET @partHeatedSquare = @heatedSquare / @personCount
            /* для членов группы из области распространения */
            SET @partRelTotalSquare = @partTotalSquare
            SET @partRelHeatedSquare = @partHeatedSquare 
            /* в зависимости от комбинации флагов определяем часть площади */
            IF (@useNorm = 1 AND @usePortion = 1)
            BEGIN
                IF (@partTotalSquare > @socNorm)
                BEGIN
                    SET @partRelTotalSquare = @socNorm
                END
                
                IF (@partHeatedSquare > @socNorm)
                BEGIN
                    SET @partRelHeatedSquare = @socNorm
                END
            END
            ELSE 
            IF (@useNorm = 1 AND @usePortion = 0)
               OR (@useNorm = 0 AND @usePortion = 0)
            BEGIN
                IF (@partTotalSquare > @socNorm)
                BEGIN
                    SET @partTotalSquare = @socNorm
                    SET @partRelTotalSquare = @socNorm
                END
                
                IF (@partHeatedSquare > @socNorm)
                BEGIN
                    SET @partHeatedSquare = @socNorm 
                    SET @partRelHeatedSquare = @socNorm
                END
            END
            
            SET @oldHcs = @hcs
            SET @oldPersonId2 = @personId
        END
        
		SELECT @factor = isnull(SUM(factor),0) FROM @factorTable 
		WHERE  groupId = @groupHCS
			AND combination = @combination
			AND hcs = @hcs
			AND personId = @personId         
			AND beginDate = @beginDate
			AND (endDate = @endDate OR (endDate IS NULL AND @endDate IS null))
        
        
        IF (@calcType LIKE 'area%')
        BEGIN
            IF (@freeTotalSquare > 0)
            BEGIN
                SET @needTotalSquare = @partTotalSquare + (@partRelTotalSquare * @factor)
                SET @freeTotalSquare = @freeTotalSquare - @needTotalSquare
            END
            ELSE
            BEGIN
                SET @needTotalSquare = 0
            END
        END
        ELSE 
        IF (@calcType LIKE 'heat%')
        BEGIN
            IF (@freeHeatedSquare > 0)
            BEGIN
                SET @needHeatedSquare = @partHeatedSquare + (@partRelHeatedSquare * @factor)
                SET @freeHeatedSquare = @freeHeatedSquare - @needHeatedSquare
            END
            ELSE
            BEGIN
                SET @needHeatedSquare = 0
            END
        END
    END
    ELSE
    BEGIN
        SET @needHeatedSquare = NULL
        SET @needTotalSquare = NULL
    END
    /* заносим результат во временную таблицу */
    UPDATE @resTable
    SET    
           totalSquare = @needTotalSquare,
           heatedSquare = @needHeatedSquare,
           cPercent = @calcPercent,
           calcType = @algId,
           tarif = @tarif,
           norm = @norma,
           areaOfDistr = @areaOfDistr,
           personCount = @personCount
    WHERE  resId = @resId
    
    FETCH NEXT FROM resultCursor INTO @resId, @groupHCS, @personId, @npdMspCat, 
    @hcs, @combination, @calcPercent, @areaOfDistr,
    @calcType, @isNorm, @totalSquare, @heatedSquare, @norma, @tarif, @usePortion, 
    @useNorm, @beginDate, @endDate, @personCount, @algId
END
CLOSE resultCursor


/* считаем коэффициент */
/*
INSERT INTO @factorTable(
    groupId,
    combination,
    hcs,
    personId,
    relatedPerson,
    factor,
    beginDate,
    endDate)
SELECT tt.groupId,
       tt.combination,
       tt.hcs,
       rt.personId,
       tt.relatedPersonId,
       1.0 / tt.factor,
       tt.beginDate,
       tt.endDate AS factor
FROM   (SELECT groupId,
               combination,
               hcs,
               relatedPersonId,
               COUNT(*) AS factor,
               beginDate,
               endDate
        FROM   @relatedPersonTable
        GROUP BY
               groupId,
               combination,
               hcs,
               cPercent,
               relatedPersonId,
               beginDate,
               endDate) tt
       INNER JOIN @relatedPersonTable rt
            ON  tt.groupId = rt.groupId
            AND tt.combination = rt.combination
            AND tt.hcs = rt.hcs
            AND tt.relatedPersonId = rt.relatedPersonId
            AND tt.beginDate = rt.beginDate
            AND tt.endDate = rt.endDate
*/        
  

DELETE FROM TMP_DEP_PC_NPDMSPCAT WHERE A_PROCESSUUID = @uuid
/* результат в таблицу для дальнейших расчётов */
INSERT INTO TMP_DEP_PC_NPDMSPCAT(
    A_GROUPHCS,
    A_PERSON,
    A_NPDMSPCAT,
    A_HCS,
    A_COMBINATION,
    A_PERCENT,
    A_CALCTYPE,
    A_TSQUARE,
    A_HSQUARE,
    A_TARIF,
    A_NORM,
    A_FACTOR,
    A_AREA_COUNT,
    A_SPHERE,
    A_BDATE,
    A_EDATE,
	A_RECEIPT,
	A_RCPT_AMOUNT,
	A_RCPT_AMOUNT_SUM,
	A_USE_NORM,
	A_ALL_PERSONS,
        A_PROCESSUUID)
SELECT rt.groupId,
       rt.personId,
       rt.npdMspCat,
       rt.hcs,
       rt.combination,
       rt.cPercent,
       rt.calcType,
       round(rt.totalSquare,4),
       round(rt.heatedSquare,4),
       case when rcpt.rcptAmountId IS NULL THEN 0 ELSE ISNULL(rt.tarif, 0) END,
       rt.norm,
       ISNULL((SELECT SUM(tt.factor) AS factor
               FROM   @factorTable tt
               WHERE  tt.groupId = rt.groupId
                      AND tt.combination = rt.combination
                      AND tt.hcs = rt.hcs
                      AND tt.personId = rt.personId
                      AND tt.beginDate = rt.beginDate
                      AND (tt.endDate = rt.endDate OR (tt.endDate IS NULL AND rt.endDate IS NULL))
               GROUP BY
                      tt.combination,
                      tt.hcs),
        0) AS factor,
       qt.areaCount,
       rt.areaOfDistr,
       rt.beginDate,
       rt.endDate,
       rcpt.rcptId,
       rcpt.rcptAmountId,
       rcpt.pay,
       rcpt.useRcptNorm,
       rt.personCount,
       @uuid
FROM   @resTable rt
LEFT JOIN (SELECT groupId,
                         combination,
                         hcs,
                         personId,
                         beginDate,
                         endDate,                         
                         COUNT(distinct rpt.relatedPersonId) areaCount
                  FROM   @relatedPersonTable rpt
                  GROUP BY
                         groupId,
                         combination,
                         hcs,
                         personId,
                         beginDate,
                         endDate) qt
            ON  rt.groupId = qt.groupId
            AND rt.hcs = qt.hcs
            AND rt.combination = qt.combination
            AND rt.personId = qt.personId
            AND rt.beginDate = qt.beginDate
            AND (rt.endDate = qt.endDate OR (rt.endDate IS NULL AND qt.endDate IS NULL))             
INNER JOIN WM_HCS wh
		ON wh.OUID = rt.hcs
LEFT JOIN @receiptTable rcpt
	ON rt.groupId = rcpt.groupId
	AND rt.hcs = rcpt.hcs
	AND rt.beginDate <= rcpt.payDate
	AND rt.endDate >= rcpt.payDate
	AND wh.A_ORG = rcpt.org
	AND rcpt.mspLkNpd = rt.npdMspCat
	
DELETE FROM TMP_DEP_PC_NPDMSPCAT
WHERE A_PROCESSUUID = @uuid
AND A_ID NOT IN (
SELECT DISTINCT tdpn.A_ID
FROM TMP_PC_NPDMSPCAT tpn
	INNER JOIN TMP_DEP_PC_NPDMSPCAT tdpn
	ON tpn.A_NPDMSPCAT = tdpn.A_NPDMSPCAT AND tpn.A_PERSON = tdpn.A_PERSON
        AND tdpn.A_PROCESSUUID = @uuid
	INNER JOIN ESRN_SERV_SERV ess 
		ON tdpn.A_NPDMSPCAT = ess.A_SERV AND tdpn.A_PERSON = ess.A_PERSONOUID
	INNER JOIN SPR_SERV_PERIOD ssp
		ON ssp.A_SERV = ess.OUID
		AND tdpn.A_BDATE >= dateadd(day,-day(ssp.STARTDATE)+1,ssp.STARTDATE)
		AND (ssp.A_LASTDATE IS NULL OR tdpn.A_EDATE IS NULL OR tdpn.A_EDATE <= ssp.A_LASTDATE)
WHERE tpn.A_PROCESSUUID = @uuid
)	

DELETE FROM TMP_DEP_PC_LINK WHERE A_PROCESSUUID = @uuid
	
/* Заполняем области распространения */
INSERT INTO TMP_DEP_PC_LINK(
    A_FROMID,
    A_TOID,
    A_PROCESSUUID)
SELECT tdpn.A_ID,
       rpt.relatedPersonId,
       @uuid
FROM   TMP_DEP_PC_NPDMSPCAT tdpn
       INNER JOIN @relatedPersonTable rpt
            ON  tdpn.A_PERSON = rpt.personId
            AND tdpn.A_HCS = rpt.hcs
            AND tdpn.A_COMBINATION = rpt.combination
            AND rpt.beginDate = tdpn.A_BDATE
            AND (rpt.endDate = tdpn.A_EDATE OR (rpt.endDate IS NULL AND tdpn.A_EDATE IS NULL))
WHERE tdpn.A_PROCESSUUID = @uuid
                        
       DEALLOCATE groupWithHCS
       DEALLOCATE resultCursor
       DEALLOCATE groupsCur
       
DROP TABLE #temp
       
SELECT 0 AS CODE, CASE WHEN @isAutoReceipt = 1 
	THEN 'Перерасчет по фактическим квитанциям успешно завершен' 
	ELSE 'Перерасчет успешно завершен' end AS MSG
go

