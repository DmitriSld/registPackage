CREATE PROCEDURE [dbo].[UPDATE_LD_IMPORT_ZAGS_SM](
@a_ouid int
, @GUID1 varchar(255)
,@DATAR varchar(255)
,@PERSON varchar(255)
,@NOMAKT varchar(255)
,@DATREG_VAR varcHAR(255)
, @GETDATE datetime
)
AS
BEGIN

	DECLARE  @COUNT INT,@PRICHINA varchar(255), @DATASM DATETIME 
	DECLARE @GUID uniqueidentifier, @GUID_STOP uniqueidentifier, @USER int, @RES int, @REF int, @OSZN INT  
	DECLARE @GUID1REASON INT, @DATAEND DATETIME,  @DATREG DATETIME, @STOPSERV INT
	, @DATEStopPaid DATETIME
	, @DATEStopS datetime
	, @DATAStopSD datetime
	, @statDoc int
, @spravSmer int
,@REF_REC int

set @spravSmer=(select A_ID from ppr_doc where A_CODE='osnovDeathSprav') 
	--select * from TEMP_IMPORT_ZAGS_SM 
 set @RES = (select OUID from SPR_RES_REMUV where GUID = 'b8bef7:10a27ebb864:-5ba2')
 set @REF = (select OUID from SPR_REFUSE where GUID = '75b32d25-494a-45a5-b32d-25494ae5a55a')
 set @REF_REC = (select OUID from SPR_REFUSE where GUID = '-4d2fb2b0:10e5fedbf4b:-7999')


 set @OSZN = (select A_REG_ORGNAME from REGISTER_CONFIG inner join SX_CONFIG on REGISTER_CONFIG.OUID = SX_CONFIG.OUID where SX_CONFIG.A_ACTIVE = 1)

 
 set @statDoc=(select A_OUID from SPR_DOC_STATUS where A_CODE='active')
 

		IF OBJECT_ID('tempdb..#tmp_02_zags') is not null
			drop table #tmp_02_zags
			
create table #tmp_02_zags(a_OUID_TEMP INT,  OUID int, A_ID INT,A_LASTDATE DATETIME,DATAEND DATETIME,DATASM DATETIME, dateStopS datetime, NOMAKT varchar(255), DATREG DATETIME, prav int)			

		IF OBJECT_ID('tempdb..#tmp_03_zags') is not null
			drop table #tmp_03_zags
			
create table #tmp_03_zags(a_OUID_TEMP INT,OUID int, A_ID INT,A_LASTDATE DATETIME,DATAEND DATETIME,DATASM DATETIME, dateStopS datetime, NOMAKT varchar(255), DATREG DATETIME, prav int)			


IF (select TOP 1 A_DEATHDATE from WM_PERSONAL_CARD pc where pc.OUID=@PERSON) IS NULL
BEGIN

SET @DATASM = convert(datetime,@DATAR, 104)
				SET @DATREG = @DATREG_VAR 
		 IF @DATASM IS NOT NULL 
		 BEGIN 
		 	UPDATE WM_PERSONAL_CARD SET A_DEATHDATE = @DATASM WHERE OUID = @PERSON 
		 	SET @GUID = NEWID() 
			
		 	INSERT INTO [WM_REASON] 
        			([GUID] 
        			,[A_CROWNER] 
        			,[A_CREATEDATE] 
        			,[A_STATUS] 
        			,[A_NAME] 
        			,[A_DATE] 
        			,[A_OSZN]
        			, [A_INFO_TEMP_ZAGS]
        			) 
				VALUES 
        			(@GUID 
        			,@USER 
        			,@GETDATE 
        			,10 
        			,@RES 
        			,@DATASM 
        			,@OSZN
        			, @a_ouid
        			) 
        
				INSERT INTO SPR_LINK_PERSON_REASON (FROMID,TOID) 
				VALUES(@PERSON,(SELECT A_OUID FROM WM_REASON WHERE [GUID] = @GUID)) 
		
		    -- дата окончания выплат для детских  
			SET @DATAEND = dateadd(month,1,dateadd(day,1-day(@DATASM),@DATASM))-1
			--Дата приостановления для детских 
			SET @DATAStopSD=@DATAEND
			
			set @DATEStopPaid=@DATASM
		
			set @DATEStopS=@DATASM
			
			IF EXISTS (
		SELECT serv.OUID, per.A_ID, per.A_LASTDATE, 
			(case when soot.A_DATE_OK=20 then
				   @DATAEND 
				    when SOOT.A_DATE_OK=10 then
				     @DATEStopPaid end)
			DATAEND, @DATASM DATASM, 
			(case when soot.A_DATE_OK=20 then
				   @DATAStopSD 
				    when SOOT.A_DATE_OK=10 then
				     @DATEStopS end) dateStopS
			FROM ESRN_SERV_SERV serv
			INNER JOIN SPR_SERV_PERIOD per 
				on per.A_ID = (select TOP 1 A_ID FROM SPR_SERV_PERIOD 
					WHERE A_SERV = serv.OUID
					AND ISNULL(FLOOR(CAST(A_LASTDATE AS FLOAT)),10000000) > FLOOR(CAST(@DATASM AS FLOAT)) 
					AND ISNULL(A_STATUS,10) = 10 
					ORDER BY ISNULL(FLOOR(CAST(A_LASTDATE AS FLOAT)),10000000) DESC)
					inner join SOOTV_SERV_DATE_ZAGS2 soot on soot.a_ouid=
					ISNULL((select top 1 a_ouid from SOOTV_SERV_DATE_ZAGS2
					where a_serv=serv.a_serv and ISNULL(a_status, 10)=10),
					(select top 1 a_ouid from SOOTV_SERV_DATE_ZAGS2
					where a_serv is null and ISNULL(a_status, 10)=10))
			WHERE serv.A_PERSONOUID = @PERSON and ISNULL(serv.A_STATUS,10) = 10)
			
			begin
				INSERT INTO #tmp_02_zags(a_OUID_TEMP , OUID, A_ID,A_LASTDATE,DATAEND, DATASM, dateStopS,  NOMAKT,DATREG, prav)		
				SELECT @a_ouid,  serv.OUID, per.A_ID, per.A_LASTDATE, 
			(case when soot.A_DATE_OK=20 then
				   @DATAEND 
				    when SOOT.A_DATE_OK=10 then
				     @DATEStopPaid end)
			DATAEND, @DATASM DATASM, 
			(case when soot.A_DATE_OK=20 then
				   @DATAStopSD 
				    when SOOT.A_DATE_OK=10 then
				     @DATEStopS end) dateStopS, 
			 @NOMAKT NOMAKT, @DATREG DATREG, SOOT.a_date_ok
				FROM ESRN_SERV_SERV serv
				INNER JOIN SPR_SERV_PERIOD per 
					on per.A_ID = (select TOP 1 A_ID FROM SPR_SERV_PERIOD 
						WHERE A_SERV = serv.OUID
						AND ISNULL(FLOOR(CAST(A_LASTDATE AS FLOAT)),10000000) > FLOOR(CAST(@DATASM AS FLOAT)) 
						AND ISNULL(A_STATUS,10) = 10 
						ORDER BY ISNULL(FLOOR(CAST(A_LASTDATE AS FLOAT)),10000000) DESC)
								inner join SOOTV_SERV_DATE_ZAGS2 soot on soot.a_ouid=
					ISNULL((select top 1 a_ouid from SOOTV_SERV_DATE_ZAGS2
					where a_serv=serv.a_serv and ISNULL(a_status, 10)=10),
					(select top 1 a_ouid from SOOTV_SERV_DATE_ZAGS2
					where a_serv is null and ISNULL(a_status, 10)=10))
				WHERE serv.A_PERSONOUID = @PERSON and ISNULL(serv.A_STATUS,10) = 10
				--and serv.A_STATUSPRIVELEGE not in (select a_id from SPR_STATUS_PROCESS where a_code in ('2'))

		SET @DATAEND = 
		dateadd(month,1,dateadd(day,1-day(@DATASM),@DATASM))-1
				SET @GUID_STOP = NEWID()
			end
		
			/*Временное приостановление*/	
		
			IF EXISTS (
		SELECT serv.OUID, per.A_ID, per.A_LASTDATE, 
			(case when soot.A_DATE_OK=20 then
				   @DATAEND 
				    when SOOT.A_DATE_OK=10 then
				     @DATEStopPaid end)
			DATAEND, @DATASM DATASM, 
			(case when soot.A_DATE_OK=20 then
				   @DATAStopSD 
				    when SOOT.A_DATE_OK=10 then
				     @DATEStopS end) dateStopS
			FROM ESRN_SERV_SERV serv
			INNER JOIN SPR_SERV_PERIOD per 
				on per.A_ID = (select TOP 1 A_ID FROM SPR_SERV_PERIOD 
					WHERE A_SERV = serv.OUID
					AND ISNULL(FLOOR(CAST(A_LASTDATE AS FLOAT)),10000000) > FLOOR(CAST(@DATASM AS FLOAT)) 
					AND ISNULL(A_STATUS,10) = 10 
					ORDER BY ISNULL(FLOOR(CAST(A_LASTDATE AS FLOAT)),10000000) DESC)
					inner join SOOTV_SERV_DATE_ZAGS2 soot on soot.a_ouid=
					ISNULL((select top 1 a_ouid from SOOTV_SERV_DATE_ZAGS2
					where a_serv=serv.a_serv and ISNULL(a_status, 10)=10),
					(select top 1 a_ouid from SOOTV_SERV_DATE_ZAGS2
					where a_serv is null and ISNULL(a_status, 10)=10))
					
			WHERE serv.A_RECIEVER = @PERSON and serv.A_PERSONOUID!=isnull(serv.A_RECIEVER, serv.A_RECIEVER) and ISNULL(serv.A_STATUS,10) = 10)
			
			begin
			
				INSERT INTO #tmp_03_zags(a_OUID_TEMP, OUID, A_ID,A_LASTDATE,DATAEND, DATASM, dateStopS,  NOMAKT,DATREG, prav)		
				SELECT @a_ouid, serv.OUID, per.A_ID, per.A_LASTDATE, 
			(case when soot.A_DATE_OK=20 then
				   @DATAEND 
				    when SOOT.A_DATE_OK=10 then
				     @DATEStopPaid end)
			DATAEND, @DATASM DATASM, 
			(case when soot.A_DATE_OK=20 then
				   @DATAStopSD 
				    when SOOT.A_DATE_OK=10 then
				     @DATEStopS end) dateStopS, 
			 @NOMAKT NOMAKT, @DATREG DATREG, SOOT.a_date_ok
				FROM ESRN_SERV_SERV serv
				INNER JOIN SPR_SERV_PERIOD per 
					on per.A_ID = (select TOP 1 A_ID FROM SPR_SERV_PERIOD 
						WHERE A_SERV = serv.OUID
						AND ISNULL(FLOOR(CAST(A_LASTDATE AS FLOAT)),10000000) > FLOOR(CAST(@DATASM AS FLOAT)) 
						AND ISNULL(A_STATUS,10) = 10 
						ORDER BY ISNULL(FLOOR(CAST(A_LASTDATE AS FLOAT)),10000000) DESC)
								inner join SOOTV_SERV_DATE_ZAGS2 soot on soot.a_ouid=
					ISNULL((select top 1 a_ouid from SOOTV_SERV_DATE_ZAGS2
					where a_serv=serv.a_serv and ISNULL(a_status, 10)=10),
					(select top 1 a_ouid from SOOTV_SERV_DATE_ZAGS2
					where a_serv is null and ISNULL(a_status, 10)=10))
				WHERE serv.A_RECIEVER = @PERSON and serv.A_PERSONOUID!=isnull(serv.A_RECIEVER, serv.A_RECIEVER) and ISNULL(serv.A_STATUS,10) = 10
				--and serv.A_STATUSPRIVELEGE not in (select a_id from SPR_STATUS_PROCESS where a_code in ('2'))

		SET @DATAEND = 
		dateadd(month,1,dateadd(day,1-day(@DATASM),@DATASM))-1
				SET @GUID_STOP = NEWID()
			end
			
			
			INSERT INTO [WM_STOP_SERVSERV]
			  ([A_CROWNER]
			   ,[A_CREATEDATE]
			   ,[A_STATUS]
			   ,[A_DATE_FINISH]
			  ,[A_REASON]
			   ,[A_BASENUM]
			   ,[A_BASEDATE]
			  ,[A_NOTE]
			   ,[A_GUID]
			   ,[A_TYPE]
			   , A_SERV
			   , A_INFO_TEMP_ZAGS
			)
			select
			   @USER
			   ,@GETDATE
			   ,10
		,dateadd(day,1,#tmp_02_zags.dateStopS) 
			   ,@REF
			  ,tmp.NUMAZSM--@NOMAKT-- номер акта
			  ,tmp.DATEAZSM--@DATREG-- дата основания
			   ,SERV.OUID
			   ,newId()
			   ,'15'
			   , SERV.OUID
				, #tmp_02_zags.a_OUID_TEMP
		FROM #tmp_02_zags
inner join ESRN_SERV_SERV serv on #tmp_02_zags.OUID = serv.OUID
inner join TEMP_IMPORT_ZAGS_SM tmp on tmp.A_PERSON=serv.A_PERSONOUID
where tmp.a_ouid=@a_ouid

INSERT INTO [WM_STOP_SERVSERV]
			  ([A_CROWNER]
			   ,[A_CREATEDATE]
			   ,[A_STATUS]
			   ,[A_DATE_FINISH]
			  ,[A_REASON]
			   ,[A_BASENUM]
			   ,[A_BASEDATE]
			  ,[A_NOTE]
			   ,[A_GUID]
			   ,[A_TYPE]
			   , A_SERV
			   , A_INFO_TEMP_ZAGS
			)
			select
			   @USER
			   ,@GETDATE
			   ,10
		,dateadd(day,1,#tmp_03_zags.dateStopS) 
			   ,@REF_REC
			  ,tmp.NUMAZSM--@NOMAKT-- номер акта
			  ,tmp.DATEAZSM--@DATREG-- дата основания
			   ,SERV.OUID
			   ,newId()
			   ,'10'
			   , SERV.OUID
			   , #tmp_03_zags.a_OUID_TEMP
				
		FROM #tmp_03_zags
inner join ESRN_SERV_SERV serv on #tmp_03_zags.OUID = serv.OUID
inner join TEMP_IMPORT_ZAGS_SM tmp on tmp.A_PERSON=serv.A_PERSONOUID
where tmp.a_ouid=@a_ouid


INSERT INTO SPR_STOPSERV_ESRNSERVSERV (FROMID,TOID) 
SELECT cast(WM_STOP_SERVSERV.A_NOTE as int), WM_STOP_SERVSERV.OUID
FROM WM_STOP_SERVSERV
INNER JOIN #tmp_02_zags ON #tmp_02_zags.OUID=cast(WM_STOP_SERVSERV.A_NOTE as int)
AND WM_STOP_SERVSERV.A_CREATEDATE=@GETDATE

update WM_STOP_SERVSERV
set A_NOTE='Инфообмен с ЗАГС'
FROM 
WM_STOP_SERVSERV
INNER JOIN #tmp_02_zags ON #tmp_02_zags.OUID=cast(WM_STOP_SERVSERV.A_NOTE as int)
AND WM_STOP_SERVSERV.A_CREATEDATE=@GETDATE


	delete from #tmp_02_zags
	where OUID not in 
	
	(select #tmp_02_zags.OUID from #tmp_02_zags
	inner join SPR_STOPSERV_ESRNSERVSERV sv on sv.FROMID=#tmp_02_zags.OUID
	inner join WM_STOP_SERVSERV stopS on stopS.OUID=sv.TOID 
	and isnull(stopS.A_STATUS, 10)=10
	and  stopS.a_NOTE='Инфообмен с ЗАГС')
	

update per
set A_STATUS=70
, A_INFO_TEMP_ZAGS=#tmp_02_zags.a_OUID_TEMP
, A_INFO_TEMP_ZAGS_PRIZNAK=1
from #tmp_02_zags
		inner join SPR_SERV_PERIOD per on #tmp_02_zags.OUID = per.A_SERV
		where ISNULL(per.A_STATUS, 10)=10
		
		insert into SPR_SERV_PERIOD(A_CREATEDATE, A_GUID, A_LASTDATE, A_SERV, A_STATUS, STARTDATE, A_INFO_TEMP_ZAGS, A_INFO_TEMP_ZAGS_PRIZNAK)
       select @getdate, NEWID(),per.a_lastdate,   per.A_SERV, 10,per.STARTDATE, per.A_INFO_TEMP_ZAGS, 0
       from #tmp_02_zags
		inner join SPR_SERV_PERIOD per on #tmp_02_zags.OUID = per.A_SERV
		where isnull(per.A_INFO_TEMP_ZAGS, 0)=#tmp_02_zags.a_OUID_TEMP
	    and isnull(per.A_INFO_TEMP_ZAGS_PRIZNAK, 0)=1
	    and datediff(day, per.STARTDATE, #tmp_02_zags.dateStopS)>=0
	    
	    
	    
	    update per
	    set A_LASTDATE=#tmp_02_zags.dateStopS
	         from #tmp_02_zags
		inner join SPR_SERV_PERIOD per on #tmp_02_zags.OUID = per.A_SERV
	where isnull(per.a_Status, 10)=10
	and datediff(day,  isnull(per.A_LASTDATE,convert(datetime, '31.12.3000', 104)), #tmp_02_zags.dateStopS)<0
	    
/*
		update per
		set per.A_LASTDATE=#tmp_02_zags.dateStopS
		from #tmp_02_zags
		inner join SPR_SERV_PERIOD per on #tmp_02_zags.OUID = per.A_SERV
		where
		
		 ISNULL(FLOOR(CAST(per.A_LASTDATE AS FLOAT)),10000000) > FLOOR(CAST(#tmp_02_zags.dateStopS AS FLOAT)) 
				AND ISNULL(per.A_STATUS,10) = 10
				and per.STARTDATE=(select min(STARTDATE) from SPR_SERV_PERIOD where A_SERV=per.A_SERV
				and isnull(SPR_SERV_PERIOD.A_STATUS,10)=10
				and datediff(day,isnull(a_lastdate, convert(datetime, '01.01.3000', 104)), #tmp_02_zags.dateStopS)<=0
				)
				
				update SPR_SERV_PERIOD
				set A_STATUS=70
				where A_ID in 
				(
				select per.A_ID from #tmp_02_zags
		inner join SPR_SERV_PERIOD per on #tmp_02_zags.OUID = per.A_SERV
		where
		 ISNULL(FLOOR(CAST(per.A_LASTDATE AS FLOAT)),10000000) > FLOOR(CAST(#tmp_02_zags.dateStopS AS FLOAT)) 
				AND ISNULL(per.A_STATUS,10) = 10
				and DATEDIFF(DAY, isnull(per.A_LASTDATE , convert(datetime, '01.01.3000', 104)),#tmp_02_zags.dateStopS)<0)
				
		
		*/
		
		
		update per
set A_STATUS=70
, A_INFO_TEMP_ZAGS=#tmp_02_zags.a_OUID_TEMP
, A_INFO_TEMP_ZAGS_PRIZNAK=1
from #tmp_02_zags
		inner join WM_SERVPAYAMOUNT per on #tmp_02_zags.OUID = per.A_MSP
		where ISNULL(per.A_STATUS, 10)=10
		
		insert into WM_SERVPAYAMOUNT (A_CREATEDATE, A_AMOUNT, A_AMOUNTINFO, A_DATELAST, A_DATESTART, A_MSP,  A_PERIODCAUSE,A_STATUS, A_UNIT, GUID,  A_INFO_TEMP_ZAGS, A_INFO_TEMP_ZAGS_PRIZNAK)
       select @getdate,per.A_AMOUNT, per.A_AMOUNTINFO, per.A_DATELAST, per.A_DATESTART, per.A_MSP, per.A_PERIODCAUSE, 10, per.A_UNIT, NEWID(), per.A_INFO_TEMP_ZAGS, 0
       from #tmp_02_zags
		inner join WM_SERVPAYAMOUNT per on #tmp_02_zags.OUID = per.A_MSP
		where isnull(per.A_INFO_TEMP_ZAGS, 0)=#tmp_02_zags.a_OUID_TEMP
	    and isnull(per.A_INFO_TEMP_ZAGS_PRIZNAK, 0)=1
	    and datediff(day, per.A_DATESTART, #tmp_02_zags.dateStopS)>=0
	    
	    
	    
	    update per
	    set A_DATELAST=#tmp_02_zags.dateStopS
	         from #tmp_02_zags
		inner join WM_SERVPAYAMOUNT per on #tmp_02_zags.OUID = per.a_msp
	where isnull(per.a_Status, 10)=10
	and datediff(day,  isnull(per.A_DATELAST,convert(datetime, '31.12.3000', 104)), #tmp_02_zags.dateStopS)<0		
		
		/*update pay
		set pay.A_DATELAST = #tmp_02_zags.DATAEND
		from #tmp_02_zags
		inner join WM_SERVPAYAMOUNT pay on #tmp_02_zags.OUID = pay.A_MSP
		where ISNULL(FLOOR(CAST(pay.A_DATELAST AS FLOAT)),10000000) > FLOOR(CAST(#tmp_02_zags.DATAEND AS FLOAT)) 
				AND ISNULL(pay.A_STATUS,10) = 10 
				and pay.A_DATESTART=(select MIN(A_DATESTART) from WM_SERVPAYAMOUNT where A_MSP=pay.A_MSP
				and isnull(a_status,10)=10
				and datediff(day,isnull(a_DATELAST, convert(datetime, '01.01.3000', 104)), #tmp_02_zags.DATAEND)<=0
				)
				
				update  WM_SERVPAYAMOUNT
				set A_STATUS=70
				Where a_id in 
				(
				select pay.A_ID from #tmp_02_zags
		inner join WM_SERVPAYAMOUNT pay on #tmp_02_zags.OUID = pay.A_MSP
		where
		 ISNULL(FLOOR(CAST(pay.A_DATELAST AS FLOAT)),10000000) > FLOOR(CAST(#tmp_02_zags.DATAEND AS FLOAT)) 
				AND ISNULL(pay.A_STATUS,10) = 10
				and DATEDIFF(DAY, isnull(pay.a_DATELAST, convert(datetime, '01.01.3000', 104)),#tmp_02_zags.DATAEND)<0)

update pay
set A_STATUS=70
 from #tmp_02_zags
 inner join WM_SERVPAYAMOUNT pay on #tmp_02_zags.OUID = pay.A_MSP
and datediff(day,isnull(pay.A_DATESTART, convert(datetime, '01.01.1900', 104)), isnull(pay.A_DATELAST,convert(datetime, '31.12.3000', 104)))<0
*/
				update pay
				set A_STATUS=70
				, A_INFO_TEMP_ZAGS=#tmp_02_zags.a_OUID_TEMP
				, A_INFO_TEMP_ZAGS_PRIZNAK=1
				from #tmp_02_zags
		inner join WM_SERV_AMOUNT pay on #tmp_02_zags.OUID = pay.A_MSP
				

--пересчет к начислению


--не с начала месяца
insert into WM_SERV_AMOUNT  (	GUID,
	A_CREATEDATE	
	,TS,	
	A_STATUS,
		A_MSP,
			A_AMOUNT,	
			A_DATESTART,
				A_DATELAST,
					A_UNIT
					, A_INFO_TEMP_ZAGS
					, A_INFO_TEMP_ZAGS_PRIZNAK
					)

select 

NEWID(), 
dateadd(day, -1, @getdate), 
dateadd(day, -1,@getdate), 
10,
knaz.A_MSP,
round(knaz.A_AMOUNT*(cast(DAY(dateadd(month, 1, knaz.A_DATESTART)-DAY(dateadd(month, 1, knaz.A_DATESTART)))-DAY(knaz.A_DATESTART)+1 as float))/
cast(DAY(dateadd(month, 1, knaz.A_DATESTART)-DAY(dateadd(month, 1, knaz.A_DATESTART))) as float), 2) as a_amount, 
 kNaz.A_DATESTART,
 dateadd(month, 1, knaz.A_DATESTART)-DAY(dateadd(month, 1, knaz.A_DATESTART)),
  kNaz.A_UNIT
  , #tmp_02_zags.a_OUID_TEMP
  , 0

 from #tmp_02_zags
		inner join WM_SERVPAYAMOUNT kNaz on #tmp_02_zags.OUID = kNaz.A_MSP 
where datediff(day, knaz.A_DATESTART,knaz.A_DATESTART-DAY(knaz.A_DATESTART)+1)<>0
and isnull(kNaz.A_STATUS,10)=10

--не до конца месяца
insert into WM_SERV_AMOUNT  (GUID,
	A_CREATEDATE	
	,TS,	
	A_STATUS,
		A_MSP,
			A_AMOUNT,	
			A_DATESTART,
				A_DATELAST,
					A_UNIT
				     , A_INFO_TEMP_ZAGS
					, A_INFO_TEMP_ZAGS_PRIZNAK
					)

select 

NEWID(), 
dateadd(day,1,  @getdate), 
dateadd(day, 1, @getdate), 
10,
knaz.A_MSP,
round(knaz.A_AMOUNT*cast(DAY(knaz.A_DATELAST) as float)/CAST(day(dateadd(month, 1, knaz.A_DATELAST)-DAY(dateadd(month, 1, knaz.A_DATELAST))) as float), 2),
knaz.A_DATELAST-DAY(knaz.A_DATELAST)+1 ,
knaz.A_DATELAST,

  kNaz.A_UNIT
  , #tmp_02_zags.a_OUID_TEMP
  , 0
 from #tmp_02_zags
inner join WM_SERVPAYAMOUNT knaz on #tmp_02_zags.OUID = kNaz.A_MSP 
where
 datediff(day, knaz.A_DATELAST,dateadd(month, 1, knaz.A_DATELAST)-DAY(dateadd(month, 1, knaz.A_DATELAST)))<>0
 and isnull(kNaz.A_STATUS,10)=10
 --серединки

insert into WM_SERV_AMOUNT (GUID,
	A_CREATEDATE	
	,TS,	
	A_STATUS,
		A_MSP,
			A_AMOUNT,	
			A_DATESTART,
				A_DATELAST,
					A_UNIT
					, A_INFO_TEMP_ZAGS
					, A_INFO_TEMP_ZAGS_PRIZNAK
					)
					
					
select 
NEWID(),
@getdate,
@getdate,
10,  
 kNaz.A_MSP,
 Knaz.A_AMOUNT,
 case when DAY(KNAZ.A_DATESTART)=1
 THEN KNAZ.A_DATESTART
 ELSE dateadd(month,1, knaz.A_DATESTART-DAY(knaz.A_DATESTART)+1)
 end,
 case when 
 datediff(day, knaz.A_DATELAST,dateadd(month, 1, knaz.A_DATELAST)-DAY(dateadd(month, 1, knaz.A_DATELAST)))=0
 then 
 knaz.A_DATELAST
 else
  knaz.A_DATELAST-DAY(knaz.A_DATELAST)
  end,
knaz.A_UNIT
  , #tmp_02_zags.a_OUID_TEMP
  , 0
from #tmp_02_zags
inner join WM_SERVPAYAMOUNT kNaz on #tmp_02_zags.OUID = kNaz.A_MSP 
where 
isnull(kNaz.A_STATUS,10)=10 and
(DATEDIFF(MONTH, knaz.A_DATELAST, A_DATESTART)<>0
or
(
datediff(day, knaz.A_DATESTART,knaz.A_DATESTART-DAY(knaz.A_DATESTART)+1)=0
and datediff(day, knaz.A_DATELAST,dateadd(month, 1, knaz.A_DATELAST)-DAY(dateadd(month, 1, knaz.A_DATELAST)))=0
))


	delete from WM_SERV_AMOUNT
	where A_CREATEDATE=@getdate
	and datediff(day, A_DATESTART, isnull(A_DATELAST, convert(datetime, '31.12.3000',104)))<0		
			
				
						
		update serv
		set serv.A_STOPDATE =#tmp_02_zags.dateStopS
		, A_INFO_TEMP_ZAGS=#tmp_02_zags.a_OUID_TEMP
		, A_STATE_SM=serv.A_STATUSPRIVELEGE
		from #tmp_02_zags
		inner join ESRN_SERV_SERV serv on #tmp_02_zags.OUID = serv.OUID 		
		
		update serv
		set A_INFO_TEMP_ZAGS=#tmp_03_zags.a_OUID_TEMP
		, A_STATE_SM=serv.A_STATUSPRIVELEGE
		from #tmp_03_zags
		inner join ESRN_SERV_SERV serv on #tmp_03_zags.OUID = serv.OUID 
		
		
		
		update  PrichSn
		set A_DATE=dateadd(day, -1, q.dateF)
		 from 
		WM_PERSONAL_CARD pc
		inner join SPR_LINK_PERSON_REASON sv on sv.FROMID=pc.OUID
		inner join WM_REASON PrichSn on PrichSn.A_OUID=sv.TOID
		inner join 
		(select pc.OUID, MAX(prec.A_DATE_FINISH) dateF  from TEMP_IMPORT_ZAGS_SM tmp
		inner join WM_PERSONAL_CARD pc on pc.OUID=tmp.A_PERSON
		inner join SPR_LINK_PERSON_REASON sv on sv.FROMID=pc.OUID
		inner join WM_REASON PrichSn on PrichSn.A_OUID=sv.TOID
		and ISNULL(PrichSn.A_STATUS, 10)=10 
		inner join Esrn_serv_serv naz on naz.A_PERSONOUID=pc.OUID
		and ISNULL(naz.A_STATUS, 10)=10 
		inner join SPR_STOPSERV_ESRNSERVSERV sv2 on sv2.FROMID=naz.OUID
		inner join WM_STOP_SERVSERV prec on prec.OUID=sv2.TOID
		and ISNULL(prec.A_STATUS, 10)=10
		and prec.A_NOTE='Инфообмен с ЗАГС'
		where  tmp.a_ouid=@a_ouid
		group by pc.OUID)q on q.OUID=pc.OUID
		
		
		

		--поиск и замена сведений в документе
		update adoc
		set 
		DOCBASENUMBER=tab.NUMAZSM
		, A_DEATHDATE=DATESM
		, A_BASE_DATE=DATEAZSM
		, A_INFO_TEMP_ZAGS=tab.a_ouid
		 from TEMP_IMPORT_ZAGS_SM tab
		inner join WM_PERSONAL_CARD pc on pc.OUID=tab.A_PERSON
		inner	join wm_actdocuments adoc
		inner join ppr_doc vdoc on vdoc.a_id=adoc.DOCUMENTSTYPE
		and vdoc.A_CODE='osnovDeathSprav'
		on adoc.PERSONOUID=pc.OUID
		and ISNULL(adoc.A_STATUS, 10)=10
		and isnull(adoc.A_DOCSTATUS, @statDoc)=@statDoc
		where   tab.a_ouid=@a_ouid
	
		
		
		--добавление документов
		insert into WM_ACTDOCUMENTS
		(
		DOCBASENUMBER,
		PERSONOUID
		, A_PERSCARD_LINK
		, A_DOCSTATUS
		,A_STATUS
		, DOCUMENTSTYPE
		, A_DEATHDATE
		, A_BASE_DATE
		, A_INFO_TEMP_ZAGS
		)
		
		select 
		tab.NUMAZSM,
		 pc.OUID
		, pc.OUID
		,@statDoc
		, 10
		, @spravSmer
		, CONVERT(datetime, tab.DATESM , 104)
		, CONVERT(datetime, tab.DATEAZSM , 104)
		, tab.a_ouid
		from TEMP_IMPORT_ZAGS_SM tab
		inner join WM_PERSONAL_CARD pc on pc.OUID=tab.A_PERSON
		left join wm_actdocuments adoc
		inner join ppr_doc vdoc on vdoc.a_id=adoc.DOCUMENTSTYPE
		and vdoc.A_CODE='osnovDeathSprav'
		on adoc.PERSONOUID=pc.OUID
		and ISNULL(adoc.A_STATUS, 10)=10
		and isnull(adoc.A_DOCSTATUS, @statDoc)=@statDoc
	    where adoc.OUID is null 
		and tab.a_ouid=@a_ouid
END
END
END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:85 
--   sx.admin.AdmDispatchAction.execute:40
go

