CREATE PROCEDURE dbo.addraion @guid VARCHAR(255),@rayons VARCHAR(8000)
AS
BEGIN
  DECLARE @sqlreq AS VARCHAR(8000)
  SET @sqlreq = 'INSERT INTO link_pack_and_ray  (pack_ouid,ray_ouid)  SELECT (select OUID FROM pack where GUID = '''+@guid+'''), a_ouid FROM REFERENCE_INF WHERE A_OUID IN ('+@rayons+')'
  --PRINT @sqlreq
  EXEC(@sqlreq)
END
go

