CREATE VIEW [dbo].[backup_history] (id,[url],[name],fullbackup,diffbackup,region)
  AS 
SELECT MAX(id) id,[url],[name],fullbackup,diffbackup,region FROM (
  SELECT ROW_NUMBER() OVER( ORDER BY b1.name ) AS id, b1.url,b1.name,b1.a_date fullbackup,b2.a_date diffbackup,r.a_name region
  FROM backup_hist_temp b1
  LEFT JOIN backup_hist_temp b2 ON (b1.backup_set_uuid = b2.differential_base_guid )
  JOIN reference_inf ri ON ri.A_IP_ADRESS_RAION = b1.url
  JOIN SPR_SUBJFED r ON ri.A_REGION = r.ouid
  WHERE b1.differential_base_guid IS NULL ) x
GROUP BY [url],[name],fullbackup,diffbackup,region
go

