CREATE VIEW [dbo].[monitoring]
AS
SELECT
  ROW_NUMBER() OVER(ORDER BY ri.guid ASC) AS id,
  /*Суммируем косяки в битовую маску*/
  CONCAT(
  CASE --проверяем косяки с бэкапами
    WHEN date_full IS NULL THEN 1
    WHEN DATEDIFF(HOUR, date_full, b.a_ts) > 7 * 24 THEN 1
    WHEN DATEDIFF(HOUR, ISNULL(date_diff, date_full), b.a_ts) > 1 * 24 THEN 1
    ELSE 0
  END 
  ,CASE --проверяем косяки со свободным местом (если места меньше чем занимает полный бэкап)
    WHEN isnull(f,1000000)<b.size_full OR  isnull(l,1000000)<b.size_full OR  isnull(b,1000000)<b.size_full THEN 1
    ELSE 0
  END) alarm
 ,r.a_name region
 ,ri.guid
 ,ri.A_IP_ADRESS_RAION
 ,REPLACE(ri.A_RAION_NAME, LEFT(ri.A_RAION_NAME, PATINDEX('% %', ri.A_RAION_NAME)), '') A_RAION_NAME
 ,ri.A_RAION_NUMBER
 ,b.a_ts sbor
 ,b.date_full
 ,b.date_diff
 ,b.size_full
 ,b.size_diff
 ,isnull(s.f,-1) f
 ,isnull(s.l,-1) l
 ,isnull(s.b,-1) b
FROM REFERENCE_INF ri
JOIN SPR_SUBJFED r ON ri.A_REGION = r.ouid
LEFT JOIN monitoring_backup b
  ON b.url = ri.A_IP_ADRESS_RAION
LEFT JOIN monitoring_disk_space s
  ON s.url = ri.A_IP_ADRESS_RAION
WHERE a_mon = 1
go

