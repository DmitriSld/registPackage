CREATE PROCEDURE dbo.addpack @pack VARCHAR(255),@code VARCHAR(255),@path VARCHAR(255),@comment VARCHAR(4000),@guid VARCHAR(255),@user int,@descr VARCHAR(255),@region int,@iswebapps bit,@needrestart BIT
--RETURNS int
AS
BEGIN
  INSERT INTO pack (a_name, a_cod,a_path,comment,guid,TS,crowner,descr,region,is_webapps,need_restart) 
  VALUES (@pack,@code,@path,@comment,@guid,getdate(),@user,@descr,@region,@iswebapps,@needrestart)
  UPDATE pack
    SET num = (SELECT MAX(num)+1 FROM pack WHERE region = @region)
  WHERE guid = @guid
END
go

