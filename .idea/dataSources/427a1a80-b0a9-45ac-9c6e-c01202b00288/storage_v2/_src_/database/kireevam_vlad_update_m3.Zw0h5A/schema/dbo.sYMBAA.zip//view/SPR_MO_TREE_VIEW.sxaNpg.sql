CREATE VIEW SPR_MO_TREE
AS 
WITH SPR_MO (id,idchild,lev) AS (
	SELECT OUID,OUID, 0 
	FROM SPR_MUNICIPAL_INFOOBMEN
	UNION ALL
	SELECT tree.id, OUID, lev + 1
	FROM SPR_MUNICIPAL_INFOOBMEN mo
	INNER JOIN SPR_MO tree ON mo.A_PARENT = tree.idchild	
)
SELECT * FROM SPR_MO;
 
--   sx.datastore.db.SXDb.execute:433 
--   sx.common.replication.DoReplication.installPatch:2939 
--   sx.common.replication.SXPatchInstallParams.installPatch:82 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:200 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:180 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:57 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:43 
--   java.lang.reflect.Method.invoke:601 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:153 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160
go

