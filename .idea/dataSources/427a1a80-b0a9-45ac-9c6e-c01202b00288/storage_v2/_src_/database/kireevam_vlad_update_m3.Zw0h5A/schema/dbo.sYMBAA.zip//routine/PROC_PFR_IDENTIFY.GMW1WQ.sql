/* Процедура идентификации данных ПФР */
create procedure PROC_PFR_IDENTIFY
(
  @checkINITIALS int,    -- поиск по ФИО
  @checkBIRTHDATE bit,   -- поиск по дате рождения
  @checkADDRESS int,     -- поиск по адресу
  @checkDOCUMENT int     -- поиск по паспорту
)
as
begin

 set nocount on        -- отключаем вывод информации о количестве обработанных данных

 /*
 declare @iMaxDist int
 set @iMaxDist = 2     -- расхождение на длину символов, при сравнении
 */

 /*
   Сбрасываем поиск по дате рождения и адресу
   если не задан поиск по ФИО.
 */
 if (@checkINITIALS is NULL) begin
   select @checkBIRTHDATE = 0,
          @checkADDRESS = NULL
 end

 set @checkBIRTHDATE = isNull(@checkBIRTHDATE, 0)

 if ((@checkINITIALS is not NULL) and (@checkINITIALS != 0)) begin
   set @checkINITIALS = @checkINITIALS + 1
 end
 if ((@checkADDRESS is not NULL) and (@checkADDRESS != 0)) begin
   set @checkADDRESS = @checkADDRESS + 1
 end
 if ((@checkDOCUMENT is not NULL) and (@checkDOCUMENT != 0)) begin
   set @checkDOCUMENT = @checkDOCUMENT + 1
 end
  
 /* Таблица для поиска по СНИЛС */
 declare @tmpPFRTable table
         (
           ID int not NULL,
           SNILS varchar(255)
         )


 declare @tmpDuble table
         (
           ID int,
           OUID int
         )

 /* 
   Предварительная попытка поиска по SNILS.
   Если маски в импортированных данных и в ЕСРН совпадают,
   то данный поиск может ускорить всю идентификацию
 */
 update SR_PFR_PC set A_LDID = pc.OUID
   from SR_PFR_PC pfrld, WM_PERSONAL_CARD pc
  where (pfrld.A_LDID is NULL) and (pfrld.A_SNILS = pc.A_SNILS)

 declare @fldID int,              -- для идентификатора ID
         @fldSNILS varchar(255),  -- для номера SNILS
         @newSNILS varchar(255),  -- для номера SNILS без форматирования
         @iCount int,             -- количество обработанных номеров
         @i int,                   
         @iLen int,
         @chLetter char(1)

 set @iCount = 0

 /*
   Заполняем временную таблицу номеров SNILS
   без учета их форматирования
 */
 declare crPFRImport cursor FORWARD_ONLY STATIC for
         select A_ID, A_SNILS from SR_PFR_PC where (A_LDID is NULL)
 open crPFRImport
 fetch next from crPFRImport into @fldID, @fldSNILS
 while (@@FETCH_STATUS = 0) begin
   if (@fldSNILS is not NULL) begin
     select @newSNILS = '',
            @iLen = Len(@fldSNILS),
            @i = 1
     while (@i <= @iLen) begin
       set @chLetter = substring(@fldSNILS, @i, 1)
       if (CHARINDEX(@chLetter, '0123456789') > 0) begin
         set @newSNILS = @newSNILS + @chLetter 
       end
       set @i = @i + 1
     end
   end else begin
     set @newSNILS = NULL
   end
   set @iCount = @iCount + 1
   insert into @tmpPFRTable(ID, SNILS) values (@fldID, @newSNILS)
   fetch next from crPFRImport into @fldID, @fldSNILS  
 end
 close crPFRImport
 deallocate crPFRImport

 /*
    Производим идентификацию оставшихся данных  
 */
 if (@iCount != 0) begin
   /*
      Проводим сравнение по SNILS без форматирования с данными
      из временной таблицы.
   */    
   declare crPersons cursor FORWARD_ONLY STATIC for
                     select OUID, A_SNILS from WM_PERSONAL_CARD
                      where (A_SNILS is not NULL)
   open crPersons
   fetch next from crPersons into @fldID, @fldSNILS
   while (@@FETCH_STATUS = 0) begin
     select @newSNILS = '',
            @iLen = Len(@fldSNILS),
            @i = 1
     while (@i <= @iLen) begin
       set @chLetter = substring(@fldSNILS, @i, 1)
       if (CHARINDEX(@chLetter, '0123456789') > 0) begin
         set @newSNILS = @newSNILS + @chLetter 
       end
       set @i = @i + 1
     end
     if (exists(select 1 from @tmpPFRTable where (SNILS = @newSNILS))) begin
       /*
          Записи найденные по СНИЛС исключаются из дальнейшей обработки,
          т.к. по СНИЛС явная идентификация.
       */
       update SR_PFR_PC set A_LDID = @fldID
         from SR_PFR_PC pfr, @tmpPFRTable tmp
        where (pfr.A_ID = tmp.ID) and (tmp.SNILS = @newSNILS)
       delete from @tmpPFRTable where (SNILS = @newSNILS)
     end
     fetch next from crPersons into @fldID, @fldSNILS
   end
   close crPersons
   deallocate crPersons

   if ((exists(select 1 from @tmpPFRTable)) and
        ((@checkINITIALS is not NULL) or (@checkDOCUMENT is not NULL))) begin

     --update SR_PFR_PC set A_LDID = 
     insert into @tmpDuble (ID, OUID)
                 select pfr.A_ID, pc.OUID from WM_PERSONAL_CARD pc
                 cross join SR_PFR_PC pfr
                 inner join @tmpPFRTable tmp on (tmp.ID = pfr.A_ID)
                 /* ФИО */
                 left join SPR_FIO_SURNAME fam on (pc.SURNAME = fam.OUID) and
                                                  (fam.A_NAME is not NULL) and (@checkINITIALS is not NULL)
                 left join SPR_FIO_NAME nam on (pc.A_NAME = nam.OUID) and
                                               (nam.A_NAME is not NULL) and (@checkINITIALS is not NULL)
                 left join SPR_FIO_SECONDNAME otch on (pc.A_SECONDNAME = otch.OUID) and
                                                      (otch.A_NAME is not NULL) and (@checkINITIALS is not NULL)
                 /* документ */
                 left join WM_ACTDOCUMENTS doc
                          inner join PPR_DOC doctp on (doc.DOCUMENTSTYPE = doctp.A_ID) and (doctp.A_ISIDENTITYCARD = 1)
                          inner join OGBD_DOC ogdoc on (doctp.A_ID = ogdoc.A_KOD)
                          on (pc.OUID = doc.PERSONOUID) and (@checkDOCUMENT is not NULL)
                 /* адрес */
                 left join (select pfrtmp.A_ID,
                                  case when (@checkDOCUMENT is not NULL)
                                  /* удаляем почтовый индекс */
                                  then UPPER(LTRIM(substring(pfrtmp.A_ADDRESS, CHARINDEX(',', pfrtmp.A_ADDRESS) + 1, len(pfrtmp.A_ADDRESS))))
                                  else NULL end ADDRESS
                            from SR_PFR_PC pfrtmp /* where (pfrtmp.A_ID = pfr.A_ID) */) pfradr
                       on (pfradr.A_ID = pfr.A_ID) and (@checkADDRESS is not NULL)
                 left join (select adr.OUID,
                               UPPER(sft.A_NAME + char(32) + sf.A_NAME + ',' +
                                     case when (sfb.A_NAME is not NULL)
                                          then char(32) + sfb.A_NAME + char(32) + sfbt.A_NAME
                                          else '' end + ',' +
                                     case when (tw.A_NAME is not NULL)
                                          then char(32) + tw.A_NAME + char(32) + twp.A_NAME
                                          else '' end + ',' + 
                                     case when (st.A_NAME is not NULL)
                                          then char(32) + st.A_NAME + char(32) + stp.A_NAME
                                          else '' end + ',' +
                                     case when (adr.A_HOUSENUMBER is not NULL)
                                          then char(32) + 'д.' + adr.A_HOUSENUMBER
                                          else '' end + ','  +
                                     case when (adr.A_BUILDING is not NULL)
                                          then char(32) + 'к.' + adr.A_BUILDING
                                          else '' end + ',' +
                                     case when (adr.A_FLATNUMBER is not NULL)
                                          then char(32) + 'кв.' +  adr.A_FLATNUMBER
                                          else '' end) SZADDR
                        from WM_ADDRESS adr
                        inner join SPR_SUBJFED sf on (sf.OUID = adr.A_SUBFED)
                        inner join SPR_SUBJFEDTYPE sft on (sft.A_ID = sf.A_TYPE)
                        left join SPR_FEDERATIONBOROUGHT sfb
                                  inner join SPR_FBTYPE sfbt on (sfbt.A_ID = sfb.A_TYPE)
                                  on (sfb.OUID = adr.A_FEDBOROUGH) 
                        left join SPR_TOWN tw
                                  inner join SPR_TOWN_TYPE twp on (twp.OUID = tw.A_TOWNTYPE)
                                  on (tw.OUID = adr.A_TOWN)
                        left join SPR_STREET st
                                  inner join SPR_STEET_TYPE stp on (stp.OUID = st.A_STREETTYPE)
                                  on (st.OUID = adr.A_STREET)) tmaddr
                       on (tmaddr.OUID = pc.A_REGFLAT) and (@checkADDRESS is not NULL)
                 where ((@checkINITIALS is NULL) or -- поиск по ФИО
                    (((@checkBIRTHDATE = 0) or ((pc.BIRTHDATE is not NULL) and (DATEDIFF(day, pc.BIRTHDATE, pfr.A_BDATE) = 0))) and
                    ((fam.A_NAME = pfr.A_SNAME) or
                     ((fam.A_NAME is not NULL) and (pfr.A_SNAME is not NULL) and
                      (ABS(len(fam.A_NAME) - len(pfr.A_SNAME)) < @checkINITIALS) and
                      (dbo.DIFF_STRING(fam.A_NAME,  pfr.A_SNAME, @checkINITIALS) < @checkINITIALS))) and -- фамилия
                    ((nam.A_NAME = pfr.A_FNAME) or
                     ((nam.A_NAME is not NULL) and (pfr.A_FNAME is not NULL) and
                      (ABS(len(nam.A_NAME) - len(pfr.A_FNAME)) < @checkINITIALS) and
                      (dbo.DIFF_STRING(nam.A_NAME,  pfr.A_FNAME, @checkINITIALS) < @checkINITIALS))) and -- имя
                    ((otch.A_NAME = pfr.A_MNAME) or
                     ((otch.A_NAME is not null) and (pfr.A_MNAME is not NULL) and
                      (ABS(len(otch.A_NAME) - len(pfr.A_MNAME)) < @checkINITIALS) and
                      (dbo.DIFF_STRING(otch.A_NAME, pfr.A_MNAME,  @checkINITIALS) < @checkINITIALS)))))   -- отчество
                    and 
                    ((@checkDOCUMENT is NULL) or -- поиск по Документу
                     (((doc.DOCUMENTSERIES = pfr.A_DSER) or
                       ((doc.DOCUMENTSERIES is not NULL) and (pfr.A_DSER is not NULL) and
                        (dbo.DIFF_STRING(doc.DOCUMENTSERIES,  pfr.A_DSER, @checkDOCUMENT) < @checkDOCUMENT))) and  -- серия документа
                      ((doc.DOCUMENTSNUMBER = pfr.A_DNUM) or
                       ((doc.DOCUMENTSNUMBER is not NULL) and (pfr.A_DNUM is not NULL) and
                        (dbo.DIFF_STRING(doc.DOCUMENTSNUMBER, pfr.A_DNUM, @checkDOCUMENT) < @checkDOCUMENT)))) and  -- номер
                      ((ogdoc.A_OGBD_KOD = pfr.A_DTC) or
                       ((ABS(len(ogdoc.A_OGBD_KOD) - len(pfr.A_DTC)) < @checkDOCUMENT) and
                        (dbo.DIFF_STRING(ogdoc.A_OGBD_KOD, pfr.A_DTC, @checkDOCUMENT) < @checkDOCUMENT))))  
                    and
                    ((@checkADDRESS is NULL) or
                     ((pc.A_REGFLAT is not NULL) and (tmaddr.SZADDR is not NULL) and (pfr.A_ADDRESS is not NULL) and
                      ((tmaddr.SZADDR = pfr.A_ADDRESS) or
                       ((ABS(len(tmaddr.SZADDR) - len(pfr.A_ADDRESS)) < @checkADDRESS) and
                        (dbo.DIFF_STRING(tmaddr.SZADDR, pfr.A_ADDRESS, @checkADDRESS) < @checkADDRESS))) ))
    
     update SR_PFR_PC set A_LDID = (select dd1.OUID from @tmpDuble dd1
                                     where (dd1.ID = pfr.A_ID) and
                                           ((select count(1) from @tmpDuble dd2
                                              where (dd2.ID = dd1.ID)) = 1))
       from SR_PFR_PC pfr, @tmpPFRTable tmp 
      where (tmp.ID = pfr.A_ID)
   end
 end
end
 
--   sx.datastore.db.SXDb.execute:375 
--   sx.common.replication.DoReplication.installPatch:3736 
--   sx.common.replication.SXPatchInstallParams.installPatch:89 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:89 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:122 
--   sx.admin.AdmServlet.doGet:80 
--   sx.admin.AdmServlet.doPost:162 
--   javax.servlet.http.HttpServlet.service:709
go

