/*
 * Процедура для создания выплатных событий
 **/
CREATE PROCEDURE [dbo].[PROCESS_POE_EVENT](
    @year         INT,	--Год события
    @month        INT,	--Месяц события
    @modePay      INT,	--параметры с обрабатываемыми событиями, передаются через битовую маску
    @epid         INT,	--Id выгрузки
    @usePredicte  BIT,
    @commit       INT--флаг комита
               --1 - только заполенние временной таблицы
               --2 - только коммит
               --3 - заполнение временной таблицы и комит
)
AS
BEGIN
	SET NOCOUNT ON	
	
	DECLARE @status        INT
	SELECT @status          = A_ID   FROM ESRN_SERV_STATUS   WHERE  A_STATUSCODE = 'act' --Статус действует
	
	DECLARE @regMode INT,@payModeCode VARCHAR(255)
	SET @regMode = 0
	
	SELECT  
	@regMode = 	CASE payMode.A_EVENT_REG_MODE
					WHEN 2 THEN 1
					WHEN 3 THEN 2
					WHEN 4 THEN 3
					WHEN 5 THEN 4
					ELSE 0
				END,
	@payModeCode = payMode.A_CODE
	FROM WM_PAY_MODE payMode	
	WHERE payMode.A_OUID = @modePay
		AND (payMode.A_STATUS = @status OR payMode.A_STATUS IS NULL)
	
	--Дата до которой собираем состояние	
	DECLARE @limitDateEvent DATETIME,@eventDate DATETIME
	SET @eventDate = CONVERT(DATETIME,'01.' + CAST(@month AS VARCHAR) + '.' + CAST(@year AS VARCHAR),104)	
	--Если экспорт виртуальный,то учитываем события в тек месяце
	SET @limitDateEvent = CASE WHEN @regMode = 3 THEN @eventDate ELSE  dateadd(day,-1,dateadd(month,1,@eventDate))	END 
	--Прошлое время
	DECLARE @prevYear   INT,@prevMonth  INT,@prevQuartYear INT,@prevQuartMonth INT 
	IF (@month = 1)
	BEGIN
	    SET @prevMonth = 12
	    SET @prevYear = @year - 1
	END
	ELSE
	BEGIN
	    SET @prevMonth = @month - 1
	    SET @prevYear = @year
	END
	
	IF (@month < =3)
	BEGIN
	    SET @prevQuartMonth = 10
	    SET @prevQuartYear = @year - 1
	END
	ELSE
	BEGIN
	    SET @prevQuartMonth = (@month-1)/3*3-2
	    SET @prevQuartYear = @year
	END
	
	SELECT  ouid,childOuid,	
	CASE WHEN rootEvent.A_PARENT IN (SELECT a_ouid FROM SPR_PAY_EVENT WHERE A_PARENT IS null)		
		THEN 1
		ELSE 0 
	END rootNode
	INTO #EVENT_TREE
	FROM [dbo].[GET_POE_EVENT_TYPE_TREE]() three
	INNER JOIN SPR_PAY_EVENT rootEvent ON rootEvent.A_OUID = three.ouid	
	CREATE INDEX [ouid_IDX] ON #EVENT_TREE(ouid ASC)
	CREATE INDEX [childOuid_IDX] ON #EVENT_TREE(childOuid ASC)
	
	                 
	DECLARE @docStatus     INT,
	        @servIdStatus  INT,
	        @servSformStatus INT,
	        @sform         INT,
	        @prekr         INT,	       
	        @udergano      INT,
	        @ostanov       INT,
	        @nepolVip      INT,
	        @noPayAmount   INT,
	        @paidPayAmount INT,
	        @sendPayAmount INT,
	        @sformPayAmount INT,
	        @noAllPayAmount INT	        
	

	SELECT @docStatus       = a_ouid FROM SPR_DOC_STATUS     WHERE  A_CODE = 'active' --Статус документа дейтвует
	SELECT @servSformStatus = A_ID   FROM SPR_STATUS_PROCESS WHERE  A_CODE = 8 --Статус Сформировано
	SELECT @servIdStatus    = A_ID   FROM SPR_STATUS_PROCESS WHERE  A_CODE = 100 --Статус Утверждено
	SELECT @sform           = A_ID   FROM SPR_STATUS_PROCESS WHERE  A_CODE = 11 --Статус Выплпта сформирована
	SELECT @nepolVip        = A_ID   FROM SPR_STATUS_PROCESS WHERE  A_CODE = 9 --Неполная выплата 
	SELECT @prekr           = A_ID   FROM SPR_STATUS_PROCESS WHERE  A_CODE = 2 --Статус Прекращение
	SELECT @ostanov         = A_ID   FROM SPR_STATUS_PROCESS WHERE  A_CODE = 1 --Выплата приостановлена
	SELECT @udergano        = a_id   FROM SPR_STATUS_PROCESS WHERE  a_code = 333 --Статус Удержано	
	SELECT @noPayAmount     = a_id   FROM SPR_STATUS_PAYMENT WHERE  a_code = 2  --Статус Неоплата
	SELECT @paidPayAmount   = a_id   FROM SPR_STATUS_PAYMENT WHERE  a_code = 10 --Выплачено (Закрыто)
	SELECT @sendPayAmount   = a_id   FROM SPR_STATUS_PAYMENT WHERE  a_code = 4  --Передано в выплатную организацию
	SELECT @sformPayAmount  = a_id   FROM SPR_STATUS_PAYMENT WHERE  a_code = 0  --Сформирована
	SELECT @noAllPayAmount  = a_id   FROM SPR_STATUS_PAYMENT WHERE  a_code = 3  --Неоплата с запретом

	
		  
	
	DECLARE @virtualEventsGroup     INT,
	        @virtualNoPay           INT,
	        @virtualDeny            INT,
		    @virtualMonthlyEveryPay INT,
			@payStartGroup          INT,
			@payStart               INT,
			@payStartSingle         INT,
			@payStartSingleNoPay    INT,
			@changeSizeGroup        INT,
			@changeSizeOther        INT,
			@changeSizeDeduction    INT,
			@changeSizeCount        INT,
			@changeSizePartMonth    INT,
			@changeSizePredicte     INT,
			@changeSizeAddPay       INT,
			@changeSizeInnerPeriod  INT,
			@changeMonth            INT,
			@changePcGroup          INT,
			@changePcFIO            INT,
			@changePcDoc            INT,
			@changePcAddress        INT,
			@changePcPayment        INT,
			@changePcPaymentInPost  INT,	
			@changePcPaymentDuplicate INT ,	
			@changePcChangeBase     INT,	
			@stopPayGroup           INT,
			@stopPayEnd             INT,			
			@stopPayDeduction       INT,
			@stopPayPcDeath         INT,
			@stopPayChildDeath      INT,
			@stopPayReciverDeath    INT,
			@stopPayLongNoPay       INT,
			@stopPayNoActive        INT,
			@stopPayOther           INT,
			@stopPayEndPartMonth    INT,
			@prolongationPay        INT,
			@noPay                  INT,
			@endMonth               INT
			
	SELECT @virtualEventsGroup       = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '00'   --  Очередная выплата
	SELECT @virtualMonthlyEveryPay   = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '001'  --  Очередная выплата	
	SELECT @virtualNoPay             = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '002'  --  Вирт неоплата	
	SELECT @virtualDeny              = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '003'  --  Отказ	
	SELECT @payStartGroup            = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '01'   --  Группа Начало выплаты
	SELECT @payStart                 = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '011'  --  Начало выплаты	
	SELECT @payStartSingle           = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '012'  --  Разовая Начало выплаты 	
	SELECT @payStartSingleNoPay      = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '013'  --  Разовая Начало выплаты неоплаты	
	SELECT @changeSizeGroup          = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '02'   --  Смена размера
	SELECT @changeSizeOther          = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '021'  --	Изменение размера
	SELECT @changeSizeDeduction      = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '022'  --	Удержание
	SELECT @changeSizeCount          = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '023'  --	Изменение количественного состава назначения по одному ВД
	SELECT @changeSizePartMonth      = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '024'  --	Неполный месяц
	SELECT @changeSizePredicte       = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '025'  --	Прогнозируемое изменение размера
	SELECT @changeSizeAddPay         = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '026'  --	Доплата
	SELECT @changeSizeInnerPeriod    = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '027'  --  Смена размера в выплатном периоде	
	SELECT @changeMonth              = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '03'   --  Смена года
	SELECT @changePcGroup            = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '04'   --  Изменение личных данных
	SELECT @changePcFIO              = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '041'  --	Изменение ФИО
	SELECT @changePcAddress          = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '042'  --	Изменение адреса
	SELECT @changePcDoc              = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '043'  --	Изменение паспортных данных
	SELECT @changePcPayment          = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '044'  --	Изменение выплатных ревизитов
	SELECT @changePcPaymentInPost    = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '045'  --	Изменение выплатных ревизитов в отрганизации
	SELECT @changePcPaymentDuplicate = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '046'  --	Изминение выплатных реквизитов на такие же
	SELECT @changePcChangeBase       = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '047'  --	Смена основания
	SELECT @stopPayGroup             = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '05'   --  Прекращение
	SELECT @stopPayEnd               = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '0511' --	Истечение срока назначения
	SELECT @stopPayEndPartMonth      = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '0512' --  Истечение срока назначения (Неполный месяц)	
	SELECT @stopPayDeduction         = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '053'  --	100% удержание начисления
	SELECT @stopPayPcDeath           = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '054'  --	Льготодержатель умер
	SELECT @stopPayChildDeath        = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '057'  --	ЛД, на основании данных которого сделано назначение умерло
	SELECT @stopPayReciverDeath      = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '059'  --	Получатель умер
	SELECT @stopPayLongNoPay         = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '055'  --	Длительная неоплата
	SELECT @stopPayNoActive          = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '056'  --	Снятие с учета
	SELECT @stopPayOther             = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '058'  --	Ручное прекращение/приостановление	
	SELECT @prolongationPay          = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '061'  --	Продление назначения
	SELECT @noPay                    = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '07'   --  Невыплаченная сумма
	SELECT @endMonth                 = a_ouid FROM  SPR_PAY_EVENT WHERE A_CODE = '11'   --  окончание месяца    	
	--Таблица с обрабатываемыми событиями
	SELECT DISTINCT 
	sprPayEvent.A_OUID payEvent
	INTO #PAY_MODE_EVENTS
	FROM WM_PAY_MODE payMode
	INNER JOIN LINK_PAY_MODE_SETTINGS linkPayModeSetting ON linkPayModeSetting.A_FROMID = payMode.A_OUID
	INNER JOIN WM_PAY_MODE_SETTING payModeSetting ON payModeSetting.A_OUID = linkPayModeSetting.A_TOID
		AND (payModeSetting.A_STATUS = @status OR payModeSetting.A_STATUS IS NULL)
	INNER JOIN LINK_PAY_MODE_SETTINGS_EVENT  linkPayModeSettingEvent ON linkPayModeSettingEvent.A_FROMID = payModeSetting.A_OUID
	INNER JOIN #EVENT_TREE eventTree ON linkPayModeSettingEvent.A_TOID = eventTree.ouid
	INNER JOIN SPR_PAY_EVENT sprPayEvent ON eventTree.childOuid = sprPayEvent.A_OUID
		AND (sprPayEvent.A_STATUS = @status OR sprPayEvent.A_STATUS IS NULL)	
	WHERE (payMode.A_STATUS = @status OR payMode.A_STATUS IS NULL)
		AND  payMode.A_OUID = @modePay
	CREATE INDEX [payEvent_IDX] ON #PAY_MODE_EVENTS(payEvent ASC)	
	IF 	@modePay IS NULL 
	BEGIN
		INSERT INTO #PAY_MODE_EVENTS
		SELECT DISTINCT A_OUID FROM SPR_PAY_EVENT sprPayEvent
		WHERE  (sprPayEvent.A_STATUS = @status OR sprPayEvent.A_STATUS IS NULL)
	END	
	
	--Создание временной таблицы,если нет
	IF OBJECT_ID('dbo.WM_PAY_TEMPDATA', 'U') IS NOT NULL
	BEGIN
		 DROP TABLE WM_PAY_TEMPDATA		
	END
		
    CREATE TABLE WM_PAY_TEMPDATA (
    	id             INT IDENTITY(1, 1)PRIMARY KEY CLUSTERED,	--Идентификатор
    	epid           INT,	--Id выгрузки
    	payBookId      INT,	--выплатное дело
    	additionalPaymentBookId INT,--Дополнительное выплатное дело
    	payStart       DATETIME,	--дата начала назанчения
    	payEnd         DATETIME,	--дата окончания назначения
    	payNewEnd      DATETIME,	--дата окончания назначения
    	
    	payAmount      NUMERIC(18, 2),	--размер назначения
    	payAmountStart DATETIME, --дата начала основного размера
    	payAmountEnd   DATETIME, --дата окончания основного размера
    	
    	payPrevAmount  NUMERIC(18, 2),	--старый размер назначения
    	payPrevStart   DATETIME,--дата начала прошлого размера
    	payPrevEnd     DATETIME,--дата окончания прошлого размера
    	
    	addPayAmount   NUMERIC(18, 2),	--доплата
    	addPayStart    DATETIME,	--дата начала доплаты
    	addPayEnd      DATETIME,	--дата окончания доплаты
    	
    	noPayAmount    NUMERIC(18, 2),	--неоплата
    	noPayStart     DATETIME,	--дата начала неоплата
    	noPayEnd       DATETIME,	--дата окончания неоплата
    	
    	paidAmount     NUMERIC(18, 2),	--периодически выплачиваемая сумма
    	paidStart      DATETIME,	--дата начала периодически выплачиваемая сумма
    	paidEnd        DATETIME,	--дата окончания периодически выплачиваемая сумма	    	
    	
    	ouidOld        INT,	--Стрый объект
    	ouidNew        INT,	--Новый объект
    	class          INT,	--Класс
    	
    	eventType      INT,	--тип события
    	eventId        INT,	--событие
    	eventUnitId    INT,	--субъект события
    	new            BIT DEFAULT 1,	--флаг создания нового события
    	                  	--1 Создавать
    	                  	--0 или NULL не создавать
    	PRIORITY       INT DEFAULT 1,
    	eventDate      DATETIME, --Дата событияб
    	msg            VARCHAR(512)  	    	                       	
    )
    CREATE INDEX [payBookId_IDX] ON WM_PAY_TEMPDATA(payBookId ASC)
    CREATE INDEX [additionalPaymentBookId_IDX] ON WM_PAY_TEMPDATA(additionalPaymentBookId ASC)	    
    CREATE INDEX [eventType_IDX] ON WM_PAY_TEMPDATA(eventType ASC)
    CREATE INDEX [eventId_IDX] ON WM_PAY_TEMPDATA(eventId ASC)
    CREATE INDEX [eventUnitId_IDX] ON WM_PAY_TEMPDATA(eventUnitId ASC)
    CREATE INDEX [PRIORITY_IDX] ON WM_PAY_TEMPDATA(PRIORITY ASC)
    CREATE INDEX [eventDate_IDX] ON WM_PAY_TEMPDATA(eventDate ASC)
    CREATE INDEX [new_IDX] ON WM_PAY_TEMPDATA(new ASC)		
	
	--Провека корректности данных
	--таблица с ошибками	
	SELECT DISTINCT
	payBook.payBookId,
	CAST(NULL AS VARCHAR(1024)) msg
    INTO #DENY_TABLE
    FROM WM_PAY_PAYBOOK_TEMP payBook
    INNER JOIN ESRN_SERV_SERV serv ON serv.A_PAYMENTBOOK = payBook.payBookId
		AND ( serv.A_STATUS  = @status  OR serv.A_STATUS  IS NULL  )
	INNER JOIN WM_PAY_CALC payCalc ON payCalc.A_MSP = serv.OUID
    	AND ( payCalc.A_STATUS  = @status  OR payCalc.A_STATUS  IS NULL  )
    LEFT JOIN WM_PAIDAMOUNTS payAmount ON payAmount.A_PAYCALC = payCalc.OUID
        	AND ( payAmount.A_STATUS  = @status  OR payAmount.A_STATUS  IS NULL  )
	WHERE  (payCalc.A_STATUSPRIVELEGE = @servIdStatus OR payAmount.A_STATUSPRIVELEGE = @noPayAmount)    
	CREATE INDEX [payBookId_IDX] ON #DENY_TABLE(payBookId ASC)		
    -- Не заполнена история изменения ФИО
    UPDATE #DENY_TABLE
    SET msg = 'Не заполнена история изменения ФИО'
    WHERE msg IS NULL 
    AND payBookId  IN (	  SELECT conf.payBookId  
						  FROM #DENY_TABLE  conf 						  
						  INNER JOIN WM_PAYMENT_BOOK  paymentBook ON paymentBook.OUID  = conf.payBookId 
								AND ( paymentBook.A_STATUS  = @status  OR paymentBook.A_STATUS  IS NULL  )
						  INNER JOIN WM_PAYMENT payment ON payment.OUID  = paymentBook.A_ACTREQUISIT  
								AND ( payment.A_STATUS  = @status  OR payment.A_STATUS  IS NULL  )  						  
						  INNER JOIN WM_PERSONAL_CARD pc ON pc.OUID  = payment.PERSONOUID 
							AND ( pc.A_STATUS  = @status  OR pc.A_STATUS IS NULL  )
						  LEFT JOIN PC_FIO_HISTORY pcFioHist ON pcFioHist.A_PC  = pc.OUID         
							AND ( pcFioHist.A_STATUS  = @status  OR pcFioHist.A_STATUS  IS NULL  )
						  WHERE pcFioHist.OUID  IS NULL 
    )    
    -- Не заполнен адрес регистрации 
    UPDATE #DENY_TABLE
    SET msg = 'Не заполнен адрес регистрации'
    WHERE msg IS NULL 
    AND payBookId  IN (SELECT conf.payBookId  
					   FROM #DENY_TABLE  conf 					   
					   INNER JOIN WM_PAYMENT_BOOK  paymentBook ON paymentBook.OUID  = conf.payBookId 
							AND ( paymentBook.A_STATUS  = @status  OR paymentBook.A_STATUS  IS NULL  )
					   INNER JOIN WM_PAYMENT  payment ON payment.OUID  = paymentBook.A_ACTREQUISIT  
							AND ( payment.A_STATUS  = @status  OR payment.A_STATUS  IS NULL  )  						  
					   INNER JOIN WM_PERSONAL_CARD pc ON pc.OUID  = payment.PERSONOUID 
							AND ( pc.A_STATUS  = @status  OR pc.A_STATUS IS NULL  )
					   WHERE pc.A_REGFLAT  IS NULL AND pc.A_TEMPREGFLAT IS NULL 
    )    
    -- Не допустимое направление выплаты      
    UPDATE #DENY_TABLE
    SET msg = 'Не допустимое направление выплаты'
    WHERE msg IS NULL 
    AND payBookId  IN ( SELECT conf.payBookId  
						FROM #DENY_TABLE  conf 							
						INNER JOIN WM_PAYMENT_BOOK  paymentBook ON paymentBook.OUID  = conf.payBookId 
							AND ( paymentBook.A_STATUS  = @status  OR paymentBook.A_STATUS  IS NULL  )
						INNER JOIN WM_PAYMENT  payment ON payment.OUID  = paymentBook.A_ACTREQUISIT  
							AND ( payment.A_STATUS  = @status  OR payment.A_STATUS  IS NULL  )
						INNER JOIN WM_PAY_CALC payCalc ON payCalc.A_PAYACCOUNT = paymentBook.OUID
							AND ( payCalc.A_STATUS  = @status  OR payCalc.A_STATUS  IS NULL  ) 	
							AND  payCalc.A_STATUSPRIVELEGE = @servIdStatus
						INNER JOIN ESRN_SERV_SERV  serv ON serv.OUID  = payCalc.A_MSP          
							AND ( serv.A_STATUS  = @status  OR serv.A_STATUS  IS NULL  ) 
						INNER JOIN SPR_NPD_MSP_CAT  mspLkNpd ON mspLkNpd.A_ID  = serv.A_SERV  
							AND ( mspLkNpd.A_STATUS  = @status  OR mspLkNpd.A_STATUS  IS NULL  ) 
						INNER JOIN PPR_SERV  msp ON msp.A_ID  = mspLkNpd.A_MSP        
							AND ( msp.A_STATUS  = @status  OR msp.A_STATUS  IS NULL  ) 
						INNER JOIN SPR_DELIVERY_TYPES_MSP  mainCorr ON mainCorr.A_MSP  = msp.A_ID  
							AND ( mainCorr.A_STATUS  = @status  OR mainCorr.A_STATUS  IS NULL  ) 
						LEFT JOIN SPR_DELIVERY_TYPES_MSP  corr ON corr.A_MSP  = msp.A_ID  
							AND corr.A_DELIVERY_TYPE  = payment.A_DELIVERY_TYPES  
							AND ( corr.A_STATUS  = @status  OR corr.A_STATUS  IS NULL  ) 
						WHERE corr.A_OUID  IS NULL
      ) 
      --В выплатных реквизитах адрес для доставки отличается от адреса регистрации
      UPDATE #DENY_TABLE  
      SET msg = 'В выплатных реквизитах адрес для доставки отличается от адреса регистрации ' 
      WHERE msg IS NULL 
      AND payBookId  IN ( 	SELECT conf.payBookId  
							FROM #DENY_TABLE  conf							
							INNER JOIN WM_PAYMENT_BOOK  paymentBook ON paymentBook.OUID  = conf.payBookId 
								AND ( paymentBook.A_STATUS  = @status  OR paymentBook.A_STATUS  IS NULL  )
							INNER JOIN WM_PAYMENT  payment ON payment.OUID  = paymentBook.A_ACTREQUISIT  
								AND ( payment.A_STATUS  = @status  OR payment.A_STATUS  IS NULL  ) 
							INNER JOIN WM_PERSONAL_CARD  pc ON pc.OUID  = payment.PERSONOUID
								AND ( pc.A_STATUS  = @status  OR pc.A_STATUS  IS NULL  ) 
							INNER JOIN SPR_PAY_TYPE  delWay ON payment.DELIVERYWAY  = delWay.A_ID 
								AND delWay.A_COD  = 'NR1' 
							INNER JOIN SPR_DELIVERTYPES  delType ON payment.A_DELIVERY_TYPES  = delType.OUID
								AND delType.A_COD  <> '2' 
							WHERE (payment.ALTERNATIVEADDRESSDEIVERY  NOT IN   (ISNULL(pc.A_REGFLAT,-1) , ISNULL(pc.A_TEMPREGFLAT ,-1), ISNULL(pc.A_LIVEFLAT,-1))
								OR payment.ALTERNATIVEADDRESSDEIVERY IS NULL
							)
    )   
    -- В выплатных реквизитах не заполнен способ доставки
    UPDATE #DENY_TABLE
    SET msg = 'В выплатных реквизитах не заполнен способ доставки'
    WHERE msg IS NULL 
    AND payBookId  IN (   SELECT conf.payBookId  
						  FROM #DENY_TABLE  conf 
						  INNER JOIN WM_PAYMENT_BOOK  paymentBook ON paymentBook.OUID  = conf.payBookId  
							AND ( paymentBook.A_STATUS  = @status  OR paymentBook.A_STATUS  IS NULL  )
						  INNER JOIN WM_PAYMENT  payment ON payment.OUID  = paymentBook.A_ACTREQUISIT  
							AND ( payment.A_STATUS  = @status  OR payment.A_STATUS  IS NULL  )
						  WHERE payment.DELIVERYWAY  IS NULL 
    )   
    -- В выплатных реквизитах не заполнен способ получения выплаты
    UPDATE #DENY_TABLE
    SET msg = 'В выплатных реквизитах не заполнен способ получения выплаты'
    WHERE msg IS NULL 
    AND payBookId  IN (	SELECT conf.payBookId  
						FROM #DENY_TABLE  conf 
						INNER JOIN WM_PAYMENT_BOOK  paymentBook ON paymentBook.OUID  = conf.payBookId 
							AND ( paymentBook.A_STATUS  = @status  OR paymentBook.A_STATUS  IS NULL  )
						INNER JOIN WM_PAYMENT  payment ON payment.OUID  = paymentBook.A_ACTREQUISIT  
							AND ( payment.A_STATUS  = @status  OR payment.A_STATUS  IS NULL  )
						WHERE payment.A_DELIVERY_TYPES  IS NULL 
    ) 
    UPDATE #DENY_TABLE
    SET msg = 'Статус выплатных реквизитов Не действует'
    WHERE msg IS NULL 
    AND payBookId  IN (   SELECT conf.payBookId  
						  FROM #DENY_TABLE  conf 
						  INNER JOIN WM_PAYMENT_BOOK  paymentBook ON paymentBook.OUID  = conf.payBookId  
							AND ( paymentBook.A_STATUS  = @status  OR paymentBook.A_STATUS  IS NULL  )
						  INNER JOIN WM_PAYMENT  payment ON payment.OUID  = paymentBook.A_ACTREQUISIT  
							AND ( payment.A_STATUS  = @status  OR payment.A_STATUS  IS NULL  )
						   INNER JOIN SPR_DOC_STATUS docStatus ON payment.A_DOCSTATUS = docStatus.A_OUID
							AND docStatus.A_CODE = 'nonactive'
    )    
    -- В выплатных реквизитах не заполнен расчетный счет  
    UPDATE #DENY_TABLE
    SET msg = 'В выплатных реквизитах не заполнен расчетный счет'
    WHERE msg IS NULL 
    AND payBookId  IN ( SELECT conf.payBookId  
						FROM #DENY_TABLE  conf 
					    INNER JOIN WM_PAYMENT_BOOK  paymentBook ON paymentBook.OUID  = conf.payBookId  
							AND ( paymentBook.A_STATUS  = @status  OR paymentBook.A_STATUS  IS NULL  )
					    INNER JOIN WM_PAYMENT  payment ON payment.OUID  = paymentBook.A_ACTREQUISIT  
							AND ( payment.A_STATUS  = @status  OR payment.A_STATUS  IS NULL  )
						INNER JOIN SPR_PAY_TYPE  delWay ON payment.DELIVERYWAY  = delWay.A_ID 
								AND delWay.A_COD  = 'NR2' 								
					    WHERE payment.ACCOUNTINGCOUNT  IS NULL 
    )   

    DECLARE @SQL_FILTER VARCHAR(MAX)      
	DECLARE settCursor CURSOR STATIC FOR
    SELECT sxQuery.SQLSTATEMENT
    FROM WM_PAY_MODE payMode
    INNER JOIN LINK_PAY_MODE_FILTER linkPayModeFilter ON payMode.A_OUID = linkPayModeFilter.A_FROMID
    INNER JOIN SX_OBJ_QUERY sxQuery ON sxQuery.OUID = linkPayModeFilter.A_TOID
		AND sxQuery.USINGSQL = 1
    WHERE ( payMode.A_STATUS  = @status  OR payMode.A_STATUS  IS NULL  )
		AND payMode.A_OUID = @modePay
    ORDER BY linkPayModeFilter.A_NUM
	OPEN settCursor
	FETCH NEXT FROM settCursor
	INTO @SQL_FILTER
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SQL_FILTER IS NOT NULL 
		BEGIN 
    		EXECUTE (@SQL_FILTER)
		END 
	FETCH NEXT FROM settCursor
	INTO @SQL_FILTER
	END
	CLOSE settCursor
	DEALLOCATE settCursor  

	DELETE FROM #DENY_TABLE WHERE msg IS NULL 
	
	
	

	
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,msg)
	SELECT DISTINCT denyTable.payBookId,@virtualDeny,msg
	FROM #DENY_TABLE denyTable		
	DELETE FROM WM_PAY_PAYBOOK_TEMP	    WHERE payBookId IN (SELECT payBookId FROM #DENY_TABLE WHERE msg IS NOT NULL)
	DELETE FROM #TEMP_POE_PAYMENT_STATE WHERE payBookId IN (SELECT payBookId FROM #DENY_TABLE WHERE msg IS NOT NULL)	
	DROP TABLE #DENY_TABLE
	   
	--Создание временной таблицы
	IF OBJECT_ID('dbo.WM_PAY_TEMPDATA_DETAILS', 'U') IS NOT NULL
	BEGIN
	     DROP TABLE WM_PAY_TEMPDATA_DETAILS
	END
	 CREATE TABLE WM_PAY_TEMPDATA_DETAILS(
	    	id            INT IDENTITY(1, 1)PRIMARY KEY CLUSTERED,	--Идентификатор	    	
	    	payBookId     INT,	          --выплатное дело
			additionalPaymentBookId INT,  --Дополнительное выплатное дело
	    	payCalcId     INT,	          --Начисление
	    	paidAmountId  INT,	          --Выплата	    	
	    	payAmount     NUMERIC(18, 2), --размер назначения	    	
	    	addPayAmount  NUMERIC(18, 2), --доплата
	    	noPayAmount   NUMERIC(18, 2)  --неоплата
    )	    
    CREATE INDEX [payBookId_IDX] ON WM_PAY_TEMPDATA_DETAILS(payBookId ASC)
    CREATE INDEX [additionalPaymentBookId_IDX] ON WM_PAY_TEMPDATA_DETAILS(additionalPaymentBookId ASC)
    CREATE INDEX [payCalcId_IDX] ON WM_PAY_TEMPDATA_DETAILS(payCalcId ASC)
    CREATE INDEX [payId_IDX] ON WM_PAY_TEMPDATA_DETAILS(paidAmountId ASC)
	
    --временная таблица с данными выплат   
    SELECT 
    payBook.payBookId,
	payBook.paymentId,
	payBook.orgId,
	payBook.reciver,
	payBook.mspLkNpdId,
	servPeriod.payStart,
	servPeriod.payEnd,
	payBook.periodCode mspType,
	payBook.fioId fio,
	payBook.adressId adress,
	payBook.docId
	INTO #TEMP_EVENT_PAYBOOK
    FROM WM_PAY_PAYBOOK_TEMP payBook      
    
	LEFT JOIN (	SELECT 
				serv.A_PAYMENTBOOK,
				MIN(period.STARTDATE) payStart,
				CASE WHEN MAX(ISNULL(period.A_LASTDATE,CONVERT(DATETIME, '01.01.2300', 104))) = CONVERT(DATETIME, '01.01.2300', 104)
					THEN NULL
					ELSE MAX(period.A_LASTDATE)
				END payEnd		
				FROM ESRN_SERV_SERV serv   
				INNER JOIN SPR_SERV_PERIOD period ON  period.A_SERV = serv.OUID
					AND (period.A_STATUS = @status OR period.A_STATUS IS NULL)					
				WHERE (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)		
					AND serv.A_STATUSPRIVELEGE <> @servSformStatus					
				GROUP BY serv.A_PAYMENTBOOK	
    ) servPeriod ON servPeriod.A_PAYMENTBOOK = payBook.payBookId	
    INNER JOIN PC_FIO_HISTORY fioHistory ON fioHistory.OUID  = payBook.fioId   
		AND (fioHistory.A_STATUS = @status OR fioHistory.A_STATUS IS NULL)
	INNER JOIN SPR_FIO_SURNAME sfs ON sfs.OUID = fioHistory.A_SURNAME
	INNER JOIN SPR_FIO_NAME sfn ON sfn.OUID = fioHistory.A_NAME
		
		
   CREATE INDEX [payBookIdOuid_IDX] ON #TEMP_EVENT_PAYBOOK(payBookId ASC)
   CREATE INDEX [paymentId_IDX] ON #TEMP_EVENT_PAYBOOK(paymentId ASC)
   CREATE INDEX [reciver_IDX] ON #TEMP_EVENT_PAYBOOK(reciver ASC)            
         
    --Таблица с закрытиями                 
   SELECT DISTINCT
   payBook.payBookId
   INTO #TEMP_ENDMONTH
   FROM   WM_PAY_EVENT_UNIT payEventUnit
   INNER JOIN #TEMP_EVENT_PAYBOOK payBook ON payEventUnit.A_PAYMENT_BOOK = payBook.payBookId
   INNER JOIN WM_PAY_EVENT payEvent ON  payEventUnit.A_EVENT = payEvent.A_OUID
       AND (payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL  )
   WHERE  (payEventUnit.A_STATUS = @status OR payEventUnit.A_STATUS IS NULL )
	   AND payEvent.A_EVENT_TYPE  = @endMonth
	   AND datediff(day,payEvent.A_EVENT_DATE,@eventDate) = 0
	   AND @regMode NOT IN (2,3,4)  
	   
	   
    --Таблица с закрытиями                 
   SELECT DISTINCT
   payBook.payBookId
   INTO #TEMP_STOP_EVENT
   FROM WM_PAY_EVENT_UNIT payEventUnit
   INNER JOIN #TEMP_EVENT_PAYBOOK payBook ON payEventUnit.A_PAYMENT_BOOK = payBook.payBookId
   INNER JOIN WM_PAY_EVENT payEvent ON  payEventUnit.A_EVENT = payEvent.A_OUID
       AND (payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL  )
   WHERE  (payEventUnit.A_STATUS = @status OR payEventUnit.A_STATUS IS NULL )
	   AND payEvent.A_EVENT_TYPE  IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid  IN (@stopPayGroup))
	   AND datediff(month,payEvent.A_EVENT_DATE,@eventDate) = 0
	   
	   
	    
	   
	--Таблица с закрытиями                 
   SELECT 
   payBook.payBookId
   INTO #TEMP_ENDMONTH_REAL
   FROM   WM_PAY_EVENT_UNIT payEventUnit
   INNER JOIN #TEMP_EVENT_PAYBOOK payBook ON payEventUnit.A_PAYMENT_BOOK = payBook.payBookId
   INNER JOIN WM_PAY_EVENT payEvent ON  payEventUnit.A_EVENT = payEvent.A_OUID
       AND (payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL  )
   WHERE  (payEventUnit.A_STATUS = @status OR payEventUnit.A_STATUS IS NULL )
	   AND payEvent.A_EVENT_TYPE  = @endMonth
	   AND datediff(day,payEvent.A_EVENT_DATE,@eventDate) = 0

         
     --Фильтрация мертвых людей
	SELECT payBookT.payBookId
	INTO #DEATH_PC
	FROM #TEMP_EVENT_PAYBOOK payBookT
	INNER JOIN WM_PAYMENT_BOOK payBook ON payBook.OUID = payBookT.payBookId
		AND (payBook.A_STATUS = @status OR payBook.A_STATUS IS NULL)
	INNER JOIN WM_PAYMENT payment ON payment.OUID = payBook.A_ACTREQUISIT
		AND (payment.A_STATUS = @status OR payment.A_STATUS IS NULL)
	INNER JOIN WM_PERSONAL_CARD deathPc ON ( deathPc.OUID = payBook.PERSONALOUID OR deathPc.OUID = payment.PERSONOUID)
		AND (deathPc.A_STATUS = @status OR deathPc.A_STATUS IS NULL)		
	LEFT JOIN (	SELECT 
				doc.PERSONOUID pc,
				doc.OUID,
				ROW_NUMBER () OVER ( PARTITION BY doc.PERSONOUID ORDER BY doc.OUID desc) num
				FROM WM_ACTDOCUMENTS doc
				INNER JOIN PPR_DOC pprDoc ON doc.DOCUMENTSTYPE = pprDoc.A_ID AND pprDoc.A_CODE IN ('deathSprav','deathCertificate')
           		WHERE 	(doc.A_STATUS = @status OR doc.A_STATUS IS NULL)
	) deathDoc ON deathDoc.pc = deathPc.OUID AND deathDoc.num = 1				
	WHERE (deathPc.A_DEATHDATE IS NOT NULL OR deathDoc.OUID IS NOT NULL )   
	CREATE INDEX [payBookId_IDX] ON #DEATH_PC(payBookId ASC)      
         
    --Временная таблица с текущем состоянием выплаты
    SELECT 
    IDENTITY(INT,1,1)     id, 
    curState.payBookId    payBookId,
    curState.additionalPaymentBookId     additionalPaymentBookId ,    
    
	curState.fioId            A_FIO,
	curState.addrId           A_ADDRESS,
	curState.idDocId          A_ID_DOC,
	curState.paymentId        A_PAYMENT,		
	curState.mspLkNpdId       A_MSP_LK_NPD,	
	
	curState.payStartDate     payStart,	
	curState.payEndDate       payEnd,
	
	curState.curAmount	      curAmount,
	curState.amountStart      amountStart,
	
	curState.eventTypeLast    eventTypeLast,
	curState.startEventType   eventType,
	
	curState.startEventDate   eventDate,	
	curState.startEventId     eventId,
	curState.startEventUnitId eventUnitId,	
	
	CASE WHEN curState.startEventType = @payStart
		THEN 1 
		ELSE 0
	END longPay,
	curState.activePay
	
	INTO #CUR_EVENT_STATE
    FROM #TEMP_POE_PAYMENT_STATE curState    
	--WHERE curState.activePay = 1	
	
	CREATE INDEX [id_IDX]        ON #CUR_EVENT_STATE(id ASC)
    CREATE INDEX [payBookId_IDX] ON #CUR_EVENT_STATE(payBookId ASC)
    CREATE INDEX [A_FIO_IDX]     ON #CUR_EVENT_STATE(A_FIO ASC)
    CREATE INDEX [A_ADDRESS_IDX] ON #CUR_EVENT_STATE(A_ADDRESS ASC)
    CREATE INDEX [A_ID_DOC_IDX]  ON #CUR_EVENT_STATE(A_ID_DOC ASC)
    CREATE INDEX [A_PAYMENT_IDX] ON #CUR_EVENT_STATE(A_PAYMENT ASC) 
    CREATE INDEX [eventDate_IDX] ON #CUR_EVENT_STATE(eventDate ASC) 
    CREATE INDEX [longPay_IDX]   ON #CUR_EVENT_STATE(longPay ASC) 
    CREATE INDEX [activePay_IDX] ON #CUR_EVENT_STATE(activePay ASC)   
       
    --Маска для выплатных дел   
    SELECT DISTINCT
    IDENTITY(int,1,1) id,   
    payBook.payBookId,
    mask.additionalPaymentBookId,
    mask.mspLkNpd

    INTO #TEMP_MASK_PAYBOOK
    FROM #TEMP_EVENT_PAYBOOK payBook    
    LEFT JOIN (	SELECT DISTINCT 
				serv.A_PAYMENTBOOK payBookId,
				deathServ.A_PAYMENTBOOK additionalPaymentBookId,
				min(deathServ.A_SERV)  mspLkNpd			
				FROM WM_PAIDAMOUNTS deathPayAmount				
				INNER JOIN WM_PAY_CALC deathCayCalc ON deathCayCalc.OUID = deathPayAmount.A_PAYCALC	
					AND (deathCayCalc.A_STATUS IS NULL OR deathCayCalc.A_STATUS = @status)
				INNER JOIN ESRN_SERV_SERV deathServ ON deathServ.OUID = deathCayCalc.A_MSP
					AND (deathServ.A_STATUS IS NULL OR deathServ.A_STATUS = @status)									
				INNER JOIN WM_REL_PAIDAMOUNT relPayAmount ON relPayAmount.A_PAIDAMOUNT = deathPayAmount.OUID
					AND (relPayAmount.A_STATUS IS NULL OR relPayAmount.A_STATUS = @status)	
				INNER JOIN WM_PETITION petition ON	relPayAmount.A_PETITION = petition.OUID
					AND (petition.A_STATUS IS NULL OR petition.A_STATUS = @status)
				INNER JOIN ESRN_SERV_SERV serv ON serv.A_REQUEST = petition.OUID
					AND (serv.A_STATUS IS NULL OR serv.A_STATUS = @status)	
				INNER JOIN WM_PAY_CALC payCalc ON payCalc.A_MSP = serv.OUID	
					AND (payCalc.A_STATUS IS NULL OR payCalc.A_STATUS = @status)				
				INNER JOIN WM_PAIDAMOUNTS payAmount ON payCalc.OUID = payAmount.A_PAYCALC	
					AND (payAmount.A_STATUS IS NULL OR payAmount.A_STATUS = @status)
					--AND payAmount.A_STATUSPRIVELEGE = @sformPayAmount
				WHERE (deathPayAmount.A_STATUS IS NULL OR deathPayAmount.A_STATUS = @status)
					AND deathPayAmount.A_STATUSPRIVELEGE IN( @paidPayAmount	,@noAllPayAmount,@noPayAmount,@sendPayAmount,@sformPayAmount)
               	GROUP BY serv.A_PAYMENTBOOK,deathServ.A_PAYMENTBOOK		
	)mask ON mask.payBookId = payBook.payBookId  	
	CREATE INDEX [id_IDX]                      ON #TEMP_MASK_PAYBOOK(id ASC)
	CREATE INDEX [payBookId_IDX]               ON #TEMP_MASK_PAYBOOK(payBookId ASC)
	CREATE INDEX [additionalPaymentBookId_IDX] ON #TEMP_MASK_PAYBOOK(additionalPaymentBookId ASC)       
                
    --Маска для выплат
    SELECT DISTINCT
    IDENTITY(int,1,1) id,   
    payBook.payBookId,
    mask.additionalPaymentBookId,
    mask.payCalcId,
    mask.maskPayCalcId,   
    mask.paidAmountId,
    mask.maskPaidAmountId,
    mask.realPayAmount,
    mask.realDeathPayAmount,
    mask.deathPayAmount,
    mask.persentPay,
    CASE WHEN mask.A_STATUSPRIVELEGE = @noPayAmount
		THEN 1
		ELSE 0
    END noPay 
    INTO #TEMP_MASK_PAIDAMOUNT
    FROM #TEMP_EVENT_PAYBOOK payBook    
    LEFT JOIN (	SELECT DISTINCT 
    			serv.A_PAYMENTBOOK payBookId,
				deathServ.A_PAYMENTBOOK additionalPaymentBookId,
				payCalc.OUID payCalcId,
				deathCayCalc.OUID maskPayCalcId,
				payAmount.OUID paidAmountId,
				deathPayAmount.OUID maskPaidAmountId,
				cast(payAmount.AMOUNT AS NUMERIC(18,2)) realPayAmount,
				cast(deathPayAmount.AMOUNT AS NUMERIC(18,2)) realDeathPayAmount,				
				cast(relPayAmount.AMOUNT AS NUMERIC(18,2)) deathPayAmount,				
				CASE WHEN cast(relPayAmount.AMOUNT AS NUMERIC(18,2)) = cast(deathPayAmount.AMOUNT AS NUMERIC(18,2))
					THEN 0
					ELSE 1
				END persentPay,
				payAmount.A_STATUSPRIVELEGE							
				FROM WM_PAIDAMOUNTS deathPayAmount				
				INNER JOIN WM_PAY_CALC deathCayCalc ON deathCayCalc.OUID = deathPayAmount.A_PAYCALC	
					AND (deathCayCalc.A_STATUS IS NULL OR deathCayCalc.A_STATUS = @status)
				INNER JOIN ESRN_SERV_SERV deathServ ON deathServ.OUID = deathCayCalc.A_MSP
					AND (deathServ.A_STATUS IS NULL OR deathServ.A_STATUS = @status)
								
				INNER JOIN WM_REL_PAIDAMOUNT relPayAmount ON relPayAmount.A_PAIDAMOUNT = deathPayAmount.OUID
					AND (relPayAmount.A_STATUS IS NULL OR relPayAmount.A_STATUS = @status)	
				INNER JOIN WM_PETITION petition ON	relPayAmount.A_PETITION = petition.OUID
					AND (petition.A_STATUS IS NULL OR petition.A_STATUS = @status)
				INNER JOIN ESRN_SERV_SERV serv ON serv.A_REQUEST = petition.OUID
					AND (serv.A_STATUS IS NULL OR serv.A_STATUS = @status)	
				INNER JOIN WM_PAY_CALC payCalc ON payCalc.A_MSP = serv.OUID	
					AND (payCalc.A_STATUS IS NULL OR payCalc.A_STATUS = @status)				
				INNER JOIN WM_PAIDAMOUNTS payAmount ON payCalc.OUID = payAmount.A_PAYCALC	
					AND (payAmount.A_STATUS IS NULL OR payAmount.A_STATUS = @status)
					--AND payAmount.A_STATUSPRIVELEGE = @sformPayAmount
				WHERE (deathPayAmount.A_STATUS IS NULL OR deathPayAmount.A_STATUS = @status)	
					AND deathPayAmount.A_STATUSPRIVELEGE IN( @paidPayAmount	,@noAllPayAmount,@noPayAmount,@sendPayAmount,@sformPayAmount)		
									
	)mask ON mask.payBookId = payBook.payBookId  
	CREATE INDEX [id_IDX]               ON #TEMP_MASK_PAIDAMOUNT(id ASC)
	CREATE INDEX [payBookId_IDX]               ON #TEMP_MASK_PAIDAMOUNT(payBookId ASC)
	CREATE INDEX [additionalPaymentBookId_IDX] ON #TEMP_MASK_PAIDAMOUNT(additionalPaymentBookId ASC)  
	CREATE INDEX [paidAmountId_IDX]     ON #TEMP_MASK_PAIDAMOUNT(payBookId ASC)
	CREATE INDEX [maskPaidAmountId_IDX] ON #TEMP_MASK_PAIDAMOUNT(additionalPaymentBookId ASC)    
   --Если Неоплата то еще однозначное сочеитание
    DELETE FROM #TEMP_MASK_PAIDAMOUNT 
	WHERE id NOT IN ( 	SELECT mask.id       
						FROM #TEMP_MASK_PAIDAMOUNT mask  							 	
                   		WHERE noPay = 1
						AND CASE WHEN persentPay = 1
									THEN deathPayAmount
									ELSE realDeathPayAmount
							END = realPayAmount
		
					)  
	AND noPay = 1 
   --Фильтр на размер
    DELETE FROM #TEMP_MASK_PAIDAMOUNT 
	WHERE payBookId NOT IN ( 	SELECT mask.payBookId       
								FROM #TEMP_MASK_PAIDAMOUNT mask     
								INNER JOIN (SELECT DISTINCT
											payBookId,paidAmountId,
											min(realPayAmount) realPayAmount    
											FROM #TEMP_MASK_PAIDAMOUNT 
								            WHERE noPay = 0 
											GROUP BY payBookId,paidAmountId,additionalPaymentBookId    
								) realPay ON mask.payBookId = realPay.payBookId AND mask.paidAmountId = realPay.paidAmountId 
	                           	WHERE noPay = 0
								GROUP BY mask.payBookId,mask.paidAmountId
								HAVING      sum(CASE WHEN persentPay = 1
													THEN deathPayAmount
													ELSE realDeathPayAmount
											END)= min(realPay.realPayAmount) 
	  )
	AND noPay = 0
  
  
  --Удаоление из таблицы если нет в таблице маски выплаты
  DELETE FROM #TEMP_MASK_PAYBOOK 
  WHERE ID  IN ( 	SELECT maskPayBook.ID       
					FROM #TEMP_MASK_PAYBOOK maskPayBook
					LEFT JOIN #TEMP_MASK_PAIDAMOUNT mask 
					ON maskPayBook.payBookId = mask.payBookId
						AND maskPayBook.additionalPaymentBookId = mask.additionalPaymentBookId 
                 	WHERE mask.payBookId IS NULL 
  )  


	  
	--Таблица с данными о прекращении Назначений
	SELECT
	payBook.payBookId,
	stopServ.servId,
	stopServ.A_DATE_FINISH stopServDate,
	YEAR(dateadd(day,-1,stopServ.A_DATE_FINISH)) stopYear,
	
	CASE 
		WHEN payBook.mspType = 1 THEN MONTH(dateadd(day,-1,stopServ.A_DATE_FINISH)) 
		WHEN payBook.mspType = 2 THEN 12
		WHEN payBook.mspType = 3 THEN MONTH(dateadd(day,-1,stopServ.A_DATE_FINISH)) 
		WHEN payBook.mspType = 4 THEN ((MONTH(dateadd(day,-1,stopServ.A_DATE_FINISH))-1)/3+1)*3
	END stopMonth
	
	INTO #TEMP_STOP_SERV
	FROM #TEMP_EVENT_PAYBOOK payBook	  
	INNER JOIN (SELECT
				payBook.payBookId,
				serv.OUID servId,	
				stopServ.A_TYPE,
				stopServ.A_DATE_FINISH,
				stopServ.A_DATEENDFINISH,
				ROW_NUMBER () OVER ( PARTITION BY serv.OUID ORDER BY stopServ.A_DATE_FINISH desc) num	
				FROM #TEMP_EVENT_PAYBOOK payBook
				INNER JOIN ESRN_SERV_SERV serv ON  serv.A_PAYMENTBOOK = payBook.payBookId
					AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
				INNER JOIN SPR_STOPSERV_ESRNSERVSERV linkClass ON linkClass.FROMID = serv.OUID
				INNER JOIN WM_STOP_SERVSERV stopServ ON stopServ.OUID = linkClass.TOID
					AND (stopServ.A_STATUS = @status OR stopServ.A_STATUS IS NULL) 
					AND stopServ.A_TYPE IN (10,15)
	            WHERE YEAR(stopServ.A_DATE_FINISH)*100+MONTH(stopServ.A_DATE_FINISH)<=@year*100+@month
					AND (YEAR(stopServ.A_DATEENDFINISH)*100+MONTH(stopServ.A_DATEENDFINISH)>=@year*100+@month OR stopServ.A_DATEENDFINISH IS NULL) 
  	)stopServ ON stopServ.payBookId = payBook.payBookId	
  		AND stopServ.num = 1
	LEFT JOIN ( SELECT
				payBook.payBookId,
				serv.OUID servId,	
				stopServ.A_TYPE,
				stopServ.A_DATE_FINISH,
				stopServ.A_DATEENDFINISH,
				ROW_NUMBER () OVER ( PARTITION BY serv.OUID ORDER BY stopServ.A_DATE_FINISH desc) num	
				FROM #TEMP_EVENT_PAYBOOK payBook
				INNER JOIN ESRN_SERV_SERV serv ON  serv.A_PAYMENTBOOK = payBook.payBookId
					AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
				INNER JOIN SPR_STOPSERV_ESRNSERVSERV linkClass ON linkClass.FROMID = serv.OUID
				INNER JOIN WM_STOP_SERVSERV stopServ ON stopServ.OUID = linkClass.TOID
					AND (stopServ.A_STATUS = @status OR stopServ.A_STATUS IS NULL) 
					AND stopServ.A_TYPE IN (20,30)
				WHERE YEAR(stopServ.A_DATE_FINISH)*100+MONTH(stopServ.A_DATE_FINISH)<=@year*100+@month
	)resumeServ ON resumeServ.payBookId = payBook.payBookId
	  	AND resumeServ.num = 1
		AND resumeServ.servId = stopServ.servId
		AND datediff(day,stopServ.A_DATE_FINISH,resumeServ.A_DATE_FINISH)>=1
	LEFT JOIN #TEMP_ENDMONTH endMonth ON endMonth.payBookId = payBook.payBookId
	WHERE resumeServ.servId IS NULL AND endMonth.payBookId IS NULL 
		
	CREATE INDEX [payBookId_IDX]            ON #TEMP_STOP_SERV(payBookId ASC) 
	CREATE INDEX [servId_IDX]               ON #TEMP_STOP_SERV(servId ASC) 	
		
		
	--Удержания	
	SELECT 
	dedLog.A_PAYCALC,	
	CASE WHEN ded.A_ID IS NOT NULL AND ded.A_DEDUCTION_TYPE <> 4
					THEN dedLog.A_YEAR
					ELSE NULL 
				END A_YEAR,
	CASE WHEN ded.A_ID IS NOT NULL AND ded.A_DEDUCTION_TYPE <> 4
					THEN dedLog.A_MONTH
					ELSE NULL 
	END A_MONTH,
	cast(dedLog.A_AMOUNT AS NUMERIC(18,2)) AS amount
	INTO #TEMP_DEDUCTION	
	FROM #TEMP_EVENT_PAYBOOK payBook
    INNER JOIN ESRN_SERV_SERV serv ON  serv.A_PAYMENTBOOK = payBook.payBookId
         AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
    INNER JOIN WM_PAY_CALC mainCalc ON  serv.ouid = mainCalc.A_MSP
        AND (mainCalc.A_STATUS = @status OR mainCalc.A_STATUS IS NULL)
		AND(
		   (payBook.mspType in (1,3) AND mainCalc.A_YEAR*100 + mainCalc.A_MONTH = @year*100 + @month)
		OR (payBook.mspType = 4 
			AND mainCalc.A_YEAR*100 + mainCalc.A_MONTH >= @year*100 + (@month-1)/3*3+1
			AND mainCalc.A_YEAR*100 + mainCalc.A_MONTH <= @year*100 + (@month-1)/3*3+3
			)
		OR (payBook.mspType = 2 AND mainCalc.A_YEAR = @year)							
		)
        AND mainCalc.A_STATUSPRIVELEGE IN (@servIdStatus, @sform, @udergano, @nepolVip)  
    
    LEFT JOIN WM_PAIDAMOUNTS paidAmount ON  paidAmount.A_PAYCALC = mainCalc.OUID
		AND (paidAmount.A_STATUS = @status OR paidAmount.A_STATUS IS NULL )
		AND paidAmount.A_STATUSPRIVELEGE IN( @sformPayAmount)        
        
     LEFT JOIN #TEMP_MASK_PAIDAMOUNT maskPayAmount ON maskPayAmount.payBookId = payBook.payBookId
		AND maskPayAmount.paidAmountId = paidAmount.OUID		
		
    INNER JOIN WM_PAY_CALC calc ON  calc.OUID = isnull(maskPayAmount.maskPayCalcId,mainCalc.ouid)
        AND (calc.A_STATUS = @status OR calc.A_STATUS IS NULL)    
        AND((mainCalc.A_STATUSPRIVELEGE = @sform AND paidAmount.OUID IS NOT NULL)
			OR mainCalc.A_STATUSPRIVELEGE <> @sform
        )  	
        
	INNER JOIN WM_DEDUCTION_LOG dedLog ON dedLog.A_PAYCALC = calc.OUID
	LEFT JOIN WM_DEDUCTION ded ON ded.A_ID = dedLog.A_DEDUCTION
	AND ( ded.A_STATUS = @status OR  ded.A_STATUS IS NULL)
	LEFT JOIN #TEMP_STOP_SERV stopServ ON stopServ.servId = calc.A_MSP
	WHERE ( dedLog.A_STATUS = @status OR  dedLog.A_STATUS IS NULL)
		AND(dedLog.A_YEAR*100 + dedLog.A_MONTH <= stopServ.stopYear*100+stopServ.stopMonth OR stopServ.servId IS NULL)     
	CREATE INDEX [A_PAYCALC_IDX]  ON #TEMP_DEDUCTION(A_PAYCALC ASC) 		
	  
    --Раздельные размеры для настоящего времени
    --Текущее начисление 
    SELECT DISTINCT
    payBook.payBookId,
	maskPayAmount.additionalPaymentBookId,
    serv.OUID servId,
    mainCalc.OUID calcId,    
    
    CASE WHEN maskPayAmount.persentPay = 1
		THEN maskPayAmount.deathPayAmount
		ELSE cast(calc.AMOUNT AS NUMERIC(18,2))
    END AS curTotalAmount,
    
    CASE WHEN mainCalc.A_STATUSPRIVELEGE<>@nepolVip
		THEN CASE WHEN maskPayAmount.persentPay = 1
				THEN maskPayAmount.deathPayAmount
				ELSE cast(calc.A_SUMASSIGN AS NUMERIC(18,2))
			 END  
		ELSE 0
    END     
    +     
    ISNULL(curAddPay.amount,0) AS curAmount,
    
    ISNULL(calc.A_FROMDATE,CONVERT(DATETIME,'01.' + CAST(calc.A_MONTH AS VARCHAR) + '.' + CAST(calc.A_YEAR AS VARCHAR),104)) AS curAmountStart,
    ISNULL(calc.A_TODATE,dateadd(day,-1,dateadd(month,1,CONVERT(DATETIME,'01.' + CAST(calc.A_MONTH AS VARCHAR) + '.' + CAST(calc.A_YEAR AS VARCHAR),104)))) AS curAmountEnd,     
    cast(deduct.amount AS NUMERIC(18,2)) AS curDeductAmount,
        
    CASE WHEN  mainCalc.A_STATUSPRIVELEGE<>@nepolVip
		THEN cast(addPay.amount AS NUMERIC(18,2))
		ELSE cast(isnull(mainCalc.A_RESIDUEPAY,calc.A_RESIDUEPAY) AS NUMERIC(18,2)) 
    END AS curAddPayAmount,    
    
    CASE WHEN mainCalc.A_STATUSPRIVELEGE<>@nepolVip
		THEN CASE WHEN maskPayAmount.persentPay = 1
				THEN maskPayAmount.deathPayAmount
				ELSE cast(calc.A_SUMASSIGN AS NUMERIC(18,2)) 
			 END 
		ELSE 0
    END       
    + ISNULL(curAddPay.amount,0)     
    -     
    ISNULL(curDeduct.amount,0)	
    as curRealAmount,	
	
	CASE WHEN  mainCalc.A_STATUSPRIVELEGE<>@nepolVip
		THEN cast(addPay.amount AS NUMERIC(18,2))
		ELSE cast(isnull(mainCalc.A_RESIDUEPAY,calc.A_RESIDUEPAY) AS NUMERIC(18,2)) 
    END 
	- (ISNULL(deduct.amount,0) - ISNULL(curDeduct.amount,0))
	as curAddPayRealAmount,
    addPay.startDate addStartDate,
    addPay.endDate addEndDate,    
    CASE WHEN DAY(DATEADD(DAY, 1, calc.A_TODATE))= 1 OR calc.A_TODATE IS null
             THEN 0
             ELSE 1
    END curIncompleteMonth,
    calc.A_STATUSPRIVELEGE calcState  
    INTO #TEMP_CUR_CALC
    FROM #TEMP_EVENT_PAYBOOK payBook
    INNER JOIN ESRN_SERV_SERV serv ON  serv.A_PAYMENTBOOK = payBook.payBookId
         AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
    INNER JOIN WM_PAY_CALC mainCalc ON  serv.ouid = mainCalc.A_MSP
        AND (mainCalc.A_STATUS = @status OR mainCalc.A_STATUS IS NULL)
		AND(
		   (payBook.mspType in (1,3) AND mainCalc.A_YEAR*100 + mainCalc.A_MONTH = @year*100 + @month)
		OR (payBook.mspType = 4 
			AND mainCalc.A_YEAR*100 + mainCalc.A_MONTH >= @year*100 + (@month-1)/3*3+1
			AND mainCalc.A_YEAR*100 + mainCalc.A_MONTH <= @year*100 + (@month-1)/3*3+3
			)
		OR (payBook.mspType = 2 AND mainCalc.A_YEAR = @year)							
		)
        AND mainCalc.A_STATUSPRIVELEGE IN (@servIdStatus, @sform, @udergano, @nepolVip)  
    
    LEFT JOIN WM_PAIDAMOUNTS paidAmount ON  paidAmount.A_PAYCALC = mainCalc.OUID
		AND (paidAmount.A_STATUS = @status OR paidAmount.A_STATUS IS NULL )
		AND paidAmount.A_STATUSPRIVELEGE IN( @sformPayAmount)        
        
     LEFT JOIN #TEMP_MASK_PAIDAMOUNT maskPayAmount ON maskPayAmount.payBookId = payBook.payBookId
		AND maskPayAmount.paidAmountId = paidAmount.OUID		
		
	LEFT JOIN #TEMP_STOP_SERV stopServ ON stopServ.servId = serv.OUID
        
     INNER JOIN WM_PAY_CALC calc ON  calc.OUID = isnull(maskPayAmount.maskPayCalcId,mainCalc.ouid)
        AND (calc.A_STATUS = @status OR calc.A_STATUS IS NULL)    
        AND((mainCalc.A_STATUSPRIVELEGE = @sform AND paidAmount.OUID IS NOT NULL)
			OR mainCalc.A_STATUSPRIVELEGE <> @sform
        )        
    --Доплата за прошлый период 
    LEFT JOIN ( SELECT 
				addPay.A_PAYCALC,
			    SUM(cast(addPay.A_AMOUNT AS NUMERIC(18,2))) AS amount,
			    MIN(ISNULL(addPay.A_FROMDATE,CONVERT(DATETIME,'01.' + CAST(addPay.A_MONTH AS VARCHAR) + '.' + CAST(addPay.A_YEAR AS VARCHAR),104)))startDate,
			    MAX(ISNULL(addPay.A_TODATE,dateadd(day,-1,dateadd(month,1,CONVERT(DATETIME,'01.' + CAST(addPay.A_MONTH AS VARCHAR) + '.' + CAST(addPay.A_YEAR AS VARCHAR),104))))) endDate,
                COUNT(addPay.A_PAYCALC) cnt
                FROM WM_PAY_CALC payCalc
                LEFT JOIN #TEMP_STOP_SERV stopServ ON stopServ.servId = payCalc.A_MSP
				inner join WM_ADDPAY_CALC addPay ON payCalc.OUID = addPay.A_PAYCALC
					AND (payCalc.A_STATUS = @status OR  payCalc.A_STATUS IS NULL)
					AND NOT (payCalc.A_YEAR = addPay.A_YEAR AND payCalc.A_MONTH = addPay.A_MONTH)
				WHERE  (addPay.A_STATUS = @status OR  addPay.A_STATUS IS NULL)
					AND(addPay.A_YEAR*100 + addPay.A_MONTH <= stopServ.stopYear*100+stopServ.stopMonth OR stopServ.servId IS NULL)     
				GROUP BY addPay.A_PAYCALC
    ) addPay ON  calc.OUID = addPay.A_PAYCALC 
		AND mainCalc.A_STATUSPRIVELEGE <> @nepolVip
		AND (maskPayAmount.persentPay <> 1 OR maskPayAmount.persentPay IS NULL)
    --Доплата за текущий период 
    LEFT JOIN (SELECT 
			   addPay.A_PAYCALC,
		       SUM(cast(addPay.A_AMOUNT AS NUMERIC(18,2))) AS amount,
		       addPay.A_YEAR,
		       addPay.A_MONTH
			   FROM WM_PAY_CALC payCalc  
			   INNER JOIN WM_ADDPAY_CALC addPay ON addPay.A_PAYCALC = payCalc.OUID
			   LEFT JOIN #TEMP_STOP_SERV stopServ ON stopServ.servId = payCalc.A_MSP				
			   WHERE  (addPay.A_STATUS = @status OR  addPay.A_STATUS IS NULL)
			   		AND(addPay.A_YEAR*100 + addPay.A_MONTH <= stopServ.stopYear*100+stopServ.stopMonth OR stopServ.servId IS NULL)     
			   GROUP BY addPay.A_PAYCALC,addPay.A_YEAR,addPay.A_MONTH
   ) curAddPay ON  calc.OUID = curAddPay.A_PAYCALC
		AND calc.A_YEAR = curAddPay.A_YEAR
		AND calc.A_MONTH = curAddPay.A_MONTH   
		AND mainCalc.A_STATUSPRIVELEGE <> @nepolVip
		AND (maskPayAmount.persentPay <> 1 OR maskPayAmount.persentPay IS NULL)
	
    LEFT JOIN (SELECT 
			   ded.A_PAYCALC,
			   sum(ded.amount) amount,		
			   ISNULL(ded.A_YEAR,calc.A_YEAR ) A_YEAR,
			   ISNULL(ded.A_MONTH,calc.A_MONTH ) A_MONTH
               FROM #TEMP_DEDUCTION ded
               INNER JOIN WM_PAY_CALC calc ON  calc.OUID = ded.A_PAYCALC
					AND (calc.A_STATUS = @status OR calc.A_STATUS IS NULL)                       
               GROUP BY ded.A_PAYCALC,ISNULL(ded.A_YEAR,calc.A_YEAR ),ISNULL(ded.A_MONTH,calc.A_MONTH )
	) curDeduct ON (calc.OUID = curDeduct.A_PAYCALC )
		AND	calc.A_YEAR = curDeduct.A_YEAR AND calc.A_MONTH = curDeduct.A_MONTH
		AND mainCalc.A_STATUSPRIVELEGE<>@nepolVip
		AND (maskPayAmount.persentPay <> 1 OR maskPayAmount.persentPay IS NULL)

    --Удержания для начисления
    LEFT JOIN (SELECT 
			  A_PAYCALC,
			  sum(amount) amount
			  FROM #TEMP_DEDUCTION payCalc			  
			  GROUP BY A_PAYCALC  
	) deduct ON (calc.OUID = deduct.A_PAYCALC )
		AND mainCalc.A_STATUSPRIVELEGE<>@nepolVip
		AND (maskPayAmount.persentPay <> 1 OR maskPayAmount.persentPay IS NULL)
	
    WHERE  (calc.A_YEAR*100 + calc.A_MONTH <=stopServ.stopYear*100+stopServ.stopMonth OR stopServ.servId IS NULL OR addPay.amount = calc.A_SUM_PAY_CALC)   
     

     
    CREATE INDEX [payBookId_IDX]               ON #TEMP_CUR_CALC(payBookId ASC) 
    CREATE INDEX [additionalPaymentBookId_IDX] ON #TEMP_CUR_CALC(additionalPaymentBookId ASC) 
    CREATE INDEX [servId_IDX]                  ON #TEMP_CUR_CALC(servId ASC) 
    CREATE INDEX [calcId_IDX]                  ON #TEMP_CUR_CALC(calcId ASC)    
  
	UPDATE #TEMP_CUR_CALC SET curAddPayRealAmount = curAddPayRealAmount + curRealAmount, curRealAmount = 0
	WHERE curRealAmount < 0 
		AND curAddPayRealAmount >= - curRealAmount
	
	UPDATE #TEMP_CUR_CALC SET curRealAmount = curRealAmount + curAddPayRealAmount, curAddPayRealAmount = 0
	WHERE curAddPayRealAmount < 0 
		AND curRealAmount >= -curAddPayRealAmount	
  
   --Выплаченные начисления
    SELECT DISTINCT
    payBook.payBookId,
	null additionalPaymentBookId,
    serv.OUID servId,
    ISNULL(sum(cast(paidAmount.AMOUNT AS NUMERIC(18,2))),0)-ISNULL(sum(cast(paidAmount.A_ADDPAY AS NUMERIC(18,2))),0) AS paidAmount
    INTO #TEMP_CUR_CALC_PAID
    FROM #TEMP_EVENT_PAYBOOK payBook
    INNER JOIN ESRN_SERV_SERV serv ON  serv.A_PAYMENTBOOK = payBook.payBookId
         AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
    INNER JOIN WM_PAY_CALC calc ON  serv.ouid = calc.A_MSP
        AND (calc.A_STATUS = @status OR calc.A_STATUS IS NULL)
		AND(
		   (payBook.mspType in (1,3) AND calc.A_YEAR*100 + calc.A_MONTH = @year*100 + @month)
		OR (payBook.mspType = 4 
			AND calc.A_YEAR*100 + calc.A_MONTH >= @year*100 + (@month-1)/3*3+1
			AND calc.A_YEAR*100 + calc.A_MONTH <= @year*100 + (@month-1)/3*3+3
			)
		OR (payBook.mspType = 2 AND calc.A_YEAR = @year)							
		)
        AND calc.A_STATUSPRIVELEGE IN (@sform,@nepolVip)             
	INNER JOIN WM_PAIDAMOUNTS paidAmount ON  paidAmount.A_PAYCALC = calc.OUID
		AND (paidAmount.A_STATUS = @status OR paidAmount.A_STATUS IS NULL )
		AND paidAmount.A_STATUSPRIVELEGE IN( @paidPayAmount,@sendPayAmount,@noPayAmount,@noAllPayAmount)		
   GROUP BY payBook.payBookId,serv.OUID
   CREATE INDEX [payBookId_IDX]               ON #TEMP_CUR_CALC_PAID(payBookId ASC)
   CREATE INDEX [additionalPaymentBookId_IDX] ON #TEMP_CUR_CALC_PAID(additionalPaymentBookId ASC)
   CREATE INDEX [servId_IDX]                  ON #TEMP_CUR_CALC_PAID(servId ASC)  
    --Неоплаты
	SELECT DISTINCT
	IDENTITY (INT,1,1) id,
	payBook.payBookId,
	maskPayAmount.additionalPaymentBookId,
    serv.OUID servId,
    mainCalc.OUID calcId,
    mainPaidAmount.OUID paidAmountId,    
    
    CASE WHEN maskPayAmount.persentPay = 1
		THEN ISNULL(maskPayAmount.deathPayAmount,0)
		ELSE ISNULL(cast(paidAmount.AMOUNT AS NUMERIC(18,2)),0)
	END AS  amount,	
	CASE WHEN paidAmount.A_ADDPAY>0 
		THEN  isnull(addPay.minAddDate,ISNULL(calc.A_FROMDATE,CONVERT(DATETIME,'01.' + CAST(calc.A_MONTH AS VARCHAR) + '.' + CAST(calc.A_YEAR AS VARCHAR),104)))
		ELSE ISNULL(calc.A_FROMDATE,CONVERT(DATETIME,'01.' + CAST(calc.A_MONTH AS VARCHAR) + '.' + CAST(calc.A_YEAR AS VARCHAR),104))
	END startDate,
	CASE WHEN paidAmount.A_ADDPAY>0 AND (paidAmount.AMOUNT-paidAmount.A_ADDPAY) = 0
		THEN  isnull(addPay.maxAddDate,ISNULL(calc.A_TODATE,dateadd(day,-1,dateadd(month,1,CONVERT(DATETIME,'01.' + CAST(calc.A_MONTH AS VARCHAR) + '.' + CAST(calc.A_YEAR AS VARCHAR),104)))))
		ELSE ISNULL(calc.A_TODATE,dateadd(day,-1,dateadd(month,1,CONVERT(DATETIME,'01.' + CAST(calc.A_MONTH AS VARCHAR) + '.' + CAST(calc.A_YEAR AS VARCHAR),104))))
	END endDate,
	mainPaidAmount.A_YEAR [year],
	mainPaidAmount.A_MONTH [month],
	pprServ.A_MSP_TYPE mspType
	INTO #TEMP_CUR_NEOPL
	FROM #TEMP_EVENT_PAYBOOK payBook
	INNER JOIN ESRN_SERV_SERV serv ON  serv.A_PAYMENTBOOK = payBook.payBookId
		AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
	INNER JOIN SPR_NPD_MSP_CAT mspLkNpd ON serv.A_SERV = mspLkNpd.A_ID
    	AND (mspLkNpd.A_STATUS = @status OR mspLkNpd.A_STATUS IS NULL)
    LEFT JOIN PPR_SERV pprServ ON pprServ.A_ID = mspLkNpd.A_MSP
    	AND (pprServ.A_STATUS = @status OR pprServ.A_STATUS IS NULL)		
	INNER JOIN WM_PAY_CALC mainCalc ON  mainCalc.A_MSP = serv.OUID
		AND (mainCalc.A_STATUS = @status OR mainCalc.A_STATUS  IS NULL )
		
	INNER JOIN WM_PAIDAMOUNTS mainPaidAmount ON  mainPaidAmount.A_PAYCALC = mainCalc.OUID
		AND (mainPaidAmount.A_STATUS = @status OR mainPaidAmount.A_STATUS IS NULL )
		AND mainPaidAmount.A_STATUSPRIVELEGE =  @noPayAmount	
		AND (mainPaidAmount.A_YEAR < @year OR (mainPaidAmount.A_YEAR = @year AND mainPaidAmount.A_MONTH <= @month))	

	
	LEFT JOIN #TEMP_MASK_PAIDAMOUNT maskPayAmount ON maskPayAmount.payBookId = payBook.payBookId
		AND maskPayAmount.paidAmountId = mainPaidAmount.OUID	
		
	LEFT JOIN #TEMP_STOP_SERV stopServ ON stopServ.servId = serv.OUID
	INNER JOIN WM_PAY_CALC calc ON  calc.OUID = ISNULL(maskPayAmount.maskPayCalcId,mainCalc.OUID)
		AND (calc.A_STATUS = @status OR calc.A_STATUS  IS NULL )			
		
	INNER JOIN WM_PAIDAMOUNTS paidAmount ON  paidAmount.OUID =  ISNULL(maskPayAmount.maskPaidAmountId,mainPaidAmount.OUID)
		AND (paidAmount.A_STATUS = @status OR paidAmount.A_STATUS IS NULL )							
		
	LEFT JOIN ( SELECT 
				sum(cast(addPay.A_AMOUNT AS NUMERIC(18,2))) A_AMOUNT,
				addPay.A_PAYCALC calcOuid,
				MIN(ISNULL(addPay.A_FROMDATE,CONVERT(DATETIME,'01.' + CAST(addPay.A_MONTH AS VARCHAR) + '.' + CAST(addPay.A_YEAR AS VARCHAR),104))) minAddDate,
				MAX(ISNULL(addPay.A_TODATE,dateadd(day,-1,dateadd(month,1,CONVERT(DATETIME,'01.' + CAST(addPay.A_MONTH AS VARCHAR) + '.' + CAST(addPay.A_YEAR AS VARCHAR),104)))     )) maxAddDate
				FROM  WM_PAY_CALC payCalc 
				LEFT JOIN #TEMP_STOP_SERV stopServ ON stopServ.servId = payCalc.A_MSP
				INNER JOIN WM_ADDPAY_CALC addPay ON addPay.A_PAYCALC = payCalc.OUID
				WHERE  ( addPay.A_STATUS = @status OR addPay.A_STATUS IS NULL )
					   		AND(addPay.A_YEAR*100 + addPay.A_MONTH <= stopServ.stopYear*100+stopServ.stopMonth OR stopServ.servId IS NULL)     
				GROUP BY addPay.A_PAYCALC
	)addPay ON  addPay.calcOuid = calc.OUID		
		AND (maskPayAmount.persentPay <> 1 OR maskPayAmount.persentPay IS NULL) 	
	WHERE (calc.A_YEAR*100 + calc.A_MONTH <= stopServ.stopYear*100+stopServ.stopMonth OR stopServ.servId IS NULL OR addPay.A_AMOUNT = calc.A_SUM_PAY_CALC)         
	
	CREATE INDEX [Id_IDX]                      ON #TEMP_CUR_NEOPL(Id ASC) 
	CREATE INDEX [payBookId_IDX]               ON #TEMP_CUR_NEOPL(payBookId ASC) 
	CREATE INDEX [additionalPaymentBookId_IDX] ON #TEMP_CUR_NEOPL(additionalPaymentBookId ASC) 
    CREATE INDEX [servId_IDX]                  ON #TEMP_CUR_NEOPL(servId ASC) 
    CREATE INDEX [calcId_IDX]                  ON #TEMP_CUR_NEOPL(calcId ASC) 
    CREATE INDEX [paidAmountId_IDX]            ON #TEMP_CUR_NEOPL(paidAmountId ASC)           
   
    --Начисление за прошлый период      
    SELECT DISTINCT
    payBook.payBookId,
	maskPayAmount.additionalPaymentBookId,
    serv.OUID servId,
    mainCalc.OUID calcId,    
    CASE WHEN mainCalc.A_STATUSPRIVELEGE<>@nepolVip
		THEN CASE WHEN maskPayAmount.persentPay = 1
				THEN ISNULL(maskPayAmount.deathPayAmount,0)
				ELSE cast(calc.AMOUNT AS NUMERIC(18,2)) 
			 END			
		ELSE cast(calc.A_RESIDUEPAY AS NUMERIC(18,2)) 
    END  AS amount,    

    ISNULL(calc.A_FROMDATE,CONVERT(DATETIME,'01.' + CAST(calc.A_MONTH AS VARCHAR) + '.' + CAST(calc.A_YEAR AS VARCHAR),104)) minDate,
    ISNULL(addPay.startDate, ISNULL(calc.A_FROMDATE,CONVERT(DATETIME,'01.' + CAST(calc.A_MONTH AS VARCHAR) + '.' + CAST(calc.A_YEAR AS VARCHAR),104))) addStartDate,
    calc.A_TODATE addEndDate,
    mainCalc.A_STATUSPRIVELEGE calcState  
	INTO #TEMP_CUR_OTHER_CALC		
	FROM #TEMP_EVENT_PAYBOOK payBook
	INNER JOIN ESRN_SERV_SERV serv ON  serv.A_PAYMENTBOOK = payBook.payBookId
		AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
	INNER JOIN WM_PAY_CALC mainCalc ON  mainCalc.A_MSP =  serv.OUID
		AND ( mainCalc.A_STATUS = @status OR mainCalc.A_STATUS  IS NULL)
		AND mainCalc.A_STATUSPRIVELEGE IN (@servIdStatus, @sform, @udergano, @nepolVip)  

	 LEFT JOIN WM_PAIDAMOUNTS paidAmount ON  paidAmount.A_PAYCALC = mainCalc.OUID
		 AND (paidAmount.A_STATUS = @status OR paidAmount.A_STATUS IS NULL )
		 AND paidAmount.A_STATUSPRIVELEGE IN( @sformPayAmount)        
    
    LEFT JOIN #TEMP_MASK_PAIDAMOUNT maskPayAmount ON maskPayAmount.payBookId = payBook.payBookId
		AND maskPayAmount.paidAmountId = paidAmount.OUID
		
     LEFT JOIN #TEMP_STOP_SERV stopServ ON stopServ.servId = serv.OUID
     
     INNER JOIN WM_PAY_CALC calc ON  calc.OUID = isnull(maskPayAmount.maskPayCalcId,mainCalc.ouid)
        AND (calc.A_STATUS = @status OR calc.A_STATUS IS NULL)    
			AND ((mainCalc.A_STATUSPRIVELEGE = @sform AND paidAmount.OUID IS NOT NULL)	OR mainCalc.A_STATUSPRIVELEGE <> @sform)
			AND (
				   (payBook.mspType IN (1,3) AND mainCalc.A_YEAR*100 + mainCalc.A_MONTH <= @prevYear*100 + @prevMonth)
				OR (payBook.mspType = 4 AND mainCalc.A_YEAR*100 + mainCalc.A_MONTH <= @prevQuartYear*100 + @prevQuartMonth+2)
				OR (payBook.mspType = 2 AND mainCalc.A_YEAR < @year)							
			)
   
   	LEFT JOIN (SELECT 
			   addPay.A_PAYCALC,
			   sum(cast(addPay.A_AMOUNT AS NUMERIC (18,2))) A_AMOUNT,
			   MIN(ISNULL(addPay.A_FROMDATE,CONVERT(DATETIME,'01.' + CAST(addPay.A_MONTH AS VARCHAR) + '.' + CAST(addPay.A_YEAR AS VARCHAR),104)))  startDate,
			   MAX(ISNULL(addPay.A_TODATE,dateadd(day,-1,dateadd(month,1,CONVERT(DATETIME,'01.' + CAST(addPay.A_MONTH AS VARCHAR) + '.' + CAST(addPay.A_YEAR AS VARCHAR),104)))  ))  endDate
			   FROM   WM_PAY_CALC payCalc
			   INNER JOIN WM_ADDPAY_CALC addPay ON payCalc.OUID = addPay.A_PAYCALC	
			   LEFT JOIN #TEMP_STOP_SERV stopServ ON stopServ.servId = payCalc.A_MSP		
     		   WHERE  (addPay.A_STATUS =  @status OR  addPay.A_STATUS IS NULL)
     				AND(addPay.A_YEAR*100 + addPay.A_MONTH <= stopServ.stopYear*100+stopServ.stopMonth OR stopServ.servId IS NULL)     
			   GROUP BY  addPay.A_PAYCALC
	 ) addPay ON calc.OUID =  addPay.A_PAYCALC AND mainCalc.A_STATUSPRIVELEGE<>@nepolVip    
		AND (maskPayAmount.persentPay <> 1 OR maskPayAmount.persentPay IS NULL)	
     WHERE (calc.A_YEAR*100 + calc.A_MONTH <= stopServ.stopYear*100+stopServ.stopMonth OR stopServ.servId IS NULL OR addPay.A_AMOUNT = calc.A_SUM_PAY_CALC)         

	 CREATE INDEX [payBookId_IDX]               ON #TEMP_CUR_OTHER_CALC(payBookId ASC) 
	 CREATE INDEX [additionalPaymentBookId_IDX] ON #TEMP_CUR_OTHER_CALC(additionalPaymentBookId ASC) 
	 CREATE INDEX [servId_IDX]                  ON #TEMP_CUR_OTHER_CALC(servId ASC) 
	 CREATE INDEX [calcId_IDX]                  ON #TEMP_CUR_OTHER_CALC(calcId ASC)       




	--Выплаченные начисления в прошлом периоде
	SELECT 
	payBook.payBookId,
	ISNULL(SUM(deduct.amount), 0) prevDeductAmount,
	ISNULL(COUNT(DISTINCT calc.OUID), 0) prevCalcCount
	INTO #TEMP_PREV_PAID_CALC
	FROM #TEMP_EVENT_PAYBOOK payBook
	INNER JOIN #CUR_EVENT_STATE curState	ON curState.payBookId = payBook.payBookId
		AND curState.longPay = 1 AND curState.activePay = 1
		AND curState.eventDate < @limitDateEvent 	
	INNER JOIN   ESRN_SERV_SERV serv ON payBook.payBookId = serv.A_PAYMENTBOOK
		AND (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)
	LEFT JOIN WM_PAY_CALC calc ON  serv.ouid = calc.A_MSP
		AND (calc.A_STATUS = @status OR calc.A_STATUS IS NULL)				
		AND(
			   (payBook.mspType = 1 AND calc.A_YEAR*100 + calc.A_MONTH = @prevYear*100 + @prevMonth)
			OR (payBook.mspType = 4 
				AND calc.A_YEAR*100 + calc.A_MONTH >= @prevQuartYear*100 + @prevQuartMonth
				AND calc.A_YEAR*100 + calc.A_MONTH <= @prevQuartYear*100 + @prevQuartMonth+2
				)
			OR (payBook.mspType = 2 AND calc.A_YEAR = (@year-1) )							
		)
		AND calc.A_STATUSPRIVELEGE IN (@servIdStatus, @sform, @udergano, @nepolVip)

	LEFT JOIN (SELECT 
			  A_PAYCALC,
			  A_YEAR,
			  A_MONTH,
			  SUM(cast(A_AMOUNT AS NUMERIC(18,2))) AS amount
			  FROM   WM_DEDUCTION_LOG
			  WHERE  (A_STATUS = @status OR  A_STATUS IS NULL)
			  GROUP BY A_PAYCALC,A_YEAR,A_MONTH
	) deduct ON  (calc.OUID = deduct.A_PAYCALC)
		AND calc.A_YEAR = deduct.A_YEAR
		AND calc.A_MONTH = deduct.A_MONTH	  	
	GROUP BY payBook.payBookId	
	CREATE INDEX [payBookId_IDX]               ON #TEMP_PREV_PAID_CALC(payBookId ASC)         
   --Удаление размеров для мертвых людей
   DELETE FROM #TEMP_CUR_NEOPL      WHERE payBookId IN (SELECT deathPc.payBookId FROM #DEATH_PC deathPc)
   DELETE FROM #TEMP_CUR_OTHER_CALC WHERE payBookId IN (SELECT deathPc.payBookId FROM #DEATH_PC deathPc)
   DELETE FROM #TEMP_CUR_CALC_PAID  WHERE payBookId IN (SELECT deathPc.payBookId FROM #DEATH_PC deathPc)
   DELETE FROM #TEMP_CUR_CALC       WHERE payBookId IN (SELECT deathPc.payBookId FROM #DEATH_PC deathPc) 
   DELETE FROM #TEMP_PREV_PAID_CALC WHERE payBookId IN (SELECT deathPc.payBookId FROM #DEATH_PC deathPc) 
   
   
	--Таблица с невыплаченной суммой   
	SELECT 
	neopl.id,  
	neopl.amount,  
	noPayEvent.A_UNPAYMENT realAmount,
	noPayEvent.A_OUID noPayEventId
	INTO #TEMP_TABLE_NOPAYEVENT  
	FROM #TEMP_CUR_NEOPL neopl
	INNER JOIN WM_PAY_EVENT_UNIT payEventUnit ON payEventUnit.A_PAYMENT_BOOK = neopl.payBookId
	AND (payEventUnit.A_ADDIT_PAYMENT_BOOK = neopl.additionalPaymentBookId  OR (payEventUnit.A_ADDIT_PAYMENT_BOOK IS NULL AND  neopl.additionalPaymentBookId IS NULL)) 
		AND (payEventUnit.A_STATUS = @status OR payEventUnit.A_STATUS IS NULL)
	INNER JOIN WM_PAY_EVENT_UNIT_VZAMEN noPayEvent ON payEventUnit.A_OUID = noPayEvent.A_OUID

	INNER JOIN WM_PAY_EVENT payEvent ON payEventUnit.A_EVENT = payEvent.A_OUID
		AND (payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL)  
	WHERE (neopl.[YEAR] * 100 + neopl.[MONTH]) <= YEAR(payEvent.A_EVENT_DATE) * 100 +  MONTH(payEvent.A_EVENT_DATE)
		AND neopl.startDate >= noPayEvent.A_NO_PAY_START
		AND neopl.endDate <= noPayEvent.A_NO_PAY_END 
	CREATE INDEX [id_IDX]               ON #TEMP_TABLE_NOPAYEVENT(id ASC)  
	CREATE INDEX [noPayEventId_IDX]     ON #TEMP_TABLE_NOPAYEVENT(noPayEventId ASC)  
	
	INSERT INTO #TEMP_TABLE_NOPAYEVENT(id,amount,realAmount,noPayEventId)
	SELECT 
	neopl.id,  
	neopl.amount,  
	newServ.A_R1 realAmount,
	newServ.A_OUID noPayEventId	   
	FROM #TEMP_CUR_NEOPL neopl
	INNER JOIN WM_PAY_EVENT_UNIT payEventUnit ON payEventUnit.A_PAYMENT_BOOK = neopl.payBookId
		AND (payEventUnit.A_STATUS = @status OR payEventUnit.A_STATUS IS NULL)
	INNER JOIN WM_PAY_EVENT_UNIT_NEWSERV newServ ON payEventUnit.A_OUID = newServ.A_OUID
	INNER JOIN WM_PAY_EVENT payEvent ON payEventUnit.A_EVENT = payEvent.A_OUID
		AND (payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL)  
	WHERE (neopl.[YEAR] * 100 + neopl.[MONTH]) = YEAR(payEvent.A_EVENT_DATE) * 100 +  MONTH(payEvent.A_EVENT_DATE)
		AND neopl.startDate >= newServ.A_ADD_PAY_START
		AND neopl.endDate <= newServ.A_ADD_PAY_END 
		AND payEvent.A_EVENT_TYPE = @payStartSingle
	--Удаление паразитного размера
	DELETE FROM #TEMP_TABLE_NOPAYEVENT 
	WHERE noPayEventId NOT IN (SELECT noPayEventId
							   FROM #TEMP_TABLE_NOPAYEVENT neopl
							   GROUP BY noPayEventId
							   HAVING MIN(realAmount) = SUM(amount) 
							   )
 
   
    --Таблицы с детализированной суммом
    --начисление на текущий месяц+доплаты
    INSERT INTO WM_PAY_TEMPDATA_DETAILS (payBookId,additionalPaymentBookId,payCalcId, payAmount,addPayAmount,paidAmountId)
    SELECT  
    curCalc.payBookId,
    curCalc.additionalPaymentBookId,
	curCalc.calcId  payCalcId,
	sum(ISNULL(curCalc.curRealAmount, 0)) payAmount,
    sum(ISNULL(curCalc.curAddPayRealAmount, 0))  addPayAmount,
    paidAmount.OUID
    FROM #TEMP_CUR_CALC curCalc
    LEFT JOIN WM_PAIDAMOUNTS paidAmount ON  paidAmount.A_PAYCALC = curCalc.calcId
		 AND (paidAmount.A_STATUS = @status OR paidAmount.A_STATUS IS NULL )
		 AND paidAmount.A_STATUSPRIVELEGE IN( @sformPayAmount)   
		 AND curCalc.calcState = @sform
	GROUP BY    curCalc.payBookId,
				curCalc.additionalPaymentBookId,
				curCalc.calcId ,
				paidAmount.OUID
     --Неоплаты
    INSERT INTO WM_PAY_TEMPDATA_DETAILS(payBookId,additionalPaymentBookId,payCalcId,paidAmountId,noPayAmount)
    SELECT 
    neopl.payBookId payBookId,
    neopl.additionalPaymentBookId,
    neopl.calcId payCalcId,
    neopl.paidAmountId,
    SUM(ISNULL(cast(neopl.amount AS NUMERIC(18,2)),0)) curNeopl
    FROM #TEMP_CUR_NEOPL neopl    
	GROUP BY neopl.payBookId,neopl.additionalPaymentBookId,neopl.calcId,neopl.paidAmountId
	--Начисление за прошлый месяц
    INSERT INTO WM_PAY_TEMPDATA_DETAILS(payBookId,additionalPaymentBookId,payCalcId,addPayAmount,paidAmountId)
    SELECT 
    otherCalc.payBookId,
    otherCalc.additionalPaymentBookId,
	otherCalc.calcId  payCalcId,
	sum(ISNULL(otherCalc.amount, 0)) addPayAmount,
    paidAmount.OUID
    FROM #TEMP_CUR_OTHER_CALC otherCalc   
    LEFT JOIN WM_PAIDAMOUNTS paidAmount ON  paidAmount.A_PAYCALC = otherCalc.calcId
		 AND (paidAmount.A_STATUS = @status OR paidAmount.A_STATUS IS NULL )
		 AND paidAmount.A_STATUSPRIVELEGE IN( @sformPayAmount)    
		 AND otherCalc.calcState = @sform
    GROUP BY    otherCalc.payBookId,
				otherCalc.additionalPaymentBookId,
				otherCalc.calcId ,
				paidAmount.OUID
	
		
		 
	DECLARE 
	@payAmountType   INT,--Основная сумма	
	@addAmountType   INT,--Доплата	
	@noPayAmountType INT,--Неоплата
	@payPrevAmount   INT,--Предыдущий выплачивыемый размер
	@paidAmountType  INT --Выплачиваемый размер	
	
	SELECT @payAmountType   = a_ouid FROM SPR_PAY_AMOUNT WHERE A_CODE = '01'  --Основная сумма	
	SELECT @addAmountType   = a_ouid FROM SPR_PAY_AMOUNT WHERE A_CODE = '03'  --Доплата	
	SELECT @noPayAmountType = a_ouid FROM SPR_PAY_AMOUNT WHERE A_CODE = '04'  --Неоплата
	SELECT @payPrevAmount   = a_ouid FROM SPR_PAY_AMOUNT WHERE A_CODE = '11'  --Предыдущий выплачивыемый размер	
	SELECT @paidAmountType  = a_ouid FROM SPR_PAY_AMOUNT WHERE A_CODE = '10'  --Выплачиваемый размер		 
	--Создание временной таблицы
	IF OBJECT_ID('dbo.WM_PAY_TEMPDATA_AMOUNT', 'U') IS NOT NULL
	BEGIN
	     DROP TABLE WM_PAY_TEMPDATA_AMOUNT
	END
	 CREATE TABLE WM_PAY_TEMPDATA_AMOUNT(
	    	id            INT IDENTITY(1, 1)PRIMARY KEY CLUSTERED,	--Идентификатор	    	
	    	payBookId     INT,	          --Выплатное дело
			additionalPaymentBookId INT,  --Дополнительное выплатное дело	    	
	    	
			payAmount      NUMERIC(18, 2),	--размер назначения
	    	payAmountStart DATETIME,        --дата начала основного размера
	    	payAmountEnd   DATETIME,        --дата окончания основного размера
	    	
	    	payAmountType  INT,  --Тип размера
	    	eventType      INT,	--тип события
			eventUnitId    INT,	 --субъект события	    	
	    	
    )	    
    CREATE INDEX [payBookId_IDX]               ON WM_PAY_TEMPDATA_AMOUNT(payBookId               ASC)
    CREATE INDEX [additionalPaymentBookId_IDX] ON WM_PAY_TEMPDATA_AMOUNT(additionalPaymentBookId ASC)
    CREATE INDEX [payAmountType_IDX]           ON WM_PAY_TEMPDATA_AMOUNT(payAmountType           ASC)	
    
     
     
    /**
    * Заполнение таблице с размерами
    **/
    INSERT INTO WM_PAY_TEMPDATA_AMOUNT(payBookId,additionalPaymentBookId,payAmount,payAmountStart,payAmountEnd,payAmountType)
    --Основной размер
    SELECT payBookId,additionalPaymentBookId,curRealAmount,curAmountStart,curAmountEnd,@addAmountType     
    FROM #TEMP_CUR_CALC WHERE curRealAmount > 0   
    UNION ALL
    --Доплата 
    SELECT payBookId,additionalPaymentBookId,curAddPayRealAmount,addStartDate,addEndDate,@addAmountType     
    FROM #TEMP_CUR_CALC WHERE curAddPayRealAmount > 0
    UNION ALL 
    SELECT payBookId,additionalPaymentBookId,amount,addStartDate,addEndDate,@addAmountType 
    FROM #TEMP_CUR_OTHER_CALC WHERE amount > 0
    UNION ALL 
    --Проставляем прошлый размер
    SELECT 
	curState.payBookId,NULL,
	curState.curAmount amount,curState.amountStart startDate,DATEADD(DAY, -1, @eventDate) endDate,@payPrevAmount
	FROM   #CUR_EVENT_STATE curState		  
	WHERE curState.eventDate < @limitDateEvent AND curState.longPay = 1 AND curState.activePay = 1
	UNION ALL 
	--Неоплата
	SELECT payBookId,additionalPaymentBookId,amount,startDate,endDate,@noPayAmountType
	FROM  #TEMP_CUR_NEOPL neopl
	WHERE neopl.amount > 0
	UNION ALL 
	--Проставляем выплаченный размер
	SELECT 
	calc.payBookId,	
	calc.additionalPaymentBookId,
	ISNULL(calc.curRealAmount,0) amount,
	ISNULL(curState.amountStart,payBook.payStart) startDate,
	payBook.payEnd endDate,
	@paidAmountType				
	FROM  #TEMP_CUR_CALC calc	
	INNER JOIN #TEMP_EVENT_PAYBOOK payBook ON payBook.payBookId = calc.payBookId
	left JOIN #CUR_EVENT_STATE curState ON curState.payBookId = calc.payBookId
		AND (curState.additionalPaymentBookId = calc.additionalPaymentBookId OR (curState.additionalPaymentBookId IS NULL AND calc.additionalPaymentBookId IS NULL))
		AND curState.longPay = 1 AND curState.activePay = 1	
	WHERE calc.curRealAmount > 0
	UNION ALL 								        
	SELECT 	
	paid.payBookId,null,
	paid.paidAmount paidAmount,
	ISNULL(curState.amountStart,payBook.payStart) startDate,payBook.payEnd endDate,
	@paidAmountType
	FROM #TEMP_CUR_CALC_PAID paid
	INNER JOIN #TEMP_EVENT_PAYBOOK payBook ON payBook.payBookId = paid.payBookId
	LEFT JOIN #CUR_EVENT_STATE curState ON curState.payBookId = paid.payBookId
		AND (curState.additionalPaymentBookId = paid.additionalPaymentBookId OR (curState.additionalPaymentBookId IS NULL AND paid.additionalPaymentBookId IS NULL))
		AND curState.longPay = 1 AND curState.activePay = 1	
	WHERE paid.paidAmount > 0
	
     
		 
    --Временная таблица для определения размеров выплат 
    SELECT 
    payBook.payBookId,
    mask.additionalPaymentBookId,
	ISNULL(SUM(curState.curAmount), 0)  prevRealAmount,
	--MIN(curState.amountStart)           prevPayStart,
      
	ISNULL(SUM(calc.curTotalAmount), 0) curTotalAmount,
	ISNULL(SUM(noPay.noPayAmount)  , 0) curNoPayAmount,	
	ISNULL(SUM(paid.paidAmount)    , 0) curPaidAmount,
	ISNULL(SUM(calc.curRealAmount) , 0) curRealAmount,
	ISNULL(SUM(calc.curAmount)     , 0) curAmount,
	
	MIN(calc.curAmountStart)            curAmountStart,--?
	MAX(calc.curAmountEnd)              curAmountEnd,--?
	
	ISNULL(SUM(calc.curDeductAmount)   , 0) curDeductAmount,
	ISNULL(SUM(calc.curAddPayAmount)   , 0) curAddPayAmount,
	ISNULL(SUM(calc.curCalcCount)      , 0) curCalcCount,
	ISNULL(MAX(calc.curIncompleteMonth), 0) curIncompleteMonth,
	
	
	
	ISNULL(SUM(calc.curAddPayRealAmount), 0) + ISNULL(SUM(otherCalc.amount), 0) curAddPayRealAmount,
	
	CASE WHEN MIN(otherCalc.addStartDate) < MIN(calc.addStartDate) OR MIN(calc.addStartDate) IS null
		THEN MIN(otherCalc.addStartDate)
		ELSE MIN(calc.addStartDate)
	end curaddPayStart,--?
	CASE WHEN MAX(calc.addEndDate)>MAX(otherCalc.addEndDate) OR MIN(otherCalc.addEndDate) IS null
		THEN MAX(calc.addEndDate)
		ELSE MAX(otherCalc.addEndDate)
	end curaddPayEnd,--?
	
	
	
	MIN(ISNULL(otherCalc.minDate, calc.curAmountStart)) curMinDate--?
	INTO #TEMP_EVENT_AMOUNT
    FROM #TEMP_EVENT_PAYBOOK payBook    
    LEFT JOIN #TEMP_MASK_PAYBOOK mask ON payBook.payBookId = mask.payBookId
	LEFT JOIN #CUR_EVENT_STATE curState	ON curState.payBookId = payBook.payBookId
		AND curState.eventDate < @limitDateEvent	
		AND curState.longPay = 1 AND curState.activePay = 1
    LEFT JOIN (SELECT 
			   payBookId,
			   additionalPaymentBookId,
			   SUM(curTotalAmount) AS curTotalAmount,
			   SUM(curAmount) AS curAmount,						   
			   SUM(curRealAmount) curRealAmount,
			   SUM(curAddPayRealAmount) curAddPayRealAmount,							   
			   MIN(curAmountStart)AS curAmountStart,
			   MAX(curAmountEnd)AS curAmountEnd,  
			   MAX(curIncompleteMonth) curIncompleteMonth,
			   SUM(curDeductAmount) AS curDeductAmount,
			   COUNT(DISTINCT calcId) curCalcCount,
			   SUM(curAddPayAmount) AS curAddPayAmount,
			   MIN(addStartDate) addStartDate,
			   MAX(addEndDate) addEndDate						     
			   FROM #TEMP_CUR_CALC calc
			   GROUP BY payBookId,additionalPaymentBookId
     ) calc ON  calc.payBookId = payBook.payBookId    
				AND (calc.additionalPaymentBookId = mask.additionalPaymentBookId OR (calc.additionalPaymentBookId IS NULL AND mask.additionalPaymentBookId  IS NULL))
	LEFT JOIN(	SELECT
				payBookId,
				additionalPaymentBookId,
   				MIN(otherCalc.minDate) minDate,
				SUM(otherCalc.amount) AS amount,
				MIN(otherCalc.addStartDate) addStartDate,
				MAX(otherCalc.addEndDate) addEndDate
   				FROM #TEMP_CUR_OTHER_CALC otherCalc
   				GROUP BY payBookId,additionalPaymentBookId	
	) otherCalc ON otherCalc.payBookId = payBook.payBookId
				AND (otherCalc.additionalPaymentBookId = mask.additionalPaymentBookId OR (otherCalc.additionalPaymentBookId IS NULL AND mask.additionalPaymentBookId  IS NULL))

	LEFT JOIN (	SELECT 
   				payBookId,
   				additionalPaymentBookId,
   				SUM(paid.paidAmount) paidAmount
   				FROM #TEMP_CUR_CALC_PAID paid
   				GROUP BY payBookId,additionalPaymentBookId			   
	) paid ON paid.payBookId = payBook.payBookId
				AND (paid.additionalPaymentBookId = mask.additionalPaymentBookId OR (paid.additionalPaymentBookId IS NULL AND mask.additionalPaymentBookId  IS NULL))

	LEFT JOIN (	SELECT 
   				payBookId,
   				additionalPaymentBookId,
   				SUM(noPay.amount) noPayAmount
   				FROM #TEMP_CUR_NEOPL noPay
   				GROUP BY payBookId,additionalPaymentBookId			   
	) noPay ON noPay.payBookId = payBook.payBookId	
				AND (noPay.additionalPaymentBookId = mask.additionalPaymentBookId OR (noPay.additionalPaymentBookId IS NULL AND mask.additionalPaymentBookId  IS NULL))

	WHERE (curState.payBookId  is not null or calc.payBookId is not null or otherCalc.payBookId is NOT NULL OR paid.payBookId is NOT NULL OR noPay.payBookId IS NOT NULL)	
	
    GROUP BY payBook.payBookId, mask.additionalPaymentBookId
    CREATE INDEX [payBookId_IDX] ON #TEMP_EVENT_AMOUNT(payBookId ASC)
    CREATE INDEX [additionalPaymentBookId_IDX] ON #TEMP_EVENT_AMOUNT(additionalPaymentBookId ASC)
	
	--создание нового назначения
    INSERT INTO WM_PAY_TEMPDATA(payBookId,additionalPaymentBookId,eventType)
    SELECT DISTINCT
    payBook.payBookId,amount.additionalPaymentBookId,
	CASE 
		WHEN (endMonthReal.payBookId IS NOT NULL AND @regMode = 3 AND amount.curAmount > 0 AND amount.curPaidAmount > 0)
			THEN @payStartSingle
		WHEN    (payBook.mspType IN (1,2,4) OR amount.additionalPaymentBookId IS NOT NULL)
			AND amount.curRealAmount > 0
			AND (NOT (curState.payBookId IS NULL AND amount.curRealAmount > 0 AND datediff(month,@limitDateEvent,payBook.payEnd) = 0 AND day(DATEADD(DAY,1,payBook.payEnd)) <> 1 ) OR payBook.payEnd IS NULL ) 
			THEN @payStart			
		WHEN   (payBook.mspType = 3 AND amount.curRealAmount > 0)
			OR (ISNULL(amount.curRealAmount,0) = 0 AND amount.curAddPayRealAmount > 0)
			OR (curState.payBookId IS NULL AND amount.curRealAmount > 0 AND  datediff(month,@limitDateEvent,payBook.payEnd) = 0 AND day(DATEADD(DAY,1,payBook.payEnd)) <> 1 )
			OR (amount.additionalPaymentBookId IS NOT NULL AND amount.curNoPayAmount > 0  )						
			THEN @payStartSingle
		WHEN   ((ISNULL(amount.curRealAmount,0) + ISNULL(amount.curAddPayRealAmount,0) = 0)		AND prevEvent.A_PAYMENT_BOOK IS NULL AND amount.curNoPayAmount > 0)			
			THEN @payStartSingleNoPay
    END payEvent         
    FROM   #TEMP_EVENT_PAYBOOK payBook    
    LEFT JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = payBook.payBookId
         AND curState.eventDate < @limitDateEvent   
         AND curState.longPay = 1 AND curState.activePay = 1   
    INNER JOIN #TEMP_EVENT_AMOUNT amount ON  payBook.payBookId = amount.payBookId
    LEFT JOIN #TEMP_ENDMONTH_REAL endMonthReal ON endMonthReal.payBookId = payBook.payBookId	  
    LEFT JOIN (    	
    	SELECT DISTINCT WM_PAY_EVENT_UNIT.A_PAYMENT_BOOK
		FROM   WM_PAY_EVENT
		INNER JOIN WM_PAY_EVENT_UNIT ON  WM_PAY_EVENT_UNIT.A_EVENT = WM_PAY_EVENT.A_OUID
			AND (WM_PAY_EVENT_UNIT.A_STATUS = @status OR WM_PAY_EVENT_UNIT.A_STATUS IS NULL )
		WHERE  (WM_PAY_EVENT.A_STATUS = @status OR WM_PAY_EVENT.A_STATUS IS NULL )	
			AND WM_PAY_EVENT.A_EVENT_DATE < @eventDate	
    ) prevEvent ON prevEvent.A_PAYMENT_BOOK = payBook.payBookId	 
    
	--Удаление не ликвидных событий
	DELETE FROM WM_PAY_TEMPDATA 
	WHERE id IN  (  SELECT  tempEvent.id 
					FROM  WM_PAY_TEMPDATA tempEvent
					LEFT JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = tempEvent.payBookId
						 AND curState.eventDate < @limitDateEvent   
						 AND curState.longPay = 1 AND curState.activePay = 1
					WHERE NOT (curState.payBookId IS NULL      
								 OR tempEvent.eventType = @payStartSingle 
								 OR tempEvent.eventType = @payStartSingleNoPay)
	)
	--Смена размера  		    	
	IF @usePredicte = 1
	BEGIN
		
		--актуализация события прогнозируемое изминение суммы
		SELECT DISTINCT payUnit.A_OUID eventUnitId
		INTO #TEMP_OBJECT_PREDICTE_DELETE		
		FROM WM_PAY_EVENT payEvent	
			 INNER JOIN WM_PAY_EVENT_UNIT payUnit ON payUnit.A_EVENT = payEvent.A_OUID
		 			AND(payUnit.A_STATUS = @status OR payUnit.A_STATUS IS NULL )  
		WHERE payEvent.A_EVENT_DATE > @limitDateEvent
			AND datediff(day,payEvent.A_EVENT_REGDATE,GETDATE())>0
			AND payEvent.A_EVENT_TYPE = @changeSizePredicte	
			AND(payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL ) 
			
		--Удаление прогнозируемых событий
		DELETE FROM WM_PAY_EVENT_UNIT WHERE A_OUID IN (SELECT eventUnitId FROM #TEMP_OBJECT_PREDICTE_DELETE)		
		DELETE FROM WM_PAY_EVENT_UNIT_NEW_SIZE WHERE A_OUID IN (SELECT eventUnitId FROM #TEMP_OBJECT_PREDICTE_DELETE)
		
		DROP TABLE #TEMP_OBJECT_PREDICTE_DELETE	
		
		
		
		
		CREATE TABLE #PERIODS ([YEAR] INT, [MONTH] INT, [DATE] DATETIME)
		DECLARE @pMonth int
		SET @pMonth = @month		
		WHILE (@pMonth <= 12)
		BEGIN
				INSERT INTO #PERIODS ([YEAR], [MONTH], [DATE])
				VALUES(@year, @pMonth, CONVERT(DATETIME, '01.' + CAST(@pMonth AS VARCHAR) +
					   '.' + CAST(@year AS VARCHAR), 104))
				SET @pMonth = @pMonth + 1					
		END			    		

   		
	  INSERT INTO WM_PAY_TEMPDATA(payBookId,payAmount,payPrevAmount,
			eventType,PRIORITY,eventDate,payPrevStart,payPrevEnd)	 
	   SELECT DISTINCT payBook.payBookId,	    
        curPeriod.amount curPeriod,
		prevPeriod.amount prevPeriod,                       
        @changeSizePredicte,
        50 PRIORITY ,
        p.DATE eventDate,		        
        ISNULL(curState.amountStart,payBook.payStart) payPrevStart,
        DATEADD(DAY,-1,p.DATE) payPrevEnd
		FROM #TEMP_EVENT_PAYBOOK payBook	
		
		INNER JOIN (
		   SELECT 
			serv.A_PAYMENTBOOK payBookId,
			period.[YEAR],
			period.[MONTH],
			SUM(A_AMOUNT) amount 
			FROM ESRN_SERV_SERV serv 
			INNER JOIN WM_SERV_AMOUNT servPayAmount ON  serv.OUID = servPayAmount.A_MSP 
				AND(servPayAmount.A_STATUS = @status OR servPayAmount.A_STATUS IS NULL)
			INNER JOIN #PERIODS period 
			ON datediff(day,servPayAmount.A_DATESTART,period.DATE)>=0
				AND (datediff(day,period.DATE,servPayAmount.A_DATELAST)>=0 OR servPayAmount.A_DATELAST IS null)				
			WHERE (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)					
			GROUP BY serv.A_PAYMENTBOOK,period.[YEAR],period.[MONTH]
		)prevPeriod ON prevPeriod.payBookId = payBook.payBookId			
		INNER JOIN (
		   SELECT 
			serv.A_PAYMENTBOOK payBookId,
			period.[YEAR],
			period.[MONTH],
			SUM(A_AMOUNT) amount 
			FROM ESRN_SERV_SERV serv 
			INNER JOIN WM_SERV_AMOUNT servPayAmount ON  serv.OUID = servPayAmount.A_MSP 
				AND(servPayAmount.A_STATUS = @status OR servPayAmount.A_STATUS IS NULL)
			INNER JOIN #PERIODS period 
			ON datediff(day,servPayAmount.A_DATESTART,period.DATE)>=0
				AND (datediff(day,period.DATE,servPayAmount.A_DATELAST)>=0 OR servPayAmount.A_DATELAST IS null)				
			WHERE (serv.A_STATUS = @status OR serv.A_STATUS IS NULL)					
			GROUP BY serv.A_PAYMENTBOOK,period.[YEAR],period.[MONTH]
		)curPeriod ON curPeriod.payBookId = payBook.payBookId		
		--
		INNER JOIN #PERIODS p ON p.[MONTH]>1
			AND prevPeriod.[MONTH]=p.[MONTH]-1
			AND curPeriod.[MONTH] = p.[MONTH]
			AND prevPeriod.amount <> curPeriod.amount	
		left JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = payBook.payBookId
			AND curState.eventDate < @limitDateEvent
			AND curState.longPay = 1 AND curState.activePay = 1
		WHERE   EXISTS(	SELECT cond.payBookId
						FROM #TEMP_EVENT_AMOUNT cond
						WHERE cond.payBookId = payBook.payBookId
							AND cond.curRealAmount > 0)								
		
	END     	
	
    --Изменение количественного состава назначения
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,PRIORITY)
    SELECT DISTINCT amount.payBookId,                   
           @changeSizeCount,10
    FROM   #TEMP_EVENT_AMOUNT amount
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = amount.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    LEFT JOIN #TEMP_PREV_PAID_CALC prevPaidCalc ON prevPaidCalc.payBookId = amount.payBookId   
        WHERE  amount.curRealAmount > 0
           AND amount.prevRealAmount > 0
           AND amount.curRealAmount <> amount.prevRealAmount
           AND ISNULL(amount.curPaidAmount,0) = 0
           AND prevPaidCalc.prevCalcCount <> amount.curCalcCount
           AND prevPaidCalc.prevCalcCount > 0
    GROUP BY amount.payBookId
    --Изменение за неполный месяц
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,PRIORITY)
    SELECT DISTINCT amount.payBookId,                
           @changeSizePartMonth,20
    FROM   #TEMP_EVENT_AMOUNT amount
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = amount.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    WHERE      amount.prevRealAmount <> amount.curRealAmount
           AND amount.curRealAmount > 0
           AND ISNULL(amount.curPaidAmount,0) = 0
           AND amount.prevRealAmount > 0
           AND amount.curIncompleteMonth = 1
    GROUP BY amount.payBookId
    --Удержание
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,PRIORITY)
    SELECT DISTINCT amount.payBookId,                
           @changeSizeDeduction,30
    FROM   #TEMP_EVENT_AMOUNT amount
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = amount.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    LEFT JOIN #TEMP_PREV_PAID_CALC prevPaidCalc ON prevPaidCalc.payBookId = amount.payBookId
    WHERE      amount.curRealAmount > 0
           AND amount.prevRealAmount > 0
           AND ISNULL(amount.curPaidAmount,0) = 0
           AND amount.prevRealAmount <> amount.curRealAmount
           AND ((amount.curDeductAmount) > 0)
           AND ISNULL(prevPaidCalc.prevDeductAmount,0) <> amount.curDeductAmount
    GROUP BY amount.payBookId
    --Доплата
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,PRIORITY)
    SELECT DISTINCT amount.payBookId,@changeSizeAddPay,35
    FROM   #TEMP_EVENT_AMOUNT amount
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = amount.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    WHERE      amount.curTotalAmount > 0
           AND amount.prevRealAmount > 0
           AND amount.curAddPayRealAmount > 0
           AND amount.curRealAmount > 0
    GROUP BY amount.payBookId

    --Перерасчет
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,PRIORITY)
    SELECT DISTINCT amount.payBookId,@changeSizeOther,   40
    FROM   #TEMP_EVENT_AMOUNT amount
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = amount.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    WHERE      amount.curRealAmount <> amount.prevRealAmount
           AND amount.curRealAmount > 0
           AND ISNULL(amount.curPaidAmount,0) = 0
           AND amount.prevRealAmount > 0
    GROUP BY amount.payBookId
	--Перерасчет в 1-м выпл.периоде
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,PRIORITY)
    SELECT DISTINCT amount.payBookId,@changeSizeInnerPeriod,   1
    FROM   #TEMP_EVENT_AMOUNT amount
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = amount.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    WHERE  
      --    amount.prevRealAmount <> ISNULL(amount.curPaidAmount,0) + ISNULL(amount.curRealAmount,0)
      -- AND 
       amount.curRealAmount > 0
       AND ISNULL(amount.curPaidAmount,0) > 0
       AND amount.prevRealAmount > 0
    GROUP BY amount.payBookId
    

	--Смена года
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType)
    SELECT DISTINCT amount.payBookId,@changeMonth
    FROM #TEMP_EVENT_AMOUNT amount
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = amount.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    WHERE  amount.prevRealAmount = amount.curTotalAmount
           AND amount.curRealAmount > 0
           AND @month = 1
    GROUP BY amount.payBookId
	--Изменение личных данных
    INSERT INTO WM_PAY_TEMPDATA(payBookId,ouidOld,ouidNew,class,eventType,PRIORITY)
    SELECT DISTINCT payBook.payBookId,   
           CASE 
                WHEN payEvent.A_OUID in (@changePcFIO) THEN curState.A_FIO
                WHEN payEvent.A_OUID in (@changePcAddress) THEN curState.A_ADDRESS
                WHEN payEvent.A_OUID in (@changePcDoc) THEN curState.A_ID_DOC
                WHEN payEvent.A_OUID in (@changePcPaymentDuplicate,@changePcPaymentInPost,@changePcPayment) THEN curState.A_PAYMENT
                WHEN payEvent.A_OUID in (@changePcChangeBase) THEN curState.A_MSP_LK_NPD
           END,
           CASE 
                WHEN payEvent.A_OUID in (@changePcFIO) THEN payBook.fio
                WHEN payEvent.A_OUID in (@changePcAddress) THEN WM_PAYMENT.ALTERNATIVEADDRESSDEIVERY
                WHEN payEvent.A_OUID in (@changePcDoc) THEN payBook.docId
                WHEN payEvent.A_OUID in (@changePcPaymentDuplicate,@changePcPaymentInPost,@changePcPayment) THEN WM_PAYMENT.ouid
                WHEN payEvent.A_OUID in (@changePcChangeBase) THEN payBook.mspLkNpdId
           END,
           
           (SELECT SXCLASS.OUID FROM SXCLASS 
              WHERE map=CASE 
						WHEN payEvent.A_OUID in (@changePcFIO) THEN 'PC_FIO_HISTORY'
						WHEN payEvent.A_OUID in (@changePcAddress) THEN 'WM_ADDRESS'
						WHEN payEvent.A_OUID in (@changePcDoc) THEN 'WM_ACTDOCUMENTS'
						WHEN payEvent.A_OUID in (@changePcPaymentDuplicate,@changePcPaymentInPost,@changePcPayment) THEN 'WM_PAYMENT'
						WHEN payEvent.A_OUID in (@changePcChangeBase) THEN 'SPR_NPD_MSP_CAT'
			          END), 
           payEvent.A_OUID,
           CASE payEvent.A_OUID
                WHEN @changePcFIO THEN 1                
                WHEN @changePcDoc THEN 1
                WHEN @changePcChangeBase THEN 1
                WHEN @changePcPaymentDuplicate THEN 1
                WHEN @changePcPaymentInPost THEN 1
                WHEN @changePcPayment THEN 1          
                WHEN @changePcAddress THEN 1                              
           END
    FROM #TEMP_EVENT_PAYBOOK payBook
    INNER JOIN WM_PAYMENT ON  WM_PAYMENT.OUID = payBook.paymentId
        AND ( WM_PAYMENT.A_STATUS = @status OR WM_PAYMENT.A_STATUS IS NULL)
    LEFT JOIN SPR_MAIL_PHONE mail ON mail.OUID = WM_PAYMENT.A_PAYMENTORG
		AND mail.OUID NOT in(SELECT A_PARENT FROM SPR_MAIL_PHONE)
	LEFT JOIN SPR_ORG_BANKS  bank ON bank.OUID = WM_PAYMENT.A_PAYMENTORG  
		AND bank.OUID NOT in (SELECT A_PARENT FROM SPR_ORG_BANKS) 
    INNER JOIN #TEMP_EVENT_AMOUNT amount ON  payBook.payBookId = amount.payBookId  
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = payBook.payBookId
        AND curState.eventDate < @limitDateEvent
    --Прошлое   ФИО
    LEFT JOIN PC_FIO_HISTORY pcFio ON pcFio.OUID = curState.A_FIO
        AND (pcFio.A_STATUS = @status OR pcFio.A_STATUS IS NULL)
    --текущее ФИО	    
    LEFT JOIN PC_FIO_HISTORY pcHistory ON pcHistory.OUID = payBook.fio
        AND (pcHistory.A_STATUS = @status OR pcHistory.A_STATUS IS NULL)
    LEFT JOIN WM_PAYMENT oldPayment ON oldPayment.ouid = curState.A_PAYMENT
		AND (oldPayment.A_STATUS = @status OR oldPayment.A_STATUS IS NULL)
	
	LEFT JOIN SPR_MAIL_PHONE oldMail ON oldMail.OUID=oldPayment.A_PAYMENTORG
	LEFT JOIN SPR_ORG_BANKS  oldBank ON oldBank.OUID=oldPayment.A_PAYMENTORG
	INNER JOIN SPR_PAY_EVENT payEvent
		ON  (payEvent.A_OUID = @changePcFIO AND (   pcFio.A_SURNAME <> pcHistory.A_SURNAME														
													OR pcFio.A_NAME <> pcHistory.A_NAME
													OR pcFio.A_SECONDNAME <> pcHistory.A_SECONDNAME
													OR (pcFio.A_SECONDNAME is null AND  pcHistory.A_SECONDNAME IS NOT null)
													OR (pcFio.A_SECONDNAME is NOT null AND  pcHistory.A_SECONDNAME IS  null)
													)
			
		    )
			OR (payEvent.A_OUID = @changePcChangeBase AND curState.A_MSP_LK_NPD <> payBook.mspLkNpdId) 
		    OR (payEvent.A_OUID = @changePcDoc     AND (curState.A_ID_DOC <> payBook.docId                          OR (curState.A_ID_DOC  IS NULL AND payBook.docId                        IS NOT NULL) OR (curState.A_ID_DOC  IS NOT NULL AND payBook.docId                        IS  NULL)))                 
		    OR (payEvent.A_OUID = @changePcPayment AND (oldPayment.ouid   <> WM_PAYMENT.ouid                        OR (oldPayment.ouid    IS NULL AND WM_PAYMENT.ouid                      IS NOT NULL) OR (oldPayment.ouid    IS NOT NULL AND WM_PAYMENT.ouid                      IS  NULL)))                    
		    OR (payEvent.A_OUID = @changePcAddress AND (curState.A_ADDRESS<> WM_PAYMENT.ALTERNATIVEADDRESSDEIVERY   OR (curState.A_ADDRESS IS NULL AND WM_PAYMENT.ALTERNATIVEADDRESSDEIVERY IS NOT NULL) OR (curState.A_ADDRESS IS NOT NULL AND WM_PAYMENT.ALTERNATIVEADDRESSDEIVERY IS  NULL)))                   
			OR (payEvent.A_OUID = @changePcPaymentInPost 
				AND (oldPayment.ouid  <> WM_PAYMENT.ouid)
				AND (oldMail.A_PARENT = mail.A_PARENT OR bank.A_PARENT = oldBank.A_PARENT)			
			) 
			OR (payEvent.A_OUID = @changePcPaymentDuplicate 
				AND (oldPayment.ouid <> WM_PAYMENT.ouid )
				AND oldPayment.DELIVERYWAY = WM_PAYMENT.DELIVERYWAY 				
				AND oldPayment.A_DELIVERY_TYPES = WM_PAYMENT.A_DELIVERY_TYPES	
				AND oldPayment.PERSONOUID = WM_PAYMENT.PERSONOUID	
				AND (oldPayment.A_STATUS = WM_PAYMENT.A_STATUS OR (oldPayment.A_STATUS is null AND WM_PAYMENT.A_STATUS IS null))	
				AND (oldPayment.A_PAYMENTORG = WM_PAYMENT.A_PAYMENTORG	 OR (oldPayment.A_PAYMENTORG is null AND WM_PAYMENT.A_PAYMENTORG IS null))	
				AND (oldPayment.A_DOCSTATUS = WM_PAYMENT.A_DOCSTATUS OR (oldPayment.A_DOCSTATUS is null AND WM_PAYMENT.A_DOCSTATUS IS null))	
				AND (oldPayment.ACCOUNTINGCOUNT = WM_PAYMENT.ACCOUNTINGCOUNT OR (oldPayment.ACCOUNTINGCOUNT is null AND WM_PAYMENT.ACCOUNTINGCOUNT IS null))
				AND (oldPayment.ALTERNATIVEADDRESSDEIVERY = WM_PAYMENT.ALTERNATIVEADDRESSDEIVERY OR (oldPayment.ALTERNATIVEADDRESSDEIVERY is null AND WM_PAYMENT.ALTERNATIVEADDRESSDEIVERY IS null))
				AND (oldPayment.A_DOST = WM_PAYMENT.A_DOST OR (oldPayment.A_DOST is null AND WM_PAYMENT.A_DOST IS null))	
				AND (oldPayment.A_SVZ = WM_PAYMENT.A_SVZ OR (oldPayment.A_SVZ is null AND WM_PAYMENT.A_SVZ IS null))
				) 	
    WHERE     
            (      ISNULL(amount.curRealAmount,0) > 0 
			   OR  ISNULL(amount.curNoPayAmount,0) > 0
			   OR  ISNULL(amount.curAddPayRealAmount,0) > 0    
			   OR (ISNULL(amount.curPaidAmount,0) > 0 AND @payModeCode = '01')
            )     
       AND  NOT EXISTS(SELECT otherpayBook.payBookId
					   FROM WM_PAY_TEMPDATA otherpayBook
					   WHERE payBook.payBookId = otherpayBook.payBookId
							AND (datediff(day,otherpayBook.eventDate,@eventDate) = 0 OR otherpayBook.eventDate IS NULL)
							AND otherpayBook.eventType in (@payStart,@payStartSingle)
       )
   ORDER BY payEvent.A_OUID
       

   DELETE FROM WM_PAY_TEMPDATA 
   WHERE id IN (   SELECT delEvent.id 
                   FROM (  SELECT 
						   id,
						   ROW_NUMBER () OVER ( PARTITION BY payBookId ORDER BY CASE eventType
																					WHEN @changePcPaymentDuplicate THEN 1
																					WHEN @changePcPaymentInPost THEN 2
																					WHEN @changePcPayment THEN 3
																				END )num						   
						   FROM WM_PAY_TEMPDATA payEvent
						   WHERE eventType IN (@changePcPaymentDuplicate,@changePcPaymentInPost,@changePcPayment)
						   ) delEvent
						   WHERE delEvent.num > 1              
				)
           
           
  	--Прекращение
    --Истечение срока назначения
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,PRIORITY)
    SELECT DISTINCT payBook.payBookId,  
    CASE 
		WHEN (curState.eventTypeLast <> @changeSizePartMonth OR curState.eventTypeLast IS NULL )
			THEN @stopPayEnd
		WHEN curState.eventTypeLast = @changeSizePartMonth  
			THEN @stopPayEndPartMonth
    END payEvent         
    ,1
    FROM   #TEMP_EVENT_PAYBOOK payBook
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = payBook.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    INNER JOIN #TEMP_EVENT_AMOUNT amount ON  payBook.payBookId = amount.payBookId
	WHERE  ( YEAR(curState.payEnd) = @prevYear AND MONTH(curState.payEnd) = @prevMonth  )			  
		  AND ISNULL(amount.curRealAmount,0) = 0
    	  AND NOT EXISTS (
                   SELECT ESRN_SERV_SERV.ouid
                   FROM   ESRN_SERV_SERV
                   INNER JOIN ( SELECT 
								ROW_NUMBER () OVER (PARTITION BY A_serv ORDER BY STARTDATE desc) num,
                   				A_LASTDATE,
                   				A_serv
                   				FROM SPR_SERV_PERIOD 
                   				where (SPR_SERV_PERIOD.A_STATUS = @status OR SPR_SERV_PERIOD.A_STATUS IS  NULL)
                   )period ON period.A_serv =  ESRN_SERV_SERV.ouid AND period.num = 1                    

                   INNER JOIN SPR_STOPSERV_ESRNSERVSERV ON  ESRN_SERV_SERV.OUID = SPR_STOPSERV_ESRNSERVSERV.FROMID
                   INNER JOIN WM_STOP_SERVSERV ON  WM_STOP_SERVSERV.OUID = SPR_STOPSERV_ESRNSERVSERV.TOID
                       AND (WM_STOP_SERVSERV.A_STATUS = @status OR WM_STOP_SERVSERV.A_STATUS IS NULL)
                       AND DATEDIFF(DAY,DATEADD(DAY, 1, period.A_LASTDATE),WM_STOP_SERVSERV.A_DATE_FINISH) = 0
                   WHERE  payBook.payBookId = ESRN_SERV_SERV.A_PAYMENTBOOK
                          AND (ESRN_SERV_SERV.A_STATUS = @status OR ESRN_SERV_SERV.A_STATUS IS NULL)
                          AND YEAR(period.A_LASTDATE) = @prevYear 
                          AND MONTH(period.A_LASTDATE) = @prevMonth
               )
    GROUP BY payBook.payBookId,curState.payEnd,curState.eventTypeLast       
   
    --100% удержание начисления
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,PRIORITY)
    SELECT DISTINCT payBook.payBookId payBookId,
    @stopPayDeduction,5
    FROM   #TEMP_EVENT_PAYBOOK payBook
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = payBook.payBookId
		AND curState.eventDate < @limitDateEvent
		AND curState.longPay = 1 AND curState.activePay = 1
    INNER JOIN #TEMP_EVENT_AMOUNT amount ON  payBook.payBookId = amount.payBookId
    WHERE  ISNULL(amount.curRealAmount,0)+ISNULL(amount.curPaidAmount,0) = 0
           AND (amount.curAmount + curAddPayAmount) = (amount.curDeductAmount)
           AND (amount.curDeductAmount) > 0
    GROUP BY payBook.payBookId
    --Длительная неоплата и
    --снятие с учета и
    --Ручное прекращение/приостановление 
    --Льготодержатель умер
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType,PRIORITY)
    SELECT DISTINCT payBook.payBookId payBookId,
           CASE
			   WHEN holder.A_DEATHDATE  IS NOT NULL
					THEN @stopPayPcDeath
			   WHEN child.A_DEATHDATE  IS NOT NULL 
					THEN @stopPayChildDeath
			   WHEN reciver.A_DEATHDATE  IS NOT NULL 
					THEN @stopPayReciverDeath
			   WHEN SPR_REFUSE.A_COD = '0909' 
					THEN   @stopPayLongNoPay     
			   WHEN SPR_REFUSE.A_COD = '11' 
					THEN @stopPayNoActive
			   ELSE @stopPayOther   
           END payEvent,    
                  
           CASE
			   WHEN holder.A_DEATHDATE  IS NOT NULL
					THEN 2
			   WHEN child.A_DEATHDATE  IS NOT NULL 
					THEN 3
			   WHEN reciver.A_DEATHDATE  IS NOT NULL 
					THEN 4
			   WHEN SPR_REFUSE.A_COD = '0909' 
					THEN   6   
			   WHEN SPR_REFUSE.A_COD = '11' 
					THEN 7
			   ELSE 8   
           END  PRIORITY   

    FROM   #TEMP_EVENT_PAYBOOK payBook
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = payBook.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    INNER JOIN #TEMP_EVENT_AMOUNT amount ON  payBook.payBookId = amount.payBookId
    INNER JOIN ESRN_SERV_SERV ON  payBook.payBookId = ESRN_SERV_SERV.A_PAYMENTBOOK
        AND (ESRN_SERV_SERV.A_STATUS = @status OR ESRN_SERV_SERV.A_STATUS IS NULL)  
    LEFT JOIN WM_PERSONAL_CARD holder ON  ESRN_SERV_SERV.A_PERSONOUID = holder.OUID
        AND (holder.A_STATUS = @status OR holder.A_STATUS IS NULL)
    LEFT JOIN WM_PERSONAL_CARD reciver ON  ESRN_SERV_SERV.A_RECIEVER = reciver.OUID
       AND (reciver.A_STATUS = @status OR reciver.A_STATUS IS NULL)
    LEFT JOIN WM_PERSONAL_CARD child ON  ESRN_SERV_SERV.A_CHILD = child.OUID
    AND (child.A_STATUS = @status OR child.A_STATUS IS NULL)    
    INNER JOIN SPR_SERV_PERIOD ON  SPR_SERV_PERIOD.A_serv = ESRN_SERV_SERV.ouid
        AND ( SPR_SERV_PERIOD.A_STATUS = @status OR SPR_SERV_PERIOD.A_STATUS IS NULL)
    LEFT JOIN SPR_STOPSERV_ESRNSERVSERV ON  ESRN_SERV_SERV.OUID = SPR_STOPSERV_ESRNSERVSERV.FROMID
    LEFT JOIN WM_STOP_SERVSERV ON  WM_STOP_SERVSERV.OUID = SPR_STOPSERV_ESRNSERVSERV.TOID
        AND (WM_STOP_SERVSERV.A_STATUS = @status OR WM_STOP_SERVSERV.A_STATUS IS NULL)
        AND DATEDIFF(DAY,DATEADD(DAY, 1, SPR_SERV_PERIOD.A_LASTDATE),WM_STOP_SERVSERV.A_DATE_FINISH) = 0
        AND (YEAR(SPR_SERV_PERIOD.A_LASTDATE) = @prevYear AND MONTH(SPR_SERV_PERIOD.A_LASTDATE) = @prevMonth )
    LEFT JOIN SPR_REFUSE
        ON  WM_STOP_SERVSERV.A_REASON = SPR_REFUSE.OUID                     

    WHERE ISNULL(amount.curRealAmount,0)+ISNULL(amount.curPaidAmount,0) = 0
			AND(
			   (payBook.mspType in (1,3) )
			OR (payBook.mspType = 4 AND  @month = (@month-1)/3*3+3)
			OR (payBook.mspType = 2 AND @month = 12)							
			)	
	
	--Изменение периода назначени
	--Продление назначения
    INSERT INTO WM_PAY_TEMPDATA(payBookId,payStart,payEnd,payNewEnd,eventType)
    SELECT DISTINCT payBook.payBookId,payBook.payStart,curState.payEnd,payBook.payEnd,@prolongationPay  
    FROM   #TEMP_EVENT_PAYBOOK payBook
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = payBook.payBookId
        AND curState.eventDate < @limitDateEvent
        AND curState.longPay = 1 AND curState.activePay = 1
    INNER JOIN #TEMP_EVENT_AMOUNT amount ON  payBook.payBookId = amount.payBookId
    WHERE  (payBook.payEnd > curState.payEnd OR (payBook.payEnd IS NULL AND curState.payEnd IS NOT NULL ))
           AND amount.curTotalAmount > 0
           AND @prevYear = YEAR(curState.payEnd)
           AND @prevMonth = MONTH(curState.payEnd)
    GROUP BY payBook.payBookId,payBook.payStart,
           curState.payEnd,payBook.payEnd
           
          
    --удаление из события перерасчет
    DELETE 
    FROM   WM_PAY_TEMPDATA
    WHERE  id IN (SELECT osn.id
                  FROM   WM_PAY_TEMPDATA osn
                  INNER JOIN WM_PAY_TEMPDATA child ON  osn.payBookId = child.payBookId
                      AND child.eventType IN (SELECT childOuid 
                                              FROM #EVENT_TREE 
                                               where ouid in(@stopPayGroup))
                  WHERE  osn.eventType IN (SELECT childOuid
                                           FROM   #EVENT_TREE
                                           WHERE  ouid in (@changeSizeGroup))
				 ) 
	--Неоплаты
    INSERT INTO WM_PAY_TEMPDATA(payBookId,additionalPaymentBookId,noPayAmount,eventType,noPayStart,noPayEnd)
    SELECT  DISTINCT   	
	payBook.payBookId,
	neopl.additionalPaymentBookId,
	SUM(ISNULL(neopl.amount,0)),
	@noPay,          
	MIN(neopl.startDate),
	MAX(neopl.endDate)             
    FROM   #TEMP_EVENT_PAYBOOK payBook
	INNER JOIN (		
			 SELECT 
			 neopl.payBookId,
			 neopl.additionalPaymentBookId,
			 SUM(ISNULL(neopl.amount,0)) amount,
			 MIN(neopl.startDate) startDate,
			 MAX(neopl.endDate) endDate
			 FROM #TEMP_CUR_NEOPL neopl
			 WHERE ISNULL(neopl.amount,0)>0
				AND (
					EXISTS(
						   SELECT WM_PAY_EVENT.A_OUID
						   FROM   WM_PAY_EVENT
						   INNER JOIN WM_PAY_EVENT_UNIT ON  WM_PAY_EVENT_UNIT.A_EVENT = WM_PAY_EVENT.A_OUID
							   AND  WM_PAY_EVENT_UNIT.A_PAYMENT_BOOK = neopl.payBookId
							   AND (WM_PAY_EVENT_UNIT.A_ADDIT_PAYMENT_BOOK = neopl.additionalPaymentBookId OR (WM_PAY_EVENT_UNIT.A_ADDIT_PAYMENT_BOOK IS NULL AND  neopl.additionalPaymentBookId IS NULL))

							   
							   
							   AND (WM_PAY_EVENT_UNIT.A_STATUS = @status OR WM_PAY_EVENT_UNIT.A_STATUS IS NULL )
						   WHERE  (WM_PAY_EVENT.A_STATUS = @status OR WM_PAY_EVENT.A_STATUS IS NULL )
								  AND (neopl.[YEAR] * 100 + neopl.[MONTH])<  YEAR(WM_PAY_EVENT.A_EVENT_DATE) * 100 +  MONTH(WM_PAY_EVENT.A_EVENT_DATE)
								  AND WM_PAY_EVENT.A_EVENT_TYPE IN (SELECT childOuid 
																FROM #EVENT_TREE 
																WHERE ouid IN (@changeSizeGroup,@changePcGroup,@stopPayGroup,@payStart,@prolongationPay,@changeMonth))
					   )
					   OR  EXISTS(SELECT otherpayBook.payBookId
								   FROM   WM_PAY_TEMPDATA otherpayBook
								   WHERE  neopl.payBookId = otherpayBook.payBookId		
										  AND (datediff(day,otherpayBook.eventDate,@eventDate) = 0 OR otherpayBook.eventDate IS null)
										  AND (neopl.additionalPaymentBookId = otherpayBook.additionalPaymentBookId OR (neopl.additionalPaymentBookId IS NULL AND otherpayBook.additionalPaymentBookId IS NULL ))					  
								  		  AND otherpayBook.eventType IN (SELECT childOuid 
																FROM #EVENT_TREE 
																WHERE ouid  IN (@changeSizeGroup,@changePcGroup,@stopPayGroup,@payStart,@prolongationPay,@changeMonth))
					   )
					   OR neopl.id IN (SELECT id from #TEMP_TABLE_NOPAYEVENT)
				  )
			 GROUP BY neopl.payBookId,neopl.additionalPaymentBookId
	) neopl ON neopl.payBookId = payBook.payBookId	 	
    GROUP BY payBook.payBookId,neopl.additionalPaymentBookId
    
    
    --удаление из события Изминение личных данных
    DELETE 
    FROM   WM_PAY_TEMPDATA
    WHERE  id IN (SELECT osn.id
                  FROM   WM_PAY_TEMPDATA osn
                  INNER JOIN WM_PAY_TEMPDATA child ON  osn.payBookId = child.payBookId
                      AND child.eventType IN (SELECT childOuid 
                                              FROM #EVENT_TREE 
                                               where ouid in(@stopPayGroup))
                  WHERE  osn.eventType IN (SELECT childOuid
                                           FROM   #EVENT_TREE
                                           WHERE  ouid in (@changePcGroup))
    )
    AND NOT EXISTS(	SELECT tmpData.payBookId 
    				FROM WM_PAY_TEMPDATA tmpData 
    				WHERE tmpData.payBookId = WM_PAY_TEMPDATA.payBookId
    					AND tmpData.eventType = @noPay
    ) 
             
   	--Тукущие события
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType)
    SELECT DISTINCT
    amount.payBookId,@virtualMonthlyEveryPay 
    FROM #TEMP_EVENT_AMOUNT amount
    INNER JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = amount.payBookId
        AND curState.eventDate < @limitDateEvent  
        AND curState.longPay = 1 AND curState.activePay = 1
        
    LEFT JOIN #TEMP_STOP_EVENT stopEvent ON stopEvent.payBookId = amount.payBookId     
        
        
        
    WHERE  stopEvent.payBookId IS NULL
		 AND amount.prevRealAmount = amount.curTotalAmount    
		 AND ISNULL(amount.curPaidAmount,0) = 0
         AND (NOT EXISTS(SELECT otherpayBook.payBookId
								   FROM   WM_PAY_TEMPDATA otherpayBook
								   WHERE  amount.payBookId = otherpayBook.payBookId
										AND (datediff(day,otherpayBook.eventDate,@eventDate) = 0 OR otherpayBook.eventDate IS NULL)
										AND otherpayBook.eventType<>@noPay
         )
         OR amount.payBookId in (select endMonth.payBookId from #TEMP_ENDMONTH endMonth))
    GROUP BY amount.payBookId
    --Виртуальная неоплата
    INSERT INTO WM_PAY_TEMPDATA(payBookId,eventType)
    SELECT DISTINCT
    payBook.payBookId,@virtualNoPay
    FROM #TEMP_EVENT_PAYBOOK payBook
    INNER JOIN #TEMP_CUR_NEOPL neopl ON payBook.payBookId = neopl.payBookId   
    WHERE 
      (NOT EXISTS(SELECT otherpayBook.payBookId
								   FROM   WM_PAY_TEMPDATA otherpayBook
								   WHERE  neopl.payBookId = otherpayBook.payBookId
										AND (neopl.additionalPaymentBookId = otherpayBook.additionalPaymentBookId OR (neopl.additionalPaymentBookId IS NULL AND otherpayBook.additionalPaymentBookId IS NULL))
										AND (datediff(day,otherpayBook.eventDate,@eventDate) = 0 OR otherpayBook.eventDate IS NULL)
										AND otherpayBook.eventType<>@noPay
					)	
					OR payBook.payBookId in (select endMonth.payBookId from #TEMP_ENDMONTH endMonth))
    GROUP BY payBook.payBookId, payBook.paymentId
       
       
   --Удаление события смена года    
   DELETE FROM WM_PAY_TEMPDATA
   WHERE eventType = @changeMonth
               AND  EXISTS(SELECT otherpayBook.payBookId
					   FROM WM_PAY_TEMPDATA otherpayBook
					   WHERE WM_PAY_TEMPDATA.payBookId = otherpayBook.payBookId
							AND (datediff(day,otherpayBook.eventDate,@eventDate) = 0 OR otherpayBook.eventDate IS NULL)
							AND otherpayBook.eventType<>@changeMonth
							AND otherpayBook.eventType NOT IN (@changePcPaymentDuplicate)
		   )	  
       
    --Устанавливаем дату событий,по умолчанию
    UPDATE WM_PAY_TEMPDATA SET eventDate = @eventDate WHERE eventDate IS NULL

	--Дата начала, дата окончания выплаты	
	--Даты периодов для разовых
	UPDATE WM_PAY_TEMPDATA SET    payStart = @eventDate, payEnd = DATEADD(day,-1,DATEADD(MONTH,1,@eventDate))
	WHERE  payStart IS NULL
		   AND payEnd IS NULL
		   AND eventType IN (@payStartSingleNoPay,@payStartSingle)	
	--Для других
	UPDATE WM_PAY_TEMPDATA SET payStart = tmp.startDate, payEnd = tmp.endDate
	FROM   ( SELECT 
			   payBook.payBookId id,ISNULL(curState.payStart ,amount.curMinDate) startDate,ISNULL(curState.payEnd,payBook.payEnd) endDate
			   FROM   #TEMP_EVENT_PAYBOOK payBook
			   LEFT JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = payBook.payBookId
				   AND curState.eventDate < @limitDateEvent
				   AND curState.longPay = 1 AND curState.activePay = 1
			   LEFT JOIN #TEMP_EVENT_AMOUNT amount ON payBook.payBookId = amount.payBookId
			   WHERE  payBook.payStart IS NOT NULL OR  payBook.payEnd IS NOT NULL
		   )tmp
	WHERE  payStart IS NULL
		   AND payEnd IS NULL
		   AND payBookId = tmp.id	
		   
		   
		   
	
	
	
	
	--Удаление не приоритетных событий
    DELETE FROM WM_PAY_TEMPDATA
    WHERE  NOT EXISTS (SELECT 
					   curPrior
					   FROM(SELECT 
						   three.ouid parentSob,
						   MIN(tmp.PRIORITY) curPrior,
						   tmp.payBookId curpayBook,
						   tmp.eventDate curEventDate
						   FROM WM_PAY_TEMPDATA tmp
						   INNER JOIN #EVENT_TREE three ON three.childOuid = tmp.eventType
								AND three.rootNode = 1						   
						   GROUP BY tmp.payBookId,tmp.eventDate,three.ouid
						  )main
					  INNER JOIN #EVENT_TREE three 
					  ON  three.ouid= main.parentSob
					  WHERE three.childOuid = eventType
						  AND curPrior = PRIORITY
						  AND curpayBook = payBookId
						  AND datediff(day,curEventDate, eventDate) = 0
					)	    

    --удаление дублей
    DELETE FROM   WM_PAY_TEMPDATA
    WHERE  id NOT IN (SELECT MAX(id) FROM WM_PAY_TEMPDATA GROUP BY payBookId,additionalPaymentBookId, eventType)	
	--актуализация события прогнозируемое изминение суммы
	SELECT DISTINCT prognoz.id,prognoz.eventUnitId
	INTO #TEMP_OBJECT_DELETE
	FROM (SELECT id,payBookId,eventId,eventUnitId,eventType,eventDate 
	      FROM WM_PAY_TEMPDATA 
	      WHERE eventType = @changeSizePredicte
			UNION ALL
		 SELECT null,payUnit.A_PAYMENT_BOOK,payEvent.A_OUID,payUnit.A_OUID,payEvent.A_EVENT_TYPE,payEvent.A_EVENT_DATE
		 FROM WM_PAY_EVENT payEvent	
		 INNER JOIN WM_PAY_EVENT_UNIT payUnit ON payUnit.A_EVENT = payEvent.A_OUID
		 		AND(payUnit.A_STATUS = @status OR payUnit.A_STATUS IS NULL ) 
		 WHERE payEvent.A_EVENT_TYPE = @changeSizePredicte	
		 		AND(payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL ) 
	)prognoz
	INNER JOIN (	
		  SELECT id,payBookId,eventId,eventUnitId,eventType,eventDate 
	      FROM WM_PAY_TEMPDATA 
	      WHERE eventType IN (SELECT childOuid 
		                      FROM #EVENT_TREE 
		                      WHERE childOuid <>@changeSizePredicte
								AND ouid  in (@changeSizeGroup,@stopPayGroup))
		 UNION ALL
		 SELECT null,payUnit.A_PAYMENT_BOOK,payEvent.A_OUID,payUnit.A_OUID,payEvent.A_EVENT_TYPE,payEvent.A_EVENT_DATE
		 FROM WM_PAY_EVENT payEvent	
		 INNER JOIN WM_PAY_EVENT_UNIT payUnit ON payUnit.A_EVENT = payEvent.A_OUID
		 		AND(payUnit.A_STATUS = @status OR payUnit.A_STATUS IS NULL ) 
		 WHERE payEvent.A_EVENT_TYPE IN (SELECT childOuid 
										 FROM #EVENT_TREE 
										 WHERE childOuid <>@changeSizePredicte
		                         AND ouid  in (@changeSizeGroup,@stopPayGroup))	
		 	AND(payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL ) 		
	)change ON prognoz.payBookId = change.payBookId
                        
    LEFT JOIN WM_PAY_EVENT prognozEvent ON prognoz.eventId  = prognozEvent.A_OUID    
		AND(prognozEvent.A_STATUS = @status OR prognozEvent.A_STATUS IS NULL ) 
	WHERE datediff(day,change.eventDate,prognoz.eventDate) >= 0
		AND datediff(day,ISNULL(prognozEvent.A_EVENT_REGDATE,GETDATE()),GETDATE())>=0
	--Удаление прогнозируемых событий
	DELETE FROM WM_PAY_TEMPDATA            WHERE id     IN (SELECT id          FROM #TEMP_OBJECT_DELETE)
	DELETE FROM WM_PAY_EVENT_UNIT          WHERE A_OUID IN (SELECT eventUnitId FROM #TEMP_OBJECT_DELETE)		
	DELETE FROM WM_PAY_EVENT_UNIT_NEW_SIZE WHERE A_OUID IN (SELECT eventUnitId FROM #TEMP_OBJECT_DELETE)
	DROP TABLE #TEMP_OBJECT_DELETE
     --Удаление событиый не зарегистрированных
    --DELETE WM_PAY_TEMPDATA 
	--WHERE eventType NOT IN (SELECT payEvent FROM #PAY_MODE_EVENTS )
	
	
	DELETE FROM WM_PAY_TEMPDATA 
	WHERE id IN (	SELECT
					tmpData.id		
					FROM WM_PAY_TEMPDATA tmpData		
					LEFT JOIN #PAY_MODE_EVENTS ev ON ev.payEvent = tmpData.eventType
					WHERE ev.payEvent IS NULL 
					AND NOT EXISTS(	SELECT dataEvent.*
									from WM_PAY_TEMPDATA dataEvent 
									WHERE dataEvent.eventType = @noPay
									AND tmpData.eventType IN (SELECT childOuid 
															  FROM #EVENT_TREE 
															  WHERE ouid in (@changePcGroup))
									AND tmpData.payBookId = dataEvent.payBookId		
					)
	)
	AND WM_PAY_TEMPDATA.eventType <> @virtualDeny
	
	
	
	--Преобразование событий	
	SELECT 
	paySETtingConv.A_OUID id,
	paySETtingConv.A_NEW_EVENT newEvent,
	linkPaySETtingBaseEvent.A_TOID baseEvent
	INTO #CONVERT_SETTING
	FROM WM_PAY_MODE payMode
	inner join LINK_PAY_MODE_TO_SETTINGCONV linkPayModeToConv ON payMode.A_OUID=linkPayModeToConv.A_FROMID
	INNER JOIN WM_PAY_SETTING_EVENT_CONV paySETtingConv ON linkPayModeToConv.A_TOID=paySETtingConv.A_OUID
		AND (paySETtingConv.A_STATUS = @status OR paySETtingConv.A_STATUS IS NULL)
	INNER JOIN LINK_PAY_SETTING_CONV_TO_BASE_EVENT linkPaySETtingBaseEvent ON paySETtingConv.A_OUID=linkPaySETtingBaseEvent.A_FROMID
	WHERE (payMode.A_STATUS = @status OR payMode.A_STATUS IS NULL)
		AND  payMode.A_OUID = @modePay
	CREATE INDEX [id_IDX] ON #CONVERT_SETTING(id ASC)
	
	--Размеры,сделать привязку к событиям
	update WM_PAY_TEMPDATA_AMOUNT SET payAmountType = sprPayAmountNew.A_OUID 
	FROM #CONVERT_SETTING conv
	INNER JOIN WM_PAY_TEMPDATA payEvent ON payEvent.eventType = conv.baseEvent
	LEFT JOIN LINK_PAY_SETTING_CONV_TO_SETTING_AMOUNT linkPayConvAmount ON conv.id = linkPayConvAmount.A_FROMID
	LEFT JOIN WM_PAY_SETTING_AMOUNT_CONV paySETtingAmountConv ON linkPayConvAmount.A_TOID = paySETtingAmountConv.A_OUID
		AND (paySETtingAmountConv.A_STATUS = @status OR paySETtingAmountConv.A_STATUS IS NULL)
	LEFT JOIN SPR_PAY_AMOUNT sprPayAmountNew ON sprPayAmountNew.A_OUID = paySETtingAmountConv.A_TYPE_AMOUNT
	LEFT JOIN LINK_PAY_SETTING_AMOUNT_TO_BASE_AMOUNT linkPaySETtingBaseAmount ON linkPaySETtingBaseAmount.A_FROMID=paySETtingAmountConv.A_OUID
	LEFT JOIN SPR_PAY_AMOUNT sprPayAmountBase ON sprPayAmountBase.A_OUID = linkPaySETtingBaseAmount.A_TOID
	WHERE WM_PAY_TEMPDATA_AMOUNT.payAmountType = sprPayAmountBase.A_OUID
		AND WM_PAY_TEMPDATA_AMOUNT.eventType = conv.baseEvent
	
	--Новое событие
	UPDATE WM_PAY_TEMPDATA SET eventType = conv.newEvent
	FROM #CONVERT_SETTING conv
	WHERE WM_PAY_TEMPDATA.eventType = conv.baseEvent	
	
		
		
	--Регистрируем событие окончание месяца
	INSERT INTO WM_PAY_TEMPDATA(payBookId,eventDate,eventType)	
	SELECT DISTINCT payBookId,@eventDate,@endMonth 
	FROM #TEMP_EVENT_PAYBOOK			
	--Поиск созданных записей
	UPDATE WM_PAY_TEMPDATA
    SET    new = 0, eventId = tmp.eventId,eventUnitId = tmp.eventUnitId
    FROM   (SELECT 
			payEvent.a_ouid eventId,
            payEventUnit.a_ouid eventUnitId,
            payEventUnit.A_PAYMENT_BOOK,
            payEventUnit.A_ADDIT_PAYMENT_BOOK,
            payEvent.A_EVENT_TYPE,
            payEvent.A_EVENT_DATE dateEvent,
            newSize.A_OLDSIZE,
            newSize.A_NEWSIZE                  
           FROM   WM_PAY_EVENT_UNIT payEventUnit
           INNER JOIN WM_PAY_EVENT payEvent ON  payEventUnit.A_EVENT = payEvent.A_OUID
               AND (payEvent.A_STATUS = @status OR payEvent.A_STATUS IS NULL  )
               AND (payEventUnit.A_STATUS = @status OR payEventUnit.A_STATUS IS NULL  )
           LEFT JOIN WM_PAY_EVENT_UNIT_NEW_SIZE newSize ON newSize.A_OUID = payEventUnit.A_OUID
           )tmp
    WHERE  tmp.A_EVENT_TYPE = eventType
           AND tmp.A_PAYMENT_BOOK = payBookId
           AND (tmp.A_ADDIT_PAYMENT_BOOK = WM_PAY_TEMPDATA.additionalPaymentBookId OR (tmp.A_ADDIT_PAYMENT_BOOK  IS NULL AND WM_PAY_TEMPDATA.additionalPaymentBookId IS NULL))
           AND (eventType NOT IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid  IN (@changeSizeGroup)) OR (tmp.A_OLDSIZE = payPrevAmount AND tmp.A_NEWSIZE = ISNULL(paidAmount,payAmount)) )
           
           AND datediff(day,tmp.dateEvent, eventDate ) = 0  	
           
    --Заточка       
    UPDATE WM_PAY_TEMPDATA SET new = 1 WHERE eventType = @changeSizePartMonth AND @regMode = 3			  
	--Удаление событий с тек
    DELETE FROM WM_PAY_TEMPDATA     
    WHERE new = 1
    AND payBookId IN (
    	SELECT temEvent.payBookId 
    	FROM WM_PAY_TEMPDATA temEvent
    	INNER JOIN #TEMP_ENDMONTH endMonth 
    	ON temEvent.payBookId = endMonth.payBookId
    	AND (datediff(day,temEvent.eventDate,@eventDate) = 0 OR temEvent.eventDate IS NULL)
    )      
    AND eventType NOT IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid  IN (@virtualEventsGroup,@stopPayChildDeath, @stopPayReciverDeath,@stopPayPcDeath))
	
	
	--Даты неоплаты   
	UPDATE WM_PAY_TEMPDATA SET noPayAmount = tmp.amountNoPAy, noPayStart = tmp.startDate,noPayEnd = tmp.endDate
	FROM   ( 
		SELECT 
			 neopl.payBookId,
			 neopl.additionalPaymentBookId,
			 SUM(ISNULL(neopl.amount,0)) amountNoPAy,
			 MIN(neopl.startDate) startDate,
			 MAX(neopl.endDate) endDate
			 FROM  #TEMP_CUR_NEOPL neopl
			 WHERE  NOT (
			 	EXISTS(
						   SELECT WM_PAY_EVENT.A_OUID
						   FROM   WM_PAY_EVENT
						  
						   INNER JOIN WM_PAY_EVENT_UNIT ON  WM_PAY_EVENT_UNIT.A_EVENT = WM_PAY_EVENT.A_OUID
							   AND WM_PAY_EVENT_UNIT.A_PAYMENT_BOOK = neopl.payBookId
							   AND (WM_PAY_EVENT_UNIT.A_ADDIT_PAYMENT_BOOK = neopl.additionalPaymentBookId OR (WM_PAY_EVENT_UNIT.A_ADDIT_PAYMENT_BOOK IS NULL AND  neopl.additionalPaymentBookId IS NULL))
							   AND (WM_PAY_EVENT_UNIT.A_STATUS = @status OR WM_PAY_EVENT_UNIT.A_STATUS IS NULL )
						   WHERE  (WM_PAY_EVENT.A_STATUS = @status OR WM_PAY_EVENT.A_STATUS IS NULL )
								  AND (neopl.[YEAR] * 100 + neopl.[MONTH])<  YEAR(WM_PAY_EVENT.A_EVENT_DATE) * 100 +  MONTH(WM_PAY_EVENT.A_EVENT_DATE)
								  AND WM_PAY_EVENT.A_EVENT_TYPE IN (SELECT childOuid 
																FROM #EVENT_TREE 
																WHERE ouid  IN (@changeSizeGroup,@changePcGroup,@stopPayGroup,@payStart,@prolongationPay,@changeMonth))
					   )
					   OR  
					        EXISTS(SELECT otherpayBook.payBookId
								   FROM   WM_PAY_TEMPDATA otherpayBook								   
								   WHERE  neopl.payBookId = otherpayBook.payBookId	
										  AND datediff(day,otherpayBook.eventDate,@eventDate) = 0		
								   		  AND (neopl.additionalPaymentBookId = otherpayBook.additionalPaymentBookId OR (neopl.additionalPaymentBookId IS NULL AND otherpayBook.additionalPaymentBookId IS NULL ))					  
										  AND otherpayBook.eventType IN (SELECT childOuid 
																FROM #EVENT_TREE 
																WHERE ouid  IN (@changeSizeGroup,@changePcGroup,@stopPayGroup,@payStart,@prolongationPay,@changeMonth))
								  )
					  OR neopl.id IN (SELECT id from #TEMP_TABLE_NOPAYEVENT)
			 )
 			 OR  (NOT EXISTS(SELECT otherpayBook.payBookId
					   FROM   WM_PAY_TEMPDATA otherpayBook								   
					   WHERE  neopl.payBookId = otherpayBook.payBookId	
							  AND datediff(day,otherpayBook.eventDate,@eventDate) = 0		
					   		  AND (neopl.additionalPaymentBookId = otherpayBook.additionalPaymentBookId OR (neopl.additionalPaymentBookId IS NULL AND otherpayBook.additionalPaymentBookId IS NULL ))					  
							  AND otherpayBook.eventType = @noPay
							  
 			 )  
 			 AND @regMode = 4)
			 
	         GROUP BY neopl.payBookId,neopl.additionalPaymentBookId	      
		   )tmp
	WHERE      WM_PAY_TEMPDATA.noPayAmount IS NULL
		   AND WM_PAY_TEMPDATA.payBookId = tmp.payBookId	
		   AND (WM_PAY_TEMPDATA.additionalPaymentBookId = tmp.additionalPaymentBookId OR (WM_PAY_TEMPDATA.additionalPaymentBookId IS NULL AND tmp.additionalPaymentBookId IS NULL ))
		   AND datediff(day,WM_PAY_TEMPDATA.eventDate,@eventDate) = 0
		   AND WM_PAY_TEMPDATA.eventType<>@noPay
	--Удаление события вирт неоплата если у него нет размера	   	  
	DELETE FROM WM_PAY_TEMPDATA where eventType = @virtualNoPay and (noPayAmount is  null or noPayAmount = 0)	   
		   
		   	   
	--Проставляем прошлый размер
	UPDATE WM_PAY_TEMPDATA
	SET    payPrevStart = tmp.startDate,payPrevEnd = tmp.endDate,payPrevAmount = tmp.amount
	FROM   ( SELECT 
			 payBook.payBookId,
			 curState.curAmount amount,curState.amountStart startDate,
			 DATEADD(DAY, -1, @eventDate) endDate
			   FROM   #TEMP_EVENT_PAYBOOK payBook
			   LEFT JOIN #CUR_EVENT_STATE curState ON  curState.payBookId = payBook.payBookId
				   AND curState.eventDate < @limitDateEvent
				   AND curState.longPay = 1 AND curState.activePay = 1
			   WHERE  curState.curAmount IS NOT NULL
		   )tmp
	WHERE  payPrevAmount IS NULL
	   AND WM_PAY_TEMPDATA.payBookId = tmp.payBookId	 
	   AND datediff(day,eventDate,@eventDate) = 0
	    AND (eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid  IN (@stopPayGroup,@changeSizeGroup,@changePcGroup))
			OR eventType IN (@changeMonth,@prolongationPay,@virtualMonthlyEveryPay)
	       )
	--Проставляем даты текущего размера
	UPDATE WM_PAY_TEMPDATA
	SET    payAmountStart = tmp.startDate,payAmountEnd = tmp.endDate,payAmount=tmp.amount
	FROM   ( SELECT 
			 amount.payBookId,	
			 amount.additionalPaymentBookId,
			 amount.curAmountStart startDate,
			 amount.curAmountEnd endDate,
			 ISNULL(amount.curRealAmount,0) amount
			 FROM  #TEMP_EVENT_AMOUNT amount	
		   )tmp
	WHERE  WM_PAY_TEMPDATA.payAmount IS NULL
	   AND WM_PAY_TEMPDATA.payBookId = tmp.payBookId
	   AND (WM_PAY_TEMPDATA.additionalPaymentBookId = tmp.additionalPaymentBookId OR (WM_PAY_TEMPDATA.additionalPaymentBookId IS NULL  AND tmp.additionalPaymentBookId IS NULL ))
	   AND datediff(day,eventDate,@eventDate) = 0
	   AND (eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid  IN (@payStartGroup,@changeSizeGroup,@changePcGroup))
			OR eventType IN (@changeMonth,@prolongationPay,@virtualMonthlyEveryPay)
	   )
	--Проставляем выплаченный размер
	UPDATE WM_PAY_TEMPDATA
    SET    paidStart = tmp.startDate,paidEnd = tmp.endDate,paidAmount=tmp.amount
	FROM   ( SELECT 
			 amount.payBookId,	
			 amount.additionalPaymentBookId,
			 ISNULL(curState.amountStart,payBook.payStart) startDate,
			 payBook.payEnd endDate,
			 ISNULL(amount.curPaidAmount,0) + ISNULL(amount.curRealAmount,0) amount
			 FROM  #TEMP_EVENT_AMOUNT amount	
			 INNER JOIN #TEMP_EVENT_PAYBOOK payBook ON payBook.payBookId = amount.payBookId
			 left JOIN #CUR_EVENT_STATE curState ON curState.payBookId = amount.payBookId
				AND curState.longPay = 1 AND curState.activePay = 1	        
		   )tmp
	WHERE  WM_PAY_TEMPDATA.paidAmount IS NULL
	   AND WM_PAY_TEMPDATA.payBookId = tmp.payBookId
	   AND (WM_PAY_TEMPDATA.additionalPaymentBookId = tmp.additionalPaymentBookId OR (WM_PAY_TEMPDATA.additionalPaymentBookId IS NULL  AND tmp.additionalPaymentBookId IS NULL ))
	   AND datediff(day,eventDate,@eventDate) = 0	  	
	--Проставляем Доплату
	UPDATE WM_PAY_TEMPDATA
	SET    addPayStart = tmp.startDate,addPayEnd = tmp.endDate,addPayAmount=tmp.amount
	FROM   ( SELECT 
			 amount.payBookId,	
			 amount.additionalPaymentBookId,			 		
			 amount.curaddPayStart startDate,
			 amount.curaddPayEnd  endDate,			 
			 amount.curAddPayRealAmount amount			 
			 FROM  #TEMP_EVENT_AMOUNT amount			 
			 	
		   )tmp
	WHERE  addPayAmount IS NULL
	   AND WM_PAY_TEMPDATA.payBookId = tmp.payBookId
	   AND (WM_PAY_TEMPDATA.additionalPaymentBookId = tmp.additionalPaymentBookId OR (WM_PAY_TEMPDATA.additionalPaymentBookId IS NULL  AND tmp.additionalPaymentBookId IS NULL ))
	   AND datediff(day,eventDate,@eventDate) = 0
	   AND (eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid  IN (@payStartGroup,@changeSizeGroup,@changePcGroup))
			OR eventType IN (@changeMonth,@prolongationPay,@virtualMonthlyEveryPay)
	) 
	
	--Удаление паразитного размера ДОПЛАТА
    UPDATE WM_PAY_TEMPDATA SET addPayAmount = null,addPayStart = null,addPayEnd = NULL
    WHERE id NOT IN(
    SELECT MAX(id) FROM WM_PAY_TEMPDATA
    GROUP BY eventDate,payBookId,additionalPaymentBookId,addPayAmount,addPayStart,addPayEnd
    )
     --Удаление паразитного размера Проставляем даты текущего размера
    UPDATE WM_PAY_TEMPDATA SET payAmount = null,payAmountStart = null,payAmountEnd = NULL
    WHERE id NOT IN(
    SELECT MAX(id) FROM WM_PAY_TEMPDATA
    GROUP BY eventDate,payBookId,additionalPaymentBookId,payAmountStart,payAmountEnd
    ) 
    
    --Удаление события вирт неоплата если у него нет размера	   	  
	DELETE FROM WM_PAY_TEMPDATA where eventType = @virtualNoPay and (noPayAmount is  null or noPayAmount = 0)
    DELETE FROM WM_PAY_TEMPDATA where eventType = @virtualMonthlyEveryPay and (payAmount is  null or payAmount = 0)
    
	
	
	IF @regMode <> 1 OR @regMode IS NULL 
	BEGIN 
		DELETE FROM WM_PAY_TEMPDATA WHERE eventType = @endMonth
	END 	

	--Неполное финансирование
	DECLARE @limit NUMERIC(18,2),@curBalance NUMERIC(18,2)
	SELECT @limit = A_BALANCE FROM WM_PAY_EXPORT WHERE A_OUID = @epid
	IF @limit > 0
	AND EXISTS ( SELECT 
				wmPayAlg.A_OUID
				FROM WM_PAY_MODE payMode 
				INNER JOIN LINK_PAYMODE_ALG linkClass ON payMode.A_OUID = linkClass.a_FROMID
				INNER JOIN WM_PAY_ALG wmPayAlg ON wmPayAlg.A_OUID = linkClass.A_TOID
				AND ( wmPayAlg.A_STATUS  = @status  OR wmPayAlg.A_STATUS  IS NULL  ) 
				WHERE payMode.A_OUID = @modePay
				AND ( payMode.A_STATUS  = @status  OR payMode.A_STATUS  IS NULL  )
			 )
	BEGIN 	
		
		SELECT 
		payData.payBookId,		
		cast(ISNULL(payAmount, 0) + ISNULL(addPayAmount, 0) + ISNULL(noPayAmount, 0) AS NUMERIC(18,2)) amount
		INTO #LIMIT_AMOUNT_TABLE
		FROM WM_PAY_TEMPDATA payData
		WHERE ISNULL(payAmount, 0) + ISNULL(addPayAmount, 0) + ISNULL(noPayAmount, 0) > 0
		ORDER BY amount,payData.payBookId
		
		UPDATE #LIMIT_AMOUNT_TABLE SET 
			@curBalance = @limit,
			@limit = CASE WHEN @limit - amount < 0 THEN @limit ELSE @limit - amount END,
			amount = CASE WHEN @curBalance - amount < 0 THEN 0 ELSE amount END			
		OPTION(MAXDOP 1)
		
		DELETE FROM WM_PAY_TEMPDATA 
		WHERE payBookId IN (SELECT payBookId FROM #LIMIT_AMOUNT_TABLE WHERE amount = 0)
			AND ISNULL(payAmount, 0) + ISNULL(addPayAmount, 0) + ISNULL(noPayAmount, 0) > 0	
		
		DROP TABLE #LIMIT_AMOUNT_TABLE	
		UPDATE WM_PAY_EXPORT SET A_BALANCE = @limit	WHERE A_OUID = @epid 
	
	END 

	--Епид
	UPDATE WM_PAY_TEMPDATA SET epid = @epid	
	--Начальное значение нумерации события
    DECLARE @eventId INT
    SELECT @eventId = IDENT_CURRENT('WM_PAY_EVENT') - 
    CASE  WHEN  IDENT_CURRENT('WM_PAY_EVENT') = IDENT_SEED('WM_PAY_EVENT') 
				AND NOT  EXISTS( SELECT * FROM   WM_PAY_EVENT) 
         THEN 1
		 ELSE 0
    END
    --Нумерация событий
    UPDATE WM_PAY_TEMPDATA
    SET    eventId = @eventId + rownum
    FROM   (SELECT 
			id ouid,
            DENSE_RANK() OVER(ORDER BY eventType) rownum
            FROM   WM_PAY_TEMPDATA
            WHERE (new = 1)
                   AND eventType NOT IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid  = @virtualEventsGroup)
           )tmp
    WHERE  tmp.ouid = id
    AND (new = 1)
    AND eventId IS NULL
    AND eventType NOT IN  (SELECT childOuid FROM #EVENT_TREE WHERE ouid = @virtualEventsGroup)
    --Создание события
    INSERT INTO WM_PAY_EVENT(A_TS,GUID,A_STATUS,A_CREATEDATE,A_EXPORT,A_EVENT_TYPE,A_EVENT_REGDATE,A_EVENT_DATE,A_YEAR,A_MONTH)
    SELECT GETDATE(),NEWID(),@status,GETDATE(),epid,eventType,GETDATE(),eventDate,YEAR(eventDate),MONTH(eventDate)
    FROM   WM_PAY_TEMPDATA
    WHERE  id IN (SELECT MIN(id)
                  FROM   WM_PAY_TEMPDATA
                  WHERE  (new = 1)
                  GROUP BY eventType)
    AND eventId IS NOT NULL
    AND (new = 1)
    ORDER BY eventId
    --Начальное значения нумерации субъектов события
    DECLARE @eventUnitId INT
    SELECT @eventUnitId = IDENT_CURRENT('WM_PAY_EVENT_UNIT')
     - CASE WHEN  IDENT_CURRENT('WM_PAY_EVENT_UNIT')  =  IDENT_SEED('WM_PAY_EVENT_UNIT') 
                 AND  NOT  EXISTS( SELECT * FROM WM_PAY_EVENT_UNIT ) 
            THEN 1
            ELSE 0
       END
    --Нумерация субъектов события
    UPDATE WM_PAY_TEMPDATA
    SET    @eventUnitId = eventUnitId = @eventUnitId + 1
    WHERE   (new = 1)
		   AND eventId IS NOT NULL
	--Родительский субъект события
    INSERT INTO WM_PAY_EVENT_UNIT(A_TS,GUID,A_STATUS,A_CREATEDATE,A_EVENT,A_PAYMENT_BOOK,A_ADDIT_PAYMENT_BOOK,SYSTEMCLASS)
    SELECT GETDATE(),NEWID(),@status,GETDATE(),eventId,payBookId,additionalPaymentBookId ,SPR_PAY_EVENT.A_UNIT_CLASS
    FROM   WM_PAY_TEMPDATA
    INNER JOIN SPR_PAY_EVENT ON  SPR_PAY_EVENT.A_OUID = eventType
    WHERE  eventUnitId IS NOT NULL
           AND new = 1
    ORDER BY eventUnitId	    
    --Событие новое назначение
    INSERT INTO WM_PAY_EVENT_UNIT_NEWSERV(A_OUID,A_START_DATE,A_END_DATE,A_SUM,A_R1,A_FIO,A_ADDRESS,
    A_ID_DOC,A_PAYMENT,A_ADD_PAY_START,A_ADD_PAY_END,A_MSP_LK_NPD)
    SELECT tempData.eventUnitId,tempData.payStart,tempData.payEnd,tempData.payAmount,tempData.addPayAmount,
           payBook.fio,
           payBook.adress,
           payBook.docId,
           payBook.paymentId,
           
           tempData.addPayStart,
           tempData.addPayEnd,
           ISNULL(mask.mspLkNpd,payBook.mspLkNpdId) mspLkNpdIdmspLkNpdId
    FROM   WM_PAY_TEMPDATA tempData
    INNER JOIN #TEMP_EVENT_PAYBOOK payBook ON payBook.payBookId = tempData.payBookId
    LEFT JOIN #TEMP_MASK_PAYBOOK mask ON mask.payBookId = payBook.payBookId			 
		AND (tempData.additionalPaymentBookId = mask.additionalPaymentBookId OR (tempData.additionalPaymentBookId IS NULL AND mask.additionalPaymentBookId IS NULL ))
    INNER JOIN SPR_PAY_EVENT ON  SPR_PAY_EVENT.A_OUID = eventType
    INNER JOIN SXCLASS clazz ON SPR_PAY_EVENT.A_UNIT_CLASS=clazz.OUID
		AND clazz.MAP='WM_PAY_EVENT_UNIT_NEWSERV'
    WHERE tempData.eventUnitId IS NOT NULL
		AND tempData.new = 1
    --Событие изминение размера назначение
    INSERT INTO WM_PAY_EVENT_UNIT_NEW_SIZE(A_OUID,A_OLDSIZE,A_NEWSIZE,a_r1,A_UNPAYMENT,A_ADD_PAY_START,A_ADD_PAY_END,A_PAID)
    SELECT eventUnitId,payPrevAmount,ISNULL(paidAmount,payAmount),addPayAmount,noPayAmount,addPayStart,addPayEnd,paidAmount
    FROM   WM_PAY_TEMPDATA
    INNER JOIN SPR_PAY_EVENT ON  SPR_PAY_EVENT.A_OUID = eventType
    INNER JOIN SXCLASS clazz ON SPR_PAY_EVENT.A_UNIT_CLASS=clazz.OUID
		AND clazz.MAP='WM_PAY_EVENT_UNIT_NEW_SIZE'
    WHERE eventUnitId IS NOT NULL
		AND new = 1
    --Событие Прекращение
    INSERT INTO WM_PAY_EVENT_UNIT_STOP_PAY(A_OUID,A_SUM,A_UNPAYMENT,A_NO_PAY_START,A_NO_PAY_END)
    SELECT eventUnitId,payPrevAmount,noPayAmount,noPayStart,noPayEnd
    FROM   WM_PAY_TEMPDATA
    INNER JOIN SPR_PAY_EVENT ON  SPR_PAY_EVENT.A_OUID = eventType
    INNER JOIN SXCLASS clazz ON SPR_PAY_EVENT.A_UNIT_CLASS=clazz.OUID
		AND clazz.MAP='WM_PAY_EVENT_UNIT_STOP_PAY'
    WHERE eventUnitId IS NOT NULL
		AND new = 1
    --Событие изминение Изменение личных данных
    INSERT INTO WM_PAY_EVENT_UNIT_PERS_CHANGE(A_OUID,A_OLD_OUID,A_NEW_OUID,A_CLASS,A_OLD_OBJ,A_NEW_OBJ)
    SELECT eventUnitId,ouidOld,ouidNew,class,CAST(ouidOld AS VARCHAR) + '@' + SXCLASS.[NAME],
    CAST(ouidNew AS VARCHAR) + '@' + SXCLASS.[NAME]
    FROM   WM_PAY_TEMPDATA
    INNER JOIN SPR_PAY_EVENT ON SPR_PAY_EVENT.A_OUID = eventType
    INNER JOIN SXCLASS ON  SXCLASS.OUID = class
    INNER JOIN SXCLASS clazz ON SPR_PAY_EVENT.A_UNIT_CLASS=clazz.OUID
		AND clazz.MAP='WM_PAY_EVENT_UNIT_PERS_CHANGE'
    WHERE eventUnitId IS NOT NULL
    AND new = 1
    --Событие Изменение периода назначения
    INSERT INTO WM_PAY_EVENT_UNIT_NEW_PERIOD(A_OUID,a_start_date,a_end_date)
    SELECT eventUnitId,payStart,payNewEnd
    FROM   WM_PAY_TEMPDATA
    INNER JOIN SPR_PAY_EVENT ON SPR_PAY_EVENT.A_OUID = eventType
    INNER JOIN SXCLASS clazz ON SPR_PAY_EVENT.A_UNIT_CLASS=clazz.OUID
		AND clazz.MAP='WM_PAY_EVENT_UNIT_NEW_PERIOD'
    WHERE eventUnitId IS NOT NULL
		AND new = 1
    --Событие реестр взамен
    INSERT INTO WM_PAY_EVENT_UNIT_VZAMEN(A_OUID,A_UNPAYMENT,A_NO_PAY_START,A_NO_PAY_END)
    SELECT eventUnitId,noPayAmount,noPayStart,noPayEnd
    FROM   WM_PAY_TEMPDATA
    INNER JOIN SPR_PAY_EVENT ON  SPR_PAY_EVENT.A_OUID = eventType
    INNER JOIN SXCLASS clazz ON SPR_PAY_EVENT.A_UNIT_CLASS=clazz.OUID
		AND clazz.MAP='WM_PAY_EVENT_UNIT_VZAMEN'
    WHERE eventUnitId IS NOT NULL
       AND new = 1    
    --Событие Закрытие
    INSERT INTO WM_PAY_EVENT_UNIT_CLOSE(A_OUID,     
       A_START_DATE,A_END_DATE,       
       A_SUM,A_R1,A_AMOUNT_START,       
       A_FIO,A_PREV_FIO,       
       A_DOC,A_PREV_DOC,       
       A_ADDRESS,A_PREV_ADDRESS,       
       A_PAYMENT,A_PREV_PAYMENT,       
       A_MSPLKNPD,A_PREV_MSPLKNPD,         
       A_STARTEVENTID,
       A_START_EVENT_UNIT_ID,
       A_START_EVENTTYPE,
       A_START_EVENTDATE,  
       A_EVENT_LAST_TYPE,  
       A_ACTPAY
    )
    SELECT 
	payData.eventUnitId                                                                  eventUnitId, 
	--Дата С и ПО
    ISNULL(ISNULL(startPay.payStart,periodPay.payStart  ),curState.payStart)             payStart, 
    ISNULL(ISNULL(startPay.payEnd  ,periodPay.payNewEnd ),curState.payEnd  )             payEnd,   
    --Размер      
    ISNULL(ISNULL(startPay.payAmount     ,sumAmount.payAmount   ),curState.curAmount  )  payAmount,     
    ISNULL(ISNULL(startPay.addPayAmount  ,sumAmount.addPayAmount),0                   )  addPayAmount, 
    ISNULL(ISNULL(startPay.startEventDate,sumAmount.eventDate   ),curState.amountStart)  amountStart,  
    --ФИО
    ISNULL(ISNULL(startPay.fio,fio.fioId),curState.A_FIO)                                fioId,                    
    ISNULL(fio.prevFioId                 ,curState.A_FIO)                                prevFioId,      
    --Документ
    ISNULL(ISNULL(startPay.docId,doc.docId) ,curState.A_ID_DOC)                          docId,                  
    ISNULL(doc.prevDocId                    ,curState.A_ID_DOC)                          prevDocId,     
    --Адресс 
    ISNULL(ISNULL(startPay.adress,addres.addrestId) ,curState.A_ADDRESS)                 addrestId,        
    ISNULL(addres.prevAddresId                      ,curState.A_ADDRESS)                 prevAddresId,   
    --Реквизиты  
    ISNULL(ISNULL(startPay.paymentId,payment.paymentId)  ,curState.A_PAYMENT)            paymentId,    
    ISNULL(payment.prevPaymentId                         ,curState.A_PAYMENT)            prevPaymentId,    
    --МСП-ЛК-НПД  
    ISNULL(ISNULL(startPay.mspLkNpdId,mspLkNpd.mspLkNpdId) ,curState.A_MSP_LK_NPD)       mspLkNpdId,
    ISNULL(mspLkNpd.prevMspLkNpdId                         ,curState.A_MSP_LK_NPD)       prevMspLkNpdId,  
    --Начало выплаты
    ISNULL(startPay.startEventId    ,curState.eventId)                                   startEventId,              
    ISNULL(startPay.startEventUnitId,curState.eventUnitId)                               startEventUnitId, 
    ISNULL(startPay.startEventType  ,curState.eventType)                                 startEventType,              
    ISNULL(startPay.startEventDate  ,curState.eventDate)                                 startEventDate,
    --Последние событие
    ISNULL(lastPay.eventType,curState.eventTypeLast)                                     eventTypeLast,
    --Флаг активного события
    ISNULL(ISNULL(ISNULL(startPay.activePay,stopPay.activePay),curState.activePay),1)    activePay  
    FROM   WM_PAY_TEMPDATA payData      		
    LEFT JOIN #CUR_EVENT_STATE curState	ON curState.payBookId = payData.payBookId   
        	AND (curState.additionalPaymentBookId = payData.additionalPaymentBookId OR (curState.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))   
    LEFT JOIN ( SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,				
				payBook.payStart,
				payBook.payEnd,				
				ISNULL(payData.payAmount,0) payAmount,
				ISNULL(addPayAmount,0) addPayAmount,				
				payBook.fio,
				payBook.docId,
				payBook.adress,
				payBook.paymentId,
				payBook.mspLkNpdId,					
				payData.eventId startEventId,
				payData.eventUnitId startEventUnitId,
				payData.eventType startEventType,
				payData.eventDate startEventDate,
				1 activePay,	
    			ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 
    			FROM WM_PAY_TEMPDATA payData
    			INNER JOIN #TEMP_EVENT_PAYBOOK payBook ON payBook.payBookId = payData.payBookId
    			WHERE payData.eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid IN(@payStart)) 
    			   AND datediff(day,payData.eventDate,@eventDate) = 0     
    ) startPay on startPay.payBookId = payData.payBookId
		AND (startPay.additionalPaymentBookId = payData.additionalPaymentBookId OR (startPay.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND startPay.num = 1
     
     LEFT JOIN (SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,
				0 activePay,				
				ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 	 		
    			FROM WM_PAY_TEMPDATA payData   
    			WHERE payData.eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid IN(@stopPayGroup)) 
    				AND datediff(day,payData.eventDate,@eventDate) = 0    
    ) stopPay on stopPay.payBookId = payData.payBookId
		AND (stopPay.additionalPaymentBookId = payData.additionalPaymentBookId OR (stopPay.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND stopPay.num = 1 				
  
    LEFT JOIN ( SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,
				payData.eventType,
    			ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 
    			FROM WM_PAY_TEMPDATA payData
    			WHERE   payData.eventType <> @endMonth
					AND payData.eventType <> @noPay
					AND payData.eventType <> @payStartSingle
					AND payData.eventType <> @payStartSingleNoPay	     
					AND datediff(day,payData.eventDate,@eventDate) = 0 			
    ) lastPay on lastPay.payBookId = payData.payBookId
		AND (lastPay.additionalPaymentBookId = payData.additionalPaymentBookId OR (lastPay.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND lastPay.num = 1      
    
    LEFT JOIN (SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,
				payStart,
				payNewEnd,			
				ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 	 		
    			FROM WM_PAY_TEMPDATA payData   
    			WHERE payData.eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid IN(@prolongationPay)) 
    				AND datediff(day,payData.eventDate,@eventDate) = 0    
    ) periodPay on periodPay.payBookId = payData.payBookId
		AND (periodPay.additionalPaymentBookId = payData.additionalPaymentBookId OR (periodPay.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND periodPay.num = 1     
    
    LEFT JOIN ( SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,				
				ISNULL(ISNULL(payData.paidAmount,payData.payAmount),0) payAmount,
				ISNULL(addPayAmount,0) addPayAmount,
				payData.eventDate,
				ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 	 		
    			FROM WM_PAY_TEMPDATA payData   
    			WHERE payData.eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid IN(@changeSizeGroup)) 
    				AND datediff(day,payData.eventDate,@eventDate) = 0 
    ) sumAmount on sumAmount.payBookId = payData.payBookId
		AND (sumAmount.additionalPaymentBookId = payData.additionalPaymentBookId OR (sumAmount.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND sumAmount.num = 1      
   
    LEFT JOIN ( SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,
    			payData.ouidOld prevMspLkNpdId,
    			payData.ouidNew mspLkNpdId,
    			ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 
    			FROM WM_PAY_TEMPDATA payData
    			WHERE payData.eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid IN(@changePcChangeBase))     
    				    AND datediff(day,payData.eventDate,@eventDate) = 0 
    ) mspLkNpd on mspLkNpd.payBookId = payData.payBookId
		AND (mspLkNpd.additionalPaymentBookId = payData.additionalPaymentBookId OR (mspLkNpd.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND mspLkNpd.num = 1  
    
     LEFT JOIN ( SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,
    			payData.ouidOld prevAddresId,
    			payData.ouidNew addrestId,
    			ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 
    			FROM WM_PAY_TEMPDATA payData
    			WHERE payData.eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid IN(@changePcAddress))     
    			    	AND datediff(day,payData.eventDate,@eventDate) = 0 
    ) addres on addres.payBookId = payData.payBookId
		AND (addres.additionalPaymentBookId = payData.additionalPaymentBookId OR (addres.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND addres.num = 1  
    
    LEFT JOIN ( SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,
    			payData.ouidOld prevPaymentId,
    			payData.ouidNew paymentId,
    			ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 
    			FROM WM_PAY_TEMPDATA payData
    			WHERE payData.eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid IN(@changePcPayment,@changePcPaymentInPost,@changePcPaymentDuplicate ))     
      				AND datediff(day,payData.eventDate,@eventDate) = 0 
    ) payment on payment.payBookId = payData.payBookId
		AND (payment.additionalPaymentBookId = payData.additionalPaymentBookId OR (payment.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND payment.num = 1     
    
     LEFT JOIN ( SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,
    			payData.ouidOld prevDocId,
    			payData.ouidNew docId,
    			ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 
    			FROM WM_PAY_TEMPDATA payData
    			WHERE payData.eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid IN(@changePcDoc))   
    			    AND datediff(day,payData.eventDate,@eventDate) = 0   
    ) doc on doc.payBookId = payData.payBookId
		AND (doc.additionalPaymentBookId = payData.additionalPaymentBookId OR (doc.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND doc.num = 1    
    
    LEFT JOIN ( SELECT 
				payData.payBookId,
				payData.additionalPaymentBookId,
    			payData.ouidOld prevFioId,
    			payData.ouidNew fioId,
    			ROW_NUMBER () OVER (PARTITION BY payData.payBookId,payData.additionalPaymentBookId ORDER BY payData.id DESC) num 
    			FROM WM_PAY_TEMPDATA payData
    			WHERE payData.eventType IN (SELECT childOuid FROM #EVENT_TREE WHERE ouid IN(@changePcFIO))    
    				AND datediff(day,payData.eventDate,@eventDate) = 0 
    ) fio on fio.payBookId = payData.payBookId
		AND (fio.additionalPaymentBookId = payData.additionalPaymentBookId OR (fio.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND fio.num = 1    
    
    INNER JOIN SPR_PAY_EVENT ON  SPR_PAY_EVENT.A_OUID = payData.eventType
    INNER JOIN SXCLASS clazz ON SPR_PAY_EVENT.A_UNIT_CLASS = clazz.OUID
		AND clazz.MAP = 'WM_PAY_EVENT_UNIT_CLOSE'
    WHERE payData.eventUnitId IS NOT NULL
       AND payData.new = 1      
    --Связь событий с закрытие месяца
    INSERT INTO LINK_CLOSEEVENT_EVENTUNIT (A_FROMID,A_TOID)    
    SELECT DISTINCT
    payData.eventUnitId,
    otherEvent.eventUnitId
    FROM WM_PAY_TEMPDATA payData 
    INNER JOIN WM_PAY_TEMPDATA otherEvent ON otherEvent.payBookId = payData.payBookId
		AND (otherEvent.additionalPaymentBookId = payData.additionalPaymentBookId OR (otherEvent.additionalPaymentBookId IS NULL AND payData.additionalPaymentBookId IS NULL))
		AND otherEvent.new = 1 
		AND payData.id <> otherEvent.id
    WHERE payData.eventUnitId IS NOT NULL
       AND payData.new = 1     
	   AND payData.eventType = @endMonth
     
       
    --Удаление события закрытие месяца  
    DELETE FROM WM_PAY_TEMPDATA 
    WHERE id IN (SELECT id 
                 FROM WM_PAY_TEMPDATA payEvent
				 WHERE payEvent.eventType = @endMonth 
				 )  				 
END
 
--   sx.datastore.db.SXDb.execute:473 
--   sx.common.replication.DoReplication.installPatch:2963 
--   sx.common.replication.SXPatchInstallParams.installPatch:82 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:200 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:180 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:57 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:43 
--   java.lang.reflect.Method.invoke:601 
--   sx.admin.AdmDispatchAction.dispatchMethod:93 
--   sx.admin.AdmDispatchAction.execute:49 
--   sx.admin.AdmServletUtil.processAction:153 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160
 
--   sx.datastore.db.SXDb.execute:473 
--   sx.common.replication.DoReplication.installPatch:2963 
--   sx.common.replication.SXPatchInstallParams.installPatch:82 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:200 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:180 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:597 
--   sx.admin.AdmDispatchAction.dispatchMethod:93 
--   sx.admin.AdmDispatchAction.execute:49 
--   sx.admin.AdmServletUtil.processAction:153 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160
go

