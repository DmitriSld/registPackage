
-- Проводит сверку данных (пока по таблице COLLATE_RESULT)
-- на основе переданных настроек
-- результаты сохраняются в таблице COLLATE_RESULT (видимо, тоже временно) проставлением RESULT
CREATE PROCEDURE COLLATE_PERSONAL_DATA
(
@checkSURNAME bit,     -- признак проверки фамилии
@checkNAME bit,        -- признак проверки имени
@checkSECONDNAME bit,  -- признак проверки отчества
@checkBIRTHDATE bit,    -- признак проверки даты рождения
@checkCOUNTRY bit,    -- признак проверки страны
@checkSUBFED bit,    -- признак проверки субъекта федерации
@checkFEBBOROUGH bit,    -- признак проверки района субъекта федерации
@checkTOWN bit,    -- признак проверки города
@checkTOWNBOROUGH bit,    -- признак проверки района города
@checkSTREET bit,    -- признак проверки улицы
@checkHOUSE bit,    -- признак проверки дома
@checkBUILDING bit,    -- признак проверки корпуса дома
@checkFLAT bit    -- признак проверки квартиры
)
AS
BEGIN
  DECLARE @SQLscript varchar(8000)

  SET nocount ON

  -- создаем таблицы для сверки на БД-источнике

  -- таблица с данными для сверки
  IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = 'COLLATE_RESULT' AND type = 'U') BEGIN
	CREATE TABLE COLLATE_RESULT (
	 OUID        int              NOT NULL,
	 GUID        varchar(255)     NULL,
	 REG_ORGNAME int              NULL,
	 SURNAME     varchar(255)     NULL,
	 NAME        varchar(255)     NULL,
	 SECONDNAME  varchar(255)     NULL,
	 BIRTHDATE   datetime         NULL,
	 ADR_COUNTRY  varchar(255)    NULL,
	 ADR_SUBFED  varchar(255)     NULL,
	 ADR_FEBBOROUGH  varchar(255) NULL,
	 ADR_TOWN  varchar(255)       NULL,
	 ADR_TOWNBOROUGH  varchar(255)NULL,
	 ADR_STREET  varchar(255)     NULL,
	 ADR_HOUSE  varchar(255)      NULL,
	 ADR_BUILDING  varchar(255)   NULL,
	 ADR_FLAT  varchar(255)       NULL,
	 SYSTEM_OUID int              NULL,
	 SYSTEM_OUID_COUNT int        NULL,
	 RESULT      tinyint          NULL,
	 RESULT_TEXT varchar(255)     NULL
	)         
	CREATE INDEX OUID_IND ON COLLATE_RESULT (OUID)
	CREATE INDEX GUID_IND ON COLLATE_RESULT (GUID)
	CREATE INDEX REG_ORGNAME ON COLLATE_RESULT (REG_ORGNAME)
	CREATE INDEX SURNAME_IND ON COLLATE_RESULT (SURNAME)      
	CREATE INDEX NAME_IND ON COLLATE_RESULT (NAME)
	CREATE INDEX SECONDNAME_IND ON COLLATE_RESULT (SECONDNAME)  
	CREATE INDEX BIRTHDATE_IND ON COLLATE_RESULT (BIRTHDATE)
	CREATE INDEX ADR_COUNTRY_IND ON COLLATE_RESULT (ADR_COUNTRY)  
	CREATE INDEX ADR_SUBFED_IND ON COLLATE_RESULT (ADR_SUBFED)
	CREATE INDEX ADR_FEBBOROUGH_IND ON COLLATE_RESULT (ADR_FEBBOROUGH)  
	CREATE INDEX ADR_TOWN_IND ON COLLATE_RESULT (ADR_TOWN)
	CREATE INDEX ADR_TOWNBOROUGH_IND ON COLLATE_RESULT (ADR_TOWNBOROUGH)  
	CREATE INDEX ADR_STREET_IND ON COLLATE_RESULT (ADR_STREET)
	CREATE INDEX ADR_HOUSE_IND ON COLLATE_RESULT (ADR_HOUSE)    
	CREATE INDEX ADR_BUILDING_IND ON COLLATE_RESULT (ADR_BUILDING)  
	CREATE INDEX ADR_FLAT_IND ON COLLATE_RESULT (ADR_FLAT)
	CREATE INDEX SYSTEM_OUID_IND ON COLLATE_RESULT (SYSTEM_OUID)    
	CREATE INDEX SYSTEM_OUID_COUNT_IND ON .COLLATE_RESULT (SYSTEM_OUID_COUNT) 
	CREATE INDEX RESULT_IND ON COLLATE_RESULT (RESULT) 
	CREATE INDEX RESULT_TEXT_IND ON COLLATE_RESULT (RESULT_TEXT) 
  END

  -- таблица связки сверяемых ЛД и с данными для сверки
  IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = 'COLLATE_LINK_RESULT' AND type = 'U') BEGIN
	CREATE TABLE COLLATE_LINK_RESULT (
	 OUID        int              NOT NULL,
	 SYSTEM_OUID int              NULL
	)  
	CREATE INDEX OUID_IND ON COLLATE_LINK_RESULT (OUID)
	CREATE INDEX SYSTEM_OUID_IND ON COLLATE_LINK_RESULT (SYSTEM_OUID)                 
  END

  -- подготавливаем данные для сверки
    INSERT INTO COLLATE_RESULT
    SELECT
    wmPC.OUID as OUID,
    wmPC.GUID as GUID,
    wmPC.A_REG_ORGNAME as REG_ORGNAME,
    fn.A_NAME as SURNAME,
    n.A_NAME as NAME,
    sn.A_NAME as SECONDNAME, 
    wmPC.BIRTHDATE as BIRTHDATE, 
    country.A_NAME as ADR_COUNTRY, 
    subfed.A_NAME as ADR_SUBFED, 
    fedborough.A_NAME as ADR_FEBBOROUGH, 
    town.A_NAME as ADR_TOWN, 
    townborough.A_NAME as ADR_TOWNBOROUGH, 
    street.A_NAME as ADR_STREET, 
    address.A_HOUSENUMBER as ADR_HOUSE,  
    address.A_BUILDING as ADR_BUILDING, 
    address.A_FLATNUMBER as ADR_FLAT, 
    NULL as SYSTEM_OUID, 
    NULL as SYSTEM_OUID_COUNT, 
    NULL as RESULT, 
    NULL as RESULT_TEXT 
    FROM WM_PERSONAL_CARD wmPC
    LEFT JOIN SPR_FIO_SURNAME fn ON wmPC.SURNAME = fn.OUID
    LEFT JOIN SPR_FIO_NAME n ON wmPC.A_NAME = n.OUID
    LEFT JOIN SPR_FIO_SECONDNAME sn ON wmPC.A_SECONDNAME = sn.OUID
    LEFT JOIN WM_ADDRESS address ON wmPC.A_REGFLAT = address.OUID
    LEFT JOIN SPR_COUNTRY country ON address.A_COUNTRY = country.OUID
    LEFT JOIN SPR_SUBJFED subfed ON address.A_SUBFED = subfed.OUID
    LEFT JOIN SPR_FEDERATIONBOROUGHT fedborough ON address.A_FEDBOROUGH = fedborough.OUID
    LEFT JOIN SPR_TOWN town ON address.A_TOWN = town.OUID
    LEFT JOIN SPR_BOROUGH townborough ON address.A_TOWNBOROUGH = townborough.OUID
    LEFT JOIN SPR_STREET street ON address.A_STREET = street.OUID
    WHERE (wmPC.A_STATUS <> 70 OR wmPC.A_STATUS IS NULL) AND wmPC.OUID NOT IN (SELECT OUID FROM COLLATE_RESULT) AND wmPC.A_ISREPLOBJ = 1

  -- загоняем в таблицу идентификторы сверяемых ЛД и идентификторы совпавших ЛД
  SET @SQLscript = 'INSERT INTO COLLATE_LINK_RESULT
                    SELECT tableResult.OUID as OUID, tableData.OUID as SYSTEM_OUID
	            FROM COLLATE_RESULT as tableResult, WM_PERSONAL_CARD as tableData
	  	    LEFT JOIN SPR_FIO_SURNAME fn ON tableData.SURNAME = fn.OUID
 		    LEFT JOIN SPR_FIO_NAME n ON tableData.A_NAME = n.OUID
		    LEFT JOIN SPR_FIO_SECONDNAME sn ON tableData.A_SECONDNAME = sn.OUID
		    LEFT JOIN WM_ADDRESS address ON tableData.A_REGFLAT = address.OUID
		    LEFT JOIN SPR_COUNTRY country ON address.A_COUNTRY = country.OUID
		    LEFT JOIN SPR_SUBJFED subfed ON address.A_SUBFED = subfed.OUID
		    LEFT JOIN SPR_FEDERATIONBOROUGHT fedborough ON address.A_FEDBOROUGH = fedborough.OUID
		    LEFT JOIN SPR_TOWN town ON address.A_TOWN = town.OUID
		    LEFT JOIN SPR_BOROUGH townborough ON address.A_TOWNBOROUGH = townborough.OUID
		    LEFT JOIN SPR_STREET street ON address.A_STREET = street.OUID
		    WHERE tableResult.RESULT IS NULL AND (tableData.A_ISREPLOBJ = 0 OR tableData.A_ISREPLOBJ IS NULL) AND (tableData.A_STATUS <> 70 OR tableData.A_STATUS IS NULL)
                    AND (' + CAST(@checkSURNAME as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.SURNAME, fn.A_NAME, 2) <= 2)
		    AND (' + CAST(@checkNAME as char(1))+ ' = 0 OR dbo.DIFF_STRING(tableResult.NAME, n.A_NAME, 2) <= 2)
		    AND (' + CAST(@checkSECONDNAME as char(1))+ ' = 0 OR dbo.DIFF_STRING(tableResult.SECONDNAME, sn.A_NAME, 2) <= 2)
		    AND (' + CAST(@checkBIRTHDATE as char(1)) + ' = 0 OR tableResult.BIRTHDATE IS NULL OR tableData.BIRTHDATE IS NULL OR (DATEDIFF(Day,tableResult.BIRTHDATE,tableData.BIRTHDATE) = 0))
		    AND (' + CAST(@checkCOUNTRY as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.ADR_COUNTRY, country.A_NAME, 2) <= 2)
		    AND (' + CAST(@checkSUBFED as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.ADR_SUBFED, subfed.A_NAME, 2) <= 2)
		    AND (' + CAST(@checkFEBBOROUGH as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.ADR_FEBBOROUGH, fedborough.A_NAME, 2) <= 2)
		    AND (' + CAST(@checkTOWN as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.ADR_TOWN, town.A_NAME, 2) <= 2)
		    AND (' + CAST(@checkTOWNBOROUGH as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.ADR_TOWNBOROUGH, townborough.A_NAME, 2) <= 2)
		    AND (' + CAST(@checkSTREET as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.ADR_STREET, street.A_NAME, 2) <= 2)
		    AND (' + CAST(@checkHOUSE as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.ADR_HOUSE, address.A_HOUSENUMBER, 1) <= 1)
		    AND (' + CAST(@checkBUILDING as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.ADR_BUILDING, address.A_BUILDING, 1) <= 1)
		    AND (' + CAST(@checkFLAT as char(1)) + ' = 0 OR dbo.DIFF_STRING(tableResult.ADR_FLAT, address.A_FLATNUMBER, 1) <= 1)'   
  EXECUTE(@SQLscript)

  -- заводим результаты сверки
    UPDATE COLLATE_RESULT
    SET SYSTEM_OUID = inselect.SYSTEM_OUID,
        SYSTEM_OUID_COUNT = inselect.COUNT 
    FROM (SELECT OUID as OUID, SUM(SYSTEM_OUID) as SYSTEM_OUID , COUNT(SYSTEM_OUID)as COUNT
	  FROM COLLATE_LINK_RESULT
	  GROUP BY OUID) inselect 
    WHERE COLLATE_RESULT.OUID = inselect.OUID  

  -- если личных дел не найдено
    UPDATE COLLATE_RESULT
    SET RESULT = 3, 
        RESULT_TEXT = 'Личное дело не найдено'
    WHERE RESULT IS NULL AND SYSTEM_OUID_COUNT IS NULL OR SYSTEM_OUID_COUNT = 0

  -- если найдено несколько личных дел
    UPDATE COLLATE_RESULT
    SET SYSTEM_OUID = NULL,
        RESULT = 2, 
        RESULT_TEXT = 'Найдено несколько личных дел'
    WHERE RESULT IS NULL AND SYSTEM_OUID_COUNT > 1  


  -- если найдено личное дело найдено и оно одно
    UPDATE COLLATE_RESULT
    SET RESULT = 1, 
        RESULT_TEXT = 'Личное дело найдено'
    WHERE RESULT IS NULL AND SYSTEM_OUID_COUNT = 1 

/* обновляем данные в главной базе*/
/* все прошедшие сверку ЛД, не найденные в основной базе, переводятся в нее без всякой переделки */
  UPDATE WM_PERSONAL_CARD 
  SET A_ISREPLOBJ = 0 
  FROM COLLATE_RESULT WHERE WM_PERSONAL_CARD.OUID = COLLATE_RESULT.OUID AND COLLATE_RESULT.RESULT = 3
  -- очищаем инфу об этих ЛД из таблиц сверки
  DELETE FROM COLLATE_LINK_RESULT
  FROM COLLATE_RESULT  WHERE COLLATE_LINK_RESULT.OUID = COLLATE_RESULT.OUID AND COLLATE_RESULT.RESULT = 3

  DELETE FROM COLLATE_RESULT WHERE COLLATE_RESULT.RESULT = 3

  /* все данные ЛД, для которых найдено 1 подходящее ЛД, переносятся в основную базу */
  -- находим все, связанное с этим объектом и привязываем к найденному
  DECLARE @table varchar(255), @field varchar(255)

  DECLARE db_cursor CURSOR FOR
  SELECT CLASS.MAP, SXATTR.MAP FROM SXATTR
  LEFT JOIN SXCLASS CLASS ON SXATTR.OUIDSXCLASS = CLASS.OUID
  LEFT JOIN SXCLASS LINK ON SXATTR.REF_CLASS = LINK.OUID
  WHERE LINK.NAME = 'wmPersonalCard' AND SXATTR.OUIDDATATYPE = 10121250 AND CLASS.DATASTORE IS NULL

  OPEN db_cursor

  FETCH NEXT FROM db_cursor 
  INTO @table, @field

  WHILE @@FETCH_STATUS = 0
  BEGIN
    SET @SQLscript = 'UPDATE ' + @table + ' SET ' + @field + ' = COLLATE_RESULT.SYSTEM_OUID FROM COLLATE_RESULT 
    WHERE ' + @field + ' = COLLATE_RESULT.OUID AND COLLATE_RESULT.RESULT = 1'
    EXECUTE(@SQLscript)

    FETCH NEXT FROM db_cursor 
    INTO @table, @field
  END

  CLOSE db_cursor
  DEALLOCATE db_cursor

  -- заносим данные "история GUID-ов"
  INSERT INTO PC_GUID_HISTORY (GUID, TS, A_PC, A_SERVERID, A_COMPLYGUID)
  SELECT NEWID(), GETDATE(), COLLATE_RESULT.SYSTEM_OUID, COLLATE_RESULT.REG_ORGNAME, COLLATE_RESULT.GUID FROM COLLATE_RESULT WHERE COLLATE_RESULT.RESULT = 1

  -- удаляем эти ЛД
  DELETE FROM WM_PERSONAL_CARD FROM COLLATE_RESULT WHERE WM_PERSONAL_CARD.OUID = COLLATE_RESULT.OUID AND COLLATE_RESULT.RESULT = 1
  -- очищаем инфу об этих ЛД из таблиц сверки
  DELETE FROM COLLATE_LINK_RESULT
  FROM COLLATE_RESULT  WHERE COLLATE_LINK_RESULT.OUID = COLLATE_RESULT.OUID AND COLLATE_RESULT.RESULT = 1

  DELETE FROM COLLATE_RESULT WHERE COLLATE_RESULT.RESULT = 1
END
go

