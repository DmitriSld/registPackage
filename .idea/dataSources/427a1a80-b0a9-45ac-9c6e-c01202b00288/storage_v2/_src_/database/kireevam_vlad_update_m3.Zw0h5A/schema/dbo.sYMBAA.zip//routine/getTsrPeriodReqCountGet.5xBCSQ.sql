CREATE FUNCTION dbo.getTsrPeriodReqCountGet(
 @ouidId as int
) RETURNS int
AS
BEGIN
 -- "Количество полученных ТСР/ПОИ" в "Период предоставления ТСР"	
 DECLARE @result int
 SELECT @result = ISNULL(SUM(TSR_DIRECTION.A_COUNT_FACT),0)
 FROM TSR_DIRECTION
 WHERE TSR_DIRECTION.A_TSR_PERIOD = @ouidId
 AND (TSR_DIRECTION.A_STATUS IS NULL OR TSR_DIRECTION.A_STATUS = (SELECT ESRN_SERV_STATUS.A_ID FROM ESRN_SERV_STATUS WHERE ESRN_SERV_STATUS.A_STATUSCODE = 'act'))
 AND TSR_DIRECTION.A_STATE IN (SELECT SPR_TSR_STATUS.A_OUID 
                               FROM SPR_TSR_STATUS 
                               WHERE SPR_TSR_STATUS.A_CODE IN ('7','8')) -- выполнено, выполнено не полностью  
 RETURN @result
END;
 
--   sx.datastore.db.SXDb.execute:-1 
--   sx.common.replication.DoReplication.installPatch:-1 
--   sx.common.replication.SXPatchInstallParams.installPatch:-1 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:-1 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:-1 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:597 
--   sx.admin.AdmDispatchAction.dispatchMethod:-1 
--   sx.admin.AdmDispatchAction.execute:-1 
--   sx.admin.AdmServletUtil.processAction:-1 
--   sx.admin.AdmServlet.doGet:-1 
--   sx.admin.AdmServlet.doPost:-1
go

