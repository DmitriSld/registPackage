
CREATE PROCEDURE [dbo].[COLLATE_PC_DATA_BY_IDENT] (
       @tempTableClassName nvarchar(255),  -- класс временной таблицы
       @linkAttrName       nvarchar(255),  -- имя арибута MxN, куда валятся дубли
       @trustLevel         integer,         -- значение уровня доверия >= которого производим сливку
       @mergeType          integer         -- тип операции слияния, null, 0 - первичная, 1 - послерепликационная
)
AS
BEGIN
  -- Инициализируем значениями по умолчанию
  IF @tempTableClassName is null
    SET @tempTableClassName = 'tempTableReplicationIDPC'
  IF @linkAttrName is null
    SET @linkAttrName = 'foundPC'

 /*
  * Создаем таблицу по которой будет производиться merge.
  * Далее мы заненм в нее данные из текущей таблицы результатов идентификации
  */
 IF EXISTS (SELECT name FROM sysobjects WHERE name = 'COLLATE_RESULT_RECAST' AND type = 'U')
    -- Сбриваем текущую таблицу.... поскольку мы не уверены в ее правильности
    DROP TABLE COLLATE_RESULT_RECAST
    -- Создаем новую таблицу
	CREATE TABLE COLLATE_RESULT_RECAST (
	 OUID        int              NOT NULL,
	 GUID        varchar(255)     NULL,
	 REG_ORGNAME int              NULL,
	 SURNAME     varchar(255)     NULL,
	 NAME        varchar(255)     NULL,
	 SECONDNAME  varchar(255)     NULL,
	 BIRTHDATE   datetime         NULL,
	 ADR_COUNTRY  varchar(255)    NULL,
	 ADR_SUBFED  varchar(255)     NULL,
	 ADR_FEBBOROUGH  varchar(255) NULL,
	 ADR_TOWN  varchar(255)       NULL,
	 ADR_TOWNBOROUGH  varchar(255)NULL,
	 ADR_STREET  varchar(255)     NULL,
	 ADR_HOUSE  varchar(255)      NULL,
	 ADR_BUILDING  varchar(255)   NULL,
	 ADR_FLAT  varchar(255)       NULL,
	 SNILS  varchar(255)          NULL,
	 SYSTEM_OUID int              NULL,
	 SYSTEM_OUID_COUNT int        NULL,
	 RESULT      tinyint          NULL,
	 RESULT_TEXT varchar(255)     NULL
	)
	CREATE INDEX OUID_IND ON COLLATE_RESULT_RECAST (OUID)
	CREATE INDEX SYSTEM_OUID_IND ON COLLATE_RESULT_RECAST (SYSTEM_OUID)
	CREATE INDEX OUID_SYSTEM_OUID_IND ON COLLATE_RESULT_RECAST (OUID,SYSTEM_OUID)

  -- Чистим текущую табличку
  -- TRUNCATE TABLE COLLATE_RESULT;

  -- Переменная, хранящая класс мержимаего объекта
  DECLARE @tableName nvarchar(255)
  -- Переменная, содержащая имя таблицы связки MxN
  DECLARE @linkTableName nvarchar(255)
  SELECT TOP 1 @tableName = refCls.MAP, @linkTableName = lnkCls.MAP FROM SXATTR attr INNER JOIN SXCLASS cls
    ON cls.NAME = @tempTableClassName AND attr.NAME = @linkAttrName
  INNER JOIN SXClass refCls
    ON attr.REF_CLASS = refCls.OUID
  INNER JOIN SXClass lnkCls
    ON attr.A_CLASS_DESCR = lnkCls.OUID



  DECLARE @SQLscript varchar(8000)
 /*
  * Транслируем данные результатов идентификации в таблицу COLLATE_RESULT_RECAST,
  * по корой далее будет производиться merge
  */
  if @mergeType is NULL OR @mergeType = 0
  SET @SQLscript =
   'INSERT INTO COLLATE_RESULT_RECAST (OUID, GUID, SYSTEM_OUID, RESULT, REG_ORGNAME)
	SELECT DISTINCT pc.OUID, pc.GUID, main_pc.OUID, 2, pc.A_REG_ORGNAME
	FROM dbo.TEMP_REPL_ID tmp INNER JOIN ' + @linkTableName + ' ln
	     INNER JOIN SXATTR attr
	           INNER JOIN SXCLASS cls
                     ON cls.NAME = ''' + @tempTableClassName + ''' AND attr.OUIDSXCLASS = cls.OUID
	           ON attr.NAME = ''' + @linkAttrName + '''
		ON tmp.A_ID_RESULT IN (1,3) AND ln.A_FROMID = tmp.A_OUID AND tmp.A_TRUST_LEVEL >= ' + cast(@trustLevel as VARCHAR) + '
	INNER JOIN ' + @tableName  + ' pc
		ON pc.OUID = ln.A_TOID
	INNER JOIN ' + @tableName  + ' main_pc
		ON main_pc.GUID = tmp.A_SOURCE_GUID
    WHERE pc.A_REG_ORGNAME IS NOT NULL'
  ELSE		
  SET @SQLscript =
   'INSERT INTO COLLATE_RESULT_RECAST (OUID, GUID, SYSTEM_OUID, RESULT, REG_ORGNAME)
	SELECT DISTINCT main_pc.OUID, main_pc.GUID, pc.OUID, 2, main_pc.A_REG_ORGNAME
	FROM dbo.TEMP_REPL_ID tmp INNER JOIN ' + @linkTableName + ' ln
	     INNER JOIN SXATTR attr
	           INNER JOIN SXCLASS cls
                     ON cls.NAME = ''' + @tempTableClassName + ''' AND attr.OUIDSXCLASS = cls.OUID
	           ON attr.NAME = ''' + @linkAttrName + '''
		ON tmp.A_ID_RESULT IN (1,3) AND ln.A_FROMID = tmp.A_OUID AND tmp.A_TRUST_LEVEL >= ' + cast(@trustLevel as VARCHAR) + '
	INNER JOIN ' + @tableName  + ' pc
		ON pc.OUID = ln.A_TOID
	INNER JOIN ' + @tableName  + ' main_pc
		ON main_pc.GUID = tmp.A_SOURCE_GUID
    WHERE main_pc.A_REG_ORGNAME IS NOT NULL'
		
  EXECUTE(@SQLscript)

   -- заносим данные "история GUID-ов" только если это было ЛД
   IF @tableName = 'WM_PERSONAL_CARD'
     INSERT INTO PC_GUID_HISTORY (GUID, TS, A_PC, A_SERVERID, A_COMPLYGUID)
     SELECT NEWID(), GETDATE(), cr.SYSTEM_OUID, cr.REG_ORGNAME, cr.GUID
     FROM COLLATE_RESULT_RECAST cr

   -- удаляем из связи MxN результатов идентификации
  if @mergeType is NULL OR @mergeType = 0
   SET @SQLscript = '
   DELETE FROM ' + @linkTableName + ' WHERE
   A_TOID IN ( SELECT lc.OUID FROM COLLATE_RESULT_RECAST lc )
   DELETE FROM ' + @linkTableName + ' WHERE
   A_FROMID IN ( SELECT lc.OUID FROM COLLATE_RESULT_RECAST lc )'
  ELSE		
  SET @SQLscript = '
   DELETE FROM ' + @linkTableName + ' WHERE
   A_TOID IN ( SELECT lc.SYSTEM_OUID FROM COLLATE_RESULT_RECAST lc )
   DELETE FROM ' + @linkTableName + ' WHERE
   A_FROMID IN ( SELECT lc.SYSTEM_OUID FROM COLLATE_RESULT_RECAST lc )'
   EXECUTE(@SQLscript)

   CREATE TABLE #LIST_COLLATE (
     OUID int,
	 SYSTEM_OUID int,
	 RESULT int
   )

   EXECUTE MERGE_FIELDS_ALT

   DECLARE @StatusDel as int
   SELECT @StatusDel = cast(A_ID as varchar) FROM ESRN_SERV_STATUS WHERE A_STATUSCODE='delete'

   -- удаляем эти слитные объекты
   /*
   SET @SQLscript =
   'UPDATE ' + @tableName  +
   ' SET ' + @tableName  + '.A_STATUS = ' + cast(@StatusDel as varchar) + '
   , ' + @tableName  + '.TS = GETDATE()
   FROM #LIST_COLLATE WHERE ' + @tableName  + '.OUID = #LIST_COLLATE.OUID'
   */
   SET @SQLscript =
   'DELETE FROM ' + @tableName  + '
   FROM #LIST_COLLATE WHERE ' + @tableName  + '.OUID = #LIST_COLLATE.OUID'
   EXECUTE(@SQLscript)

   IF @tableName = 'WM_PERSONAL_CARD' BEGIN
      IF @mergeType = 1 BEGIN
        SET @SQLscript =
        'UPDATE WM_PERSONAL_CARD SET A_ISREPLOBJ = 0, TS = GETDATE()
        WHERE A_ISREPLOBJ = 1
        AND OUID IN (
            SELECT tmp.A_SOURCE_OUID FROM TEMP_REPL_ID tmp
            LEFT JOIN ' + @linkTableName + ' ln
            ON ln.A_FROMID = tmp.A_OUID
            WHERE ln.A_FROMID IS NULL
        );
        UPDATE WM_PERSONAL_CARD SET A_PCSTATUS = 1, TS = GETDATE()
        WHERE A_PCSTATUS  = 2
        AND OUID IN (
            SELECT tmp.A_SOURCE_OUID FROM TEMP_REPL_ID tmp
            LEFT JOIN ' + @linkTableName + ' ln
            ON ln.A_FROMID = tmp.A_OUID
            WHERE ln.A_FROMID IS NULL
        )'
      EXECUTE(@SQLscript)
      END

      SET @SQLscript =
      'DELETE FROM TEMP_REPL_ID
      WHERE A_OUID IN (
          SELECT tmp.A_OUID FROM TEMP_REPL_ID tmp
          LEFT JOIN ' + @linkTableName + ' ln
          ON ln.A_FROMID = tmp.A_OUID
          WHERE ln.A_FROMID IS NULL
      )'
      EXECUTE(@SQLscript)
   END

-------------------------------
-------------------------------
-------------------------------

CREATE TABLE #UPDATE_DATA (
	"id" int,
	"name" varchar(256),
	"map" varchar(256),
	"tsMap" varchar(256),
	"ouidMap" varchar(256),
	"ouidField" varchar(256),
	"tsField" varchar(256)
)

CREATE TABLE #UPDATE_DATA_OBJ (
	"id" int,
	"ouid" int
)

INSERT INTO #UPDATE_DATA(id,name,map,tsMap,ouidMap,ouidField,tsField) 
VALUES(0,'wmPersonalCard','WM_PERSONAL_CARD','WM_PERSONAL_CARD','WM_PERSONAL_CARD','OUID','TS')
INSERT INTO #UPDATE_DATA_OBJ(id,ouid) 
SELECT DISTINCT 0 , lc.SYSTEM_OUID FROM #LIST_COLLATE lc

DECLARE @num int
SET @num = 0

WHILE @num < (SELECT COUNT(id) FROM #UPDATE_DATA)
BEGIN
	DECLARE db_cursor CURSOR FOR
	
	WITH SXClassTree (OUID, PARENT_OUID) as (
	SELECT cls.OUID, tree.PARENT_OUID FROM SXClass cls INNER JOIN SXTREE tree 
	ON tree.OUID = cls.OUID
	INNER JOIN #UPDATE_DATA udata ON udata.id = @num AND cls.NAME = udata.name
	UNION ALL
	SELECT cls.OUID, tree.PARENT_OUID FROM SXClass cls INNER JOIN SXTREE tree 
	ON tree.OUID = cls.OUID
	INNER JOIN SXClassTree ON cls.OUID = SXClassTree.PARENT_OUID)
	
	SELECT DISTINCT pcCls.MAP, pcOuidAttr.MAP, pcAttr.MAP, cls.NAME, cls.MAP, refAttr.MAP/*, ouidCls.MAP, ouidAttr.MAP, tsCls.MAP, tsAttr.MAP*/, pcDt.A_CODE
	  FROM SXClass pcCls 
		INNER JOIN SXClassTree tree ON pcCls.OUID = tree.OUID
		INNER JOIN SXAttr pcAttr ON pcAttr.OUIDSXCLASS = pcCls.OUID AND pcAttr.ISREPL = 1 AND pcAttr.A_CASCADEREP = 1 AND pcAttr.REF_CLASS is not null
		INNER JOIN SXAttr pcOuidAttr ON pcOuidAttr.OUIDSXCLASS = pcCls.OUID AND pcOuidAttr.PKEY = 1
		INNER JOIN SXDataType pcDt ON pcAttr.OUIDDATATYPE = pcDt.OUID AND pcDt.A_CODE IN ('8','10')
		INNER JOIN SXClass cls ON cls.OUID = pcAttr.REF_CLASS AND cls.MAP is not null
		INNER JOIN SXTree clsTree ON clsTree.OUID = cls.OUID
		LEFT JOIN SXAttr refAttr ON refAttr.OUIDSXCLASS = cls.OUID AND refAttr.OUID = pcAttr.REF_ATTR AND refAttr.MAP IS NOT NULL
		WHERE cls.NAME NOT IN (SELECT name FROM #UPDATE_DATA)
			AND ((pcDt.A_CODE = '8' AND refAttr.MAP IS NOT NULL) OR pcDt.A_CODE='10')
			
	OPEN db_cursor
	DECLARE @sourceTable varchar(255), @sourceOuidField varchar(255), @sourceField varchar(255), @cls varchar(255), @table varchar(255), @ouidTable varchar(255), @ouidField varchar(255), @refField varchar(255), @tsTable varchar(255), @tsField varchar(255), @refType varchar(255) 
	FETCH NEXT FROM db_cursor
	INTO @sourceTable, @sourceOuidField, @sourceField, @cls, @table, @refField/*, @ouidTable, @ouidField, @tsTable, @tsField*/, @refType
	
	WHILE @@FETCH_STATUS = 0
	BEGIN

		WITH SXClassTree (OUID, PARENT_OUID) as (
		SELECT cls.OUID, tree.PARENT_OUID FROM SXClass cls INNER JOIN SXTREE tree 
		ON tree.OUID = cls.OUID AND cls.NAME = @cls
		UNION ALL
		SELECT cls.OUID, tree.PARENT_OUID FROM SXClass cls INNER JOIN SXTREE tree 
		ON tree.OUID = cls.OUID
		INNER JOIN SXClassTree ON cls.OUID = SXClassTree.PARENT_OUID)
		SELECT DISTINCT 
			@ouidTable = clsOuid.MAP,  @ouidField = attrOuid.MAP,
			@tsTable = clsTs.MAP, @tsField = attrTs.MAP
		FROM 
		SXClass clsOuid
		INNER JOIN SXClassTree treeOuid ON clsOuid.OUID = treeOuid.OUID 
		INNER JOIN SXAttr attrOuid ON attrOuid.OUIDSXCLASS = clsOuid.OUID AND attrOuid.PKEY = 1,
		SXClass clsTs
		INNER JOIN SXClassTree treeTs ON clsTs.OUID = treeTs.OUID 
		INNER JOIN SXAttr attrTs ON attrTs.OUIDSXCLASS = clsTs.OUID AND attrTs.A_ISTIMESTAMP = 1
		WHERE attrOuid.OUID IS NOT NULL AND attrTs.OUID IS NOT NULL
		
		IF @ouidTable IS NULL OR @ouidField IS NULL OR @tsTable IS NULL OR @tsField IS NULL
			CONTINUE
		
		EXECUTE('
		INSERT INTO #UPDATE_DATA(id,name,map,tsMap,ouidMap,ouidField,tsField)
		SELECT (SELECT COUNT(id) FROM #UPDATE_DATA) as id,
		'''+ @cls + ''', '''+ @table + ''', '''+ @ouidTable + ''', '''+ @tsTable + ''', '''+ @ouidField + ''', '''+ @tsField + '''');
		
		IF @refType = '8' BEGIN
			EXECUTE('
			INSERT INTO #UPDATE_DATA_OBJ(id,ouid)
			SELECT (SELECT COUNT(id) - 1 FROM #UPDATE_DATA) as id, ' + @ouidField + ' as OUID FROM ' + @table + '
			WHERE ' + @refField + ' IN (SELECT OUID FROM #UPDATE_DATA_OBJ WHERE ID = ' + @num  + ')
			')
		END
		ELSE IF @refType = '10' BEGIN
			EXECUTE('
			INSERT INTO #UPDATE_DATA_OBJ(id,ouid)
			SELECT (SELECT COUNT(id) - 1 FROM #UPDATE_DATA) as id, ' + @sourceField + ' as OUID FROM ' + @sourceTable + '
			WHERE ' + @sourceOuidField + ' IN (SELECT OUID FROM #UPDATE_DATA_OBJ WHERE ID = ' + @num  + ')
			AND ' + @sourceField + ' IS NOT NULL')
		END
		FETCH NEXT FROM db_cursor
		INTO @sourceTable, @sourceOuidField, @sourceField, @cls, @table, @refField/*, @ouidTable, @ouidField, @tsTable, @tsField*/, @refType
	END
	
	CLOSE db_cursor
	DEALLOCATE db_cursor
	SET @num = @num + 1	
END

DECLARE db_cursor CURSOR FOR
SELECT DISTINCT data.id, data.MAP, data.ouidMap, data.tsMap, data.ouidField, data.tsField
  FROM #UPDATE_DATA data INNER JOIN #UPDATE_DATA_OBJ o ON data.id = o.id

OPEN db_cursor
DECLARE @id varchar(255)
FETCH NEXT FROM db_cursor
INTO @id, @table, @ouidTable, @tsTable, @ouidField, @tsField
	
WHILE @@FETCH_STATUS = 0
BEGIN
	EXECUTE('
	UPDATE '+ @tsTable + ' SET '+ @tsField + ' = GETDATE()
	WHERE '+ @ouidField + ' IN (
		SELECT OUID FROM #UPDATE_DATA_OBJ WHERE id = ' + @id  + '
	)
	')
	FETCH NEXT FROM db_cursor
	INTO @id, @table, @ouidTable, @tsTable, @ouidField, @tsField
END
	
CLOSE db_cursor
DEALLOCATE db_cursor

DROP TABLE #UPDATE_DATA
DROP TABLE #UPDATE_DATA_OBJ


-------------------------------
-------------------------------
-------------------------------

   DROP TABLE #LIST_COLLATE
   TRUNCATE TABLE COLLATE_RESULT_RECAST


END
 
--   sx.datastore.db.SXDb.execute:411 
--   sx.common.replication.DoReplication.installPatch:3577 
--   sx.common.replication.SXPatchInstallParams.installPatch:89 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:89 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:128 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:709
go

