CREATE PROCEDURE [dbo].[PREPARE_FOR_CALC_HCS]
	@uuid varchar(100)
AS

DECLARE @groupId                INT
/* Таблица с агрегациям групп ЖКУ (группа ЖКУ, количество членов группы, максимальная дата начала назначения)*/
DECLARE @groupAgrTable          TABLE(groupId INT, persons INT, petDate DATETIME)
/* Таблица, в которую идет расчет коэффициента. Т.к. один и тот же член семьи может входить в разные области распространения, необходимо посчитать долю вхождения (группа ЖКУ, комбинация, услуга, льготник, члены группы из области распространения, коэффициент) */
DECLARE @factorTable            TABLE(groupId INT,
         combination INT,
         hcs INT,
         personId INT,
         relatedPerson INT,
         factor FLOAT)
/* Таблица, в которой идет распределения членов группы между областями распределения (вариант, группа ЖКУ, услуга, комбинация, процент, льготник, распределяемый член группы) */
DECLARE @relatedPersonTable     TABLE(variation INT,
         groupId INT,
         hcs INT,
         combination INT,
         cPercent FLOAT,
         personId INT,
         relatedPersonId INT)
/* Таблица, в которую выбираются члены группы, из области распространения в заявлении между областями распределения (льготник, распределяемый член группы, МСП-ЛК-НПД, группа ЖКУ) */
DECLARE @relatedPetPersonTable  TABLE(personId INT,
         relatedPerson INT,
         npdMspCat 
         INT,
         hcsGroup INT,
		 hcs INT)
/* Таблица, в которую расчитывается количество льготников с одинаковым процентом по услуге (группа ЖКУ, комбинация, услуга, процент, кол-во)*/
DECLARE @sameTable              TABLE(groupId INT,
         combination INT,
         hcs INT,
         cPercent FLOAT,
         sameCounter INT)
/* Таблица в которую отбираются все актуоальнгые члены группы, нельготники (группа ЖКУ, идентификатор нельготника) */ 
DECLARE @persTable              TABLE(groupId INT, personId INT)
/* Таблица для временных расчетов распределения (группа ЖКУ, вариация, позиция, вариант)*/
DECLARE @tmpGroupTable          TABLE(groupId INT,
         variant VARCHAR(100),
         position INT,
         variantId INT)
/* Таблица, содержащая подготовленные данные для расчетов (группа ЖКУ, идетификатор связи, услуги, связанные, область распространения, процент, вид расчета, признак использования норматива, общая площадь,
отапливаемая площадь, тариф, комбинация, признак использования  долей, признак использования норм, идентификатор алгоритма вычисления)*/
DECLARE @forCalcTable           TABLE(groupId INT,
         relation INT,
         hcs INT,
         relatedPersons 
         VARCHAR(255),
         areaOfDistr VARCHAR(15),
         cPercent FLOAT,
         calcType VARCHAR(15),
         norm BIT,
         totalSquare FLOAT,
         heatedSquare 
         FLOAT,
         tarif FLOAT,
         combination INT,
         usePortion BIT,
         useNorm BIT,
         algId INT)
/* Таблица с подготвленными даными для всавки в результирующую таблицу(TMP_DEP_PC_NPDMSPCAT) (идентификатор записи, групп ЖКУ, льготник, МСП-ЛК-НПД, услуга, процент, вид расчета, общая площадь,
отапливаемая площадь, тариф, комбинация, члены группы из области распространения, номатив, тип области распространения ) */
DECLARE @resTable               TABLE(resId INT IDENTITY(1, 1) PRIMARY KEY,
         groupId INT,
         personId INT,
         npdMspCat INT,
         hcs INT,
         cPercent FLOAT,
         calcType INT,
         totalSquare FLOAT,
         heatedSquare FLOAT,
         tarif FLOAT,
         combination INT,
         norm FLOAT,
         areaOfDistr VARCHAR(15),
         personCount INT) 
/* Таблица для квитанций по группам ЖКУ */         
DECLARE @receiptTable TABLE(groupId INT, rcptId INT, payDate DATETIME, rcptAmountId INT,
 hcs INT, pay FLOAT, useRcptNorm INT, org INT, mspLkNpd INT)   
         
/* Переменные для курсоров */
DECLARE @oldHcs                 INT,
        @oldGroupId             INT,
        @oldPersonId            INT,
        @oldPersonId2			INT,        
        @personId               INT,
        @sameCounter            FLOAT,
        @hcs                    INT,
        @groupHCS               INT,
        @variant                VARCHAR(255),
        @areaOfDistr            VARCHAR(15),
        @npdMspCat              INT,
        @combination            INT,
        @position               INT,
        @calcPercent            FLOAT,
        @oldCombination         INT,
        @variantId              INT,
        @toVar                  VARCHAR(100),
        @pos                    INT,
        @pos2                   INT,
        @posFromTable           INT,
        @calcType               VARCHAR(50),
        @isNorm                 BIT,
        @totalSquare            FLOAT,
        @heatedSquare           FLOAT,
        @needTotalSquare        FLOAT,
        @needHeatedSquare       FLOAT,
        @relatedPersonId        INT,
        @norma                  FLOAT,
        @freeTotalSquare        FLOAT,
        @freeHeatedSquare       FLOAT,
        @tarif                  FLOAT,
        @fullNorm               FLOAT,
        @preparedVariant        VARCHAR(100),
        @resId                  INT,
        @algId                  INT,
        @partTotalSquare        FLOAT,
        @partHeatedSquare       FLOAT,
        @partRelTotalSquare     FLOAT,
        @partRelHeatedSquare    FLOAT, 
        @personCount            INT,
        @usePortion             BIT,
        @useNorm                BIT,
        @socNorm                FLOAT,
        @petDate                DATETIME,
        @relatedCount           INT,
        @activeStatusId         INT,
        @petMaxDate             DATETIME,
        @hcsType                INT,
        @factor					FLOAT,
        @isGroupMSP				INT
        
        
       
        
        /* статус активен */
SELECT @activeStatusId = es.A_ID
FROM   ESRN_SERV_STATUS es
WHERE  es.a_statuscode = 'act'


/* дерево услуг */
WITH HCS_TREE (A_ID, childOuid, lvl) as (
SELECT A_ID, A_ID, 0 AS lvl FROM SPR_HSC_TYPES ev
WHERE (ev.A_STATUS = @activeStatusId OR ev.A_STATUS IS NULL)
UNION ALL
SELECT evTree.A_ID, ev.A_ID, evTree.lvl + 1 FROM SPR_HSC_TYPES ev
INNER JOIN HCS_TREE evTree ON ev.A_PARENT = evTree.childOuid
WHERE (ev.A_STATUS = @activeStatusId OR ev.A_STATUS IS NULL)
)
SELECT A_ID, childOuid INTO #HCS_TYPES FROM HCS_TREE



/* актуализируем дату самого позднего заявления в группе (т.к. заявления могут быть отсеяны)*/
SELECT @petMaxDate = MAX(CONVERT(DATETIME, CONVERT(VARCHAR(8), an.A_DATE_REG, 112)))
FROM   TMP_PC_NPDMSPCAT pn
       INNER JOIN SPR_NPD_MSP_CAT sc
            ON  pn.A_NPDMSPCAT = sc.A_ID
       INNER JOIN WM_PETITION pt
            ON  pn.A_PETITION = pt.OUID
       INNER JOIN WM_APPEAL_NEW an
            ON  pt.OUID = an.OUID
       INNER JOIN SPR_STATUS_PROCESS sp
            ON  (pt.A_STATUSPRIVELEGE = sp.A_ID AND sp.A_CODE = 8)
WHERE  (an.A_STATUS IS NULL OR an.A_STATUS = @activeStatusId)
AND pn.A_PROCESSUUID = @uuid
GROUP BY pt.A_MSP


/* Заполняем таблицу квитанций по группам ЖКУ */
INSERT INTO @receiptTable
SELECT distinct gptmp.A_FROMID AS groupId, wr.A_OUID AS rcptId,
 CONVERT(DATETIME, CONVERT(VARCHAR(8), wr.A_PAYMENT_DATE, 112)) AS payDate,
 wra.A_OUID, hs.OUID AS hcs, wra.A_PAY AS pay, 
 ISNULL(CASE WHEN nm.A_NORM IS NULL OR nm.A_NORM = 0 THEN mspLnk.A_NORM ELSE nm.A_NORM END,0) as useNorm,
 wra.A_COMPANY, nm.A_ID AS mspLkNpd
FROM TMP_PC_NPDMSPCAT pm
	INNER JOIN WM_GROUPHCS_PERSCARD gptmp
		ON  pm.A_PERSON = gptmp.A_TOID
	INNER JOIN WM_GROUPHCS_PERSCARD gp
		ON gp.A_FROMID = gptmp.A_FROMID
	INNER JOIN WM_RECEIPT wr 
		ON gp.A_TOID = wr.A_PAYER AND wr.A_FACT = 1
	INNER JOIN SPR_RECEIPT_TYPE srt 
		ON wr.A_RECEIPT_TYPE= srt.A_OUID
	INNER JOIN SPR_LINK_MSP_RTYPE mlnRcpt
		ON mlnRcpt.FROMID = pm.A_NPDMSPCAT AND mlnRcpt.TOID = srt.A_OUID
	INNER JOIN WM_HCS hs
		ON hs.A_GRHCS = gptmp.A_FROMID
	INNER JOIN  WM_RECEIPT_AMOUNT wra
		ON wra.A_RECEIPT = wr.A_OUID AND hs.A_HCSTYPE = wra.A_NAME_AMOUNT
		AND hs.A_ORG = wra.A_COMPANY
	INNER JOIN SPR_LINK_NPD_MSP_CAT_HCS mspLnk
		ON mspLnk.FROMID = pm.A_NPDMSPCAT 
    INNER JOIN #HCS_TYPES hcstps
		ON mspLnk.TOID = hcstps.A_ID   		
		AND hcstps.childOuid = wra.A_NAME_AMOUNT
	INNER JOIN SPR_NPD_MSP_CAT nm
		ON nm.A_ID = pm.A_NPDMSPCAT			
	INNER JOIN ESRN_SERV_STATUS ess
		ON (gp.A_STATUS = ess.A_ID OR gp.A_STATUS IS null)
		AND (gptmp.A_STATUS = ess.A_ID OR gptmp.A_STATUS IS null)
		AND (hs.A_STATUS = ess.A_ID OR hs.A_STATUS IS null) 
		AND (wra.A_STATUS = ess.A_ID OR wra.A_STATUS IS null) 
		AND (mspLnk.A_STATUS = ess.A_ID OR mspLnk.A_STATUS IS null) 
		AND (wr.A_STATUS = ess.A_ID OR wr.A_STATUS IS null) 
		AND (srt.A_STATUS = ess.A_ID OR srt.A_STATUS IS null) 
		AND (ess.a_statuscode = 'act')					
WHERE pm.A_PROCESSUUID = @uuid
AND (gp.A_DATE_OUT IS NULL OR  CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112)) <
        CONVERT(DATETIME, CONVERT(VARCHAR(8), pm.A_BEGINDATE, 112)))
		AND (srt.A_CODE LIKE '%hcs%' 
		AND  (wr.A_PAYMENT_DATE >= gp.A_DATE_IN 
		AND (wr.A_PAYMENT_DATE < gp.A_DATE_OUT OR gp.A_DATE_OUT IS NULL)))        
		AND wr.A_PAYMENT_DATE >= pm.A_BEGINDATE
        AND ( (hs.A_START_DATE IS NULL OR
                    	CONVERT(DATETIME, CONVERT(VARCHAR(8), case when day(hs.A_START_DATE) < 15
                    	then dateadd(day,-day(hs.A_START_DATE)+1,hs.A_START_DATE)
						ELSE dateadd(month,1,dateadd(day,-day(hs.A_START_DATE)+1,hs.A_START_DATE))
					  END, 112)) <= CONVERT(DATETIME, CONVERT(VARCHAR(8), dateadd(day,-day(wr.A_PAYMENT_DATE)+1,wr.A_PAYMENT_DATE), 112)))
                    AND 
                    (hs.A_FINISH_DATE IS NULL OR 
							CONVERT(DATETIME, CONVERT(VARCHAR(8), case when day(hs.A_FINISH_DATE) < 15
								 THEN dateadd(day,-day(hs.A_FINISH_DATE),hs.A_FINISH_DATE)
								ELSE dateadd(day,-day(dateadd(month,1,hs.A_FINISH_DATE)),
									 dateadd(month,1,hs.A_FINISH_DATE)) END, 112)) >=  CONVERT(DATETIME, CONVERT(VARCHAR(8), dateadd(day,-day(dateadd(month,1,wr.A_PAYMENT_DATE)),dateadd(month,1,wr.A_PAYMENT_DATE)), 112))
                     ))                      








SELECT distinct ps2.A_ID AS serv, pn.A_NPDMSPCAT AS mspLkNpd
INTO #groupMSP
FROM   TMP_PC_NPDMSPCAT pn
       INNER JOIN SPR_NPD_MSP_CAT sc
            ON  pn.A_NPDMSPCAT = sc.A_ID
       INNER JOIN WM_PETITION pt
            ON  pn.A_PETITION = pt.OUID
       INNER JOIN WM_APPEAL_NEW an
            ON  pt.OUID = an.OUID
       INNER JOIN PPR_SERV ps
			ON ps.A_ID = pt.A_MSP
	   INNER JOIN PPR_SERV ps2
			ON ps2.A_PARENT = ps.A_ID AND ps2.A_ID = sc.A_MSP
       INNER JOIN SPR_STATUS_PROCESS sp
            ON  (pt.A_STATUSPRIVELEGE = sp.A_ID AND sp.A_CODE = 8)
WHERE  (an.A_STATUS IS NULL OR an.A_STATUS = @activeStatusId)
AND (ps.A_STATUS IS NULL OR ps.A_STATUS = @activeStatusId)
AND pn.A_PROCESSUUID = @uuid

SELECT ROW_NUMBER() OVER(PARTITION BY A_GROUPHCS ORDER BY A_PERIODSTART DESC, ISSUEEXTENSIONSDATE DESC) AS id, *
INTO #temp
FROM (
SELECT distinct  tpn.A_GROUPHCS, docs.A_PERIODSTART, docs.ISSUEEXTENSIONSDATE, isnull(docs.A_AMOUNT_PERSON, count(lnk.A_TOID)) AS cnt
FROM (select distinct A_GROUPHCS, A_PETITION from TMP_PC_NPDMSPCAT WHERE A_PROCESSUUID = @uuid) tpn
	LEFT JOIN WM_PETITION wp
		ON tpn.A_PETITION = wp.OUID
	LEFT JOIN SPR_LINK_APPEAL_DOC petLnk
		ON petLnk.FROMID = wp.OUID
 	LEFT JOIN WM_ACTDOCUMENTS docs
 		INNER JOIN PPR_DOC pd
 			ON docs.DOCUMENTSTYPE = pd.A_ID AND pd.A_CODE = 'regFlatPersonList'
 				AND (pd.A_STATUS = @activeStatusId OR pd.A_STATUS IS NULL)
 		ON petLnk.TOID = docs.OUID
 		AND (docs.A_STATUS = @activeStatusId OR docs.A_STATUS IS NULL)
 	LEFT JOIN LINK_ACTDOC_PC lnk
 		INNER JOIN WM_PERSONAL_CARD wpc
 			ON wpc.OUID = lnk.A_TOID
 				AND (wpc.A_STATUS = @activeStatusId OR wpc.A_STATUS IS NULL)
 		ON lnk.A_FROMID = docs.OUID
WHERE (docs.A_PERIODSTART <= @petMaxDate
	AND (docs.A_PERIODFINISH >= @petMaxDate OR docs.A_PERIODFINISH IS NULL))
	AND (wpc.A_STATUS IS NULL OR wpc.A_STATUS = 10)
	AND (docs.A_STATUS IS NULL OR docs.A_STATUS = 10)
GROUP BY docs.OUID, tpn.A_GROUPHCS, docs.A_PERIODSTART, docs.ISSUEEXTENSIONSDATE, docs.A_AMOUNT_PERSON
) x


--SELECT @isGroupMSP = CASE WHEN count(distinct serv) > 0 THEN 1 ELSE 0 END FROM #groupMSP

IF (DAY(@petMaxDate) > 15) 
SET @petMaxDate = dateadd(month,1,dateadd(day,-day(@petMaxDate)+1,@petMaxDate))


           
 /* курсор для  расчёта области льготника  и причитающихся площадей */
 /* формируем результирующий набор для расчётов (добавляем данные из жилищных условий и нормативы) */
DECLARE resultCursor  CURSOR  
FOR
    SELECT DISTINCT rt.resId AS resId,
           dp         .groupId AS groupHCS,
           rt         .personId AS personId,
           rt         .npdMspCat AS npdMspCat,
           rt         .hcs AS hcs,
           rt         .combination AS combination,
           dp         .cPercent AS calcPercent,
           dp         .areaOfDistr AS areaOfDistr,
           dp         .calcType AS calcType,
           dp         .norm AS isNorm,
           fc         .A_TOTAL_SQUARE AS totalSquare,
           fc         .A_HEATED_SQUARE AS heatedSquare,
           ha         .A_VALUE AS norma,
           dp         .tarif AS tarif,
           dp         .usePortion AS usePortion,
           dp         .useNorm AS useNorm,
           ga         .petDate AS petDate,
           dp         .algId AS algId
    FROM   @resTable rt
           INNER JOIN TMP_PC_NPDMSPCAT pn ON  (rt.npdMspCat = pn.A_NPDMSPCAT AND rt.personId = pn.A_PERSON)
           AND pn.A_PROCESSUUID = @uuid
           INNER JOIN @forCalcTable dp
                ON  (pn.A_ID = dp.relation AND rt.hcs = dp.hcs)
           INNER JOIN @groupAgrTable ga
                ON  dp.groupId = ga.groupId
           INNER JOIN WM_HCS hs
                ON  (dp.hcs = hs.OUID AND dp.groupId = hs.A_GRHCS)
                AND (hs.A_STATUS = @activeStatusId OR hs.A_STATUS IS NULL)
           LEFT JOIN WM_FLAT_CONDITION fc
                ON  dp.groupId = fc.A_GROUP_HCS
                AND (fc.A_STATUS IS NULL OR fc.A_STATUS = @activeStatusId)
           LEFT JOIN SPR_HCSNORM hn
                ON  hs.A_NORM = hn.A_OUID
           LEFT JOIN SPR_HCS_NORM_AM ha
                ON  hn.A_OUID = ha.A_HCS_TYPE
                AND (ha.A_STATUS = @activeStatusId OR ha.A_STATUS IS NULL)
                AND (ha.A_NUMPEOPLE = (SELECT MAX(h.A_NUMPEOPLE)
                                      FROM   SPR_HCS_NORM_AM h
                                      WHERE  ga.persons >= h.A_NUMPEOPLE
                                             AND h.A_HCS_TYPE = ha.A_HCS_TYPE
                                             AND (h.A_STATUS = @activeStatusId OR h.A_STATUS IS NULL)
                                      GROUP BY
                                             h.A_HCS_TYPE) OR ha.A_NUMPEOPLE IS NULL)
    WHERE  dp.calcType IS NOT NULL
           AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), hs.A_START_DATE, 112)) 
                <= @petMaxDate)
           AND (hs.A_FINISH_DATE IS NULL
                OR CONVERT(DATETIME, CONVERT(VARCHAR(8), hs.A_FINISH_DATE, 112)) 
                   > @petMaxDate)
           AND (ha.A_OUID IS NULL
                OR ((ha.A_STATUS = @activeStatusId OR ha.A_STATUS IS NULL)
                    AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), ha.A_START_DATE, 112)) 
                         <= pn.A_BEGINDATE)
                    AND NOT EXISTS (SELECT 1
                                    FROM   SPR_HCS_NORM_AM hq
                                    WHERE  hq.A_HCS_TYPE = ha.A_HCS_TYPE
                                           AND (hq.A_NUMPEOPLE = ha.A_NUMPEOPLE OR (hq.A_NUMPEOPLE IS NULL AND ha.A_NUMPEOPLE IS NULL))
                                           AND CONVERT(DATETIME, CONVERT(VARCHAR(8), hq.A_START_DATE, 112)) 
                                               <= pn.A_BEGINDATE
                                           AND hq.A_START_DATE > ha.A_START_DATE
                                           AND (hq.A_STATUS = @activeStatusId OR hq.A_STATUS IS NULL)
											AND (fc.A_ROOM IS NOT NULL
												AND (hq.A_ROOM_NUMBER = (SELECT MAX(h.A_ROOM_NUMBER) room
																				FROM   SPR_HCS_NORM_AM h
																				WHERE  fc.A_ROOM >= h.A_ROOM_NUMBER
																				AND (h.A_STATUS = @activeStatusId OR h.A_STATUS IS NULL)
																				AND h.A_HCS_TYPE = hq.A_HCS_TYPE
																				AND (h.A_NUMPEOPLE = hq.A_NUMPEOPLE OR (h.A_NUMPEOPLE IS NULL AND hq.A_NUMPEOPLE IS NULL))
																				GROUP BY h.A_HCS_TYPE) OR hq.A_ROOM_NUMBER IS NULL)
												OR 
												(fc.A_ROOM IS NULL
												AND (hq.A_ROOM_NUMBER = (SELECT MIN(h.A_ROOM_NUMBER) room
																			FROM   SPR_HCS_NORM_AM h
                                             WHERE  h.A_HCS_TYPE = hq.A_HCS_TYPE
													AND (h.A_STATUS = @activeStatusId OR h.A_STATUS IS NULL)
                                                    AND (h.A_NUMPEOPLE = hq.A_NUMPEOPLE OR (h.A_NUMPEOPLE IS NULL AND hq.A_NUMPEOPLE IS NULL))
                                             GROUP BY
                                                    h.A_HCS_TYPE) OR hq.A_ROOM_NUMBER IS NULL ) ))                                             
                                           
                    )
                
                )) 
               /* номера комнат */
           AND (fc.A_OUID IS NULL
                OR (
                	(CONVERT(DATETIME, CONVERT(VARCHAR(8), fc.A_START_DATE, 112)) <= pn.A_BEGINDATE
						OR (MONTH(fc.A_START_DATE) = MONTH(pn.A_BEGINDATE) AND YEAR(fc.A_START_DATE) = YEAR(pn.A_BEGINDATE))                	
                	)
                    
                    AND NOT EXISTS (SELECT *
                                    FROM   WM_FLAT_CONDITION fq
                                    WHERE  (fq.A_START_DATE > fc.A_START_DATE
                                            AND CONVERT(DATETIME, CONVERT(VARCHAR(8), fq.A_START_DATE, 112)) 
                                                <= pn.A_BEGINDATE
                                            AND fq.A_GROUP_HCS = fc.A_GROUP_HCS
                                            AND (fq.A_STATUS = @activeStatusId OR fq.A_STATUS IS NULL)))))
                                                   
           AND (fc.A_ROOM IS NOT NULL
                AND (ha.A_ROOM_NUMBER = (SELECT MAX(h.A_ROOM_NUMBER) room
                                        FROM   SPR_HCS_NORM_AM h
                                        WHERE  fc.A_ROOM >= h.A_ROOM_NUMBER
                                               AND (h.A_STATUS = @activeStatusId OR h.A_STATUS IS NULL)
                                               AND h.A_HCS_TYPE = ha.A_HCS_TYPE
                                               AND (h.A_NUMPEOPLE = ha.A_NUMPEOPLE OR (h.A_NUMPEOPLE IS NULL AND ha.A_NUMPEOPLE IS NULL))

                                        GROUP BY
                                               h.A_HCS_TYPE) OR ha.A_ROOM_NUMBER IS NULL)
                OR (fc.A_ROOM IS NULL
                    AND (ha.A_ROOM_NUMBER = (SELECT MIN(h.A_ROOM_NUMBER) room
                                            FROM   SPR_HCS_NORM_AM h
                                            WHERE  h.A_HCS_TYPE = ha.A_HCS_TYPE
                                               AND (h.A_STATUS = @activeStatusId OR h.A_STATUS IS NULL)
                                               AND (h.A_NUMPEOPLE = ha.A_NUMPEOPLE OR (h.A_NUMPEOPLE IS NULL AND ha.A_NUMPEOPLE IS NULL))
                                            GROUP BY
                                                   h.A_HCS_TYPE) OR ha.A_ROOM_NUMBER IS NULL ) ))                                                   
                                                   
    ORDER BY
           rt.combination,
           rt         .hcs,
           dp         .cPercent DESC,
           dp         .areaOfDistr 

/* заполняем таблицу с агрегированными данными по группе */
INSERT INTO @groupAgrTable(
    groupId,
    persons,
    petDate)
SELECT tt.groupId,
       COUNT(gp.A_TOID) AS persons,
       tt.petDate
FROM   (SELECT pm.A_GROUPHCS AS groupId,
               pm.A_BEGINDATE AS petDate
        FROM   TMP_PC_NPDMSPCAT pm
        WHERE pm.A_PROCESSUUID = @uuid
        GROUP BY
               pm.A_GROUPHCS,
               pm.A_BEGINDATE) tt
       INNER JOIN WM_GROUPHCS_PERSCARD gp
            ON  tt.groupId = gp.A_FROMID
            AND (gp.A_STATUS = @activeStatusId OR gp.A_STATUS IS NULL)
            AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_IN, 112)) <=
                 @petMaxDate)
            AND (gp.A_DATE_OUT IS NULL
                 OR CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112)) 
                    > @petMaxDate)
GROUP BY
       tt.groupId,
       tt.petDate
       
UPDATE @groupAgrTable SET persons = t.cnt
FROM #temp t WHERE t.id = 1 AND t.A_GROUPHCS = groupId AND t.cnt > 0
DROP TABLE #temp       
       
       
       /* заполняем временную таблицу для промежуточных рассчётов */
INSERT INTO @forCalcTable(
    groupId,
    relation,
    hcs,
    areaOfDistr,
    cPercent,
    calcType,
    norm,
    tarif,
    usePortion,
    useNorm,
    algId)
SELECT DISTINCT tt.groupId,
       tt.relation,
       tt.hcs,
       tt.areaOfDistr,
       tt.hcvPercent,
       tt.calcType,
       tt.norm,
       tt.tarif,
       tt.usePortion,
       tt.useNorm,
       tt.algId
FROM   (SELECT DISTINCT pm.A_GROUPHCS AS groupId,
               pm.A_ID AS relation,
               hs.OUID AS hcs,
               ISNULL(nm.A_SPHERE, lh.A_HCV_AREA_OF_DISTRIB) AS areaOfDistr,
               ISNULL(CASE WHEN nm.A_PORTION IS NULL OR nm.A_PORTION = 0 THEN lh.A_PORTION ELSE nm.A_PORTION END,0) usePortion,
               ISNULL(CASE WHEN nm.A_SOC_NORM IS NULL OR nm.A_SOC_NORM = 0 THEN lh.A_SOC_NORM ELSE nm.A_SOC_NORM END,0) useNorm,
--               ISNULL(nm.A_PORTION,lh.A_PORTION) usePortion,
--               ISNULL(nm.A_SOC_NORM,lh.A_SOC_NORM) useNorm,
               lh.A_HCV_RATE AS hcvPercent,
               ca.A_CODE calcType,
               lh.A_NORM AS norm,
               sp.A_AMOUNT AS tarif,
               ca.A_ID AS algId
        FROM   TMP_PC_NPDMSPCAT pm
               INNER JOIN WM_GROUPHCS_PERSCARD wp
                    ON  pm.A_PERSON = wp.A_TOID
                    AND pm.A_GROUPHCS = wp.A_FROMID
               INNER JOIN SPR_NPD_MSP_CAT nm
                    ON  pm.A_NPDMSPCAT = nm.A_ID
               INNER JOIN SPR_LINK_NPD_MSP_CAT_HCS lh
                    ON  (nm.A_ID = lh.FROMID)
                    AND (lh.A_STATUS = @activeStatusId OR lh.A_STATUS IS NULL)
               INNER JOIN #HCS_TYPES hcstps
					ON lh.TOID = hcstps.A_ID     
               INNER JOIN WM_HCS hs
                    ON  (wp.A_FROMID = hs.A_GRHCS
                         AND hcstps.childOuid = hs.A_HCSTYPE
                         AND (hs.A_STATUS = @activeStatusId OR hs.A_STATUS IS NULL))
               INNER JOIN SPR_TARIF st
                    ON  hs.A_LNK_TARIF = st.OUID
                    AND (st.A_STATUS = @activeStatusId OR st.A_STATUS IS NULL)
               INNER JOIN PPR_CALC_ALGORITHM ca
                    ON  (st.A_CALC_TYPE = ca.A_ID
                         AND (ca.A_STATUS = @activeStatusId OR ca.A_STATUS IS NULL))
               INNER JOIN SPR_TARIF_PERIOD sp
                    ON  (st.OUID = sp.A_SERV
                         AND (sp.A_STATUS IS NULL OR sp.A_STATUS = @activeStatusId)
                         AND (DATEADD(DAY,DATEDIFF(DAY,0,sp.A_START_DATE),0) <= pm.A_BEGINDATE)
                         AND (sp.A_FIN_DATE IS NULL OR DATEADD(DAY,DATEDIFF(DAY,0,sp.A_FIN_DATE),0) >= pm.A_BEGINDATE))
        WHERE  (wp.A_STATUS = @activeStatusId OR wp.A_STATUS IS NULL)
               AND pm.A_PROCESSUUID = @uuid
               AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), wp.A_DATE_IN, 112)) 
                    <=
                    @petMaxDate)
               AND (wp.A_DATE_OUT IS NULL
                    OR CONVERT(DATETIME, CONVERT(VARCHAR(8), wp.A_DATE_OUT, 112)) 
                       > @petMaxDate)
               AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), hs.A_START_DATE, 112)) 
                    <= @petMaxDate)
               AND (hs.A_FINISH_DATE IS NULL
                    OR CONVERT(DATETIME, CONVERT(VARCHAR(8), hs.A_FINISH_DATE, 112)) 
                       > @petMaxDate)) tt
GROUP BY
       tt.groupId,
       tt.relation,
       tt.hcs,
       tt.hcvPercent,
       tt.areaOfDistr,
       tt.calcType,
       tt.norm,
       tt.tarif,
       tt.usePortion,
       tt.useNorm,
       tt.algId




SELECT DISTINCT tm.A_NPDMSPCAT, fc.hcs, fc.cPercent, ps.A_NAME AS MSP , pc.A_NAME AS LK, pna.A_NAME AS NPD
INTO #badMspLkNpd
FROM @forCalcTable fc
	INNER JOIN TMP_PC_NPDMSPCAT tm
        ON fc.relation = tm.A_ID
        AND tm.A_PROCESSUUID = @uuid
	INNER JOIN SPR_NPD_MSP_CAT snmc
		ON 	tm.A_NPDMSPCAT = snmc.A_ID 
	INNER JOIN PPR_SERV ps
		ON 	snmc.A_MSP = ps.A_ID
	LEFT JOIN PPR_CAT pc
		ON snmc.A_CATEGORY = pc.A_ID
	LEFT JOIN PPR_NPD_ARTICLE pna
		ON snmc.A_DOC = pna.A_ID
WHERE areaOfDistr IS NULL OR cPercent IS NULL OR cPercent <= 0      
	

IF EXISTS (SELECT 1 FROM #badMspLkNpd) BEGIN
--	DEALLOCATE servCur
--	DEALLOCATE groupsCur
--	DEALLOCATE groupWithHCS
	DEALLOCATE resultCursor
	
	DECLARE @msg VARCHAR(2048)
	SELECT DISTINCT @msg = '"' + MSP + '" на основании ЛК "' + LK + '" и НПД "' + NPD + '"'
	FROM #badMspLkNpd

	DROP TABLE #badMspLkNpd
	SELECT 2 AS CODE, 'Ошибка в настройках МСП по основанию. Проверьте, что настроены все необходимые параметры (Размер компенсации, область распространения по услугам) в следущих связках: ' + @msg AS MSG
    RETURN  
END    

DROP TABLE #badMspLkNpd  

       
/* вытаскиваем данные по нельготникам во временную таблицу ибо они будут нужны по нескольким запросам */
INSERT INTO @persTable(
    groupId,
    personId)
SELECT gp.A_FROMID AS groupId,
       gp.A_TOID AS personId
FROM   WM_GROUPHCS_PERSCARD gp
       INNER JOIN WM_PERSONAL_CARD wp
            ON  (gp.A_TOID = wp.OUID
                 AND (wp.A_STATUS = @activeStatusId OR wp.A_STATUS IS NULL)
                 AND (wp.A_PCSTATUS = 1 OR wp.A_PCSTATUS IS NULL))
       INNER JOIN @forCalcTable td
            ON  gp.A_FROMID = td.groupId
WHERE  wp.OUID NOT IN (SELECT pp.A_PERSON
                       FROM TMP_PC_NPDMSPCAT pp
                       WHERE pp.A_PROCESSUUID = @uuid)
       AND (gp.A_STATUS = @activeStatusId OR gp.A_STATUS IS NULL)
       AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_IN, 112)) <= @petMaxDate)
       AND (gp.A_DATE_OUT IS NULL
            OR CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112)) > @petMaxDate)
GROUP BY
       gp.A_FROMID,
       gp.A_TOID
       
SET @needTotalSquare = NULL
SET @needheatedSquare = NULL



DECLARE servCur CURSOR
FOR
SELECT DISTINCT serv FROM #groupMSP       
       
DECLARE groupWithHCS                                                 CURSOR  
FOR
    SELECT hc.A_GRHCS AS groupId,
           hc  .OUID,
           hc  .A_HCSTYPE hcs
    FROM   WM_HCS hc
           INNER JOIN TMP_PC_NPDMSPCAT pm ON  hc.A_GRHCS = pm.A_GROUPHCS
           AND pm.A_PROCESSUUID = @uuid
           INNER JOIN SPR_LINK_NPD_MSP_CAT_HCS slnmch
                ON  pm.A_NPDMSPCAT = slnmch.FROMID
           INNER JOIN #HCS_TYPES hcstps
				ON slnmch.TOID = hcstps.A_ID       
                AND hc.A_HCSTYPE = hcstps.childOuid
           INNER JOIN WM_GROUPHCS_PERSCARD gp
                ON  pm.A_GROUPHCS = gp.A_FROMID
                AND pm.A_PERSON = gp.A_TOID
                AND (gp.A_STATUS IS NULL OR gp.A_STATUS = @activeStatusId)
    WHERE  (hc.A_STATUS = @activeStatusId OR hc.A_STATUS IS NULL)
		   AND (slnmch.A_STATUS = @activeStatusId OR slnmch.A_STATUS IS NULL)
           AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), hc.A_START_DATE, 112)) 
                <= @petMaxDate)
           AND (hc.A_FINISH_DATE IS NULL
                OR CONVERT(DATETIME, CONVERT(VARCHAR(8), hc.A_FINISH_DATE, 112)) 
                   > @petMaxDate)
           AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_IN, 112)) <=
                @petMaxDate)
           AND (gp.A_DATE_OUT IS NULL
                OR CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112)) 
                   > @petMaxDate)
    GROUP BY
           hc.A_GRHCS,
           hc  .OUID,
           hc         .A_HCSTYPE

DECLARE @serv INT
OPEN servCur
FETCH NEXT FROM servCur INTO @serv
WHILE @@FETCH_STATUS = 0
BEGIN

       /* курсор по группам ЖКУ(Группа ЖКУ, ЛЬГОТНИК, ЛЬГОТА) */
DECLARE groupsCur     CURSOR  
FOR
    SELECT DISTINCT gp.A_FROMID AS groupId,
           pm         .A_PERSON AS personId,
           pm         .A_NPDMSPCAT AS npdMspCat
    FROM   TMP_PC_NPDMSPCAT pm
		   INNER JOIN SPR_NPD_MSP_CAT snmc
				ON snmc.A_ID = pm.A_NPDMSPCAT AND snmc.A_MSP = @serv
           INNER JOIN WM_GROUPHCS_PERSCARD gp
                ON  pm.A_PERSON = gp.A_TOID
                AND pm.A_GROUPHCS = gp.A_FROMID
    WHERE  (gp.A_STATUS IS NULL OR gp.A_STATUS = @activeStatusId)
           AND pm.A_PROCESSUUID = @uuid
           AND (CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_IN, 112)) <= @petMaxDate)
           AND (gp.A_DATE_OUT IS NULL
                OR CONVERT(DATETIME, CONVERT(VARCHAR(8), gp.A_DATE_OUT, 112)) 
                   > @petMaxDate)/* курсор по заявленным в  группах  услугах */
                   


OPEN groupsCur

/* идём по группам, льготникам МСП-ЛК-НПД */
FETCH NEXT FROM groupsCur INTO @groupId,@personId,@npdMspCat
SET @combination = 0
WHILE @@FETCH_STATUS = 0
BEGIN
    /* Если изменилась группа ЖКУ, то сдвигаем позицию... */
    IF (@oldGroupId <> @groupId)
       OR @oldGroupId IS NULL
    BEGIN
        DELETE 
        FROM   @tmpGroupTable
        WHERE  position = (@position - 1)
               AND groupId = @oldGroupId
        
        SET @position = 1
        SET @oldGroupId = @groupId
        SET @oldPersonId = @personId
    END
    /*  Если изменился льготник, то меняем позицию */
    IF (@oldPersonId <> @personId)
    BEGIN
        DELETE 
        FROM   @tmpGroupTable
        WHERE  position = (@position - 1)
               AND groupId = @groupId
        
        SET @position = @position + 1
        SET @oldPersonId = @personId
    END
    /* курсор по комбинациям */
    DECLARE tmpCursor     CURSOR  
    FOR
        SELECT groupId,
               variant,
               position,
               variantId  
        FROM   @tmpGroupTable
        WHERE  position = @position -1
               AND groupId = @groupId
        ORDER BY
               groupId,
               variant    
    
    OPEN tmpCursor 
    FETCH NEXT FROM tmpCursor INTO @groupHCS, @variant, @posFromTable, @variantId                                                    
    IF @@FETCH_STATUS <> 0
    BEGIN
        SET @combination = @combination + 1
        SET @preparedVariant = CONVERT(VARCHAR(10), @personId) + ':' + CONVERT(VARCHAR(10), @npdMspCat)
        INSERT INTO @tmpGroupTable(
            groupId,
            variant,
            position,
            variantId)
        VALUES(
            @groupId,
            @preparedVariant,
            @position,
            @combination)
    END
    ELSE
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @combination = @combination + 1
            SET @preparedVariant = @variant + ',' + CONVERT(VARCHAR(10), @personId) 
                + ':' + CONVERT(VARCHAR(10), @npdMspCat)
            
            INSERT INTO @tmpGroupTable(
                groupId,
                variant,
                position,
                variantId)
            VALUES(
                @groupId,
                @preparedVariant,
                @position,
                @combination)
            FETCH NEXT FROM tmpCursor INTO @groupHCS, @variant, @posFromTable, @variantId
        END
    
    CLOSE tmpCursor
    DEALLOCATE tmpCursor
    FETCH NEXT FROM groupsCur INTO @groupId, @personId, @npdMspCat
END
DELETE 
FROM   @tmpGroupTable
WHERE  position = (@position - 1)
       AND groupId = @oldGroupId
 
CLOSE groupsCur


DEALLOCATE groupsCur
	
FETCH NEXT FROM servCur INTO @serv	
END
CLOSE servCur
DEALLOCATE servCur
DROP TABLE #groupMSP



/* парсим полученные комбинации, добавляем в них услуги и проценты */
/* идём по курсору с услугами для групп */
OPEN groupWithHCS /* услуги в группе */
FETCH NEXT FROM groupWithHCS INTO @groupId, @hcs, @hcsType
WHILE @@FETCH_STATUS = 0
BEGIN
    DECLARE tmpCursor     CURSOR  
    FOR
        SELECT groupId,
               variant,
               position,
               variantId  
        FROM   @tmpGroupTable
        WHERE  groupId = @groupId
    
    OPEN tmpCursor 
    /* идём по курсорe с МСП-ЛК-НПД */
    FETCH NEXT FROM tmpCursor INTO @groupHCS, @variant, @position, @combination                                                    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        /* разбиваем */
        WHILE @variant != ''
        BEGIN
            SET @pos = CHARINDEX(',', @variant)
            /* вынимаем ЛЬГОТНИК:МСП-ЛК-НПД */
            SET @toVar = RTRIM(SUBSTRING(@variant, 0, @pos))
            /* удаляем вытащенное */
            SET @variant = LTRIM(SUBSTRING(@variant, @pos + 1, LEN(@variant)))
            /* для последней итерации */
            IF @toVar = ''
            BEGIN
                SET @toVar = @variant;
                SET @variant = '';
            END
            
            SET @pos2 = CHARINDEX(':', @toVar)
            /* ЛЬГОТНИК */
            SET @personId = CONVERT(INT, LEFT(@toVar, @pos2 -1))
            /* МСП-ЛК-НПД */
            SET @npdMspCat = CONVERT(INT, RIGHT(@toVar, LEN(@toVar) - @pos2))

            
            IF EXISTS (SELECT lh.A_OUID
                       FROM   SPR_LINK_NPD_MSP_CAT_HCS lh
								INNER JOIN #HCS_TYPES hcstps
									ON lh.TOID = hcstps.A_ID       
                       WHERE  lh.FROMID = @npdMspCat
                              AND hcstps.childOuid = @hcsType
                              AND (lh.A_STATUS IS NULL OR lh.A_STATUS = @activeStatusId) )
            BEGIN
                INSERT INTO @resTable(
                    groupId,
                    personId,
                    npdMspCat,
                    hcs,
                    combination,
                    cPercent,
                    calcType,
                    totalSquare,
                    heatedSquare,
                    tarif)
                VALUES(
                    @groupId,
                    @personId,
                    @npdMspCat,
                    @hcs,
                    @combination,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL)
            END
            
        END
        FETCH NEXT FROM tmpCursor INTO @groupHCS, @variant, @position, @combination
    END 
    CLOSE tmpCursor
    DEALLOCATE tmpCursor
    FETCH NEXT FROM groupWithHCS INTO @groupId, @hcs, @hcsType
END
CLOSE groupWithHCS



SET @oldHcs = NULL

/* проверяем есть ли заполненные люди в заявлении - для них другой расчёт */ 
INSERT INTO @relatedPetPersonTable(
    personId,
    relatedPerson,
    npdMspCat,
    hcsGroup,
	hcs)
SELECT pe.A_MSPHOLDER,
       lp.TOID,
       pn.A_NPDMSPCAT,
       gp.A_FROMID,
       ctb.hcs
FROM   TMP_PC_NPDMSPCAT pn
       INNER JOIN SPR_NPD_MSP_CAT nm
            ON  pn.A_NPDMSPCAT = nm.A_ID
       INNER JOIN WM_PETITION pe
            ON  pn.A_PETITION = pe.OUID
       INNER JOIN WM_APPEAL_NEW app
			ON app.OUID = pe.OUID     
       INNER JOIN SPR_STATUS_PROCESS sp
            ON  (pe.A_STATUSPRIVELEGE = sp.A_ID AND sp.A_CODE = 8)
       INNER JOIN SPR_LINK_PET_PC lp
            ON  lp.FROMID = pe.OUID
       INNER JOIN WM_GROUPHCS_PERSCARD gp
            ON  pe.A_MSPHOLDER = gp.A_TOID
            AND pn.A_GROUPHCS = gp.A_FROMID
       INNER JOIN @forCalcTable ctb
			ON ctb.relation = pn.A_ID AND pn.A_GROUPHCS = ctb.groupId 
				and ctb.areaOfDistr IN ('family','dependent')              
WHERE  (gp.A_STATUS IS NULL OR gp.A_STATUS = @activeStatusId)
       AND pn.A_PROCESSUUID = @uuid
       AND (app.A_STATUS IS NULL OR app.A_STATUS = @activeStatusId)
       AND (nm.A_STATUS IS NULL OR nm.A_STATUS = @activeStatusId)

drop table #HCS_TYPES

SET @relatedCount = 0

---------------------------------------------------------------------------------

OPEN resultCursor
FETCH NEXT FROM resultCursor INTO @resId, @groupHCS, @personId, @npdMspCat, @hcs, 
@combination, @calcPercent, @areaOfDistr,
@calcType, @isNorm, @totalSquare, @heatedSquare, @norma, @tarif, @usePortion, @useNorm, 
@petDate, @algId 

WHILE @@FETCH_STATUS = 0
BEGIN
	
    IF (@areaOfDistr = 'family' OR @areaOfDistr = 'dependent')
    BEGIN
        /* курсор, вылавливающий доступных для распределения членов семьи */
        DECLARE relatedPersonsCursor CURSOR  
        FOR
            SELECT DISTINCT pt.personId AS relatedPerson
            FROM   @persTable pt
            WHERE  pt.groupId = @groupHCS
                   AND NOT EXISTS (SELECT *
                                   FROM   @relatedPersonTable rp
                                   WHERE  groupId = pt.groupId
                                          AND hcs = @hcs
                                          AND combination = @combination
                                          AND cPercent > @calcPercent
                                          AND relatedPersonId = pt.personId)
                   AND (NOT EXISTS (SELECT *
                                    FROM   @relatedPetPersonTable WHERE hcs = @hcs)
                        OR NOT EXISTS (SELECT *
                                       FROM   @relatedPetPersonTable pp
                                       WHERE  pp.relatedPerson = pt.personId
											  AND pp.hcs = @hcs
                                              /*AND pp.npdMspCat = @npdMspCat*/)
                        OR EXISTS (SELECT *
                                   FROM   @relatedPetPersonTable pp
                                   WHERE  pp.personId = @personId
                                          AND pp.relatedPerson = pt.personId
                                          AND pp.npdMspCat = @npdMspCat 
                                          AND pp.hcs = @hcs))
        
        OPEN relatedPersonsCursor
        FETCH NEXT FROM relatedPersonsCursor INTO @relatedPersonId
        
        WHILE @@FETCH_STATUS = 0
        BEGIN
            /* если область распространения на иждевенцев, то проверяем является ли иждевенцем */
            IF ((@areaOfDistr = 'dependent')
                AND EXISTS (SELECT *
                            FROM   WM_RELATEDRELATIONSHIPS rs
                            WHERE  rs.A_ID1 = @personId
								   AND (rs.A_STATUS IS NULL OR rs.A_STATUS = @activeStatusId)
                                   AND rs.A_ID2 = @relatedPersonId
                                   AND rs.A_MAINTENANCE = 1))
               OR (@areaOfDistr = 'family')
            BEGIN
                SET @relatedCount = @relatedCount + 1 
                INSERT INTO @relatedPersonTable(
                    groupId,
                    hcs,
                    combination,
                    cPercent,
                    personId,
                    relatedPersonId)
                VALUES(
                    @groupHCS,
                    @hcs,
                    @combination,
                    @calcPercent,
                    @personId,
                    @relatedPersonId)
            END
            
            FETCH NEXT FROM relatedPersonsCursor INTO @relatedPersonId
        END
        CLOSE relatedPersonsCursor 
        DEALLOCATE relatedPersonsCursor



    	
    END		
	
	
    FETCH NEXT FROM resultCursor INTO @resId, @groupHCS, @personId, @npdMspCat, 
    @hcs, @combination, @calcPercent, @areaOfDistr,
    @calcType, @isNorm, @totalSquare, @heatedSquare, @norma, @tarif, @usePortion, 
    @useNorm, @petDate,@algId	
END	
CLOSE resultCursor

/* считаем коэффициент */

INSERT INTO @factorTable(
    groupId,
    combination,
    hcs,
    personId,
    relatedPerson,
    factor)
SELECT tt.groupId,
       tt.combination,
       tt.hcs,
       rt.personId,
       tt.relatedPersonId,
       1.0 / tt.factor AS factor
FROM   (SELECT groupId,
               combination,
               hcs,
               relatedPersonId,
               COUNT(*) AS factor
        FROM   @relatedPersonTable
        GROUP BY
               groupId,
               combination,
               hcs,
               cPercent,
               relatedPersonId) tt
       INNER JOIN @relatedPersonTable rt
            ON  tt.groupId = rt.groupId
            AND tt.combination = rt.combination
            AND tt.hcs = rt.hcs
            AND tt.relatedPersonId = rt.relatedPersonId
---------------------------------------------------------------------------------------------
 
OPEN resultCursor
FETCH NEXT FROM resultCursor INTO @resId, @groupHCS, @personId, @npdMspCat, @hcs, 
@combination, @calcPercent, @areaOfDistr,
@calcType, @isNorm, @totalSquare, @heatedSquare, @norma, @tarif, @usePortion, @useNorm, 
@petDate, @algId 

WHILE @@FETCH_STATUS = 0
BEGIN
    /* в зависимости от процента распределяем людей между льготниками запросом */    
    IF (@areaOfDistr = 'family' OR @areaOfDistr = 'dependent')
    BEGIN
        IF (@oldHcs IS NULL
            OR @oldHcs <> @hcs
            OR @oldPersonId <> @personId
            OR @oldPersonId IS NULL)
        BEGIN
            SET @oldPersonId = @personId
        END            
    END
    
            /* смотрим сколько людей в группе */
            SELECT @personCount = ga.persons
            FROM   @groupAgrTable ga
            WHERE  ga.groupId = @groupHCS    
    
    /* если расчёт зависит от площадей, то распределяем площади */
    IF (@calcType LIKE 'area%' OR @calcType LIKE 'heat%')
    BEGIN
        IF (@oldHcs <> @hcs
            OR @oldHcs IS NULL
            OR @oldCombination <> @combination
            OR @oldCombination IS NULL
			OR @personId <> @oldPersonId2
			OR @oldPersonId2 IS NULL)
        BEGIN
            SET @oldCombination = @combination
            SET @freeTotalSquare = @totalSquare
            SET @freeHeatedSquare = @heatedSquare

            /* вытаскиваем соц норму */
            SELECT TOP 1 @socNorm = ss.A_NORM
            FROM   SPR_SOCNORM ss
            WHERE  ss.A_PERSNUM <= @personCount
				   AND (ss.A_STATUS IS NULL OR ss.A_STATUS = @activeStatusId)
                   AND (ss.A_BDATE <= @petDate OR ss.A_BDATE IS NULL)
                   AND (ss.A_EDATE >= @petDate OR ss.A_EDATE IS NULL)
            ORDER BY
                   ss.A_PERSNUM DESC 
            /* в  случае, когда использовать и доли и нормативы, у льготников по долям, у остальных по нормативам */ 
            /* для льготников */
            SET @partTotalSquare = @totalSquare / @personCount 
            SET @partHeatedSquare = @heatedSquare / @personCount
            /* для членов группы из области распространения */
            SET @partRelTotalSquare = @partTotalSquare 
            SET @partRelHeatedSquare = @partHeatedSquare 
            /* в зависимости от комбинации флагов определяем часть площади */
            IF (@useNorm = 1 AND @usePortion = 1)
            BEGIN
                IF (@partTotalSquare > @socNorm)
                BEGIN
                    SET @partRelTotalSquare = @socNorm
                END
                
                IF (@partHeatedSquare > @socNorm)
                BEGIN
                    SET @partRelHeatedSquare = @socNorm
                END
            END
            ELSE 
            IF (@useNorm = 1 AND @usePortion = 0)
               OR (@useNorm = 0 AND @usePortion = 0)
            BEGIN
                IF (@partTotalSquare > @socNorm)
                BEGIN
                    SET @partTotalSquare = @socNorm
                    SET @partRelTotalSquare = @socNorm
                END
                
                IF (@partHeatedSquare > @socNorm)
                BEGIN
                    SET @partHeatedSquare = @socNorm 
                    SET @partRelHeatedSquare = @socNorm
                END
            END
            
            SET @oldHcs = @hcs
            SET @oldPersonId2 = @personId

        END
        
		SELECT @factor = isnull(SUM(factor),0) FROM @factorTable 
		WHERE  groupId = @groupHCS
			AND combination = @combination
			AND hcs = @hcs
			AND personId = @personId        
        
        
        IF (@calcType LIKE 'area%')
        BEGIN
            IF (@freeTotalSquare > 0)
            BEGIN
                SET @needTotalSquare = @partTotalSquare + (@partRelTotalSquare * @factor)
                SET @freeTotalSquare = @freeTotalSquare - @needTotalSquare
            END
            ELSE
            BEGIN
                SET @needTotalSquare = 0
            END
        END
        ELSE 
        IF (@calcType LIKE 'heat%')
        BEGIN
            IF (@freeHeatedSquare > 0)
            BEGIN
                SET @needHeatedSquare = @partHeatedSquare + (@partRelHeatedSquare * @factor)
                SET @freeHeatedSquare = @freeHeatedSquare - @needHeatedSquare
            END
            ELSE
            BEGIN
                SET @needHeatedSquare = 0
            END
        END
    END
    ELSE
    BEGIN
        SET @needHeatedSquare = NULL
        SET @needTotalSquare = NULL
    END
    /* заносим результат во временную таблицу */
    UPDATE @resTable SET
           totalSquare = @needTotalSquare,
           heatedSquare = @needHeatedSquare,
           cPercent = @calcPercent,
           calcType = @algId,
           tarif = @tarif,
           norm = @norma,
           areaOfDistr = @areaOfDistr,
           personCount = CASE WHEN @personCount < 0 THEN 1 ELSE @personCount END
    WHERE  resId = @resId
    
    FETCH NEXT FROM resultCursor INTO @resId, @groupHCS, @personId, @npdMspCat, 
    @hcs, @combination, @calcPercent, @areaOfDistr,
    @calcType, @isNorm, @totalSquare, @heatedSquare, @norma, @tarif, @usePortion, 
    @useNorm, @petDate,@algId
END
CLOSE resultCursor          
 
DELETE FROM TMP_DEP_PC_NPDMSPCAT WHERE A_PROCESSUUID = @uuid
/* результат в таблицу для дальнейших расчётов */
INSERT INTO TMP_DEP_PC_NPDMSPCAT(
    A_GROUPHCS,
    A_PERSON,
    A_NPDMSPCAT,
    A_HCS,
    A_COMBINATION,
    A_PERCENT,
    A_CALCTYPE,
    A_TSQUARE,
    A_HSQUARE,
    A_TARIF,
    A_NORM,
    A_FACTOR,
    A_AREA_COUNT,
    A_SPHERE,
    A_ALL_PERSONS,
    A_PROCESSUUID,
    A_RECEIPT,
	A_RCPT_AMOUNT,
	A_RCPT_AMOUNT_SUM,
	A_USE_NORM)
SELECT rt.groupId,
       rt.personId,
       rt.npdMspCat,
       rt.hcs,
       rt.combination,
       rt.cPercent,
       rt.calcType,
       round(rt.totalSquare,4),
       round(rt.heatedSquare,4),
       0,
       rt.norm,
       ISNULL((SELECT SUM(tt.factor) AS factor
               FROM   @factorTable tt
               WHERE  tt.groupId = rt.groupId
                      AND tt.combination = rt.combination
                      AND tt.hcs = rt.hcs
                      AND tt.personId = rt.personId
               GROUP BY
                      tt.combination,
                      tt.hcs),
        0) AS factor,
       qt.areaCount,
       rt.areaOfDistr,
       rt.personCount,
       @uuid,
       rcpt.rcptId,
       rcpt.rcptAmountId,
       ISNULL(rcpt.pay,0),
       0
FROM   @resTable rt 
LEFT JOIN (SELECT groupId,
                         combination,
                         hcs,
                         personId,
                         COUNT(rpt.relatedPersonId) areaCount
                  FROM   @relatedPersonTable rpt
                  GROUP BY
                         groupId,
                         combination,
                         hcs,
                         personId) qt
            ON  rt.groupId = qt.groupId
            AND rt.hcs = qt.hcs
            AND rt.combination = qt.combination
            AND rt.personId = qt.personId
INNER JOIN WM_HCS wh
		ON wh.OUID = rt.hcs            
LEFT JOIN @receiptTable rcpt
	ON rt.groupId = rcpt.groupId
	AND rt.hcs = rcpt.hcs
	AND YEAR(@petMaxDate) = YEAR(rcpt.payDate)
	AND MONTH(@petMaxDate) = MONTH(rcpt.payDate)
	AND wh.A_ORG = rcpt.org
	AND rcpt.mspLkNpd = rt.npdMspCat	            
DELETE FROM TMP_DEP_PC_LINK WHERE A_PROCESSUUID = @uuid
            
/* Заполняем области распространения */
INSERT INTO TMP_DEP_PC_LINK(
    A_FROMID,
    A_TOID,
    A_PROCESSUUID)
SELECT tdpn.A_ID,
       rpt.relatedPersonId,
       @uuid
FROM   TMP_DEP_PC_NPDMSPCAT tdpn
       INNER JOIN @relatedPersonTable rpt
            ON  tdpn.A_PERSON = rpt.personId
            AND tdpn.A_HCS = rpt.hcs
            AND tdpn.A_COMBINATION = rpt.combination
       WHERE tdpn.A_PROCESSUUID = @uuid

       DEALLOCATE groupWithHCS
       DEALLOCATE resultCursor
--       DEALLOCATE groupsCur


 
SELECT 0 AS CODE, 'Назначение льгот ЖКУ завершено завершено' AS MSG
 
--   sx.datastore.db.SXDb.execute:-1 
--   sx.common.replication.DoReplication.installPatch:-1 
--   sx.common.replication.SXPatchInstallParams.installPatch:-1 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:-1 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:-1 
--   sx.admin.AdmDispatchAction.execute:-1 
--   sx.admin.AdmServletUtil.processAction:-1 
--   sx.admin.AdmServlet.doGet:-1 
--   sx.admin.AdmServlet.doPost:-1 
--   javax.servlet.http.HttpServlet.service:710
go

