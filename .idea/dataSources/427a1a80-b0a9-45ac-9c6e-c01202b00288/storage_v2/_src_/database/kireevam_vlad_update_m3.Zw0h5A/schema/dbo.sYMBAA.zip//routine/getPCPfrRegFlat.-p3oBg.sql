CREATE FUNCTION dbo.getPCPfrRegFlat(
 @pcId as INT
) RETURNS varchar(255)
AS
BEGIN
 -- "Количество путевок" в "Контракт с поставщиком ТСР"	
 DECLARE @result varchar(255)
 SELECT @result = A_ADDRESS
 FROM GSP_SOC_SERV
 WHERE GSP_SOC_SERV.A_PC = @pcId

 RETURN @result
END;
 
--   sx.datastore.db.SXDb.getStackTraceAsString:2954 
--   sx.datastore.db.SXDb.execute:464 
--   sx.common.replication.DoReplication.installPatch:2996 
--   sx.common.replication.SXPatchInstallParams.installPatch:84 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:191 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:171 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:39 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:25 
--   java.lang.reflect.Method.invoke:597 
--   sx.admin.AdmDispatchAction.dispatchMethod:96 
--   sx.admin.AdmDispatchAction.execute:51 
--   sx.admin.AdmServletUtil.processAction:153 
--   sx.admin.AdmServlet.doGet:78
go

