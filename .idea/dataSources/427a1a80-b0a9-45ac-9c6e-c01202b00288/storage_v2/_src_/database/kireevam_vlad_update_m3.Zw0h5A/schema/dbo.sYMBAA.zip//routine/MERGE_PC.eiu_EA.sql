CREATE PROCEDURE [dbo].[MERGE_PC] (
	@mainOuid INT, 
	@dupOuid INT,
	@trustLevel INT,
	@mainIdentType INT
)
AS
BEGIN
-- СЃРѕР·РґР°РµРј С‚Р°Р±Р»РёС†Сѓ, РєСѓРґР° Р±СѓРґРµРј СЃРєР»Р°РґС‹РІР°С‚СЊ РѕР±СЉРµРєС‚С‹ РґР»СЏ РѕР±СЂР°Р±РѕС‚РєРё
CREATE TABLE #DUPLICATE_OBJECTS (
		num INT IDENTITY(1,1), 
		objClass VARCHAR(128), -- РєРѕРґРѕРІРѕРµ РёРјСЏ РєР»Р°СЃСЃР°
		mainOuid INT,		   -- РѕСЃРЅРѕРІРЅРѕР№ РёРґРµРЅС‚РёС„РёРєР°С‚РѕСЂ
		dupOuid INT,		   -- РёРґРµРЅС‚РёС„РёРєР°С‚РѕСЂ РґСѓР±Р»СЏ
		delType INT			   -- 0 - РЅРµ СѓРґР°Р»СЏРµРј, 1 - СѓРґР°Р»СЏРµРј С„РёР·РёС‡РµСЃРєРё, 2 - СѓРґР°Р»СЏРµРј Р»РѕРіРёС‡РµСЃРєРё
)	

DECLARE @pcCls VARCHAR(128), @pcDelType INT
SET @pcCls = 'wmPersonalCard'
SET @pcDelType = 1

DECLARE @actAttrOuid INT
SELECT @actAttrOuid = A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act'

-- Р­С‚Рѕ РґР»СЏ СЂСѓС‡РЅРѕР№ СЃР»РёРІРєРё... РјС‹ РїРµСЂРµРґР°РµРј С‚РѕР»СЊРєРѕ РґРІР° РёРґРµРЅС‚РёС„РёРєР°С‚РѕСЂР° Рё РІСЃРµ
IF(@mainOuid IS NOT NULL AND @dupOuid IS NOT NULL) 
BEGIN
	INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
	SELECT @pcCls, pcMain.OUID, pcDUp.OUID, @pcDelType
	FROM WM_PERSONAL_CARD pcMain, WM_PERSONAL_CARD pcDup
	WHERE pcMain.OUID = @mainOuid AND pcDUp.OUID = @dupOuid
END
-- Р·РґРµСЃСЊ РёРґРµС‚ Р»РѕРіРёРєР° РѕР±СЂР°Р±РѕС‚РєРё СЃР»РёРІРєРё РЅР° РѕСЃРЅРѕРІРµ РІСЂРµРјРµРЅРЅРѕР№ С‚Р°Р±Р»РёС†С‹
ELSE IF(@trustLevel IS NOT NULL AND @mainIdentType = 1) BEGIN
	INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
	SELECT DISTINCT @pcCls, mainPc.OUID, dupPc.OUID, @pcDelType
	FROM TEMP_REPL_ID temp 
	INNER JOIN TEMP_REPL_ID_LINK tempLink ON temp.A_OUID = tempLink.A_FROMID
	INNER JOIN WM_PERSONAL_CARD mainPc ON mainPc.OUID = temp.A_SOURCE_OUID
	INNER JOIN WM_PERSONAL_CARD dupPc ON dupPc.OUID = tempLink.A_TOID
	WHERE temp.A_TRUST_LEVEL >= @trustLevel
END
ELSE IF(@trustLevel IS NOT NULL AND @mainIdentType = 2) BEGIN
	INSERT INTO #DUPLICATE_OBJECTS(objClass,mainOuid,dupOuid,delType)
	SELECT DISTINCT @pcCls, mainPc.OUID, dupPc.OUID, @pcDelType
	FROM TEMP_REPL_ID temp 
	INNER JOIN TEMP_REPL_ID_LINK tempLink ON temp.A_OUID = tempLink.A_FROMID
	INNER JOIN WM_PERSONAL_CARD mainPc ON mainPc.OUID = tempLink.A_TOID
	INNER JOIN WM_PERSONAL_CARD dupPc ON dupPc.OUID = temp.A_SOURCE_OUID
	WHERE temp.A_TRUST_LEVEL >= @trustLevel
END
-- РїСЂРѕРёР·РІРѕРґРёРј РѕС‡РёСЃС‚РєСѓ РїРµСЂРµСЃРµС‡РµРЅРЅС‹С… РѕР±СЉРµРєС‚РѕРІ РЅР° СЃР»СѓС‡Р°Р№ РІСЃС‚СЂРµС‡РЅРѕРіРѕ СѓРґР°Р»РµРЅРёСЏ
-- РёР»Рё РЅР°Р»РёС‡РёСЏ С†РµРїРѕС‡РµРє СѓРґР°Р»РµРЅРёСЏ
DELETE FROM #DUPLICATE_OBJECTS
FROM (
	SELECT dups1.mainOuid, dups1.dupOuid
	FROM #DUPLICATE_OBJECTS dups1 INNER JOIN #DUPLICATE_OBJECTS dups2
	ON dups1.objClass = dups2.objClass AND dups1.mainOuid = dups2.dupOuid 
) x
WHERE #DUPLICATE_OBJECTS.mainOuid IN (x.mainOuid,x.dupOuid) OR #DUPLICATE_OBJECTS.dupOuid IN (x.mainOuid,x.dupOuid)

-- РґРѕР±Р°РІР»СЏРµРј РІ РѕСЃРЅРѕРІРЅС‹Рµ Р›Р” РёСЃС‚РѕСЂРёСЋ РіСѓРёРґРѕРІ
INSERT INTO PC_GUID_HISTORY (GUID, TS, A_PC, A_SERVERID, A_COMPLYGUID)
SELECT NEWID(), GETDATE(), dups.mainOuid, dupPc.A_REG_ORGNAME, dupPc.GUID
FROM #DUPLICATE_OBJECTS dups 
INNER JOIN WM_PERSONAL_CARD dupPc ON dups.dupOuid = dupPc.OUID

-- СѓРґР°Р»СЏРµРј РёР· СЃРІСЏР·Рё MxN СЂРµР·СѓР»СЊС‚Р°С‚РѕРІ РёРґРµРЅС‚РёС„РёРєР°С†РёРё Рё Р·Р°РїРёСЃРё РґСѓР±Р»РµР№
IF(@mainIdentType IS NOT NULL AND @trustLevel IS NOT NULL) BEGIN
	DELETE FROM TEMP_REPL_ID_LINK
	WHERE A_TOID IN (SELECT dupOuid FROM #DUPLICATE_OBJECTS)
	
	DELETE FROM TEMP_REPL_ID_LINK
	WHERE A_FROMID IN (
		SELECT temp.A_OUID FROM TEMP_REPL_ID temp
		INNER JOIN #DUPLICATE_OBJECTS dups ON temp.A_SOURCE_OUID = dups.dupOuid
	)

	DELETE FROM TEMP_REPL_ID
	WHERE A_SOURCE_OUID IN (SELECT dupOuid FROM #DUPLICATE_OBJECTS)
END
-- СЃРѕР±РёСЂР°РµРј РґСѓР±Р»Рё РїРѕ РѕСЃС‚Р°РІС€РµРјСЃСЏ
EXECUTE MERGE_PC_FILL_DUPS

SELECT * FROM #DUPLICATE_OBJECTS

-- Р·Р°РїСѓСЃРєР°РµРј РїСЂРѕС†РµСЃСЃ РѕР±СЂР°Р±РѕС‚РєРё РґСѓР±Р»РµР№
EXECUTE PROCESS_DUPLICATE_OBJECTS

IF(@mainIdentType = 2) BEGIN
	UPDATE WM_PERSONAL_CARD SET A_ISREPLOBJ = 0, TS = GETDATE()
	WHERE A_ISREPLOBJ = 1  AND OUID IN (
		SELECT temp.A_SOURCE_OUID FROM TEMP_REPL_ID temp
        LEFT JOIN TEMP_REPL_ID_LINK tempLink
        ON tempLink.A_FROMID = temp.A_OUID
        WHERE tempLink.A_FROMID IS NULL
    )
        
    UPDATE WM_PERSONAL_CARD SET A_PCSTATUS = 1, TS = GETDATE()
    WHERE A_PCSTATUS = 2 AND OUID IN (
        SELECT temp.A_SOURCE_OUID FROM TEMP_REPL_ID temp
        LEFT JOIN TEMP_REPL_ID_LINK tempLink
        ON tempLink.A_FROMID = temp.A_OUID
        WHERE tempLink.A_FROMID IS NULL
    )
END
	
DELETE FROM TEMP_REPL_ID
WHERE A_OUID IN (
	SELECT temp.A_OUID FROM TEMP_REPL_ID temp
    LEFT JOIN TEMP_REPL_ID_LINK tempLink
    INNER JOIN WM_PERSONAL_CARD pc ON tempLink.A_TOID = pc.OUID AND (pc.A_STATUS = @actAttrOuid OR pc.A_STATUS IS NULL)
    ON tempLink.A_FROMID = temp.A_OUID
    WHERE tempLink.A_TOID IS NULL
)

-------------------------------
-------------------------------
-------------------------------

CREATE TABLE #UPDATE_DATA (
	"id" int,
	"name" varchar(256),
	"map" varchar(256),
	"tsMap" varchar(256),
	"ouidMap" varchar(256),
	"ouidField" varchar(256),
	"tsField" varchar(256)
)

CREATE TABLE #UPDATE_DATA_OBJ (
	"id" int,
	"ouid" int
)

INSERT INTO #UPDATE_DATA(id,name,map,tsMap,ouidMap,ouidField,tsField) 
VALUES(0,'wmPersonalCard','WM_PERSONAL_CARD','WM_PERSONAL_CARD','WM_PERSONAL_CARD','OUID','TS')
INSERT INTO #UPDATE_DATA_OBJ(id,ouid) 
SELECT DISTINCT 0 , dups.mainOuid FROM #DUPLICATE_OBJECTS dups

DECLARE @num int
SET @num = 0

RETURN;

WHILE @num < (SELECT COUNT(id) FROM #UPDATE_DATA)
BEGIN
	DECLARE db_cursor CURSOR FOR
	
	WITH SXClassTree (OUID, PARENT_OUID) as (
	SELECT cls.OUID, tree.PARENT_OUID FROM SXClass cls INNER JOIN SXTREE tree 
	ON tree.OUID = cls.OUID
	INNER JOIN #UPDATE_DATA udata ON udata.id = @num AND cls.NAME = udata.name
	UNION ALL
	SELECT cls.OUID, tree.PARENT_OUID FROM SXClass cls INNER JOIN SXTREE tree 
	ON tree.OUID = cls.OUID
	INNER JOIN SXClassTree ON cls.OUID = SXClassTree.PARENT_OUID)
	
	SELECT DISTINCT pcCls.MAP, pcOuidAttr.MAP, pcAttr.MAP, cls.NAME, cls.MAP, refAttr.MAP/*, ouidCls.MAP, ouidAttr.MAP, tsCls.MAP, tsAttr.MAP*/, pcDt.A_CODE
	  FROM SXClass pcCls 
		INNER JOIN SXClassTree tree ON pcCls.OUID = tree.OUID
		INNER JOIN SXAttr pcAttr ON pcAttr.OUIDSXCLASS = pcCls.OUID AND pcAttr.ISREPL = 1 AND pcAttr.A_CASCADEREP = 1 AND pcAttr.REF_CLASS is not null
		INNER JOIN SXAttr pcOuidAttr ON pcOuidAttr.OUIDSXCLASS = pcCls.OUID AND pcOuidAttr.PKEY = 1
		INNER JOIN SXDataType pcDt ON pcAttr.OUIDDATATYPE = pcDt.OUID AND pcDt.A_CODE IN ('8','10')
		INNER JOIN SXClass cls ON cls.OUID = pcAttr.REF_CLASS AND cls.MAP is not null
		INNER JOIN SXTree clsTree ON clsTree.OUID = cls.OUID
		LEFT JOIN SXAttr refAttr ON refAttr.OUIDSXCLASS = cls.OUID AND refAttr.OUID = pcAttr.REF_ATTR AND refAttr.MAP IS NOT NULL
		WHERE cls.NAME NOT IN (SELECT name FROM #UPDATE_DATA)
			AND ((pcDt.A_CODE = '8' AND refAttr.MAP IS NOT NULL) OR pcDt.A_CODE='10')
			
	OPEN db_cursor
	DECLARE @sourceTable varchar(255), @sourceOuidField varchar(255), @sourceField varchar(255), @cls varchar(255), @table varchar(255), @ouidTable varchar(255), @ouidField varchar(255), @refField varchar(255), @tsTable varchar(255), @tsField varchar(255), @refType varchar(255) 
	FETCH NEXT FROM db_cursor
	INTO @sourceTable, @sourceOuidField, @sourceField, @cls, @table, @refField/*, @ouidTable, @ouidField, @tsTable, @tsField*/, @refType
	
	WHILE @@FETCH_STATUS = 0
	BEGIN

		WITH SXClassTree (OUID, PARENT_OUID) as (
		SELECT cls.OUID, tree.PARENT_OUID FROM SXClass cls INNER JOIN SXTREE tree 
		ON tree.OUID = cls.OUID AND cls.NAME = @cls
		UNION ALL
		SELECT cls.OUID, tree.PARENT_OUID FROM SXClass cls INNER JOIN SXTREE tree 
		ON tree.OUID = cls.OUID
		INNER JOIN SXClassTree ON cls.OUID = SXClassTree.PARENT_OUID)
		SELECT DISTINCT 
			@ouidTable = clsOuid.MAP,  @ouidField = attrOuid.MAP,
			@tsTable = clsTs.MAP, @tsField = attrTs.MAP
		FROM 
		SXClass clsOuid
		INNER JOIN SXClassTree treeOuid ON clsOuid.OUID = treeOuid.OUID 
		INNER JOIN SXAttr attrOuid ON attrOuid.OUIDSXCLASS = clsOuid.OUID AND attrOuid.PKEY = 1,
		SXClass clsTs
		INNER JOIN SXClassTree treeTs ON clsTs.OUID = treeTs.OUID 
		INNER JOIN SXAttr attrTs ON attrTs.OUIDSXCLASS = clsTs.OUID AND attrTs.A_ISTIMESTAMP = 1
		WHERE attrOuid.OUID IS NOT NULL AND attrTs.OUID IS NOT NULL
		
		IF @ouidTable IS NOT NULL AND @ouidField IS NOT NULL AND @tsTable IS NOT NULL AND @tsField IS NOT NULL
		BEGIN
		
			EXECUTE('
			INSERT INTO #UPDATE_DATA(id,name,map,tsMap,ouidMap,ouidField,tsField)
			SELECT (SELECT COUNT(id) FROM #UPDATE_DATA) as id,
			'''+ @cls + ''', '''+ @table + ''', '''+ @ouidTable + ''', '''+ @tsTable + ''', '''+ @ouidField + ''', '''+ @tsField + '''');
			
			IF @refType = '8' BEGIN
				EXECUTE('
				INSERT INTO #UPDATE_DATA_OBJ(id,ouid)
				SELECT (SELECT COUNT(id) - 1 FROM #UPDATE_DATA) as id, ' + @ouidField + ' as OUID FROM ' + @table + '
				WHERE ' + @refField + ' IN (SELECT OUID FROM #UPDATE_DATA_OBJ WHERE ID = ' + @num  + ')
				')
			END
			ELSE IF @refType = '10' BEGIN
				EXECUTE('
				INSERT INTO #UPDATE_DATA_OBJ(id,ouid)
				SELECT (SELECT COUNT(id) - 1 FROM #UPDATE_DATA) as id, ' + @sourceField + ' as OUID FROM ' + @sourceTable + '
				WHERE ' + @sourceOuidField + ' IN (SELECT OUID FROM #UPDATE_DATA_OBJ WHERE ID = ' + @num  + ')
				AND ' + @sourceField + ' IS NOT NULL')
			END
		END
		FETCH NEXT FROM db_cursor
		INTO @sourceTable, @sourceOuidField, @sourceField, @cls, @table, @refField/*, @ouidTable, @ouidField, @tsTable, @tsField*/, @refType
	END
	
	CLOSE db_cursor
	DEALLOCATE db_cursor
	SET @num = @num + 1	
END

DECLARE db_cursor CURSOR FOR
SELECT DISTINCT data.id, data.MAP, data.ouidMap, data.tsMap, data.ouidField, data.tsField
  FROM #UPDATE_DATA data INNER JOIN #UPDATE_DATA_OBJ o ON data.id = o.id

OPEN db_cursor
DECLARE @id varchar(255)
FETCH NEXT FROM db_cursor
INTO @id, @table, @ouidTable, @tsTable, @ouidField, @tsField
	
WHILE @@FETCH_STATUS = 0
BEGIN
	EXECUTE('
	UPDATE '+ @tsTable + ' SET '+ @tsField + ' = GETDATE()
	WHERE '+ @ouidField + ' IN (
		SELECT OUID FROM #UPDATE_DATA_OBJ WHERE id = ' + @id  + '
	)
	')
	FETCH NEXT FROM db_cursor
	INTO @id, @table, @ouidTable, @tsTable, @ouidField, @tsField
END
	
CLOSE db_cursor
DEALLOCATE db_cursor

DROP TABLE #UPDATE_DATA
DROP TABLE #UPDATE_DATA_OBJ

-------------------------------
-------------------------------
-------------------------------

DROP TABLE #DUPLICATE_OBJECTS

END
go

