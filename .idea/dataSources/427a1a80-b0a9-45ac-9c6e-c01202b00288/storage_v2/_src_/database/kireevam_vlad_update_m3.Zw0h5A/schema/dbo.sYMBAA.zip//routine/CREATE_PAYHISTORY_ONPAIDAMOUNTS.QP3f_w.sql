CREATE PROCEDURE [dbo].[CREATE_PAYHISTORY_ONPAIDAMOUNTS]
	(@file VARCHAR(255), -- Название файла, куда произошла выгрузка данных
	@curAccount INT, -- Пользователь, который запустил выгрузку
	@tableName VARCHAR(255), -- Название временной таблицы, в которой находятся идентификаторы выплат
	@attrName VARCHAR(255) -- Название поля временной таблицы, в которой находятся идентификаторы выплат
	)
AS
BEGIN
	DECLARE @statusPrVpOrg INT, @status INT, @sql VARCHAR(8000)
	SET @statusPrVpOrg = (SELECT TOP 1 ssp.A_ID FROM SPR_STATUS_PAYMENT ssp WHERE ssp.A_CODE = 4)
	SET @status = (SELECT TOP 1 A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE = 'act')

	/* создаем историю выплат для существовавших выплат */
	SET @sql = 'INSERT INTO PAYHISTORY
	(
		A_NUM,
		A_DATE,
		A_STATUS_PAID,
		A_PAYMENT,
		A_CONFIRMDATE,
		A_PAIDAMOUNT,
		A_NOPAY_REASON,
		A_CROWNER,
		A_CREATEDATE,
		A_STATUS,
		GUID,
		TS
	)
	SELECT '
		+ ISNULL(char(39) + @file + char(39),'NULL') + ',
		GETDATE(),'
		+ ISNULL(cast(@statusPrVpOrg AS varchar),'NULL') + ',
		wp3.A_PAYMENT,
		wp3.A_CONFIRMDATE,
		wp3.OUID,
		wp3.A_NOPAY_REASON,'
		+ ISNULL(cast(@curAccount AS varchar),'NULL') + ',
		GETDATE(),'
		+ ISNULL(cast(@status AS varchar),'NULL') + ',
		NEWID(),
		GETDATE()
	FROM ' + @tableName + '
		INNER JOIN WM_PAIDAMOUNTS wp3 ON ' + @tableName + '.' + @attrName + ' = wp3.OUID
	WHERE ' + @tableName + '.' + @attrName + ' IS NOT NULL'
	EXEC(@sql)
END
go

