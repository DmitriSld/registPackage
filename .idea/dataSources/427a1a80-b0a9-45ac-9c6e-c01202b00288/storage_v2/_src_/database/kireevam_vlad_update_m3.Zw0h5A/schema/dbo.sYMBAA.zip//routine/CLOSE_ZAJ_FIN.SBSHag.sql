CREATE PROCEDURE [dbo].[CLOSE_ZAJ_FIN] (@obj int)
AS
BEGIN
declare @statusZak int, @stateUtv int
select @statusZak=a_id from SPR_STATUS_PROCESS
where A_CODE='701'
select @stateUtv=a_id from SPR_STATUS_PROCESS
where A_CODE='100'
update FIN_ZAJ_SVOD_VL
set A_STATE=@statusZak
 from  FIN_ZAJ_SVOD_VL
left join (select distinct
 FIN_ZAJ_SVOD_VL.a_ouid
-- , WM_PAIDAMOUNTS.AMOUNT-sum(isnull(LINK_ZAJ_PAID.A_SUM, 0.00)) DIFFSUM 
, round(sum(isnull(LINK_ZAJ_PAID.A_SUM, 0.00)), 2) A_SUM_VYP
, round(sum(isnull(LINK_ZAJ_PAID.A_SUM, 0.00)), 2)
+round(sum(isnull(LINK_ZAJ_PAID.A_SUM_BANK, 0.00)), 2)
+round(sum(isnull(LINK_ZAJ_PAID.A_NDS, 0.00)), 2) A_SUM_VYP_SBOR
from FIN_ZAJ_SVOD_VL
inner join LINK_WM_PAY_CALC_FIN_ZAJ on LINK_WM_PAY_CALC_FIN_ZAJ.A_FROMID=FIN_ZAJ_SVOD_VL.A_OUID
and isnull(FIN_ZAJ_SVOD_VL.A_STATUS, 10)=10
and ISNULL(LINK_WM_PAY_CALC_FIN_ZAJ.A_STATUS, 10)=10
inner join WM_PAIDAMOUNTS on WM_PAIDAMOUNTS.A_PAYCALC=LINK_WM_PAY_CALC_FIN_ZAJ.A_TOID
and ISNULL(WM_PAIDAMOUNTS.A_STATUS, 10)=10
inner join SPR_STATUS_PAYMENT on SPR_STATUS_PAYMENT.A_ID= WM_PAIDAMOUNTS.A_STATUSPRIVELEGE
and SPR_STATUS_PAYMENT.A_CODE='10'
inner join LINK_ZAJ_PAID on LINK_ZAJ_PAID.A_VYP=WM_PAIDAMOUNTS.OUID
and ISNULL(LINK_ZAJ_PAID.a_Status, 10)=10
and LINK_ZAJ_PAID.a_fromid=LINK_WM_PAY_CALC_FIN_ZAJ.A_OUID
where isnull(FIN_ZAJ_SVOD_VL.A_STATE, 0)!=@statusZak 
and FIN_ZAJ_SVOD_VL.A_OUID=@obj
group by FIN_ZAJ_SVOD_VL.a_ouid) vyp on vyp.A_OUID=FIN_ZAJ_SVOD_VL.A_OUID
where ISNULL(FIN_ZAJ_SVOD_VL.A_SUM_NACH_SBOR, 0.00)=ISNULL(vyp.A_SUM_VYP_SBOR, 0.00)
and isnull(FIN_ZAJ_SVOD_VL.A_STATE, 0)=@stateUtv
and FIN_ZAJ_SVOD_VL.A_OUID=@obj

END
 
--   sx.datastore.db.SXDb.getStackTraceAsString:3515 
--   sx.datastore.db.SXDb.getStackTraceAsString:3493 
--   sx.datastore.db.SXDb.execute:595 
--   sx.common.replication.DoReplication.installStepSQL:2988 
--   sx.common.replication.DoReplication.installPatch:2623 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.common.replication.DoReplication.installPatchFileStep:3047 
--   sx.common.replication.DoReplication.installPatch:2612 
--   sx.common.replication.SXPatchInstallParams.installPatch:104 
--   sx.admin.actions.util.UnpackPatchPackage.installPackage:313 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:200 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1
go

