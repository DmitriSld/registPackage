CREATE VIEW _hypmv_33   AS SELECT  [dbo].[SPR_STATUS_PROCESS].[A_CODE] as _hypmv_33_col_1,  [dbo].[WM_PETITION].[A_STATUS] as _hypmv_33_col_2,  [dbo].[WM_PETITION].[A_PETITIONNUM] as _hypmv_33_col_3,  [dbo].[WM_PETITION].[OUID] as _hypmv_33_col_4,  [dbo].[WM_PETITION].[A_PERSONAL_CARD] as _hypmv_33_col_5,  [dbo].[WM_PETITION].[A_MSP] as _hypmv_33_col_6,  [dbo].[WM_PETITION].[A_PETITIONREG] as _hypmv_33_col_7 FROM  [dbo].[SPR_STATUS_PROCESS],  [dbo].[WM_PETITION]   WHERE ( [dbo].[SPR_STATUS_PROCESS].[A_ID] = [dbo].[WM_PETITION].[A_STATUSPRIVELEGE] )
go

