CREATE FUNCTION [dbo].[GET_PARENT_BANK_NAME]
(
@orgId INT,
@deep int
)
RETURNS VARCHAR(255)
AS
begin

declare @result_table TABLE
(
ouid INT,
COUNT int	
)


WITH tables(ouid ,count )
AS(
SELECT spr_org_banks.a_parent,1 FROM spr_org_banks WHERE ouid=@orgId
UNION ALL
SELECT spr_org_banks.a_parent,(tables.count+1) FROM spr_org_banks 
inner join tables ON tables.ouid=spr_org_banks.ouid
)
INSERT  INTO @result_table
SELECT ouid,count  FROM tables
OPTION (MAXRECURSION 0)

DELETE FROM @result_table WHERE ouid IS NULL



UPDATE @result_table SET [COUNT] = tmp.num
FROM (
SELECT RANK() Over (ORDER BY COUNT DESC) AS num  ,ouid AS id FROM @result_table
)tmp
WHERE tmp.id=ouid

DECLARE @str VARCHAR(2555)
SELECT @str=a_name1 from spr_org_base WHERE ouid=(SELECT ouid FROM @result_table WHERE COUNT=@deep) AND spr_org_base.A_STATUS=10

IF @str IS NULL
BEGIN
SELECT @str=a_name1 from spr_org_base WHERE ouid=@orgId	
END


  RETURN @str
END
 
--   sx.datastore.db.SXDb.execute:410 
--   sx.common.replication.DoReplication.installPatch:3136 
--   sx.common.replication.SXPatchInstallParams.installPatch:93 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:88 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:94 
--   sx.admin.AdmDispatchAction.execute:50 
--   sx.admin.AdmServletUtil.processAction:140 
--   sx.admin.AdmServlet.doGet:79 
--   sx.admin.AdmServlet.doPost:160 
--   javax.servlet.http.HttpServlet.service:710
go

