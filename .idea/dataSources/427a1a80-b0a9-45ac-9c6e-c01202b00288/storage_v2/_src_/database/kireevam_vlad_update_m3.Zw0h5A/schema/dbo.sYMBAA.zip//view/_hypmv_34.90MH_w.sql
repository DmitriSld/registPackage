CREATE VIEW _hypmv_34   AS SELECT  [dbo].[WM_PETITION].[A_PETITIONNUM] as _hypmv_34_col_1,  [dbo].[WM_PETITION].[OUID] as _hypmv_34_col_2,  [dbo].[WM_PETITION].[A_PERSONAL_CARD] as _hypmv_34_col_3,  [dbo].[WM_PETITION].[A_MSP] as _hypmv_34_col_4,  [dbo].[WM_PETITION].[A_PETITIONREG] as _hypmv_34_col_5 FROM  [dbo].[SPR_STATUS_PROCESS],  [dbo].[WM_PETITION]   WHERE ( [dbo].[SPR_STATUS_PROCESS].[A_ID] = [dbo].[WM_PETITION].[A_STATUSPRIVELEGE] ) AND ( [dbo].[SPR_STATUS_PROCESS].[A_CODE] = 8 ) AND (( [dbo].[WM_PETITION].[A_STATUS] = NULL ) OR ( [dbo].[WM_PETITION].[A_STATUS] = 10 ))
go

