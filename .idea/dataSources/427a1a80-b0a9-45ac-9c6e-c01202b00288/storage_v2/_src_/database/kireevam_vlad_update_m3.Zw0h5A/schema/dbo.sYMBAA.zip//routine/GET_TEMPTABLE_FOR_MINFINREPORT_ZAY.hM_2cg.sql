CREATE FUNCTION [dbo].[GET_TEMPTABLE_FOR_MINFINREPORT_ZAY](@year int,@month int,@type int)
RETURNS @tmpTableMinFinReportZay TABLE 
(

amount NUMERIC(10,2),
dost NUMERIC(10,2)

)
AS
  BEGIN
	
/**
* Дата начала и конца
**/
DECLARE @StartDate DATETIME,@EndDate DATETIME
SET @StartDate= CONVERT(DATETIME,'01.' + CAST(@month AS VARCHAR) + '.' + CAST(@year AS varchar),104)
SET @EndDate= DATEADD(DAY,-1,DATEADD(MONTH,1,@StartDate))

DECLARE @statusUtv INT,@pered INT,@sform int
--Передано в выплатную организацию
SELECT @pered =a_id FROM SPR_STATUS_PAYMENT WHERE a_code=4
--Выплата сформирована
SELECT @sform=a_id FROM spr_Status_Process WHERE a_code=11
--Утверждено
SELECT @statusUtv=a_id FROM spr_Status_Process WHERE a_code=100

--Действующие Объекты
DECLARE @actPc int ,@actObject int ,@actDoc int
	--Действующие ЛД
	SELECT @actPc=ouid FROM SPR_PC_STATUS WHERE a_code=1
	--Действующие Объект
	SELECT @actObject=A_ID FROM ESRN_SERV_STATUS WHERE A_STATUSCODE='act'
  
INSERT INTO @tmpTableMinFinReportZay (amount,dost)
SELECT 
ISNULL(sum(iSNULL(WM_PAY_CALC.amount,0)),0) AS amount,
ISNULL(sum(iSNULL(dbo.GET_FINANCE_VALUE(wm_payment.DELIVERYWAY,wm_payment.A_DELIVERY_TYPES,PPR_SERV.a_id,wm_payment.A_PAYMENTORG,WM_PAY_CALC.amount,wm_address.A_TOWN,WM_PAIDAMOUNTS.PAIDDATE),0)),0) AS dostSum--стоимость доставки
FROM WM_PAY_CALC 
INNER JOIN WM_PAIDAMOUNTS ON WM_PAIDAMOUNTS.A_PAYCALC=WM_PAY_CALC.OUID
INNER JOIN esrn_serv_serv ON WM_PAY_CALC.A_MSP=esrn_serv_serv.OUID
INNER JOIN SPR_NPD_MSP_CAT ON SPR_NPD_MSP_CAT.A_ID=esrn_serv_serv.A_SERV
INNER JOIN PPR_SERV ON PPR_SERV.A_ID=SPR_NPD_MSP_CAT.A_MSP
INNER JOIN WM_PERSONAL_CARD ON WM_PERSONAL_CARD.OUID=WM_PAY_CALC.PERSONOUID
LEFT JOIN WM_ADDRESS ON WM_ADDRESS.OUID=WM_PERSONAL_CARD.A_REGFLAT
--Реквизиты
LEFT JOIN wm_payment 
ON wm_payment.ouid=WM_PAIDAMOUNTS.a_payment
WHERE WM_PAY_CALC.PAIDDATE BETWEEN @StartDate AND @EndDate
AND WM_PAY_CALC.A_STATUSPRIVELEGE=@sform--@pered
AND WM_PAIDAMOUNTS.A_STATUSPRIVELEGE=@pered--@sform
AND esrn_serv_serv.A_STATUSPRIVELEGE=@statusUtv
AND (WM_ADDRESS.A_STATUS=@actObject OR WM_ADDRESS.A_STATUS IS NULL)
AND (WM_PAY_CALC.A_STATUS=@actObject OR WM_PAY_CALC.A_STATUS IS NULL)
AND (esrn_serv_serv.A_STATUS=@actObject OR esrn_serv_serv.A_STATUS IS NULL)
AND (SPR_NPD_MSP_CAT.A_STATUS=@actObject OR SPR_NPD_MSP_CAT.A_STATUS IS NULL)
AND (PPR_SERV.A_STATUS=@actObject OR PPR_SERV.A_STATUS IS NULL)
AND (WM_PERSONAL_CARD.A_STATUS=@actObject OR WM_PERSONAL_CARD.A_STATUS IS NULL)
AND WM_PERSONAL_CARD.A_PCSTATUS=@actPc
AND SPR_NPD_MSP_CAT.A_ID IN (SELECT LINK_REPORT_ZAY_MSP_MINFIN.a_toid
FROM SETTING_MINFIN_REPORT_ZAY
INNER JOIN LINK_REPORT_ZAY_MSP_MINFIN ON LINK_REPORT_ZAY_MSP_MINFIN.A_FROMID=SETTING_MINFIN_REPORT_ZAY.OUID
WHERE SETTING_MINFIN_REPORT_ZAY.A_TYPE=@type
)

      
   RETURN
END
 
--   sx.datastore.db.SXDb.execute:-1 
--   sx.common.replication.DoReplication.installPatch:-1 
--   sx.common.replication.SXPatchInstallParams.installPatch:-1 
--   sx.admin.actions.util.UnpackPatchPackage.proccedFileCmd:-1 
--   sun.reflect.NativeMethodAccessorImpl.invoke0:-2 
--   sun.reflect.NativeMethodAccessorImpl.invoke:-1 
--   sun.reflect.DelegatingMethodAccessorImpl.invoke:-1 
--   java.lang.reflect.Method.invoke:-1 
--   sx.admin.AdmDispatchAction.dispatchMethod:-1 
--   sx.admin.AdmDispatchAction.execute:-1 
--   sx.admin.AdmServletUtil.processAction:-1 
--   sx.admin.AdmServlet.doGet:-1 
--   sx.admin.AdmServlet.doPost:-1 
--   javax.servlet.http.HttpServlet.service:710
go

